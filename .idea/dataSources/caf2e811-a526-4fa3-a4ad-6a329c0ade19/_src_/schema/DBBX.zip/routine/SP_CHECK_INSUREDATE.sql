CREATE PROCEDURE      "SP_CHECK_INSUREDATE" (PIN_AJID IN varCHAR2,Pin_userid IN varCHAR2 ,PReturnCode OUT varchar2,
                              PReturnMsg    OUT varchar2) AS
                              v_no number:=0; --????
                              v_error_flag number:=0; --???????
                              v_ajxgdm varchar2(512):='';
                              v_sfywyl varchar2(2):='';
 begin
    PReturnCode:='E';
    PReturnMsg:='Error!';
    --????????????? ??????????????
    v_error_flag:=0;
    for rec in(select * from tb_zpaxx where ajid=to_number(trim(PIN_AJID)) and nvl(ZPAJL,'01')!='02' and fpid is not null and ((PFZRDM not like 'PCA%' and PFZRDM not like 'AIOP%'  and PFZRDM not like 'ADD%') or PFZRDM like 'MAT%'))  loop
         v_no:=-1;
         select sfywyl into v_sfywyl from tb_lpfpxx where fpid=rec.fpid;
         if  v_sfywyl='0' then
             select count(1) into v_no from tb_fdxx a,tb_fdzrmx b,tb_lpajxx c where a.fdid=b.fdid and a.fdid=c.fdid and c.ajid=to_number(trim(PIN_AJID))
                       and b.zrid=rec.zrid and exists(select 'x' from tb_lpfpxx where  fpid=rec.fpid and sfywyl='0' and nvl(ryrq,jzrq)>=nvl(b.ZRKSRQ,a.FDSXR) and nvl(ryrq,jzrq)<=nvl(b.ZRJSRQ,a.FDZZR));
             if v_no<1 then
                update tb_zpaxx set XGDM=case when xgdm is null then 'CL14' else substr(xgdm||',CL14',1,100) end where zpaid=rec.zpaid;
                v_error_flag:=1;
             end if;
          end if;
          --????????????????????????????
         if  v_sfywyl='1' then
             select count(1) into v_no from tb_fdxx a,tb_fdzrmx b,tb_lpajxx c where a.fdid=b.fdid and a.fdid=c.fdid and c.ajid=to_number(trim(PIN_AJID))
                     and b.zrid=rec.zrid and exists(select 'x' from tb_lpfpxx where  fpid=rec.fpid and sfywyl='1' and c.BBRYWSGFSRQ>=nvl(b.ZRKSRQ,a.FDSXR) and c.BBRYWSGFSRQ<=nvl(b.ZRJSRQ,a.FDZZR));
           if v_no<1 then
              update tb_zpaxx set XGDM=case when xgdm is null then 'CL15' else substr(xgdm||',CL15',1,100) end where zpaid=rec.zpaid;
              v_error_flag:=1;
           end if;
         end if;
    end loop;
    if v_error_flag =1 then
        v_ajxgdm:='CL14';
     end if;
   v_error_flag:=0;
    --?????????????? nvl(c.BBRYWSGFSRQ,nvl(ryrq,jzrq))
      for rec in(select * from tb_zpaxx where ajid=to_number(trim(PIN_AJID))  and nvl(ZPAJL,'01')!='02' and exists(select 'x' from tb_lpajxx where ajid=to_number(trim(PIN_AJID)) and BBRYWSGFSRQ is not null)
         and (PFZRDM  like 'PCA%' or PFZRDM  like 'AIOP%'  or PFZRDM  like 'ADD%' or pfzrdm like 'TERM%')
        ) loop
         v_no:=-1;
          select count(1) into v_no from tb_fdxx a,tb_fdzrmx b,tb_lpajxx c where a.fdid=b.fdid and a.fdid=c.fdid and c.ajid=to_number(trim(PIN_AJID))
                   and b.zrid=rec.zrid and c.BBRYWSGFSRQ>=nvl(b.ZRKSRQ,a.FDSXR) and c.BBRYWSGFSRQ<=nvl(b.ZRJSRQ,a.FDZZR);
         if  v_no<1 then
           update tb_zpaxx a set XGDM=case when xgdm is null then 'CL15' else substr(xgdm||',CL15',1,100) end where zpaid=rec.zpaid and not exists(
            select 'x' from tb_zpaxx b where zpaid=a.zpaid and xgdm like '%CL15%') ;
           v_error_flag:=1;

         end if;
    end loop;
     if v_error_flag =1 then
        select case when v_ajxgdm is null then 'CL15' else v_ajxgdm||',CL15' end into v_ajxgdm from dual;
     end if;
     v_error_flag:=0;

    --???????????(??????????????TERM????????????)
      for rec in(select * from tb_zpaxx where ajid=to_number(trim(PIN_AJID)) and nvl(ZPAJL,'01')!='02' and exists(select 'x' from tb_lpajxx where ajid=to_number(trim(PIN_AJID)) and BBRSWRQ is not null)
         and (pfzrdm like 'TERM%')
        ) loop
         v_no:=-1;
          select count(1) into v_no from tb_fdxx a,tb_fdzrmx b,tb_lpajxx c where a.fdid=b.fdid and a.fdid=c.fdid and c.ajid=to_number(trim(PIN_AJID))
                   and b.zrid=rec.zrid and c.BBRSWRQ>=nvl(b.ZRKSRQ,a.FDSXR) and c.BBRSWRQ<=nvl(b.ZRJSRQ,a.FDZZR);
         if  v_no<1 then
           update tb_zpaxx a set XGDM=case when xgdm is null then 'CL16' else substr(xgdm||',CL16',1,100) end where zpaid=rec.zpaid
           and not exists(
            select 'x' from tb_zpaxx b where zpaid=a.zpaid and xgdm like '%CL16%');
           v_error_flag:=1;
         end if;
    end loop;
     if v_error_flag =1 then
        select case when v_ajxgdm is null then 'CL16' else v_ajxgdm||',CL16' end into v_ajxgdm from dual;
     end if;
     v_error_flag:=0;

    --????????????
     --???????????
      for rec in(select * from tb_zpaxx where ajid=to_number(trim(PIN_AJID)) and nvl(ZPAJL,'01')!='02' and exists(select 'x' from tb_lpajxx where ajid=to_number(trim(PIN_AJID)) and ZJQZR is not null)
         and (PFZRDM  like 'CI%')
        ) loop
         v_no:=-1;
          select count(1) into v_no from tb_fdxx a,tb_fdzrmx b,tb_lpajxx c where a.fdid=b.fdid and a.fdid=c.fdid and c.ajid=to_number(trim(PIN_AJID))
                   and b.zrid=rec.zrid and c.ZJQZR>=nvl(b.ZRKSRQ,a.FDSXR) and c.ZJQZR<=nvl(b.ZRJSRQ,a.FDZZR);
         if  v_no<1 then
           update tb_zpaxx a set XGDM=case when xgdm is null then 'CL17' else substr(xgdm||',CL17',1,100) end where zpaid=rec.zpaid
           and not exists(
            select 'x' from tb_zpaxx b where zpaid=a.zpaid and xgdm like '%CL17%');
           v_error_flag:=1;
         end if;
    end loop;
     if v_error_flag =1 then
        select case when v_ajxgdm is null then 'CL17' else v_ajxgdm||',CL17' end into v_ajxgdm from dual;
     end if;
     v_error_flag:=0;
   -- CL18  ??????   ??
  --  CL19  ??????
  --  CL20  ????????
  --  CL21  ??????180????
     for rec in(select * from tb_zpaxx where ajid=to_number(trim(PIN_AJID)) and nvl(ZPAJL,'01')!='02') loop
        --???????,??????????
         if rec.pfzrdm like 'MAT%' or rec.pfzrdm like 'AIOP%'  or rec.PFZRDM like 'PP%' or rec.PFZRDM like 'FM%'  or rec.pfzrdm like 'OP%' or rec.pfzrdm like 'IP%'  or rec.PFZRDM like 'HI%' or rec.pfzrdm like 'OIP%'  or rec.pfzrdm like 'PE%' or rec.pfzrdm like 'DE%' then
                select count(1) into v_no    from   tb_lpajxx a,tb_fdzrmx b,tb_zrxx c,tb_lpfpxx d ,tb_fdxx f
               where a.ajid=rec.ajid and a.fdid=b.fdid and a.fdid=f.fdid and b.zrid=c.zrid  and c.zrid=rec.zrid
                and nvl(d.SFYWYL,'0')!='1'
                and  d.fpid(+)=rec.fpid and nvl(ryrq,jzrq)>=nvl(b.ZRKSRQ,f.FDSXR)  and c.ddq>0 and f.fdid=b.fdid
                   and nvl(ryrq,jzrq)<=to_number(to_char( to_date(nvl(b.ZRKSRQ,f.FDSXR),'yyyy-mm-dd')+nvl(c.ddq,1),'yyyymmdd'));

             if  v_no>0 then
               update tb_zpaxx a set XGDM=case when xgdm is null then 'CL18' else substr(xgdm||',CL18',1,100) end where zpaid=rec.zpaid
               and not exists(
               select 'x' from tb_zpaxx b where zpaid=a.zpaid and xgdm like '%CL18%');
               v_error_flag:=1;
            end if;
        end if;
        --??????????
         if   rec.pfzrdm like 'TERM%' then
                select count(1) into v_no    from   tb_lpajxx a,tb_fdzrmx b,tb_zrxx c,tb_fdxx f
               where a.ajid=rec.ajid and a.fdid=f.fdid and b.zrid=c.zrid  and c.zrid=rec.zrid  and f.fdid=b.fdid
                and a.BBRSWRQ>=nvl(b.ZRKSRQ,f.FDSXR) and a.BBRYWSGFSRQ is null --????????????
               /* and (( rec.PFZRDM like 'HI%' and c.zpasjlx in('01','03') and c.zrlx='03')
                  or (rec.PFZRDM not like 'HI%' and c.zpasjlx in('01','03'))) */
                   and c.ddq>0
                   and nvl(a.BBRSWRQ,a.BBRYWSGFSRQ)<=to_number(to_char( to_date(nvl(b.ZRKSRQ,f.FDSXR),'yyyy-mm-dd')+nvl(c.ddq,1),'yyyymmdd'));

             if  v_no>0 then
               update tb_zpaxx a set XGDM=case when xgdm is null then 'CL19' else substr(xgdm||',CL19',1,100) end where zpaid=rec.zpaid
               and not exists(
            select 'x' from tb_zpaxx b where zpaid=a.zpaid and xgdm like '%CL19%');
               v_error_flag:=2;
            end if;
         end if;
         --???? ????????
         if  rec.PFZRDM  like 'CI%'   then
                select count(1) into v_no    from   tb_lpajxx a,tb_fdzrmx b,tb_zrxx c,tb_fdxx f
               where a.ajid=rec.ajid and a.fdid=f.fdid and b.zrid=c.zrid  and c.zrid=rec.zrid  and f.fdid=b.fdid
                and a.ZJQZR>=nvl(b.ZRKSRQ,f.FDSXR)
                and ( rec.PFZRDM like 'CI%') and c.ddq>0
                and a.ZJQZR<=to_number(to_char( to_date(nvl(b.ZRKSRQ,f.FDSXR),'yyyy-mm-dd')+nvl(c.ddq,1),'yyyymmdd'));

             if  v_no>0 then
               update tb_zpaxx a set XGDM=case when xgdm is null then 'CL20' else substr(xgdm||',CL20',1,100) end where zpaid=rec.zpaid
               and not exists(
                select 'x' from tb_zpaxx b where zpaid=a.zpaid and xgdm like '%CL20%');
               v_error_flag:=3;
            end if;
         end if;
             --CL21  ??????180????
         if  rec.PFZRDM  like 'AIOP%' or rec.PFZRDM  like 'IOP%' or rec.PFZRDM  like 'OP%'  or rec.PFZRDM  like 'IP%' or rec.PFZRDM like 'HI%' or rec.pfzrdm like 'PE%' or rec.pfzrdm like 'DE%' then
                select count(1) into v_no    from   tb_lpajxx a,tb_fdzrmx b,tb_zrxx c,tb_fdxx f
               where a.ajid=rec.ajid and a.fdid=f.fdid and b.zrid=c.zrid  and c.zrid=rec.zrid  and f.fdid=b.fdid
                 and exists(select 'x' from tb_lpfpxx where fpid=rec.fpid and sfywyl='1')
                 and a.BBRYWSGFSRQ is not null and to_date(a.BBRYWSGFSRQ,'yyyy-mm-dd')<to_date((select nvl(cyrq,jzrq) as rq  from tb_lpfpxx where fpid=rec.fpid),'yyyy-mm-dd')-180 ;
               -- and a.ZJQZR>=nvl(b.ZRKSRQ,f.FDSXR)
               /* and  (( rec.PFZRDM like 'HI%' and c.zpasjlx in('02','03') and c.zrlx in('01','02','03','07'))
                  or (rec.PFZRDM not like 'HI%' and c.zpasjlx in('02','03')))
                and to_date(a.BBRYWSGFSRQ,'yyyy-mm-dd')<trunc(sysdate)-180   ;*/


             if  v_no>0 then
               update tb_zpaxx a set XGDM=case when xgdm is null then 'CL21' else substr(xgdm||',CL21',1,100) end where zpaid=rec.zpaid
               and not exists(
            select 'x' from tb_zpaxx b where zpaid=a.zpaid and xgdm like '%CL21%');
               v_error_flag:=4;
            end if;
            /* ????????????????
            if rec.PFZRDM like 'HI%'  then  --????????????????180?
                 select nvl(sum(nvl(sjgfts,0)),0) into v_no from tb_zpaxx a   where a.PFZRDM like 'HI%' and nvl(zpajl,'01')!='02' and exists(
                   select 'x' from tb_fdxx b where b.fdid=a.fdid and (b.bbrkhid,b.khbdh) in (select bbrkhid,khbdh from tb_lpajxx h where h.ajid=to_number(trim(PIN_AJID)))
                   );
                   if v_no>180 then
                       update tb_zpaxx a set XGDM=case when xgdm is null then 'CL21' else substr(xgdm||',CL21',1,100) end where zpaid=rec.zpaid
                       and  not xgdm like '%CL21%';
                   end if;
            end if;
            */
         end if;
     end loop;
     if v_error_flag!=0 then
         select case when v_ajxgdm is null then decode(v_error_flag,1,'CL18',2,'CL19',3,'CL20',4,'CL21','CL18') else v_ajxgdm||','||decode(v_error_flag,1,'CL18',2,'CL19',3,'CL20',4,'CL21','CL18') end into v_ajxgdm from dual;
     end if;
     if    v_ajxgdm is not null and length(v_ajxgdm)>0 and trim(Pin_userid) is null then
          update tb_lpajxx a set ajzt='04' ,AJXGDM=substr(AJXGDM||v_ajxgdm,1,80) where ajid=to_number(trim(PIN_AJID))
          and not exists(
            select 'x' from tb_lpajxx b where ajid=a.ajid and ajxgdm like '%'||v_ajxgdm||'%');
     end if;
     if trim(Pin_userid) is not null and v_ajxgdm is not null then--???????????????????????
           PReturnCode:='-4';--????
           PReturnMsg:=v_ajxgdm;
           return;
     end if;
    PReturnCode:='0';--????
    PReturnMsg:='check success!';
    return;
  EXCEPTION
  WHEN OTHERS THEN
    PReturnCode := 'E';
    DBMS_OUTPUT.PUT_LINE('[yhs debug] ' || 'PReturncode= ' ||
                         PReturnCode);
    PReturnMsg := 'Error:' || sqlerrm;
    DBMS_OUTPUT.PUT_LINE(PReturnMsg);
end SP_CHECK_INSUREDATE;

/
