CREATE PROCEDURE      "SP_P1_30015" (report_id   In t_report_def_info.REPORTID%TYPE,
                                        pStartdate  IN varchar2, -- ??????yyyymmdd
                                        pEnddate    IN varchar2, -- ??????yyyymmdd
                                        pStatman    IN t_report_gen_info.STATMAN%TYPE, --???
                                        ptype       in varchar2, /*0 ???? ,1 ?? 2 ?? 3 ?? */ --?????
                                        POther1     IN varchar2, --??id
                                        POther2     IN varchar2, --??id
                                        POther3     IN varchar2, --??id
                                        POther4     IN varchar2, --??ID
                                        POther5     IN varchar2, --????
                                        POther6     IN varchar2, --??ID
                                        POther7     IN varchar2, --????????
                                        POther8     IN varchar2, --????????
                                        PReturnCode OUT varchar2,
                                        PReturnMsg  OUT varchar2) AS
  V_STEP_CODE  CHAR(5); --?????????????????
  vreportid    t_report_def_info.REPORTID%TYPE; --??ID
  v_start_date number := 0; --????????
  v_end_date   number := 0; --????????
  vxzqhdm      t_report_gen_info.STATORGID%TYPE; --????????????

  vstatid varchar(30); --?????????????????
  type cellType is record(
    statid  varchar2(15),
    col     number,
    r       number,
    content varchar2(1024));

  cell      cellType; --?????????????
  vdwmc     varchar2(50); --????????????
  vusername t_report_gen_info.STATMAN%TYPE; --????????
  vnd       t_report_gen_info.STATYEAR%TYPE; --????
  rowno     number := 0; --??????

  v_bf     number := 0; --??
  v_sjpfje number := 0; --?????
  v_trpfje number := 0; --??????
  v_xypfje number := 0; --??????
  v_zpfje  number := 0; --?????
  v_ylpfl  varchar2(10); --?????
  v_trpfl  varchar2(10); --?????
  v_xypfl  varchar2(10); --?????
  v_zpfl   varchar2(10); --????

begin
  V_STEP_CODE := '00000';
  PReturnMsg  := 'OK';
  PReturnCode := 'E';
  vreportid   := substr(report_id, 1, 5);
  vusername   := pStatman;
  vnd         := substr(pStartdate, 1, 4);

  v_start_date := to_number(substr(pStartdate, 1, 8));
 /* v_end_date   := to_number(substr(pEnddate, 1, 8));*/

  --???????????????????????????
  delete from t_report_data_info
   where statid in
         (select statid from T_REPORT_GEN_INFO where reportid = report_id);

  delete from T_REPORT_GEN_INFO
   where statid in
         (select statid from T_REPORT_GEN_INFO where reportid = report_id);

  V_STEP_CODE := '00001';
  --???,?T_RERORT_GEN_INFO?????????????
  --???????
  select seq_statid.nextval into vstatid from dual;

  -- ??????????
  insert into t_report_gen_info
    (STATID,
     REPORTID,
     STATORGID,
     STATORGNAME,
     STATDATE,
     STATMAN,
     STATYEAR,
     BEGINDATE,
     ENDDATE,
     STAT_OTHER,
     STAT_TYPE)
  values
    (vstatid,
     vreportid,
     '',
     '',
     to_char(sysdate, 'yyyymmdd'),
     vusername,
     vnd,
     v_start_date,
     v_end_date,
     substr(pEnddate, 1, 1),
     trim(ptype));


     v_end_date   := to_number(substr(nvl(pEnddate,to_char(sysdate,'yyyymmdd')), 1, 8));

  /* --?????? ??excel???0?????1??,????0???*/

  --???
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,1,1,'CLFX02');

  --????
  insert into t_report_data_info
    (statid, sheet, col, r, content)
  values
    (vstatid, 0, 1, 2, to_char(sysdate, 'yyyymmdd'));

  --????
  select max(bxgsqc)
    into cell.content
    from tb_bxgsxx
   where bxgsid = trim(POther1);
  if cell.content is not null then
    insert into t_report_data_info
      (statid, sheet, col, r, content)
    values
      (vstatid, 0, 1, 4, cell.content);
  end if;

  --????
  select max(ttmc)
    into cell.content
    from tb_ttxx
   where ttid = trim(POther2);
  if cell.content is not null then
    insert into t_report_data_info
      (statid, sheet, col, r, content)
    values
      (vstatid, 0, 1, 5, cell.content);
  end if;

  --????
  select max(khbdh)
    into cell.content
    from tb_bdxx
   where bdid = trim(POther3);
  if cell.content is not null then
    insert into t_report_data_info
      (statid, sheet, col, r, content)
    values
      (vstatid, 0, 1,6, cell.content);
  end if;

  --????????
  insert into t_report_data_info
    (statid, sheet, col, r, content)
  values
    (vstatid, 0, 1, 7, trim(pStartdate) || '-' || trim(pEnddate));

  --????????
  insert into t_report_data_info
    (statid, sheet, col, r, content)
  values
    (vstatid, 0, 1,8, trim(POther7) || '-' || trim(POther8));

  cell.statid := vstatid;
  cell.col    := 0; --?1???
  cell.r      := 11; --?14???
  --???????????????????????????????excel????????????????????

  for rec_gxgs in ( --????
                   select a.bxgsid
                     from tb_bxgsxx a,
                                         tb_ttxx b,
                                         tb_bdxx c,
                                         tb_zrxx g,
                                         TB_CPZRDZB h,
                                         TB_CPXX i,
                                         tb_fdxx j,
                                         tb_fdzrmx k,
                                         tb_lpajxx e,
                                         tb_zpaxx f
                                         --tb_zrxx g
                                   where
                                      f.ajid = e.ajid
                                     and g.zrid = f.zrid
                                     and g.zrid = h.zrid
                                     and h.cpid = i.cpid
                                     and e.khbdh = c.khbdh
                                     and a.bxgsid = c.bxgsid
                                     and b.ttid = c.ttid
                                     and k.fdid = j.fdid
                                     and k.zrid = h.zrid
                                     and g.zrid = h.zrid
                                     and h.cpid = i.cpid
                                     and j.khbdh = c.khbdh

                      --and j.Fdzbf != 0
                      and a.bxgsid = nvl(trim(POther1), a.bxgsid)
                      and b.ttid = nvl(trim(POther2), b.ttid)
                      and c.bdid = nvl(trim(POther3), c.bdid)
                       and c.bdsxrq >=nvl(trim(pStartdate), 19000101)
                        and c.bdzzrq >= nvl(trim(pEnddate), c.bdzzrq)
                      and c.bdsxrq <=nvl(trim(pEnddate), 99991231)
                      and e.ajzt in(08,09,10)
                      /*and e.jarq <= nvl(trim(POther8), 99991231)*/
                    group by a.bxgsid
                    order by a.bxgsid) loop

    for rec_tt in ( --??
                   select b.ttid
                   from  tb_bxgsxx a,
                                         tb_ttxx b,
                                         tb_bdxx c,
                                         tb_zrxx g,
                                         TB_CPZRDZB h,
                                         TB_CPXX i,
                                         tb_fdxx j,
                                         tb_fdzrmx k,
                                         tb_lpajxx e,
                                         tb_zpaxx f
                                   where f.ajid = e.ajid
                                     and g.zrid = f.zrid
                                     and g.zrid = h.zrid
                                     and h.cpid = i.cpid
                                     and e.khbdh = c.khbdh
                                     and a.bxgsid = c.bxgsid
                                     and b.ttid = c.ttid
                                     and k.fdid = j.fdid
                                     and k.zrid = h.zrid
                                     and g.zrid = h.zrid
                                     and h.cpid = i.cpid
                                     and j.khbdh = c.khbdh
                                     and a.bxgsid = rec_gxgs.bxgsid

                      and b.ttid = nvl(trim(POther2), b.ttid)
                      and c.bdid = nvl(trim(POther3), c.bdid)
                       and c.bdsxrq >=nvl(trim(pStartdate), 19000101)
                       and c.bdzzrq >= nvl(trim(pEnddate), c.bdzzrq)
                       and c.bdsxrq <=nvl(trim(pEnddate), 99991231)
                       and e.ajzt in(08,09,10)
                      /*and e.jarq >= nvl(trim(POther7), 19000101)
                      and e.jarq >= nvl(trim(POther8), 19000101)*/
                    group by b.ttid
                    order by b.ttid) loop
      for rec_bd in ( --??
                     select c.bdid
                       from tb_bxgsxx a,
                                         tb_ttxx b,
                                         tb_bdxx c,
                                         tb_zrxx g,
                                         TB_CPZRDZB h,
                                         TB_CPXX i,
                                         tb_fdxx j,
                                         tb_fdzrmx k,
                                         tb_lpajxx e,
                                         tb_zpaxx f
                                   where f.ajid = e.ajid
                                     and g.zrid = f.zrid
                                     and g.zrid = h.zrid
                                     and h.cpid = i.cpid
                                     and e.khbdh = c.khbdh
                                     and a.bxgsid = c.bxgsid
                                     and b.ttid = c.ttid
                                     and k.fdid = j.fdid
                                     and k.zrid = h.zrid
                                     and g.zrid = h.zrid
                                     and h.cpid = i.cpid
                                     and j.khbdh = c.khbdh
                                     and a.bxgsid = rec_gxgs.bxgsid
                                     and b.ttid = rec_tt.ttid
                        and c.bdid = nvl(trim(POther3), c.bdid)
                        and c.bdsxrq >=nvl(trim(pStartdate), 19000101)
                        and c.bdzzrq >= nvl(trim(pEnddate), c.bdzzrq)
                        and c.bdsxrq <=nvl(trim(pEnddate), 99991231)
                        and e.ajzt in(08,09,10)
                        /*and e.jarq >= nvl(trim(POther7), 19000101)
                        and e.jarq <= nvl(trim(POther8), 99991231)*/
                      group by c.bdid
                      order by c.bdid) loop
        for rec_data in (
                         --????=???/365?*???????????-?????or??????
                        select x.*,y.Sjpfje,y.trpfje,y.xypfje,zpfje FROM  (
select                       a.bxgsbh,
                                         a.bxgsqc,
                                         b.ttbh,
                                         b.ttmc,
                                         c.khbdh,
                                         -- e.Jarq,to_char(sum (nvl(f.sjpfje,0)),'999999990.99')
                                         c.bdsxrq || '-' || c.bdzzrq as bdqj,
                                         i.cpmc,sum(nvl(k.zrbf,0)) as bf
                                    from tb_bxgsxx a,
                                         tb_ttxx b,
                                         tb_bdxx c,
                                         tb_zrxx g,
                                         TB_CPZRDZB h,
                                         TB_CPXX i,
                                         tb_fdxx j,
                                         tb_fdzrmx k
                                   where a.bxgsid = c.bxgsid
                                     and b.ttid = c.ttid
                                     and k.fdid = j.fdid
                                     and k.zrid = h.zrid
                                     and g.zrid = h.zrid
                                     and h.cpid = i.cpid
                                     and j.khbdh = c.khbdh
                                     and a.bxgsid = rec_gxgs.bxgsid
                                     and b.ttid = rec_tt.ttid
                                     and c.bdid = rec_bd.bdid
                                     and nvl(k.ZRJSRQ,j.fdzzr)>=nvl(pStartdate,19000101)
                                   and nvl(k.ZRkSRQ,j.fdsxr)<=nvl(pEnddate,99991231)
                                   group by a.bxgsbh,
                                            a.bxgsqc,
                                            b.ttbh,
                                            b.ttmc,
                                            c.khbdh,
                                            c.bdsxrq || '-' || c.bdzzrq,
                                            i.cpmc,
                                            j.fdsxr
) X, (  select              c.khbdh||i.cpmc as key2  ,
                                         sum(nvl(decode(f.zpajl,
                                                                '01',
                                                                Sjpfje,'03',Sjpfje),
                                                         0))
                                                  Sjpfje, --?????
                                         sum(nvl(decode(f.zpajl,
                                                                '04',
                                                                Sjpfje),
                                                         0))
                                                  as trpfje, --??????
                                         sum(nvl(decode(f.zpajl,
                                                                '05',
                                                                Sjpfje),
                                                         0))
                                                  as xypfje, --??????
                                         sum(nvl(case
                                                           when f.zpajl != '02' then
                                                            f.Sjpfje
                                                         end,
                                                         0))
                                                  as zpfje --?????
                                                  ,count(1) as zpas
                                    from
                                         tb_bdxx c,
                                         tb_lpajxx e,
                                         tb_zpaxx f,
                                         tb_zrxx g,
                                         TB_CPZRDZB h,
                                         TB_CPXX i
                                   where  f.ajid = e.ajid
                                     and g.zrid = f.zrid
                                     and g.zrid = h.zrid
                                     and h.cpid = i.cpid
                                     and e.khbdh = c.khbdh
                                     and c.bdid = rec_bd.bdid
                                   and e.jarq >= nvl(trim(POther7), 19000101)
                                   and e.jarq <= nvl(trim(POther8), 99991231)
                                   and e.ajzt in(08,09,10)
                                   group by    c.khbdh||i.cpmc ) Y
                                   where x.khbdh||X.CPMC = Y.key2(+)
                                   order by x.bxgsbh, x.ttbh, x.khbdh, x.cpmc) loop
          --????

          --??????
          insert into t_report_data_info
            (statid, sheet, col, r, content)
          values
            (cell.statid, 0, 0, cell.r, rec_data.bxgsbh);
          --??????
          insert into t_report_data_info
            (statid, sheet, col, r, content)
          values
            (cell.statid, 0, 1, cell.r, rec_data.bxgsqc);
          --?????
          select max(e.zttbh)
            into cell.content
            from tb_zttxx e, tb_bdxx d
           where e.zttid = d.zttid
             and d.bdid = rec_bd.bdid;
          if cell.content is not null then
            insert into t_report_data_info
              (statid, sheet, col, r, content)
            values
              (cell.statid, 0, 2, cell.r, cell.content);
          else
            insert into t_report_data_info
              (statid, sheet, col, r, content)
            values
              (cell.statid, 0, 2, cell.r, rec_data.ttbh);
          end if;
          --??????
          select max(e.zttmc)
            into cell.content
            from tb_zttxx e, tb_bdxx d
           where e.zttid = d.zttid
             and d.bdid = rec_bd.bdid;
          if cell.content is not null then
            insert into t_report_data_info
              (statid, sheet, col, r, content)
            values
              (cell.statid, 0, 3, cell.r, cell.content);
          else
            insert into t_report_data_info
              (statid, sheet, col, r, content)
            values
              (cell.statid, 0, 3, cell.r, rec_data.ttmc);
          end if;
          --???
          insert into t_report_data_info
            (statid, sheet, col, r, content)
          values
            (cell.statid, 0, 4, cell.r, rec_data.khbdh);
          --????
          insert into t_report_data_info
            (statid, sheet, col, r, content)
          values
            (cell.statid, 0, 5, cell.r, rec_data.bdqj);
          --??
          insert into t_report_data_info
            (statid, sheet, col, r, content)
          values
            (cell.statid, 0, 6, cell.r, rec_data.cpmc);
          --?????
          insert into t_report_data_info
            (statid, sheet, col, r, content)
          values
            (cell.statid, 0, 7, cell.r, rec_data.bf);
          --?????
          insert into t_report_data_info
            (statid, sheet, col, r, content)
          values
            (cell.statid, 0, 8, cell.r, rec_data.Sjpfje);
          --??????
          insert into t_report_data_info
            (statid, sheet, col, r, content)
          values
            (cell.statid, 0, 9, cell.r, rec_data.trpfje);
          --??????
          insert into t_report_data_info
            (statid, sheet, col, r, content)
          values
            (cell.statid, 0, 10, cell.r, rec_data.xypfje);
          --?????
          insert into t_report_data_info
            (statid, sheet, col, r, content)
          values
            (cell.statid, 0, 11, cell.r, rec_data.zpfje);
          --?????
          insert into t_report_data_info
            (statid, sheet, col, r, content)
          select
            cell.statid, 0, 12, cell.r,case when rec_data.bf<=0 then '--' else to_char(round(rec_data.sjpfje/rec_data.bf *100,2)) end from dual;
          --?????
          insert into t_report_data_info
            (statid, sheet, col, r, content)
          select
            cell.statid, 0, 12, cell.r,case when rec_data.bf<=0 then '--' else to_char(round(rec_data.trpfje/rec_data.bf *100,2)) end from dual;
          --?????
          insert into t_report_data_info
            (statid, sheet, col, r, content)
          select
            cell.statid, 0, 12, cell.r,case when rec_data.bf<=0 then '--' else to_char(round(rec_data.xypfje/rec_data.bf *100,2)) end from dual;
          --????
          insert into t_report_data_info
            (statid, sheet, col, r, content)
           select
            cell.statid, 0, 12, cell.r,case when rec_data.bf<=0 then '--' else to_char(round(rec_data.zpfje/rec_data.bf *100,2)) end from dual;
          cell.r := cell.r + 1;
        end loop;
        --????

        select t.bf,t.Sjpfje,t.trpfje,t.xypfje,t.zpfje,
                     decode(bf,0,0,round(t.Sjpfje*100/t.bf,2)) as ylpfl,--?????
                     decode(bf,0,0,round(t.trpfje*100/t.bf,2)) as yrpfl,--?????
                     decode(bf,0,0,round(t.xypfje*100/t.bf,2)) as xypfl,--?????
                     decode(bf,0,0,round(t.zpfje*100/t.bf,2)) as zpfl--????
              into v_bf,v_sjpfje,v_trpfje,v_xypfje,v_zpfje,v_ylpfl,v_trpfl,v_xypfl,v_zpfl
              from (
                   select x.*,y.Sjpfje,y.trpfje,y.xypfje,zpfje FROM  (
              select
                                         c.khbdh,

                                         /*round(sum(nvl(j.Fdzbf, 0)) / 365, 2) *
                                         round(to_number(sysdate -
                                                         to_date(j.fdsxr,
                                                                 'yyyymmdd'))) as bf,*/
                                        sum(nvl(k.zrbf,0)) as bf
                                    from tb_bxgsxx a,
                                         tb_ttxx b,
                                         tb_bdxx c,
                                         tb_zrxx g,
                                         TB_CPZRDZB h,
                                         TB_CPXX i,
                                         tb_fdxx j,
                                         tb_fdzrmx k
                                   where a.bxgsid = c.bxgsid
                                     and b.ttid = c.ttid
                                     and k.fdid = j.fdid
                                     and k.zrid = h.zrid
                                     and g.zrid = h.zrid
                                     and h.cpid = i.cpid
                                     and j.khbdh = c.khbdh
                                     /*and a.bxgsid = rec_gxgs.bxgsid
                                     and b.ttid = rec_tt.ttid*/
                                     and c.bdid = rec_bd.bdid
                                     /*and c.bdsxrq >=
                                         nvl(trim('20131230'), 19000101)
                                     and c.bdzzrq <=
                                         nvl(trim('20140228'), 99991231)
                                     and e.jarq >= nvl(trim(POther7), 19000101)
                                     and e.jarq <= nvl(trim(POther8), 99991231)*/
                                   and nvl(k.ZRJSRQ,j.fdzzr)>=nvl(pStartdate,19000101)
                                   and nvl(k.ZRkSRQ,j.fdsxr)<=nvl(pEnddate,99991231)
                                --   and nvl(k.ZRKSRQ,j.fdzzr)>=to_number(to_char(sysdate,'yyyymmdd'))
                                   group by
                                            c.khbdh
) X, (  select              c.khbdh as key2  ,
                                         sum(nvl(decode(f.zpajl,
                                                                '01',
                                                                Sjpfje,'03',Sjpfje),
                                                         0))
                                                  Sjpfje, --?????
                                         sum(nvl(decode(f.zpajl,
                                                                '04',
                                                                Sjpfje),
                                                         0))
                                                  as trpfje, --??????
                                         sum(nvl(decode(f.zpajl,
                                                                '05',
                                                                Sjpfje),
                                                         0))
                                                  as xypfje, --??????
                                         sum(nvl(case
                                                           when f.zpajl != '02' then
                                                            f.Sjpfje
                                                         end,
                                                         0))
                                                  as zpfje --?????
                                                  ,count(1) as zpas
                                    from
                                         tb_bdxx c,
                                         tb_lpajxx e,
                                         tb_zpaxx f,
                                         tb_zrxx g,
                                         TB_CPZRDZB h,
                                         TB_CPXX i
                                   where  f.ajid = e.ajid
                                     and g.zrid = f.zrid
                                     and g.zrid = h.zrid
                                     and h.cpid = i.cpid
                                     and e.khbdh = c.khbdh
                                  /*   and a.bxgsid = rec_gxgs.bxgsid
                                     and b.ttid = rec_tt.ttid*/
                                     and c.bdid = rec_bd.bdid
                                     /*and c.bdsxrq >=
                                         nvl(trim(pStartdate), 19000101)
                                     and c.bdzzrq <=
                                         nvl(trim(pEnddate), 99991231)
                                     and e.jarq >= nvl(trim(POther7), 19000101)
                                     and e.jarq <= nvl(trim(POther8), 99991231)*/
                                   /*  and nvl(k.ZRJSRQ,j.fdzzr)>=nvl(pStartdate,19000101)  */
                                   and e.jarq >= nvl(trim(POther7), 19000101)
                                   and e.jarq <= nvl(trim(POther8), 19000101)
                                   and e.ajzt in(08,09,10)
                                   group by    c.khbdh) Y
                                   where x.khbdh = Y.key2(+)) t;

        insert into t_report_data_info
          (statid, sheet, col, r, content)
        values
          (cell.statid, 0, 4, cell.r, '?????');
        --??
        insert into t_report_data_info
          (statid, sheet, col, r, content)
        values
          (cell.statid, 0, 7, cell.r, v_bf);
        --?????
        insert into t_report_data_info
          (statid, sheet, col, r, content)
        values
          (cell.statid, 0, 8, cell.r, v_sjpfje);
        --??????
        insert into t_report_data_info
          (statid, sheet, col, r, content)
        values
          (cell.statid, 0, 9, cell.r, v_trpfje);
        --??????
        insert into t_report_data_info
          (statid, sheet, col, r, content)
        values
          (cell.statid, 0, 10, cell.r, v_xypfje);
        --?????
        insert into t_report_data_info
          (statid, sheet, col, r, content)
        values
          (cell.statid, 0, 11, cell.r, v_zpfje);
        --?????
        insert into t_report_data_info
          (statid, sheet, col, r, content)
        values
          (cell.statid, 0, 12, cell.r, v_ylpfl);
        --?????
        insert into t_report_data_info
          (statid, sheet, col, r, content)
        values
          (cell.statid, 0, 13, cell.r, v_trpfl);
        --?????
        insert into t_report_data_info
          (statid, sheet, col, r, content)
        values
          (cell.statid, 0, 14, cell.r, v_xypfl);
        --????
        insert into t_report_data_info
          (statid, sheet, col, r, content)
        values
          (cell.statid, 0, 15, cell.r, v_zpfl);
        cell.r := cell.r + 1;
      end loop;
      --????
       select t.bf,t.Sjpfje,t.trpfje,t.xypfje,t.zpfje,
                 decode(bf,0,0,round(t.Sjpfje*100/t.bf,2)) as ylpfl,--?????
                 decode(bf,0,0,round(t.trpfje*100/t.bf,2)) as yrpfl,--?????
                 decode(bf,0,0,round(t.xypfje*100/t.bf,2)) as xypfl,--?????
                 decode(bf,0,0,round(t.zpfje*100/t.bf,2)) as zpfl--????
          into v_bf,v_sjpfje,v_trpfje,v_xypfje,v_zpfje,v_ylpfl,v_trpfl,v_xypfl,v_zpfl
          from (
               select x.*,y.Sjpfje,y.trpfje,y.xypfje,zpfje FROM  (
select                      b.ttid,sum(nvl(k.zrbf,0)) as bf
                                    from tb_bxgsxx a,
                                         tb_ttxx b,
                                         tb_bdxx c,
                                         tb_zrxx g,
                                         TB_CPZRDZB h,
                                         TB_CPXX i,
                                         tb_fdxx j,
                                         tb_fdzrmx k
                                   where a.bxgsid = c.bxgsid
                                     and b.ttid = c.ttid
                                     and k.fdid = j.fdid
                                     and k.zrid = h.zrid
                                     and g.zrid = h.zrid
                                     and h.cpid = i.cpid
                                     and j.khbdh = c.khbdh
                                     and a.bxgsid = rec_gxgs.bxgsid
                                     and b.ttid = rec_tt.ttid

                                     and nvl(k.ZRJSRQ,j.fdzzr)>=nvl(pStartdate,19000101)
                                   and nvl(k.ZRkSRQ,j.fdsxr)<=nvl(pEnddate,99991231)
                                   group by b.ttid
) X, (  select              c.ttid as key2  ,
                                         sum(nvl(decode(f.zpajl,
                                                                '01',
                                                                Sjpfje,'03',Sjpfje),
                                                         0))
                                                  Sjpfje, --?????
                                         sum(nvl(decode(f.zpajl,
                                                                '04',
                                                                Sjpfje),
                                                         0))
                                                  as trpfje, --??????
                                         sum(nvl(decode(f.zpajl,
                                                                '05',
                                                                Sjpfje),
                                                         0))
                                                  as xypfje, --??????
                                         sum(nvl(case
                                                           when f.zpajl != '02' then
                                                            f.Sjpfje
                                                         end,
                                                         0))
                                                  as zpfje --?????
                                                  ,count(1) as zpas
                                    from
                                         tb_bdxx c,
                                         tb_lpajxx e,
                                         tb_zpaxx f,
                                         tb_zrxx g,
                                         TB_CPZRDZB h,
                                         TB_CPXX i
                                   where  f.ajid = e.ajid
                                     and g.zrid = f.zrid
                                     and g.zrid = h.zrid
                                     and h.cpid = i.cpid
                                     and e.khbdh = c.khbdh
                                     and c.ttid =rec_tt.ttid
                                     and c.bxgsid = rec_gxgs.bxgsid
                                   and e.jarq >= nvl(trim(POther7), 19000101)
                                   and e.jarq <= nvl(trim(POther8), 99991231)
                                   and e.ajzt in(08,09,10)
                                   group by    c.ttid ) Y
                                   where x.ttid = Y.key2(+)
                                   order by x.ttid) t;

      insert into t_report_data_info
        (statid, sheet, col, r, content)
      values
        (cell.statid, 0, 2, cell.r, '?????');
      --??
      insert into t_report_data_info
        (statid, sheet, col, r, content)
      values
        (cell.statid, 0, 7, cell.r, v_bf);
      --?????
      insert into t_report_data_info
        (statid, sheet, col, r, content)
      values
        (cell.statid, 0, 8, cell.r, v_sjpfje);
      --??????
      insert into t_report_data_info
        (statid, sheet, col, r, content)
      values
        (cell.statid, 0, 9, cell.r, v_trpfje);
      --??????
      insert into t_report_data_info
        (statid, sheet, col, r, content)
      values
        (cell.statid, 0, 10, cell.r, v_xypfje);
      --?????
      insert into t_report_data_info
        (statid, sheet, col, r, content)
      values
        (cell.statid, 0, 11, cell.r, v_zpfje);
      --?????
      insert into t_report_data_info
        (statid, sheet, col, r, content)
      values
        (cell.statid, 0, 12, cell.r, v_ylpfl);
      --?????
      insert into t_report_data_info
        (statid, sheet, col, r, content)
      values
        (cell.statid, 0, 13, cell.r, v_trpfl);
      --?????
      insert into t_report_data_info
        (statid, sheet, col, r, content)
      values
        (cell.statid, 0, 14, cell.r, v_xypfl);
      --????
      insert into t_report_data_info
        (statid, sheet, col, r, content)
      values
        (cell.statid, 0, 15, cell.r, v_zpfl);
      cell.r := cell.r + 1;
    end loop;
    --??????
    select t.bf,t.Sjpfje,t.trpfje,t.xypfje,t.zpfje,
             decode(bf,0,0,round(t.Sjpfje*100/t.bf,2)) as ylpfl,--?????
             decode(bf,0,0,round(t.trpfje*100/t.bf,2)) as yrpfl,--?????
             decode(bf,0,0,round(t.xypfje*100/t.bf,2)) as xypfl,--?????
             decode(bf,0,0,round(t.zpfje*100/t.bf,2)) as zpfl--????
      into v_bf,v_sjpfje,v_trpfje,v_xypfje,v_zpfje,v_ylpfl,v_trpfl,v_xypfl,v_zpfl
      from (
           select x.*,y.Sjpfje,y.trpfje,y.xypfje,zpfje FROM  (
              select
                                         c.bxgsid,

                                         /*round(sum(nvl(j.Fdzbf, 0)) / 365, 2) *
                                         round(to_number(sysdate -
                                                         to_date(j.fdsxr,
                                                                 'yyyymmdd'))) as bf,*/
                                         sum(nvl(k.zrbf,0)) as bf
                                    from tb_bxgsxx a,
                                         tb_ttxx b,
                                         tb_bdxx c,
                                         tb_zrxx g,
                                         TB_CPZRDZB h,
                                         TB_CPXX i,
                                         tb_fdxx j,
                                         tb_fdzrmx k
                                   where a.bxgsid = c.bxgsid
                                     and b.ttid = c.ttid
                                     and k.fdid = j.fdid
                                     and k.zrid = h.zrid
                                     and g.zrid = h.zrid
                                     and h.cpid = i.cpid
                                     and j.khbdh = c.khbdh
                                     /*and a.bxgsid = rec_gxgs.bxgsid
                                     and b.ttid = rec_tt.ttid*/
                                   --  and c.ttid =rec_tt.ttid
                                     and c.bxgsid = rec_gxgs.bxgsid
                                     /*and c.bdsxrq >=
                                         nvl(trim('20131230'), 19000101)
                                     and c.bdzzrq <=
                                         nvl(trim('20140228'), 99991231)
                                     and e.jarq >= nvl(trim(POther7), 19000101)
                                     and e.jarq <= nvl(trim(POther8), 99991231)*/
                                   and nvl(k.ZRJSRQ,j.fdzzr)>=nvl(pStartdate,19000101)
                                   and nvl(k.ZRkSRQ,j.fdsxr)<=nvl(pEnddate,99991231)
                                 --  and nvl(k.ZRKSRQ,j.fdzzr)>=to_number(to_char(sysdate,'yyyymmdd'))
                                   group by
                                            c.bxgsid
) X, (  select              c.bxgsid as key2  ,
                                         sum(nvl(decode(f.zpajl,
                                                                '01',
                                                                Sjpfje,'03',Sjpfje),
                                                         0))
                                                  Sjpfje, --?????
                                         sum(nvl(decode(f.zpajl,
                                                                '04',
                                                                Sjpfje),
                                                         0))
                                                  as trpfje, --??????
                                         sum(nvl(decode(f.zpajl,
                                                                '05',
                                                                Sjpfje),
                                                         0))
                                                  as xypfje, --??????
                                         sum(nvl(case
                                                           when f.zpajl != '02' then
                                                            f.Sjpfje
                                                         end,
                                                         0))
                                                  as zpfje --?????
                                                  ,count(1) as zpas
                                    from
                                         tb_bdxx c,
                                         tb_lpajxx e,
                                         tb_zpaxx f,
                                         tb_zrxx g,
                                         TB_CPZRDZB h,
                                         TB_CPXX i
                                   where  f.ajid = e.ajid
                                     and g.zrid = f.zrid
                                     and g.zrid = h.zrid
                                     and h.cpid = i.cpid
                                     and e.khbdh = c.khbdh
                                  /*   and a.bxgsid = rec_gxgs.bxgsid
                                     and b.ttid = rec_tt.ttid*/
                                  --   and c.ttid =rec_tt.ttid
                                     and c.bxgsid = rec_gxgs.bxgsid
                                     /*and c.bdsxrq >=
                                         nvl(trim(pStartdate), 19000101)
                                     and c.bdzzrq <=
                                         nvl(trim(pEnddate), 99991231)
                                     and e.jarq >= nvl(trim(POther7), 19000101)
                                     and e.jarq <= nvl(trim(POther8), 99991231)*/
                                   /*  and nvl(k.ZRJSRQ,j.fdzzr)>=nvl(pStartdate,19000101)  */
                                   and e.jarq >= nvl(trim(POther7), 19000101)
                                   and e.jarq <= nvl(trim(POther8), 19000101)
                                   and e.ajzt in(08,09,10)
                                   group by    c.bxgsid) Y
                                   where x.bxgsid = Y.key2(+)) t;

    insert into t_report_data_info
      (statid, sheet, col, r, content)
    values
      (cell.statid, 0, 0, cell.r, '???????');
    --??
    insert into t_report_data_info
      (statid, sheet, col, r, content)
    values
      (cell.statid, 0, 7, cell.r, v_bf);
    --?????
    insert into t_report_data_info
      (statid, sheet, col, r, content)
    values
      (cell.statid, 0, 8, cell.r, v_sjpfje);
    --??????
    insert into t_report_data_info
      (statid, sheet, col, r, content)
    values
      (cell.statid, 0, 9, cell.r, v_trpfje);
    --??????
    insert into t_report_data_info
      (statid, sheet, col, r, content)
    values
      (cell.statid, 0, 10, cell.r, v_xypfje);
    --?????
    insert into t_report_data_info
      (statid, sheet, col, r, content)
    values
      (cell.statid, 0, 11, cell.r, v_zpfje);
    --?????
    insert into t_report_data_info
      (statid, sheet, col, r, content)
    values
      (cell.statid, 0, 12, cell.r, v_ylpfl);
    --?????
    insert into t_report_data_info
      (statid, sheet, col, r, content)
    values
      (cell.statid, 0, 13, cell.r, v_trpfl);
    --?????
    insert into t_report_data_info
      (statid, sheet, col, r, content)
    values
      (cell.statid, 0, 14, cell.r, v_xypfl);
    --????
    insert into t_report_data_info
      (statid, sheet, col, r, content)
    values
      (cell.statid, 0, 15, cell.r, v_zpfl);
    cell.r := cell.r + 1;
  end loop;

  --???????????
  /*9.??*/
  PReturnCode := '0'; /* ??????????????vstatid????????? */
  PReturnMsg  := vstatid;
  DBMS_OUTPUT.PUT_LINE('[LDS debug] ' || 'PReturncode= ' || PReturnCode);
  --COMMIT; ???java?????????

EXCEPTION
  WHEN OTHERS THEN
    --rollback;???java?????????????0?????????????????
    PReturnCode := 'E'; /*  ??????  */
    DBMS_OUTPUT.PUT_LINE('[yhs debug] ' || 'PReturncode= ' || PReturnCode);
    PReturnMsg := ' rownum' || cell.r || 'Error:' || sqlerrm; --???????????
    DBMS_OUTPUT.PUT_LINE(PReturnMsg);
end SP_P1_30015;

  /*?????????????????  171 */
  /* ???2?12 130*/

/
