CREATE PROCEDURE      "PROC_RBSCLOSE_EXPORT" (p_RtnCode OUT NUMBER, p_RtnMsg OUT VARCHAR2) IS
	i_Count	NUMBER(9) := 0;
	i_step  NUMBER(9) := 0;
	sPch	VARCHAR2(11);
	sWjm	VARCHAR2(30);
	sSql varchar2(4000);
	v_dname   VARCHAR2(50);
BEGIN
	--0.?????
    i_step := 0;
    i_Count := 0;
    p_RtnCode := 0;
    v_dname := 'E:\rbs\returndata';
    --v_dname := '\\10.1.63.178\D:\Software';
    p_RtnMsg := '????';

   	--????????
   	i_step := 1;
   	SELECT FUNC_GENERATE_LSH ('0112')
   	INTO  sPch
   	FROM DUAL;

   	---???????????
   	i_step := 2;
   	INSERT INTO TB_RBS_CLOSE_CZJL(PCH, SJRQ, KSSJ, JSSJ)
   	VALUES(sPch, TO_CHAR(SYSDATE,'YYYYMMDD'), SYSDATE, NULL);

   	--???????????
   	i_step := 3;
   	INSERT INTO TB_RBS_CLOSE_EXPORT(
   		YWLSH, PCH, AJID, BATCH_NO, WD_CLAIM_NO,
		NO, ACCIDENT_NAME, IDTYPE, IDNO,
		APPLY_FLAG, UNACCEPT_REASON, DATE_OF_LOSS,
		AREA, CAUSE_OF_LOSS, APPLY_AMT, PAYOUT_AMT,
		COVER_CODE, PAYMENT_METHOD, ACCOUNT_NAME,
		ACCOUNT_OWNER_ID_TYPE, ACCOUNT_OWNER_ID_NO,
		BANK_ID, BANK_ACCNO, MOBILE,
		EXPORT_DATE, YWLX,EMAIL)
	SELECT
		FUNC_GENERATE_LSH('0111'), sPch, A.AJID, S.PCH, A.PAH,
		TO_NUMBER(SUBSTR(A.PAH,LENGTH(A.PAH)-2,3)), A.BBRXM, FUNC_BXGSDM_PZ('ZJLX', (SELECT AAC058 FROM TB_KHXX WHERE KHID=A.BBRKHID), '613', '0',NULL,NULL),(SELECT AAC147 FROM TB_KHXX WHERE KHID=A.BBRKHID),
		DECODE(A.AJJL,'01','1','03','1','04','1','05','1','06','1',NULL,'1'), A.AJJLSM1||DECODE(A.AJJLSM1,'','',NULL,'',',')||A.AJJLSM, FUNC_GET_FORMT_DATE((SELECT TO_CHAR(NVL(MIN(B.RYRQ),MIN(B.JZRQ))) FROM TB_LPFPXX B WHERE B.AJID=A.AJID)),
		NVL(NVL(FUNC_BXGSDM_PZ('TB_YYXX', (SELECT MIN(B.YYID) FROM TB_LPFPXX B WHERE B.AJID = A.AJID), '613', '0', NULL,NULL),(select decode(m.jb,'2','1310148','3','1310020') from tb_yyxx m where m.yyid =(SELECT MIN(B.YYID) FROM TB_LPFPXX B WHERE B.AJID = A.AJID))),'???????'), NVL(NVL(FUNC_BXGSDM_PZ('TB_JBKXX',(SELECT MAX(B.ZDDM) FROM TB_ZPAXX B WHERE B.AJID=A.AJID AND B.FPID IS NOT NULL),'613','0',NULL,NULL),(SELECT MAX(B.ZDDM) FROM TB_ZPAXX B WHERE B.AJID=A.AJID AND B.FPID IS NOT NULL)),'???????'), '', G.PAYOUT_AMT,
		--DECODE(A.AJJL,'06',0,A.AJPFJE),
		--(SELECT MAX(T.XZLX) FROM TB_ZRXX T,TB_ZPAXX M WHERE T.ZRID=M.ZRID AND M.AJID=A.AJID),
		FUNC_BXGSDM_PZ(decode(a.ttid,'1301','ZRDM','RBSXZDZ'), G.YWLX, '613', '0',decode(a.ttid,'1301','1301',NULL),NULL),FUNC_BXGSDM_PZ('ZFFS', A.AJPFFS, '613', '0',NULL,NULL), case when x.zbbrgx='03' then (select z.zhmc from tb_khxx z where z.khid=x.zbbrkhid) else (select z.zhmc from tb_khxx z where z.khid=x.bbrkhid) end as zhmc,
		FUNC_BXGSDM_PZ('ZJLX', (SELECT SQRZJLX FROM TB_KHXX WHERE KHID=A.BBRKHID), '613', '0',NULL,NULL),DECODE((SELECT ZBBRGX FROM TB_FDXX WHERE FDID=A.FDID),'03',(SELECT AAC147 FROM TB_KHXX WHERE KHID = A.ZBBRKHID),A.BBRZJH),--DECODE(A.ZLDBZ,'0',A.BBRZJH,(SELECT AAC147 FROM TB_KHXX WHERE KHID = A.ZBBRKHID)),
		FUNC_GET_BANKID('613',case when x.zbbrgx='03' then (select z.khyh from tb_khxx z where z.khid=x.zbbrkhid) else (select z.khyh from tb_khxx z where z.khid=x.bbrkhid) end),
    case when x.zbbrgx='03' then (select z.yhzh from tb_khxx z where z.khid=x.zbbrkhid) else (select z.yhzh from tb_khxx z where z.khid=x.bbrkhid) end as yhzh,A.SQRSJ,
		SYSDATE,
    CASE WHEN (G.YWLX='DKMZ1' OR G.YWLX='DKMZ2') THEN '0'
         WHEN (G.YWLX='DKZY1' OR G.YWLX='DKZY2') THEN '1'
         WHEN (G.YWLX='DKZYJT' or G.YWLX='DKZYJT1') THEN 'ZYJT'
         WHEN G.YWLX='DKSY' THEN 'SY'
         ELSE G.YWLX END,
    NVL(A.SQRYX,(SELECT EMAIL FROM TB_KHXX WHERE KHID=A.BBRKHID))
	FROM TB_LPPCXX S, TB_LPAJXX A,TB_FDXX X,(select A.AJID, NVL(sum(t.sjpfje),0) AS PAYOUT_AMT,CASE WHEN a.ttid='1301' and t.pfzrdm like 'MAT%' then 'DKSY' when T.PFZRDM LIKE 'MAT%' THEN 'SY' ELSE(
  case when a.ttid='1301' then (case when (c.zdlx='0' and (t.pfzrdm like 'OP%' or t.pfzrdm='OIP00004' or t.pfzrdm='OIP00015')) then 'DKMZ1'
                                     when (c.zdlx='0' and t.pfzrdm in ('OIP00005','OIP00006')) then 'DKMZ2'
                                     when (c.zdlx='1' and (t.pfzrdm like 'IP%' or t.pfzrdm='OIP00004' or t.pfzrdm='OIP00015')) then 'DKZY1'
                                     when (c.zdlx='1' and t.pfzrdm in ('OIP00005','OIP00006')) then 'DKZY2'
                                     when (c.zdlx='1' and t.pfzrdm='HI00005' and a.khbdh in ('310000023645090','31000027294208')) then 'DKZYJT'
                                     when (c.zdlx='1' and t.pfzrdm like 'HI%' and a.khbdh='310000283936088') then 'DKZYJT1' else '' end)
       else c.zdlx end) END AS YWLX,
SUM(NVL(t.ZDZJE,0))-SUM(CASE WHEN t.ZPAJL='02' THEN 0 ELSE(SELECT NVL(SUM(CASE WHEN N.HLBHFLLSGZID IS NOT NULL THEN H.FLZFJE ELSE 0 END),0)
                    +NVL(SUM(CASE WHEN N.ZFFYLSGZID IS  NULL AND NVL(H.ZFJE,0)>0 THEN H.ZFJE ELSE 0 END),0)
                    +NVL(SUM( NVL(H.CDEJE,0)),0)
                    +NVL(t.BHLFY,0)
                     + CASE WHEN t.SBBDX='1' THEN 0 ELSE NVL(t.SBZFZJE,0) END
                   +NVL(t.QTDSFZFJE,0)
              FROM TB_ZPAXXDZB N,TB_FPXXFYXX H WHERE N.ZPAID=t.ZPAID AND N.XXID=H.XXID) END )
FROM TB_LPPCXX S, TB_LPAJXX A,tb_lpfpxx c,tb_zpaxx t
    WHERE 1=1
    AND A.BXGSID = '613'
 -- AND A.SFRQ >= TO_CHAR(SYSDATE-10,'YYYYMMDD')
  AND A.AJZT IN ('09')
  AND S.PCID = A.LPPCID
  and a.ajid= t.ajid
  AND(A.AJJL NOT IN('07') OR A.AJJL IS NULL)
  and c.fpid=t.fpid
  AND T.FPID IS NOT NULL
  group by A.AJID,(CASE WHEN a.ttid='1301' and t.pfzrdm like 'MAT%' then 'DKSY' when  T.PFZRDM LIKE 'MAT%' THEN 'SY' ELSE(
  case when a.ttid='1301' then (case when (c.zdlx='0' and (t.pfzrdm like 'OP%' or t.pfzrdm='OIP00004' or t.pfzrdm='OIP00015')) then 'DKMZ1'
                                     when (c.zdlx='0' and t.pfzrdm in ('OIP00005','OIP00006')) then 'DKMZ2'
                                     when (c.zdlx='1' and (t.pfzrdm like 'IP%' or t.pfzrdm='OIP00004' or t.pfzrdm='OIP00015')) then 'DKZY1'
                                     when (c.zdlx='1' and t.pfzrdm in ('OIP00005','OIP00006')) then 'DKZY2'
                                     when (c.zdlx='1' and t.pfzrdm='HI00005' and a.khbdh in ('310000023645090','31000027294208')) then 'DKZYJT'
                                     when (c.zdlx='1' and t.pfzrdm like 'HI%' and a.khbdh='310000283936088') then 'DKZYJT1' else '' end)
       else c.zdlx end) END))G
    WHERE 1=1
    AND A.BXGSID = '613'
    AND A.FDID=X.FDID
 -- AND A.SFRQ >= TO_CHAR(SYSDATE-10,'YYYYMMDD')
  AND A.AJZT IN ('09')
  AND S.PCID = A.LPPCID
  AND (A.AJJL NOT IN('07') OR A.AJJL IS NULL)
  AND G.AJID=A.AJID;

  i_step := 4;
  ---??????
  UPDATE TB_RBS_CLOSE_EXPORT T
  SET T.APPLY_AMT = ( SELECT
              SUM(NVL(D.ZDZJE,0))-SUM(CASE WHEN D.ZPAJL='02' THEN 0 ELSE(SELECT NVL(SUM(CASE WHEN N.HLBHFLLSGZID IS NOT NULL THEN H.FLZFJE ELSE 0 END),0)
                    +NVL(SUM(CASE WHEN N.ZFFYLSGZID IS  NULL AND NVL(H.ZFJE,0)>0 THEN H.ZFJE ELSE 0 END),0)
                    +NVL(SUM( NVL(H.CDEJE,0)),0)
                    +NVL(D.BHLFY,0)
                     + CASE WHEN D.SBBDX='1' THEN 0 ELSE NVL(D.SBZFZJE,0) END
                   +NVL(D.QTDSFZFJE,0)
              FROM TB_ZPAXXDZB N,TB_FPXXFYXX H WHERE N.ZPAID=D.ZPAID AND N.XXID=H.XXID) END )
             FROM  TB_LPAJXX A,TB_ZPAXX D
              WHERE  A.AJID=D.AJID
              AND D.FPID IS NOT NULL
              AND A.AJID=T.AJID
              AND ((T.YWLX='SY' AND D.PFZRDM LIKE 'MAT%') OR ((T.YWLX='0' ) AND EXISTS(SELECT 1 FROM TB_LPFPXX M, TB_ZPAXXDZB N,TB_FPXXFYXX H

                      WHERE M.FPID=D.FPID AND M.ZDLX='0'
                      AND N.ZPAID=D.ZPAID AND N.XXID=H.XXID
                      ))
                      OR((T.YWLX='1' ) AND EXISTS(SELECT 1 FROM TB_LPFPXX M, TB_ZPAXXDZB N,TB_FPXXFYXX H

                      WHERE M.FPID=D.FPID AND M.ZDLX='1'
                      AND N.ZPAID=D.ZPAID AND N.XXID=H.XXID
                      ))
                      OR((T.YWLX='ZYJT') AND EXISTS(SELECT 1 FROM TB_LPFPXX M, TB_ZPAXXDZB N,TB_FPXXFYXX H
                      WHERE M.FPID=D.FPID AND M.ZDLX='1'
                      AND N.ZPAID=D.ZPAID AND N.XXID=H.XXID))
                      ))
  WHERE PCH = sPch;

  UPDATE TB_RBS_CLOSE_EXPORT T
  SET T.NO =(SELECT S.XH FROM(SELECT G.YWLSH,ROWNUM XH FROM(
  SELECT A.YWLSH FROM TB_RBS_CLOSE_EXPORT A WHERE A.PCH=sPch ORDER BY A.BATCH_NO,A.WD_CLAIM_NO)G)S
  WHERE S.YWLSH=T.YWLSH)
  WHERE T.PCH=sPch;
  i_step := 5;
  ---?????????`10?
  UPDATE TB_LPAJXX A
  SET A.AJZT = '10'
  WHERE A.AJID IN(SELECT AJID FROM TB_RBS_CLOSE_EXPORT WHERE PCH=sPch);

  ----???????excel?????
  i_step := 7;
  SELECT 'RETURN_'||TO_CHAR(SYSDATE,'YYYYMMDD')||'_01' ||'.CSV'
  INTO sWjm
  FROM DUAL;

  BEGIN
    sSql := 'select BATCH_NO, WD_CLAIM_NO, NO,ACCIDENT_NAME,IDTYPE,IDNO, APPLY_FLAG , UNACCEPT_REASON , DATE_OF_LOSS,AREA,CAUSE_OF_LOSS,APPLY_AMT,PAYOUT_AMT,COVER_CODE,PAYMENT_METHOD,ACCOUNT_NAME,ACCOUNT_OWNER_ID_TYPE,ACCOUNT_OWNER_ID_NO AS ACCOUNT_OWNER_ID_NO,BANK_ID,BANK_ACCNO,MOBILE,EMAIL,DECODE(YWLX,'||CHR(39)||'0'||CHR(39)||','||CHR(39)||'??'||CHR(39)||','||CHR(39)||'1'||CHR(39)||','||CHR(39)||'??'||CHR(39)||','||CHR(39)||'ZYJT'||CHR(39)||','||CHR(39)||'????'||CHR(39)||','||CHR(39)||'??'||CHR(39)||')AS YWLX,(SELECT KHBDH FROM TB_LPAJXX A WHERE A.PAH=TB_RBS_CLOSE_EXPORT.WD_CLAIM_NO)AS KHBDH,(SELECT (SELECT AAA103 FROM AA10 WHERE AAA100='||CHR(39)||'ZBBRGX'||CHR(39)||' AND AAA102=NVL(S.ZBBRGX,'||CHR(39)||'00'||CHR(39)||')) FROM TB_LPAJXX A,TB_FDXX S WHERE A.PAH=TB_RBS_CLOSE_EXPORT.WD_CLAIM_NO AND A.FDID=S.FDID) as GX,(select bmbh from tb_khxx where aac147=TB_RBS_CLOSE_EXPORT.IDNO and xm=TB_RBS_CLOSE_EXPORT.ACCIDENT_NAME) as BMBH from TB_RBS_CLOSE_EXPORT WHERE PCH='||sPch || 'ORDER BY BMBH,TO_NUMBER(NO) ASC';
    i_step := 101;
    --EXECUTE IMMEDIATE 'create directory MYDIR as '||''''||v_dname||'''';
    --execute immediate v_sqlstr;
    i_step := 102;
    --EXECUTE IMMEDIATE 'grant read,write on directory MYDIR to public';
    i_step := 11;
    --PROC_WRITE_EXCEL(sPch,'MYDIR',sWjm);
    SELECT COUNT(1)
    INTO i_Count
    FROM TB_RBS_CLOSE_EXPORT
    WHERE PCH=sPch;

    IF i_Count>0 THEN
      sql_to_csv(sSql,'RBSMYDIR',sWjm);

      i_step := 6;
      UPDATE TB_RBS_CLOSE_CZJL
      SET JSSJ = SYSDATE
      WHERE PCH = sPch;
      COMMIT;
    ELSE
      ROLLBACK;
    END IF;
    --sql_to_csv(sSql,'MYDIR',sWjm);
    --EXECUTE IMMEDIATE 'DROP directory MYDIR';
  END;
  return;
EXCEPTION
  WHEN OTHERS THEN
      p_RtnCode := SQLCODE;
      p_RtnMsg := SQLERRM;
      ROLLBACK;
      Pkg_Error_Log.Pro_Error_In('PROC_RBSCLOSE_EXPORT', i_step, p_RtnCode, p_RtnMsg);
END PROC_RBSCLOSE_EXPORT;

/
