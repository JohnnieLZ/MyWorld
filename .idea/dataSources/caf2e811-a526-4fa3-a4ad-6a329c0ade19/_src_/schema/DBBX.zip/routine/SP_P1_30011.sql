CREATE PROCEDURE      "SP_P1_30011" (report_id   In t_report_def_info.REPORTID%TYPE,
                                        pStartdate  IN varchar2, -- ??????yyyymmdd
                                        pEnddate    IN varchar2, -- ??????yyyymmdd
                                        pStatman    IN t_report_gen_info.STATMAN%TYPE, --???
                                        ptype       in varchar2, /*0 ???? ,1 ?? 2 ?? 3 ?? */ --?????
                                        POther1     IN varchar2, --??id
                                        POther2     IN varchar2, --??id
                                        POther3     IN varchar2, --??id
                                        POther4     IN varchar2, --??ID
                                        POther5     IN varchar2, --????
                                        POther6     IN varchar2, --??ID
                                        POther7     IN varchar2, --????????
                                        POther8     IN varchar2, --????????
                                        PReturnCode OUT varchar2,
                                        PReturnMsg  OUT varchar2) AS
  V_STEP_CODE  CHAR(5); --?????????????????
  vreportid    t_report_def_info.REPORTID%TYPE; --??ID
  v_start_date number := 0; --????????
  v_end_date   number := 0; --????????
  vxzqhdm      t_report_gen_info.STATORGID%TYPE; --????????????

  vstatid varchar(30); --?????????????????
  type cellType is record(
    statid  varchar2(15),
    col     number,
    r       number,
    content varchar2(1024));

  cell      cellType; --?????????????
  vdwmc     varchar2(50); --????????????
  vusername t_report_gen_info.STATMAN%TYPE; --????????
  vnd       t_report_gen_info.STATYEAR%TYPE; --????
  rowno     number := 0; --??????

begin
  V_STEP_CODE := '00000';
  PReturnMsg  := 'OK';
  PReturnCode := 'E';
  vreportid   := substr(report_id, 1, 5);
  vusername   := pStatman;
  vnd         := substr(pStartdate, 1, 4);

  v_start_date := to_number(substr(pStartdate, 1, 8));
  v_end_date   := to_number(substr(pEnddate, 1, 8));

  --???????????????????????????
  delete from t_report_data_info
   where statid in
         (select statid from T_REPORT_GEN_INFO where reportid = report_id);

  delete from T_REPORT_GEN_INFO
   where statid in
         (select statid from T_REPORT_GEN_INFO where reportid = report_id);

  V_STEP_CODE := '00001';
  --???,?T_RERORT_GEN_INFO?????????????
  --???????
  select seq_statid.nextval into vstatid from dual;

  -- ??????????
  insert into t_report_gen_info
    (STATID,
     REPORTID,
     STATORGID,
     STATORGNAME,
     STATDATE,
     STATMAN,
     STATYEAR,
     BEGINDATE,
     ENDDATE,
     STAT_OTHER,
     STAT_TYPE)
  values
    (vstatid,
     vreportid,
     '',
     '',
     to_char(sysdate, 'yyyymmdd'),
     vusername,
     vnd,
     v_start_date,
     v_end_date,
     substr(pEnddate, 1, 1),
     trim(ptype));

  /* --?????? ??excel???0?????1??,????0???*/

  --???
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,1,2,'CLFX01');

  --????
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,1,3,to_char(sysdate,'yyyymmdd'));

  --????
  select max(bxgsqc) into cell.content from tb_bxgsxx where bxgsid=trim(POther1);
  if cell.content is not null then
    insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,1,4,cell.content);
  end if;

  --????
  select max(ttmc) into cell.content from tb_ttxx where ttid = trim(POther2);
  if cell.content is not null then
    insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,1,5,cell.content);
  end if;

  --????
  select max(khbdh) into cell.content from tb_bdxx where bdid = trim(POther3);
  if cell.content is not null then
    insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,1,6,cell.content);
  end if;

  --????????
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,1,7,trim(pStartdate) ||'-'|| trim(pEnddate));

  --????????
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,1,8,trim(POther7) ||'-'|| trim(POther8));

  cell.statid := vstatid;
  cell.col    := 0; --?1???
  cell.r      := 11; --?11???
  --???????????????????????????????excel????????????????????

  for rec_data in(
       select bxgsxx.bxgsqc,
              nvl(fdxx.wbbdh,bdxx.khbdh) as khbdh,
              case when fdxx.wbbdh is not null then
                (select zttmc from tb_nbbdwbbddzpzb where wbbdh = fdxx.wbbdh)
              else
                (select ttmc from tb_ttxx where ttid = fdxx.ttid)
              end ttmc,
              bdxx.bdsxrq,
              bdxx.bdzzrq,
              lpajxx.wbpafh,
              lppcxx.pch,
              lppcxx.sjrq,
              khxx1.xm as xm,
              (select aa10.aaa103
                 from aa10
                where aaa100 = 'AAC058'
                  and aaa102 = khxx1.aac058) as aac058,
              khxx1.aac147,
              (select aa10.aaa103
                 from aa10
                where aaa100 = 'AAC004'
                  and aaa102 = khxx1.xb) as xb,
              khxx1.csrq,
              (select aa10.aaa103
                 from aa10
                where aaa100 = 'ZLDBZ'
                  and aaa102 = fdxx.zldbz) as zldbz,
              khxx.xm as xm1,
              (select aa10.aaa103
                 from aa10
                where aaa100 = 'AAC058'
                  and aaa102 = khxx.aac058) as aac0581,
              khxx.aac147 as aac1471,
             (select zttbh from tb_zttxx where zttid=lpajxx.zttid)  as zttbh,
             (select zttmc from tb_zttxx where zttid=lpajxx.zttid) as zttmc,
             (select BM from tb_zttxx where zttid=lpajxx.zttid)  bm,
              khxx1.gh,
              --khxx1.ybbs,
              (select aa10.aaa103 from aa10 where aaa100='YBBS' and khxx1.ybbs=aa10.aaa102) as ybbs,
              khxx1.ybkh,
              (select aa26.aaa146 from aa26 where fdxx.Ybdxzqh = aa26.aab301) as ybd ,
              (select aa26.aaa146 from aa26 where fdxx.Gzdxzqh = aa26.aab301) as gzd ,
              (select aa26.aaa146 from aa26 where fdxx.jzdqh = aa26.aab301) as jzd ,
              fdxx.fdh,
              fdxx.fdsxr,
              fdxx.fdzzr,
              lpajxx.pah,
                  nvl( (select aaa103
                  from aa10
                where aa10.aaa100='AJJL'
                  and aa10.aaa102=lpajxx.ajjl),'????')ajjl,
              lpajxx.ajpfje,
              decode(lpajxx.Khsyr, null, '?', '?') as sfzkhsy,
              lpajxx.Ssyly as zcyj,
              (select aaa103
                  from aa10
                where aa10.aaa100='SYJL'
                  and aa10.aaa102=lpajxx.syjl)syjl,
              lpajxx.syyjms,
              lpajxx.sqrq,
              lppcxx.Slrq as slri,
              (select aaa103
                  from aa10
                where aa10.aaa100='SCZT'
                  and aa10.aaa102=lpajxx.Bbrsczt) as sczt,
              lpajxx.Bbrswrq,
              lpajxx.Bbrywsgfsrq,
              jbkxx.jbmc,
              jbkxx.jbdm,
              lpajxx.Zjqzr,
              zpaxx.zpah,
              lpfpxx.fprq,
              case when lpfpxx.zdlx in('1') then '' else to_char(lpfpxx.jzrq) end as jzrq,
              case when lpfpxx.zdlx in('1') then to_char(lpfpxx.Ryrq) else '' end as ryrq,
              case when lpfpxx.zdlx in('1') then to_char(lpfpxx.cyrq ) else '' end as zyrq,
              case when lpfpxx.zdlx in('1') then to_char(lpfpxx.Zyts) else '' end as zyts,
              (select aaa103
                  from aa10
                where aa10.aaa100='ZDLX'
                  and aa10.aaa102=lpfpxx.zdlx) as zdlx,
              yyxx.yydm,
              yyxx.yymc,
              yyxx.xzqhmc,
              (select aa10.aaa103
                 from aa10
                where aaa100 = 'YYJJLX'
                  and aaa102 = yyxx.yyjjlx) as yyjjlx,
              yyxx.jb,
              (select aa10.aaa103
                 from aa10
                where aaa100 = 'LB'
                  and aaa102 = yyxx.lb) as lb,
              decode(yyxx.Yblb, 1, '?', '?') as sfybddyy,
              jbkxx1.jbdm as jbdm2,
              jbkxx1.jbmc as jbms,
              zpaxx.zdzje as fyze,
              zpaxx.Zfje,
              zpaxx.flzfje as flzf,
              zpaxx.Bhlfy,
              zpaxx.sbzfzje,
              zpaxx.qtdsfzfje,
              (select aa10.aaa103
                 from aa10
                where aa10.aaa100 = 'MPLX'
                  and aa10.aaa102 =
                      (select max(nvl(bljshmplx,bljsqmplx))
                        from tb_zpalsgzdzb
                       where tb_zpalsgzdzb.zpaid=zpaxx.zpaid))as mflx,
              zpaxx.mpe,
              (select aa10.aaa103 from aa10 where aa10.aaa100='AJJL' and aa10.aaa102=zpaxx.zpajl) as zpajl,
              zpaxx.sjpfje,
              cpxx.cph,
              cpxx.cpmc,
              zrxx.zrbm,
              zrxx.zrmc,
              lpajxx.jarq as pfrq
         from tb_bxgsxx  bxgsxx,
              tb_ttxx    ttxx,
             -- tb_zttxx   zttxx,
              tb_bdxx    bdxx,
              tb_fdxx    fdxx,
              tb_khxx    khxx,
              tb_khxx    khxx1,
              --tb_bdcpxx  bdcpxx,
              tb_cpxx    cpxx,
              tb_lppcxx  lppcxx,
              tb_lpajxx  lpajxx,
              tb_zpaxx   zpaxx,
              tb_jbkxx   jbkxx,
              tb_jbkxx   jbkxx1,
              tb_lpfpxx  lpfpxx,
              tb_yyxx    yyxx,
              tb_zrxx    zrxx,
              tb_cpzrdzb cpzrdzb
       where bxgsxx.bxgsid = bdxx.bxgsid
          and bdxx.ttid = ttxx.ttid

          and lppcxx.khbdh=bdxx.khbdh

         -- and ttxx.ttid = zttxx.ttid(+)
        --  and nvl(lpajxx.zttid,0)= zttxx.zttid(+)
          and bdxx.khbdh = fdxx.khbdh
          and fdxx.BBRKHID = khxx1.khid
          --and bdcpxx.bdid = bdxx.bdid
          --and bdcpxx.cpid = cpxx.cpid
          and ttxx.ttid = lppcxx.ttid
          and bxgsxx.bxgsid = lppcxx.bxgsid
          and lppcxx.pcid = lpajxx.lppcid
          and lpajxx.ajid = zpaxx.ajid
          and lpajxx.bbrkhid=khxx1.khid
          and lpajxx.zbbrkhid=khxx.khid(+)
          and fdxx.bbrkhid = khxx1.khid
          and lpajxx.jbid = jbkxx.jbid(+)
          and zpaxx.fpid = lpfpxx.fpid(+)
          and lpfpxx.yyid = yyxx.yyid(+)
          and zpaxx.jbid = jbkxx1.jbid(+)
          and zpaxx.zrid = zrxx.zrid
          and zrxx.zrid = cpzrdzb.zrid
          and cpzrdzb.cpid = cpxx.cpid
          and EXISTS(SELECT 'X' FROM TB_LPAJXX H WHERE H.AJID=zpaxx.AJID AND AJZT = '11')
          and bxgsxx.bxgsid = nvl(trim(POther1), bxgsxx.bxgsid)
          and ttxx.ttid = nvl(trim(POther2), ttxx.ttid)
          and bdxx.bdid = nvl(trim(POther3), bdxx.bdid)
          and bdxx.bdsxrq >= nvl(trim(pStartdate), 19000101)
          and bdxx.bdsxrq <= nvl(trim(pEnddate), 99991231)
          and bdxx.bdzzrq >= nvl(trim(pStartdate), '19000101')
          and lpajxx.jarq >= nvl(trim(POther7),19000101)
          and lpajxx.jarq <= nvl(trim(POther8),99991231)
          AND LPPCXX.seqlogid <> -1
          order by bxgsxx.bxgsqc,ttxx.ttbh,bdxx.khbdh,lppcxx.pch,lpajxx.pah,zpaxx.zpah

  ) loop


          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 0, cell.r, rec_data.bxgsqc);--????
         -- insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 1, cell.r, rec_data.ttbh);--?????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 1, cell.r, rec_data.ttmc);--??????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 2, cell.r, rec_data.khbdh);--?????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 3, cell.r, rec_data.bdsxrq);--?????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 4, cell.r, rec_data.bdzzrq);--?????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 5, cell.r, rec_data.WBPAFH);--???
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 6, cell.r, rec_data.pch);--?????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 7, cell.r, rec_data.sjrq);--????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 8, cell.r, rec_data.xm);--??????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 9, cell.r, rec_data.aac058);--????????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 10, cell.r, rec_data.aac147);--????????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 11, cell.r, rec_data.xb);--??????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 12, cell.r, rec_data.csrq);--????????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 13, cell.r, rec_data.zldbz);--?/????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 14, cell.r, rec_data.xm1);--???????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 15, cell.r, rec_data.aac0581);--?????????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 16, cell.r, rec_data.aac1471);--????????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 17, cell.r, rec_data.zttbh);--????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 18, cell.r, rec_data.zttmc);--?????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 19, cell.r, rec_data.bm);--??
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 20, cell.r, rec_data.gh);--??
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 21, cell.r, rec_data.ybbs);--????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 22, cell.r, rec_data.ybkh);--????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 23, cell.r, rec_data.ybd);--???
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 24, cell.r, rec_data.gzd);--???
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 25, cell.r, rec_data.jzd);--???
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 26, cell.r, rec_data.fdh);--???
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 27, cell.r, rec_data.fdsxr);--????????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 28, cell.r, rec_data.fdzzr);--????????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 29, cell.r, rec_data.pah);--???
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 30, cell.r, rec_data.ajjl);--????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 31, cell.r, rec_data.ajpfje);--??????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 32, cell.r, rec_data.sfzkhsy);--???????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 33, cell.r, rec_data.zcyj);--????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 34, cell.r, rec_data.syjl);--??????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 35, cell.r, rec_data.syyjms);--??????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 36, cell.r, rec_data.sqrq);--????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 37, cell.r, rec_data.slri);--????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 38, cell.r, rec_data.sczt);--????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 39, cell.r, rec_data.bbrswrq);--????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 40, cell.r, rec_data.bbrywsgfsrq);--?????????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 41, cell.r, rec_data.jbmc);--????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 42, cell.r, rec_data.jbdm);--????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 43, cell.r, rec_data.zjqzr);--?????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 44, cell.r, rec_data.zpah);--????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 45, cell.r, rec_data.fprq);--????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 46, cell.r, rec_data.jzrq);--????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 47, cell.r, rec_data.ryrq);--????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 48, cell.r, rec_data.zyrq);--????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 49, cell.r, rec_data.zyts);--????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 50, cell.r, rec_data.zdlx);--????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 51, cell.r, rec_data.yydm);--????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 52, cell.r, rec_data.yymc);--????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 53, cell.r, rec_data.xzqhmc);--?????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 54, cell.r, rec_data.yyjjlx);--??????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 55, cell.r, rec_data.jb);--????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 56, cell.r, rec_data.lb);--????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 57, cell.r, rec_data.sfybddyy);--????????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 58, cell.r, rec_data.jbdm2);--????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 59, cell.r, rec_data.jbms);--????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 60, cell.r, rec_data.fyze);--????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 61, cell.r, rec_data.zfje);--??
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 62, cell.r, rec_data.flzf);--????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 63, cell.r, rec_data.bhlfy);--?????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 64, cell.r, rec_data.sbzfzje);--????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 65, cell.r, rec_data.qtdsfzfje);--???????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 66, cell.r, rec_data.mflx);--????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 67, cell.r, rec_data.mpe);--???
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 68, cell.r, rec_data.zpajl);--????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 69, cell.r, rec_data.sjpfje);--????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 70, cell.r, rec_data.cph);--????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 71, cell.r, rec_data.cpmc);--????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 72, cell.r, rec_data.zrbm);--????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 73, cell.r, rec_data.zrmc);--????
          insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 74, cell.r, rec_data.pfrq);--????


         cell.r :=  cell.r+1;


  end loop;


  --???????????
  /*9.??*/
  PReturnCode := '0'; /* ??????????????vstatid????????? */
  PReturnMsg  := vstatid;
  DBMS_OUTPUT.PUT_LINE('[LDS debug] ' || 'PReturncode= ' || PReturnCode);
  --COMMIT; ???java?????????

EXCEPTION
  WHEN OTHERS THEN
    --rollback;???java?????????????0?????????????????
    PReturnCode := 'E'; /*  ??????  */
    DBMS_OUTPUT.PUT_LINE('[yhs debug] ' || 'PReturncode= ' || PReturnCode);
    PReturnMsg := ' rownum' || cell.r || 'Error:' || sqlerrm; --???????????
    DBMS_OUTPUT.PUT_LINE(PReturnMsg);
end SP_P1_30011;

/
