CREATE PROCEDURE      "SP_P1_30012" (report_id   In t_report_def_info.REPORTID%TYPE,
                                        pStartdate  IN varchar2, -- ??????yyyymmdd
                                        pEnddate    IN varchar2, -- ??????yyyymmdd
                                        pStatman    IN t_report_gen_info.STATMAN%TYPE, --???
                                        ptype       in varchar2, /*0 ???? ,1 ?? 2 ?? 3 ?? */ --?????
                                        POther1     IN varchar2, --??id
                                        POther2     IN varchar2, --??id
                                        POther3     IN varchar2, --??id
                                        POther4     IN varchar2, --??ID
                                        POther5     IN varchar2, --????
                                        POther6     IN varchar2, --??ID
                                        POther7     IN varchar2, --??
                                        POther8     IN varchar2, --??
                                        PReturnCode OUT varchar2,
                                        PReturnMsg  OUT varchar2) AS
  V_STEP_CODE  CHAR(5); --?????????????????
  vreportid    t_report_def_info.REPORTID%TYPE; --??ID
  v_start_date number := 0; --????????
  v_end_date   number := 0; --????????
  vxzqhdm      t_report_gen_info.STATORGID%TYPE; --????????????

  vstatid varchar(30); --?????????????????
  type cellType is record(
    statid  varchar2(15),
    col     number,
    r       number,
    content varchar2(1024));

  cell      cellType; --?????????????
  vdwmc     varchar2(50); --????????????
  vusername t_report_gen_info.STATMAN%TYPE; --????????
  vnd       t_report_gen_info.STATYEAR%TYPE; --????
  rowno     number := 0; --??????



begin
  V_STEP_CODE := '00000';
  PReturnMsg  := 'OK';
  PReturnCode := 'E';
  vreportid   := substr(report_id, 1, 5);
  vusername   := pStatman;
  vnd         := substr(pStartdate, 1, 4);

  v_start_date := to_number(substr(pStartdate, 1, 8));
  v_end_date   := to_number(substr(pEnddate, 1, 8));

  --???????????????????????????
  delete from t_report_data_info
   where statid in
         (select statid from T_REPORT_GEN_INFO where reportid = report_id);

  delete from T_REPORT_GEN_INFO
   where statid in
         (select statid from T_REPORT_GEN_INFO where reportid = report_id);

  V_STEP_CODE := '00001';
  --???,?T_RERORT_GEN_INFO?????????????
  --???????
  select seq_statid.nextval into vstatid from dual;

  -- ??????????
  insert into t_report_gen_info
    (STATID,
     REPORTID,
     STATORGID,
     STATORGNAME,
     STATDATE,
     STATMAN,
     STATYEAR,
     BEGINDATE,
     ENDDATE,
     STAT_OTHER,
     STAT_TYPE)
  values
    (vstatid,
     vreportid,
     '',
     '',
     to_char(sysdate, 'yyyymmdd'),
     vusername,
     vnd,
     v_start_date,
     v_end_date,
     substr(pEnddate, 1, 1),
     trim(ptype));

  /* --?????? ??excel???0?????1??,????0???*/

  --???
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid, 0,1, 2, 'CLGL08');

  --????
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,1,3,to_char(sysdate,'yyyymmdd'));

 cell.statid := vstatid;
  cell.col    := 0; --?1???
  cell.r      := 6; --?8???
  --???????????????????????????????excel????????????????????
  for cur_zpn in (
      select a.bxgsqc,b.ttmc,c.khbdh,d.pch,e.pah,f.zpah,g.zrbm,g.zrmc,f.sjpfje,e.shr,e.jarq
      from tb_bxgsxx a,tb_ttxx b,tb_bdxx c,tb_lppcxx d,tb_lpajxx e,tb_zpaxx f,tb_zrxx g
        where a.bxgsid = c.bxgsid
        and b.ttid = c.ttid
        and d.ttid = b.ttid
        and d.bxgsid = c.bxgsid
        and e.lppcid(+) = d.pcid
        and f.ajid(+) = e.ajid
        and g.zrid = f.zrid
        and a.bxgsid = e.bxgsid
        and b.ttid = c.ttid
        and c.khbdh=e.khbdh
        and a.bxgsid = nvl(trim(POther1), a.bxgsid)
        and c.khbdh = nvl(trim(POther2), c.khbdh)
        and f.Sfsdtj = 1--??????
    group by a.bxgsqc,b.ttmc,c.khbdh,d.pch,e.pah,f.zpah,g.zrbm,g.zrmc,f.sjpfje,e.shr,e.jarq
    order by a.bxgsqc,b.ttmc,c.khbdh,d.pch,e.pah,f.zpah,g.zrbm,g.zrmc,f.sjpfje,e.shr,e.jarq
  ) loop
      --????
      insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 0, cell.r, cur_zpn.bxgsqc);

      --????
      insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 1, cell.r, cur_zpn.ttmc);

      --???
      insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 2, cell.r, cur_zpn.khbdh);

      --???
      insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 3, cell.r, cur_zpn.pch);

      --???
      insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 4, cell.r, cur_zpn.pah);

      --????
      insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 5, cell.r, cur_zpn.zpah);

      --?????????
      insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 6, cell.r, cur_zpn.zrbm);

      --?????????
      insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 7, cell.r, cur_zpn.zrmc);

      --???????
      insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 8, cell.r, cur_zpn.sjpfje);

      --???
      insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 9, cell.r, cur_zpn.shr);

      --????
      insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 10, cell.r, cur_zpn.jarq);

      cell.r := cell.r+1;
  end loop;


  --???????????
  /*9.??*/
  PReturnCode := '0'; /* ??????????????vstatid????????? */
  PReturnMsg  := vstatid;
  DBMS_OUTPUT.PUT_LINE('[LDS debug] ' || 'PReturncode= ' || PReturnCode);
  --COMMIT; ???java?????????

EXCEPTION
  WHEN OTHERS THEN
    --rollback;???java?????????????0?????????????????
    PReturnCode := 'E'; /*  ??????  */
    DBMS_OUTPUT.PUT_LINE('[yhs debug] ' || 'PReturncode= ' || PReturnCode);
    PReturnMsg := ' rownum' || cell.r || 'Error:' || sqlerrm; --???????????
    DBMS_OUTPUT.PUT_LINE(PReturnMsg);
end SP_P1_30012;

/
