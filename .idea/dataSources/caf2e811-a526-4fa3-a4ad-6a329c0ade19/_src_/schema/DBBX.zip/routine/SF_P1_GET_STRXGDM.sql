CREATE FUNCTION      "SF_P1_GET_STRXGDM" (p_ZRBHS in varchar2) return varchar2 is
cursor cur_rec is select b.aaa102,trim(b.aaa103) as aaa103 from aa10 b where p_ZRBHS like '%'|| trim(b.aaa102)||'%'   and b.aaa100='RGXGDM';
Result varchar2(1024):='' ;
BEGIN

 if length(trim(p_ZRBHS))=0 then
    Result:='?';

  end if;

  for rec in cur_rec loop
     Result:=Result||rec.aaa103||',';
  end loop;
  Result:=substr(Result,1,length(trim(Result))-1);
--dbms_output.put_line(Result);
return(Result);
END SF_P1_GET_STRXGDM;

/
