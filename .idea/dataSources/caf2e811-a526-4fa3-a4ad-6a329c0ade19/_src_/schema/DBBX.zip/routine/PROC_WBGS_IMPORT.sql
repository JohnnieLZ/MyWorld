CREATE PROCEDURE      PROC_WBGS_IMPORT(p_Wbdrbwid IN VARCHAR2, p_RtnCode OUT NUMBER, p_RtnMsg OUT VARCHAR2) IS
/*
 *@version 1.1 update by zhangjunpeng ??????????????  20150413
 *@version 1.2 update by zhangjunpeng ??????id?????      20150413
 *@version 1.2.1 update by yhs MZ150415-01 ???????????????????+????<>??+????????????????????=0?????????
 *@version 1.2.2 update by yhs  ????????????????
 *@version 1.3 update zhangjunpeng ?????????????????? 2015-5-22
 *@version 1.4 update by yhs ?????????????????+MZ150413-02?????????????????????????????????`???? 2015-5-27
 *@version 1.5 update by zhangjunpeng MZ150430-04 ?????????????????????????????
 *@version 1.6 update by zhangjunpeng MZ150604-04 ??????????????????  2015-6-4
 *@version 1.7 update by zhangjunpeng MZ150605-02 ??????????????????????????  2015-6-5
 *@version 1.8 update by zhangjunpeng ???????????????? 2015-6-11
 *@version 1.9 update by zhangjunpeng MZ150611-02 ??????????????? 2015-6-11
 *@version 2.0 update by zhangjunpeng ?????????? 2015-6-29
 *@version 2.1 update by zhangjunpeng MZ150724-03 ????????????????????????? 2015-8-14
 @version 2.2 update by yhs  ???????????????????????????? 2015-8-31?????????????
 *@version 2.3 update by chenjiandong ???????????????????????????????????????????
 */
  i_Count  NUMBER(9) := 0;
  i_step  NUMBER(9) := 0;
  rec_ajxx TB_WBGS_IMPORT_PAINFO%rowtype;--???????????????
  rec_fpxx TB_WBGS_IMPORT_FPXX%rowtype;--???????????????
  rec_fpxxfyxx TB_WBGS_IMPORT_FPXXFYXX%rowtype;--???????????????????
  v_Ajid tb_lpajxx.ajid%type := 0;
  n_Fpid   NUMBER(16);
  n_wbdrfpid number(16):=0; -- +V1.2
  v_bxgsid TB_LPAJXX.BXGSID%type :=0; -- +V1.3
  v_sfblc tb_lpajxx.sfblc%type :='0';   --+V1.5
  v_ajzt tb_lpajxx.ajzt%type :='';   --+V2.0
 -- v_zbbrgx tb_fdxx.zbbrgx%type :='00';   --+V1.5   -- -V1.8
  /*s_Qtsblx VARCHAR2(32);------??????
  s_Dsfzflx VARCHAR2(32);----???????*/
  s_Qtsblx VARCHAR2(200);------??????
  s_Dsfzflx VARCHAR2(200);----???????
  sSfsyybk  VARCHAR2(1);--???????
  CURSOR c_Ajxx IS
    SELECT  A.PAH,A.WBDRBWAJID,A.DSFPFBZ,A.BXGSMC,A.PFJE
    FROM TB_WBGS_IMPORT_PAINFO A, TB_WBGS_IMPORT_LOG B
    WHERE A.WBDRBWID=p_Wbdrbwid
    AND A.WBDRBWID = B.WBDRBWID
    AND B.CLJG='0';

  CURSOR c_Fpxx(p_Pah VARCHAR2) IS
    SELECT DISTINCT A.WBDRFPID,A.YBLX
    FROM TB_WBGS_IMPORT_FPXX A,TB_WBGS_IMPORT_PAINFO B
    WHERE A.WBDRBWID=p_Wbdrbwid
    AND A.WBDRBWAJID = B.WBDRBWAJID
    AND A.WBDRBWID = B.WBDRBWID
    AND B.PAH=p_Pah;
s_Sfdzbc VARCHAR2(1):='0';------20130331 ??? ??????
s_Sfqlc  VARCHAR2(1):='0';--20130331  ??? ??????

 preturncode varchar2(20):='E';--20150404 added by yhs  ????????????????
 preturnmsg varchar2(255):='ok';--20150404 added by yhs ????????????????
 myException Exception;--????????????????????????????
 --v2.2++ begin
 v_kfckxzqhdm varchar2(10):='';
 v_kfcklx  varchar2(2):='';
 --v2.2++ end
BEGIN
  --0.?????
    i_step := 0;
    i_Count := 0;
    p_RtnCode := 0;
    p_RtnMsg := '????';
    s_Qtsblx := '';
    s_Dsfzflx := '';


   -----???????
    FOR cc IN c_Ajxx LOOP
      i_step := 1;
      SELECT *  INTO rec_ajxx FROM  TB_WBGS_IMPORT_PAINFO WHERE WBDRBWAJID=cc.WBDRBWAJID;
      select nvl(t.ajid,0) into v_Ajid from tb_lpajxx t where t.pah = cc.pah;
      select nvl(t.bxgsid,0) into v_bxgsid from tb_lpajxx t where t.pah = cc.pah;  -- +V1.3
      select nvl(t.sfblc,0) into v_sfblc from tb_lpajxx t where t.pah= cc.pah;  --+V1.5
      /********************-- +V2.0 start******************************/
      select nvl(t.ajzt,'XX') into v_ajzt from tb_lpajxx t where t.pah = cc.pah;
      if v_ajzt <> '00' and v_ajzt <> '01' then
        update tb_wbgs_import_log t set t.cljg = 'N',t.sbyy = '??????????????????'
         where t.wbdrbwid = p_Wbdrbwid;
         commit;
        exit;
      end if;
      v_ajzt:='';
      /********************-- +V2.0 end*****************************/
      ----??????????
      i_step := 2;
      if v_sfblc = '1' then   --+V1.5
      UPDATE TB_LPAJXX T
      SET T.BBRXM = rec_ajxx.XM,
          T.BBRKHID = (SELECT KHID FROM TB_KHXX WHERE XM = rec_ajxx.XM AND AAC147 = rec_ajxx.ZJHM AND ROWNUM=1),
          T.BBRZJH = DECODE(rec_ajxx.ZJHM,'??','',rec_ajxx.ZJHM),
          --T.ZLDBZ = ?
          --T.ZBBRKHID = ?
          --T.KHBDH = ?
          --T.FDID =
          T.SQRZJLX = DECODE(rec_ajxx.SQRZJLX,'99','',rec_ajxx.SQRZJLX),
          T.SQRZJHM = DECODE(rec_ajxx.SQRZJHM,'??','',rec_ajxx.SQRZJHM),
          T.SQRXM = rec_ajxx.SQRXM,
          T.SQRSJ = rec_ajxx.SQRYDDH,
          T.SQRDZ = DECODE(rec_ajxx.SQRLXDZ,'??','',rec_ajxx.SQRLXDZ),
          T.SQRYX = rec_ajxx.SQRYX,
          T.SQLX = rec_ajxx.SQLX,
          T.SQRQ = DECODE(pkg_jkbx_util.f_is_number(rec_ajxx.BARQ),'Y',decode(rec_ajxx.BARQ,'99991231','',to_number(rec_ajxx.BARQ)),''),
          T.ZBBRGX = DECODE(rec_ajxx.GX,'99','',rec_ajxx.GX),
          --T.BBRSCZT = ?
          --T.BBRCJDM = ?
          --T.BBRCJXM = ?
          --T.BBRCJDJ = ?
          --T.BBRSWRQ = ?
          --T.BBRYWSGFSRQ = ?
          T.AJPFJE = NULL,
          --T.LPJSYR = ?
          T.AJPFFS = rec_ajxx.ZFFS,
          T.FPS = rec_ajxx.FPSL,
          T.YWSGDD = DECODE(rec_ajxx.CXDQ,'1','????','9','??'),
          T.YWSGYY = rec_ajxx.CXLX,
          T.LPKGFKHH = rec_ajxx.YHMC,
          T.LPKGFYHZH = rec_ajxx.YHZH,
          T.SKFXM = rec_ajxx.ZHMC,
          T.WBDRRQ = TO_NUMBER(TO_CHAR(SYSDATE,'YYYYMMDD')),
         ( T.lrrid,t.lrr)=(select userid,name from uap_user where (loginname,name) in(select fbsbh,wbgsmc from tb_wbgsxx where wbgsid=t.wbgsid))
          --T.SSWBYY = ?
      WHERE T.AJID = (SELECT AJID FROM TB_LPAJXX WHERE PAH=rec_ajxx.PAH);

      -------????????????
      i_step := 22;
      UPDATE TB_AJQTXX S
      SET S.SQRXB = rec_ajxx.SQRXB,
          S.SQRYB = DECODE(rec_ajxx.SQRYZBM,'000000','',rec_ajxx.SQRYZBM),
          S.AAC058 = DECODE(rec_ajxx.ZJLX,'99','',rec_ajxx.ZJLX),
          S.AAC004 = rec_ajxx.XB,
          S.BARQ = DECODE(pkg_jkbx_util.f_is_number(rec_ajxx.BARQ),'Y',decode(rec_ajxx.BARQ,'99991231','',to_number(rec_ajxx.BARQ)),''),
          S.CXRQ = DECODE(rec_ajxx.CXRQ,'99991231','',rec_ajxx.CXRQ),
          --S.CCJZRQ = ?
          S.CXJG = rec_ajxx.CXJG,
          S.SCJDRQ = rec_ajxx.SCJDRQ,
          --S.LKRLX = ?
          S.LKRLX = DECODE(rec_ajxx.lkfz,'1','01','2','02',rec_ajxx.lkfz),  -- +V1.6          --S.SQLX2 = rec_ajxx.SQLX?
          S.SYRSL = rec_ajxx.LKRGS,
          S.BBRZJYXQS = rec_ajxx.ZJYXQQ,
          S.BBRZJYXQZ = rec_ajxx.ZJYXQZ,
          S.SQRZJYXQS = rec_ajxx.ZJYXQQ2,
          S.SQRZJYXQZ = rec_ajxx.ZJYXQZ2,
          S.BBRZY = rec_ajxx.ZY,
          S.BBRGZDW = rec_ajxx.GZDW,
          S.SFYYJSDZYJ = rec_ajxx.SFYJ,
          --S.LPKGFFH = rec_ajxx.KHHFH,  -- -V1.3
          --S.LPKGFZH = rec_ajxx.KHHZH,  -- -V1.3
          S.LPKGFFH = case when v_bxgsid=945 then rec_ajxx.khhsheng  else rec_ajxx.KHHFH end,  -- +V1.3
          S.LPKGFZH = case when v_bxgsid=945 then rec_ajxx.kkhshi else rec_ajxx.KHHZH end,     -- +V1.3
          S.SFTJ = rec_ajxx.SFTJ
          --S.SFXYSCYX = ?
        WHERE S.AJID = (SELECT AJID FROM TB_LPAJXX WHERE PAH=rec_ajxx.PAH);
         v_bxgsid:=0; -- +V1.3
         /*******************-- +V1.5 start************************/
         else
/*             select nvl(t.zbbrgx,'00') into v_zbbrgx from tb_fdxx t where exists (select 1 from tb_lpajxx a where a.fdid = t.fdid and a.pah = rec_ajxx.PAH);
      if v_zbbrgx = '03' then  -- -V1.8*/
            UPDATE TB_LPAJXX T
      SET
         -- T.SQRZJLX = DECODE(rec_ajxx.SQRZJLX,'99','',rec_ajxx.SQRZJLX),
         -- T.SQRZJHM = DECODE(rec_ajxx.SQRZJHM,'??','',rec_ajxx.SQRZJHM),
       --   T.SQRXM = rec_ajxx.SQRXM,
          T.SQRSJ = rec_ajxx.SQRYDDH,
          T.SQRDZ = DECODE(rec_ajxx.SQRLXDZ,'??','',rec_ajxx.SQRLXDZ),
          T.SQRYX = rec_ajxx.SQRYX,
          T.SQLX = rec_ajxx.SQLX,
          T.SQRQ = DECODE(pkg_jkbx_util.f_is_number(rec_ajxx.BARQ),'Y',decode(rec_ajxx.BARQ,'99991231','',to_number(rec_ajxx.BARQ)),''),
          T.ZBBRGX = DECODE(rec_ajxx.GX,'99','',rec_ajxx.GX),
          T.AJPFJE = NULL,
          T.AJPFFS = rec_ajxx.ZFFS,
          T.FPS = rec_ajxx.FPSL,
          T.YWSGDD = DECODE(rec_ajxx.CXDQ,'1','????','9','??'),
          T.YWSGYY = rec_ajxx.CXLX,
          T.LPKGFKHH = rec_ajxx.YHMC,
          T.LPKGFYHZH = rec_ajxx.YHZH,
          T.SKFXM = rec_ajxx.ZHMC,
          T.WBDRRQ = TO_NUMBER(TO_CHAR(SYSDATE,'YYYYMMDD')),
         ( T.lrrid,t.lrr)=(select userid,name from uap_user where (loginname,name) in(select fbsbh,wbgsmc from tb_wbgsxx where wbgsid=t.wbgsid))
      WHERE T.AJID = (SELECT AJID FROM TB_LPAJXX WHERE PAH=rec_ajxx.PAH);

        UPDATE TB_AJQTXX S
      SET --S.SQRXB = rec_ajxx.SQRXB,
          S.SQRYB = DECODE(rec_ajxx.SQRYZBM,'000000','',rec_ajxx.SQRYZBM),
          S.AAC058 = DECODE(rec_ajxx.ZJLX,'99','',rec_ajxx.ZJLX),
         -- S.AAC004 = rec_ajxx.XB,
          S.BARQ = DECODE(pkg_jkbx_util.f_is_number(rec_ajxx.BARQ),'Y',decode(rec_ajxx.BARQ,'99991231','',to_number(rec_ajxx.BARQ)),''),
          S.CXRQ = DECODE(rec_ajxx.CXRQ,'99991231','',rec_ajxx.CXRQ),
          S.CXJG = rec_ajxx.CXJG,
          S.SCJDRQ = rec_ajxx.SCJDRQ,
          S.SYRSL = rec_ajxx.LKRGS,
          S.BBRZJYXQS = rec_ajxx.ZJYXQQ,
          S.BBRZJYXQZ = rec_ajxx.ZJYXQZ,
          S.SQRZJYXQS = rec_ajxx.ZJYXQQ2,
          S.SQRZJYXQZ = rec_ajxx.ZJYXQZ2,
          S.BBRZY = rec_ajxx.ZY,
          S.BBRGZDW = rec_ajxx.GZDW,
          S.SFYYJSDZYJ = rec_ajxx.SFYJ,
          S.LPKGFFH = rec_ajxx.KHHFH,
          S.LPKGFZH = rec_ajxx.KHHZH,
          S.LKRLX = DECODE(rec_ajxx.lkfz,'1','01','2','02',rec_ajxx.lkfz),  -- +V1.6
          S.SFTJ = rec_ajxx.SFTJ
        WHERE S.AJID = (SELECT AJID FROM TB_LPAJXX WHERE PAH=rec_ajxx.PAH);
     /*   else
                      UPDATE TB_LPAJXX T
      SET
          T.SQRZJLX = DECODE(rec_ajxx.SQRZJLX,'99','',rec_ajxx.SQRZJLX),
          T.SQRZJHM = DECODE(rec_ajxx.SQRZJHM,'??','',rec_ajxx.SQRZJHM),
          T.SQRXM = rec_ajxx.SQRXM,
          T.SQRSJ = rec_ajxx.SQRYDDH,
          T.SQRDZ = DECODE(rec_ajxx.SQRLXDZ,'??','',rec_ajxx.SQRLXDZ),
          T.SQRYX = rec_ajxx.SQRYX,
          T.SQLX = rec_ajxx.SQLX,
          T.SQRQ = DECODE(pkg_jkbx_util.f_is_number(rec_ajxx.BARQ),'Y',decode(rec_ajxx.BARQ,'99991231','',to_number(rec_ajxx.BARQ)),''),
          T.ZBBRGX = DECODE(rec_ajxx.GX,'99','',rec_ajxx.GX),
          T.AJPFJE = NULL,
          T.AJPFFS = rec_ajxx.ZFFS,
          T.FPS = rec_ajxx.FPSL,
          T.YWSGDD = DECODE(rec_ajxx.CXDQ,'1','????','9','??'),
          T.YWSGYY = rec_ajxx.CXLX,
          T.LPKGFKHH = rec_ajxx.YHMC,
          T.LPKGFYHZH = rec_ajxx.YHZH,
          T.SKFXM = rec_ajxx.ZHMC,
          T.WBDRRQ = TO_NUMBER(TO_CHAR(SYSDATE,'YYYYMMDD')),
         ( T.lrrid,t.lrr)=(select userid,name from uap_user where (loginname,name) in(select fbsbh,wbgsmc from tb_wbgsxx where wbgsid=t.wbgsid))
      WHERE T.AJID = (SELECT AJID FROM TB_LPAJXX WHERE PAH=rec_ajxx.PAH);

        UPDATE TB_AJQTXX S
      SET S.SQRXB = rec_ajxx.SQRXB,
          S.SQRYB = DECODE(rec_ajxx.SQRYZBM,'000000','',rec_ajxx.SQRYZBM),
          S.AAC058 = DECODE(rec_ajxx.ZJLX,'99','',rec_ajxx.ZJLX),
          S.AAC004 = rec_ajxx.XB,
          S.BARQ = DECODE(pkg_jkbx_util.f_is_number(rec_ajxx.BARQ),'Y',decode(rec_ajxx.BARQ,'99991231','',to_number(rec_ajxx.BARQ)),''),
          S.CXRQ = DECODE(rec_ajxx.CXRQ,'99991231','',rec_ajxx.CXRQ),
          S.CXJG = rec_ajxx.CXJG,
          S.SCJDRQ = rec_ajxx.SCJDRQ,
          S.SYRSL = rec_ajxx.LKRGS,
          S.BBRZJYXQS = rec_ajxx.ZJYXQQ,
          S.BBRZJYXQZ = rec_ajxx.ZJYXQZ,
          S.SQRZJYXQS = rec_ajxx.ZJYXQQ2,
          S.SQRZJYXQZ = rec_ajxx.ZJYXQZ2,
          S.BBRZY = rec_ajxx.ZY,
          S.BBRGZDW = rec_ajxx.GZDW,
          S.SFYYJSDZYJ = rec_ajxx.SFYJ,
          S.LPKGFFH = rec_ajxx.KHHFH,
          S.LPKGFZH = rec_ajxx.KHHZH,
          S.LKRLX = DECODE(rec_ajxx.lkfz,'1','01','2','02',rec_ajxx.lkfz),  -- +V1.6
          S.SFTJ = rec_ajxx.SFTJ
        WHERE S.AJID = (SELECT AJID FROM TB_LPAJXX WHERE PAH=rec_ajxx.PAH);
          end if; -- -V1.8*/
        end if;
         /*******************-- +V1.5 end**************************/
      ----???????--
      FOR ccfp IN c_Fpxx(cc.PAH) LOOP
        i_step := 3;
        SELECT *  INTO rec_fpxx FROM  TB_WBGS_IMPORT_FPXX WHERE WBDRFPID=ccfp.WBDRFPID;
        SELECT SEQ_FPID.NEXTVAL AS FPID INTO n_Fpid FROM DUAL;

        ------??TB_IMAGE_LINKS??????????????????02???YXDYLX
        i_step := 38;
        UPDATE TB_IMAGE_LINKS
        SET YXLB = '02'
        WHERE IMG_NAME=rec_fpxx.FPYXJMC
        AND AJID IN(SELECT AJID FROM TB_LPAJXX WHERE PAH = cc.PAH);

        i_step := 39;
        IF ccfp.YBLX IN('01','03','04','05','06') THEN
          sSfsyybk := '1';
        ELSIF ccfp.YBLX IN('02','07') THEN
          sSfsyybk := '0';
        END IF;

        ------??TB_FPQTSBZFDSFZFMXB------
        ----????--
        IF rec_fpxx.JMYB IS NOT NULL THEN
          i_step := 31;
          INSERT INTO TB_FPQTSBZFDSFZFMXB(FPQTMXID, FPID, LX, MXLX, MXJE)
          SELECT  SEQ_FPQTMXID.NEXTVAL AS FPQTMXID, n_Fpid, '1', '01',NVL(rec_fpxx.JMYB,0)
          FROM DUAL;

          s_Qtsblx := s_Qtsblx || '01,';
        END IF;

        ----???--
        IF rec_fpxx.XNH IS NOT NULL THEN
          i_step := 32;
          INSERT INTO TB_FPQTSBZFDSFZFMXB(FPQTMXID, FPID, LX, MXLX, MXJE)
          SELECT  SEQ_FPQTMXID.NEXTVAL AS FPQTMXID, n_Fpid, '1', '02',NVL(rec_fpxx.XNH,0)
          FROM DUAL;

          s_Qtsblx := s_Qtsblx || '02,';
        END IF;

        ----?????--
        IF rec_fpxx.GWYBZ IS NOT NULL THEN
          i_step := 33;
          INSERT INTO TB_FPQTSBZFDSFZFMXB(FPQTMXID, FPID, LX, MXLX, MXJE)
          SELECT  SEQ_FPQTMXID.NEXTVAL AS FPQTMXID, n_Fpid, '1', '04',NVL(rec_fpxx.GWYBZ,0)
          FROM DUAL;

          s_Qtsblx := s_Qtsblx || '04,';
        END IF;

        ----??????--
        IF rec_fpxx.SYJTZF IS NOT NULL THEN
          i_step := 34;
          INSERT INTO TB_FPQTSBZFDSFZFMXB(FPQTMXID, FPID, LX, MXLX, MXJE)
          SELECT  SEQ_FPQTMXID.NEXTVAL AS FPQTMXID, n_Fpid, '1', '03',NVL(rec_fpxx.SYJTZF,0)
          FROM DUAL;

          s_Qtsblx := s_Qtsblx || '03,';
        END IF;

        ----????/????--
        IF rec_fpxx.YYYH IS NOT NULL THEN
          i_step := 35;
          INSERT INTO TB_FPQTSBZFDSFZFMXB(FPQTMXID, FPID, LX, MXLX, MXJE)
          SELECT  SEQ_FPQTMXID.NEXTVAL AS FPQTMXID, n_Fpid, '1', '05',NVL(rec_fpxx.YYYH,0)
          FROM DUAL;

          s_Qtsblx := s_Qtsblx || '05,';
        END IF;

        ----????????????/????????????--
        IF rec_fpxx.TXBCZF IS NOT NULL THEN
          i_step := 36;
          INSERT INTO TB_FPQTSBZFDSFZFMXB(FPQTMXID, FPID, LX, MXLX, MXJE)
          SELECT  SEQ_FPQTMXID.NEXTVAL AS FPQTMXID, n_Fpid, '1', '06',NVL(rec_fpxx.TXBCZF,0)
          FROM DUAL;

          s_Qtsblx := s_Qtsblx || '06,';
        END IF;

        ---?????[???]??--
        IF rec_fpxx.DWBCXZF IS NOT NULL THEN
          i_step := 37;
          INSERT INTO TB_FPQTSBZFDSFZFMXB(FPQTMXID, FPID, LX, MXLX, MXJE)
          SELECT  SEQ_FPQTMXID.NEXTVAL AS FPQTMXID, n_Fpid, '2', '08',NVL(rec_fpxx.DWBCXZF,0)
          FROM DUAL;

          s_Dsfzflx := s_Dsfzflx || '08,';
        END IF;

        i_step := 4;
        -----???????
        n_wbdrfpid:=ccfp.WBDRFPID; -- +V1.2
        INSERT INTO TB_LPFPXX(
          FPID, AJID, YBJYLSH, FPHM, BBRKHID,
          BBRXM, FPHBLX, ZDLX, JZYY, YYID,
          JZKS, JZKSID, JBDM, FPRQ, JZRQ,
          RYRQ, CYRQ, FPZE, TCZFE, FJZFE,
          SBZFE, GRZFZFE, XJZFE, FLZFZE,
          ZFZE, BHLFY, SFSYYBK, SFYSS,
          XGDM, SFICU, SEQLOGID, JZLSH, ZYH,
          ZYJSKSSJ, ZYJSJSSJ, JYKH, JYKLX, ZDSM,
          JZLX, YBJSLX, CJLSH, SSDM, SJLX,
          QTSBLX, DSFZFLX, DSFZFJE, ZFYJE, QFJE,
          SFAZZY, AZZYTS, ICUZYTS, SFGS,
          FPXM, SFQCL, QCLDM, QCLSM,
          CSBZ, CDEJE, FPLYSFYC,
          LRCCYY, LRCCBZ, ZYTS, FPYXID, BLYXID)
        SELECT
          n_Fpid AS FPID,(SELECT AJID FROM TB_LPAJXX WHERE PAH=rec_ajxx.PAH)AJID, NULL, T.FPH AS FPHM, (SELECT BBRKHID FROM TB_LPAJXX WHERE PAH=rec_ajxx.PAH),
          T.FPXM AS BBRXM, NULL, T.FFPX AS ZDLX, T.JZYYMC AS JZYY, DECODE(T.JZYYID,-99,'',T.JZYYID) AS YYID,
          T.JZKS AS JZKS, NULL, T.ZDDM AS JBDM, NULL, NVL(T.RYRQ,T.JZRQ) AS JZRQ,
          T.RYRQ AS RYRQ, T.CYRQ AS CYRQ, T.FPZJE AS FPZE, T.TCZF AS TCZFE, NVL(T.FJZF,T.MZDEZF) AS FJZFE,
          (SELECT SUM(MXJE) FROM TB_FPQTSBZFDSFZFMXB WHERE LX='1' AND FPID=n_Fpid) AS SBZFE, T.ZHZF AS GRZFZFE, T.XJZF AS XJZFE, T.FLZF AS FLZFZE,
          T.ZIFEI AS ZFZE,NULL AS BHLFY, sSfsyybk AS SFSYYBK,NULL,
          NULL, '0',NULL,NULL,NULL,
          NULL, NULL, NULL, NULL, NULL,
          NULL, NULL, NULL, NULL, T.YBLX,
          SUBSTR(1,LENGTH(s_Qtsblx)-1) AS QTSBLX, SUBSTR(1,LENGTH(s_Dsfzflx)-1) AS DSFZFLX, (SELECT SUM(MXJE) FROM TB_FPQTSBZFDSFZFMXB WHERE LX='2' AND FPID=n_Fpid) AS DSFZFJE, NVL(T.ZIFU,0)AS ZFYJE, NVL(T.QFJE,0)AS QFJE,
          NULL, NULL, NULL, NULL,
          T.FPXM, NULL, NULL, NULL,
          NULL, T.CFDJE, NULL,
          NULL, NULL, T.ZYTS, (SELECT n.IMG_ID FROM TB_IMAGE_LINKS n WHERE n.IMG_NAME=T.FPYXJMC and exists (select 1 from tb_lpajxx m where m.ajid = n.ajid and m.pah = rec_ajxx.PAH))FPYXID,(SELECT n.IMG_ID FROM TB_IMAGE_LINKS n WHERE n.IMG_NAME=T.ZDYXJMC and exists (select 1 from tb_lpajxx m where m.ajid = n.ajid and m.pah = rec_ajxx.PAH) )BLYXID
        FROM TB_WBGS_IMPORT_FPXX T
        WHERE T.WBDRFPID = ccfp.WBDRFPID;


        i_step := 5;
        -----???????
        INSERT INTO TB_FPFYDLXX(
          FPID, AJID, BEN_RECEIPT_AMT, REGISTER_FEE,
          WESTERN_MED_FEE, CHINESE_MED_FEE,  HERBAL_MED_FEE,
          TEST_FEE, X_RAY_FEE, B_SONIC_FEE, CT_FEE,
          MRI_FEE, EXAMINE_FEE, CURE_FEE, MATERIAL_FEE,
          SURGERY_FEE, OXYGEN_FEE, TRANSFUSE_FEE, REMEDY_FEE,
          PROSTH_FEE, LAW_AUTH_FEE, BED_FEE, NURSE_FEE, HOSPITAL_FEE,
          URGENT_SAVE_FEE, AMBULANCE_FEE, NATION_MED_FEE, SELF_MADE_FEE,
          PRESCRIPTION_FEE, OTHER_FEE, DEMZNLJZF, DEZYNLJZF,
          TCJJNLJZF, LJYBFWNJE, CJJRBZZF, YLBXJJZF)
        SELECT
          n_Fpid AS FPID,(SELECT AJID FROM TB_LPAJXX WHERE PAH=rec_ajxx.PAH)AJID, T.FPZJE AS FPZE, T.REGISTER_FEE,
          T.XYF, T.ZCHENGYF, T.ZCAOYF,
          T.HYF, T.FSF, T.BCF, T.CTF,
          T.TJF, T.JCF, T.ZLF, T.CLF,
          T.SSF, T.SYF, T.SXF, T.ZJF,
          T.XYAF, T.SFJD, T.CWF, T.HLF,T.ZCF,
          T.QJF, T.JHCF, T.MZYF, T.ZZYJ,
          T.BZCFF, T.QTFY, T.NDMZDELJZF, T.DEHZLJ,
          T.TCJJLJ, T.YBFWNFYLJ, T.CJBZZF, T.JJZF
        FROM TB_WBGS_IMPORT_FPXX T
        WHERE T.WBDRFPID = ccfp.WBDRFPID;

        i_step := 6;
        -----???????
        INSERT INTO TB_FPXXFYXX(
          XXID, FPID, DXDM, DXMC,
          TYID, XMLB, XXDM, XXMC,
          ZDJE, ZDDM, SBZFJE, ZFJE,
          FLZFJE, BHLJE, JFLY, BZ2,
          ZPAID, TCZFE, FJZFE, SBZFE,
          MXXMGG, MXXMDW, MXXMDJ, MXXMSL,
          YYCLPP, ZCZH, SEQLOGID, SBZFLB,
          SJZFBL, ZFBZ, ZFBL, CDEJE,
          CLFBM, CLFMC,xxjx)
        SELECT
        /*******************-- +V2.3 start************************/
        ------is null ????????trim()???------
          SEQ_XXID.NEXTVAL, n_Fpid AS FPID, case when trim(t.dxmc) is null or not exists(select 'x' from aa10 where aaa100='FYLB' and aaa103=t.dxmc) then nvl((select dxdm from v_zlxm where TO_CHAR(TYID) = t.xmbm and xmmc = t.xmmc and rownum = 1),'XX') else  NVL((SELECT AAA102 FROM AA10 WHERE AAA100='FYLB' AND AAA103=T.DXMC),'XX') end AS DXDM,
          case when trim(t.dxmc) is null or not exists(select 'x' from aa10 where aaa100='FYLB' and aaa103=t.dxmc) then nvl((select dxmc from v_zlxm where TO_CHAR(TYID) = t.xmbm and xmmc = t.xmmc and rownum = 1),'XX') else t.dxmc end AS DXMC,
        /*******************-- +V2.3 end************************/
          decode(pkg_jkbx_util.f_is_number(T.XMBM),'N',null,to_number(T.XMBM)), (SELECT  MAX(ZLXMLB) FROM V_ZLXM WHERE TRIM(TO_CHAR(TYID)) = T.XMBM AND XMMC=T.XMMC),DECODE(T.DXMC,'???','13',(SELECT MAX(XMBM) FROM V_ZLXM WHERE TRIM(TO_CHAR(TYID)) = T.XMBM AND XMMC=T.XMMC)),DECODE(T.DXMC,'???','???',T.XMMC),
          T.XXJE,rec_fpxx.ZDDM, NULL, DECODE(T.ZFJE,-99,NULL,T.ZFJE),
          DECODE(T.FLZFJE,-99,NULL,T.FLZFJE), NULL, NULL, NULL,
          NULL, NULL,NULL,NULL,
          T.XXGG, T.XXDW,DECODE(SIGN(INSTR(T.XXDJ,'.')),'1',(TO_CHAR(T.XXDJ,'FM99999990.9999')),T.XXDJ)AS XXDJ,T.XXSL,
          NULL, NULL,NULL,DECODE(T.XXYBLX,'9','',T.XXYBLX),
          DECODE(T.XXZFBL,-99,NULL,T.XXZFBL), NULL,NULL,NULL,
          /*DECODE(T.DXMC,'???',*/DECODE((SELECT MAX(XMBM) FROM V_ZLXM WHERE TRIM(TO_CHAR(TYID)) = T.XMBM AND XMMC=T.XMMC),NULL,T.XMBM,(SELECT MAX(XMBM) FROM V_ZLXM WHERE TRIM(TO_CHAR(TYID)) = T.XMBM AND XMMC=T.XMMC)),/*NULL),DECODE(T.DXMC,'???',*/T.XMMC/*,NULL)*/,t.xxjx
        FROM TB_WBGS_IMPORT_FPXXFYXX T
        WHERE T.WBDRFPID = rec_fpxx.WBDRFPID;

      END LOOP;
     /*v2.2++???????????????????????????? begin */
     --?????????
     select  (select kfcklx from tb_bdxx where khbdh=b.khbdh) as kfcklx,
     (select decode (nvl(kfcklx,'1'),'1' , '','2' , cbdqh,'3',KFZDQH,'') as kfckxzqhdm from tb_bdxx where khbdh=b.khbdh) as kfckxzqhdm into v_kfcklx,v_kfckxzqhdm from
     tb_lpajxx b where  ajid=v_ajid ;
     --??????????????????????????????????????????
     if v_kfcklx in('2','3') and v_kfckxzqhdm is not null then
          --???????? begin
         --??????
        update tb_fpxxfyxx a set SFXTZDKF=case when  nvl(a.SJZFBL,0)=0  and a.sbzflb is null then '1' else '0' end,
           (FLZFJE,ZFJE,SBZFLB,SJZFBL, ZFBZ,ZFBL)=(select case when nvl(a.FLZFJE,0)=0 then case when (m.zfje!='2' and nvl(m.zfbl,0)<100)  then round(a.zdje*nvl(m.zfbl,0)/100,2) else null end else a.flzfje end as  FLZFJE,
           case when nvl(a.zfje,0)=0 then case when (m.zfje='2' or nvl(m.zfbl,0)>=100)  then a.zdje else null end else a.zfje end as  ZFJE,
           nvl(a.SBZFLB ,m.zfje ) as SBZFLB,case when nvl(a.SJZFBL,0)=0 then m.zfbl else a.SJZFBL end  as SJZFBL,  m.zfje as zfbz,m.zfbl as ZFBL
            from tb_ypybmlxx m,tb_ypjbxx n
          where m.ypid=n.ypid and n.xzqh=v_kfckxzqhdm and n.JBYPBM=a.xxdm and rownum<2)
          where fpid in(select fpid from tb_lpfpxx where ajid=v_ajid) /*and nvl(a.SJZFBL,0)=0
          and a.sbzflb is null and nvl(a.SJZFBL,0)=0 and a.sbzflb is null */
          and a.xxdm is not null and a.xxdm!=a.dxdm
          and a.xmlb='2'
          and exists(select 'x' from tb_ypjbxx where JBYPBM=a.xxdm and xzqh = v_kfckxzqhdm);
          --????????
            update tb_fpxxfyxx a set SFXTZDKF=case when  nvl(a.SJZFBL,0)=0  and a.sbzflb is null then '1' else '0' end, (FLZFJE,ZFJE,SBZFLB,SJZFBL, ZFBZ,ZFBL)=( select case when nvl(a.FLZFJE,0)=0 then case when (m.ZFBZ!='2' and nvl(m.zfbl,0)<100)  then round(a.zdje*nvl(m.zfbl,0)/100,2) else null end else a.FLZFJE end as  FLZFJE,
           case when nvl(a.zfje,0)=0 then   case when (m.ZFBZ='2' or nvl(m.zfbl,0)>=100)  then a.zdje else null end else a.zfje end as  ZFJE,
            nvl(a.SBZFLB ,m.ZFBZ ) as SBZFLB,case when nvl(a.SJZFBL,0)=0 then m.zfbl else a.SJZFBL end as SJZFBL,  m.ZFBZ as zfbz,m.zfbl as ZFBL
            from tb_zlxmxx m where m.xzqh=v_kfckxzqhdm and m.RSBXMBM=a.xxdm and rownum<2)
          where fpid in(select fpid from tb_lpfpxx where ajid=v_ajid) and nvl(a.SJZFBL,0)=0 and a.sbzflb is null
          and a.xxdm is not null and a.xxdm!=a.dxdm
          and a.xmlb='1'
          and exists(select 'x' from  tb_zlxmxx where xzqh=v_kfckxzqhdm and RSBXMBM=a.xxdm );
          --???????? end

          --????--?????????????
          if v_kfckxzqhdm not like '%0000' and v_kfckxzqhdm not like '__0100' then
              update tb_fpxxfyxx a set SFXTZDKF=case when  nvl(a.SJZFBL,0)=0  and a.sbzflb is null then '1' else '0' end,
               (FLZFJE,ZFJE,SBZFLB,SJZFBL, ZFBZ,ZFBL)=(select case when nvl(a.FLZFJE,0)=0 then case when (m.zfje!='2' and nvl(m.zfbl,0)<100)  then round(a.zdje*nvl(m.zfbl,0)/100,2) else null end else a.flzfje end as  FLZFJE,
               case when nvl(a.zfje,0)=0 then case when (m.zfje='2' or nvl(m.zfbl,0)>=100)  then a.zdje else null end else a.zfje end as  ZFJE,
               nvl(a.SBZFLB ,m.zfje ) as SBZFLB,case when nvl(a.SJZFBL,0)=0 then m.zfbl else a.SJZFBL end  as SJZFBL,  m.zfje as zfbz,m.zfbl as ZFBL
                from tb_ypybmlxx m,tb_ypjbxx n
              where m.ypid=n.ypid and n.xzqh=substr( v_kfckxzqhdm,1,2)||'0100' and n.JBYPBM=a.xxdm and rownum<2)
              where fpid in(select fpid from tb_lpfpxx where ajid=v_ajid) /*and nvl(a.SJZFBL,0)=0
              and a.sbzflb is null and nvl(a.SJZFBL,0)=0 and a.sbzflb is null */
              and a.xxdm is not null and a.xxdm!=a.dxdm
              and a.xmlb='2'
              and  not exists(select 'x' from tb_ypjbxx where JBYPBM=a.xxdm and xzqh = v_kfckxzqhdm)
              and exists(select 'x' from tb_ypjbxx where JBYPBM=a.xxdm and xzqh =substr( v_kfckxzqhdm,1,2)||'0100');
              --????????
                update tb_fpxxfyxx a set SFXTZDKF=case when  nvl(a.SJZFBL,0)=0  and a.sbzflb is null then '1' else '0' end, (FLZFJE,ZFJE,SBZFLB,SJZFBL, ZFBZ,ZFBL)=( select case when nvl(a.FLZFJE,0)=0 then case when (m.ZFBZ!='2' and nvl(m.zfbl,0)<100)  then round(a.zdje*nvl(m.zfbl,0)/100,2) else null end else a.FLZFJE end as  FLZFJE,
               case when nvl(a.zfje,0)=0 then   case when (m.ZFBZ='2' or nvl(m.zfbl,0)>=100)  then a.zdje else null end else a.zfje end as  ZFJE,
                nvl(a.SBZFLB ,m.ZFBZ ) as SBZFLB,case when nvl(a.SJZFBL,0)=0 then m.zfbl else a.SJZFBL end as SJZFBL,  m.ZFBZ as zfbz,m.zfbl as ZFBL
                from tb_zlxmxx m where m.xzqh=substr(v_kfckxzqhdm,1,2)||'0100' and m.RSBXMBM=a.xxdm and rownum<2)
              where fpid in(select fpid from tb_lpfpxx where ajid=v_ajid) and nvl(a.SJZFBL,0)=0 and a.sbzflb is null
              and a.xxdm is not null and a.xxdm!=a.dxdm
              and a.xmlb='1'
              and not exists(select 'x' from  tb_zlxmxx where xzqh=v_kfckxzqhdm and RSBXMBM=a.xxdm )
              and exists(select 'x' from tb_zlxmxx where RSBXMBM=a.xxdm and xzqh =substr(v_kfckxzqhdm,1,2)||'0100');
         end if;
         --?????????????????????????
          if v_kfckxzqhdm not like '%0000'   then
              update tb_fpxxfyxx a set SFXTZDKF=case when  nvl(a.SJZFBL,0)=0  and a.sbzflb is null then '1' else '0' end,
               (FLZFJE,ZFJE,SBZFLB,SJZFBL, ZFBZ,ZFBL)=(select case when nvl(a.FLZFJE,0)=0 then case when (m.zfje!='2' and nvl(m.zfbl,0)<100)  then round(a.zdje*nvl(m.zfbl,0)/100,2) else null end else a.flzfje end as  FLZFJE,
               case when nvl(a.zfje,0)=0 then case when (m.zfje='2' or nvl(m.zfbl,0)>=100)  then a.zdje else null end else a.zfje end as  ZFJE,
               nvl(a.SBZFLB ,m.zfje ) as SBZFLB,case when nvl(a.SJZFBL,0)=0 then m.zfbl else a.SJZFBL end  as SJZFBL,  m.zfje as zfbz,m.zfbl as ZFBL
                from tb_ypybmlxx m,tb_ypjbxx n
              where m.ypid=n.ypid and n.xzqh=substr(v_kfckxzqhdm,1,2)||'0000' and n.JBYPBM=a.xxdm and rownum<2)
              where fpid in(select fpid from tb_lpfpxx where ajid=v_ajid) /*and nvl(a.SJZFBL,0)=0
              and a.sbzflb is null and nvl(a.SJZFBL,0)=0 and a.sbzflb is null */
              and a.xxdm is not null and a.xxdm!=a.dxdm
              and a.xmlb='2'
              and  not exists(select 'x' from tb_ypjbxx where JBYPBM=a.xxdm and xzqh = v_kfckxzqhdm)
              and not exists(select 'x' from tb_ypjbxx where JBYPBM=a.xxdm and xzqh =substr( v_kfckxzqhdm,1,2)||'0100')
              and exists(select 'x' from tb_ypjbxx where JBYPBM=a.xxdm and xzqh =substr(v_kfckxzqhdm,1,2)||'0000');
              --????????
                update tb_fpxxfyxx a set SFXTZDKF=case when  nvl(a.SJZFBL,0)=0  and a.sbzflb is null then '1' else '0' end, (FLZFJE,ZFJE,SBZFLB,SJZFBL, ZFBZ,ZFBL)=( select case when nvl(a.FLZFJE,0)=0 then case when (m.ZFBZ!='2' and nvl(m.zfbl,0)<100)  then round(a.zdje*nvl(m.zfbl,0)/100,2) else null end else a.FLZFJE end as  FLZFJE,
               case when nvl(a.zfje,0)=0 then   case when (m.ZFBZ='2' or nvl(m.zfbl,0)>=100)  then a.zdje else null end else a.zfje end as  ZFJE,
                nvl(a.SBZFLB ,m.ZFBZ ) as SBZFLB,case when nvl(a.SJZFBL,0)=0 then m.zfbl else a.SJZFBL end as SJZFBL,  m.ZFBZ as zfbz,m.zfbl as ZFBL
                from tb_zlxmxx m where m.xzqh =substr(v_kfckxzqhdm,1,2)||'0000' and m.RSBXMBM=a.xxdm and rownum<2)
              where fpid in(select fpid from tb_lpfpxx where ajid=v_ajid) and nvl(a.SJZFBL,0)=0 and a.sbzflb is null
              and a.xxdm is not null and a.xxdm!=a.dxdm
              and a.xmlb='1'
              and not exists(select 'x' from  tb_zlxmxx where xzqh=v_kfckxzqhdm and RSBXMBM=a.xxdm )
              and not exists(select 'x' from tb_zlxmxx where RSBXMBM=a.xxdm and xzqh =substr(v_kfckxzqhdm,1,2)||'0100')
              and exists(select 'x' from tb_zlxmxx where RSBXMBM=a.xxdm and xzqh =substr(v_kfckxzqhdm,1,2)||'0000');
          end if;

     else  --???????????????????????????????????
         for rec_fp in (select fpid,fphm,yyid,(select xzqhdm from tb_yyxx where yyid=a.yyid ) as kfckxzqhdm from tb_lpfpxx a where ajid=v_ajid and yyid is not null order by fpid asc) loop
            v_kfckxzqhdm:=rec_fp.kfckxzqhdm;
            --???????begin
             --??????
           update tb_fpxxfyxx a set SFXTZDKF=case when  nvl(a.SJZFBL,0)=0  and a.sbzflb is null then '1' else '0' end,(FLZFJE,ZFJE,SBZFLB,SJZFBL, ZFBZ,ZFBL)=( select case when nvl(a.FLZFJE,0)=0 then case when (m.zfje!='2' and nvl(m.zfbl,0)<100)  then round(a.zdje*nvl(m.zfbl,0)/100,2) else null end else a.flzfje end as  FLZFJE,
             case when nvl(a.zfje,0)=0 then case when (m.zfje='2' or nvl(m.zfbl,0)>=100)  then a.zdje else null end else a.zfje end as  ZFJE,
             nvl(a.SBZFLB ,m.zfje ) as SBZFLB,case when nvl(a.SJZFBL,0)=0 then m.zfbl else a.SJZFBL end  as SJZFBL,  m.zfje as zfbz,m.zfbl as ZFBL
              from tb_ypybmlxx m,tb_ypjbxx n
            where m.ypid=n.ypid and n.xzqh=v_kfckxzqhdm and n.JBYPBM=a.xxdm and rownum<2)
            where fpid =rec_fp.fpid /*and nvl(a.SJZFBL,0)=0 and a.sbzflb is null*/
            and a.xxdm is not null and a.xxdm!=a.dxdm
            and a.xmlb='2'
            and exists(select 'x' from tb_ypjbxx where JBYPBM=a.xxdm and xzqh=v_kfckxzqhdm);
            --????????
              update tb_fpxxfyxx a set SFXTZDKF=case when  nvl(a.SJZFBL,0)=0  and a.sbzflb is null then '1' else '0' end, (FLZFJE,ZFJE,SBZFLB,SJZFBL, ZFBZ,ZFBL)=( select case when nvl(a.FLZFJE,0)=0 then case when (m.ZFBZ!='2' and nvl(m.zfbl,0)<100)  then round(a.zdje*nvl(m.zfbl,0)/100,2) else null end else a.FLZFJE end as  FLZFJE,
             case when nvl(a.zfje,0)=0 then   case when (m.ZFBZ='2' or nvl(m.zfbl,0)>=100)  then a.zdje else null end else a.zfje end as  ZFJE,
              nvl(a.SBZFLB ,m.ZFBZ ) as SBZFLB,case when nvl(a.SJZFBL,0)=0 then m.zfbl else a.SJZFBL end as SJZFBL,  m.ZFBZ as zfbz,m.zfbl as ZFBL
              from tb_zlxmxx m where m.xzqh=v_kfckxzqhdm and m.RSBXMBM=a.xxdm and rownum<2)
            where fpid =rec_fp.fpid /*and nvl(a.SJZFBL,0)=0 and a.sbzflb is null */
            and a.xxdm is not null and a.xxdm!=a.dxdm
            and a.xmlb='1'
            and exists(select 'x'  from tb_zlxmxx where xzqh=v_kfckxzqhdm and RSBXMBM=a.xxdm );
          --??????? end
            --????--?????????????
          if v_kfckxzqhdm not like '%0000' and v_kfckxzqhdm not like '__0100' then
              update tb_fpxxfyxx a set SFXTZDKF=case when  nvl(a.SJZFBL,0)=0  and a.sbzflb is null then '1' else '0' end,
               (FLZFJE,ZFJE,SBZFLB,SJZFBL, ZFBZ,ZFBL)=(select case when nvl(a.FLZFJE,0)=0 then case when (m.zfje!='2' and nvl(m.zfbl,0)<100)  then round(a.zdje*nvl(m.zfbl,0)/100,2) else null end else a.flzfje end as  FLZFJE,
               case when nvl(a.zfje,0)=0 then case when (m.zfje='2' or nvl(m.zfbl,0)>=100)  then a.zdje else null end else a.zfje end as  ZFJE,
               nvl(a.SBZFLB ,m.zfje ) as SBZFLB,case when nvl(a.SJZFBL,0)=0 then m.zfbl else a.SJZFBL end  as SJZFBL,  m.zfje as zfbz,m.zfbl as ZFBL
                from tb_ypybmlxx m,tb_ypjbxx n
              where m.ypid=n.ypid and n.xzqh=substr( v_kfckxzqhdm,1,2)||'0100' and n.JBYPBM=a.xxdm and rownum<2)
              where fpid =rec_fp.fpid
              and a.xxdm is not null and a.xxdm!=a.dxdm
              and a.xmlb='2'
              and  not exists(select 'x' from tb_ypjbxx where JBYPBM=a.xxdm and xzqh = v_kfckxzqhdm)
              and exists(select 'x' from tb_ypjbxx where JBYPBM=a.xxdm and xzqh =substr( v_kfckxzqhdm,1,2)||'0100');
              --????????
                update tb_fpxxfyxx a set SFXTZDKF=case when  nvl(a.SJZFBL,0)=0  and a.sbzflb is null then '1' else '0' end, (FLZFJE,ZFJE,SBZFLB,SJZFBL, ZFBZ,ZFBL)=( select case when nvl(a.FLZFJE,0)=0 then case when (m.ZFBZ!='2' and nvl(m.zfbl,0)<100)  then round(a.zdje*nvl(m.zfbl,0)/100,2) else null end else a.FLZFJE end as  FLZFJE,
               case when nvl(a.zfje,0)=0 then   case when (m.ZFBZ='2' or nvl(m.zfbl,0)>=100)  then a.zdje else null end else a.zfje end as  ZFJE,
                nvl(a.SBZFLB ,m.ZFBZ ) as SBZFLB,case when nvl(a.SJZFBL,0)=0 then m.zfbl else a.SJZFBL end as SJZFBL,  m.ZFBZ as zfbz,m.zfbl as ZFBL
                from tb_zlxmxx m where m.xzqh=substr(v_kfckxzqhdm,1,2)||'0100' and m.RSBXMBM=a.xxdm and rownum<2)
              where fpid =rec_fp.fpid
              and a.xxdm is not null and a.xxdm!=a.dxdm
              and a.xmlb='1'
              and not exists(select 'x' from  tb_zlxmxx where xzqh=v_kfckxzqhdm and RSBXMBM=a.xxdm )
              and exists(select 'x' from tb_zlxmxx where RSBXMBM=a.xxdm and xzqh =substr(v_kfckxzqhdm,1,2)||'0100');
         end if;
         --?????????????????????????
          if v_kfckxzqhdm not like '%0000'   then
              update tb_fpxxfyxx a set SFXTZDKF=case when  nvl(a.SJZFBL,0)=0  and a.sbzflb is null then '1' else '0' end,
               (FLZFJE,ZFJE,SBZFLB,SJZFBL, ZFBZ,ZFBL)=(select case when nvl(a.FLZFJE,0)=0 then case when (m.zfje!='2' and nvl(m.zfbl,0)<100)  then round(a.zdje*nvl(m.zfbl,0)/100,2) else null end else a.flzfje end as  FLZFJE,
               case when nvl(a.zfje,0)=0 then case when (m.zfje='2' or nvl(m.zfbl,0)>=100)  then a.zdje else null end else a.zfje end as  ZFJE,
               nvl(a.SBZFLB ,m.zfje ) as SBZFLB,case when nvl(a.SJZFBL,0)=0 then m.zfbl else a.SJZFBL end  as SJZFBL,  m.zfje as zfbz,m.zfbl as ZFBL
                from tb_ypybmlxx m,tb_ypjbxx n
              where m.ypid=n.ypid and n.xzqh=substr(v_kfckxzqhdm,1,2)||'0000' and n.JBYPBM=a.xxdm and rownum<2)
              where fpid =rec_fp.fpid /*and nvl(a.SJZFBL,0)=0
              and a.sbzflb is null and nvl(a.SJZFBL,0)=0 and a.sbzflb is null */
              and a.xxdm is not null and a.xxdm!=a.dxdm
              and a.xmlb='2'
              and  not exists(select 'x' from tb_ypjbxx where JBYPBM=a.xxdm and xzqh = v_kfckxzqhdm)
              and not exists(select 'x' from tb_ypjbxx where JBYPBM=a.xxdm and xzqh =substr( v_kfckxzqhdm,1,2)||'0100')
              and exists(select 'x' from tb_ypjbxx where JBYPBM=a.xxdm and xzqh =substr(v_kfckxzqhdm,1,2)||'0000');
              --????????
                update tb_fpxxfyxx a set SFXTZDKF=case when  nvl(a.SJZFBL,0)=0  and a.sbzflb is null then '1' else '0' end, (FLZFJE,ZFJE,SBZFLB,SJZFBL, ZFBZ,ZFBL)=( select case when nvl(a.FLZFJE,0)=0 then case when (m.ZFBZ!='2' and nvl(m.zfbl,0)<100)  then round(a.zdje*nvl(m.zfbl,0)/100,2) else null end else a.FLZFJE end as  FLZFJE,
               case when nvl(a.zfje,0)=0 then   case when (m.ZFBZ='2' or nvl(m.zfbl,0)>=100)  then a.zdje else null end else a.zfje end as  ZFJE,
                nvl(a.SBZFLB ,m.ZFBZ ) as SBZFLB,case when nvl(a.SJZFBL,0)=0 then m.zfbl else a.SJZFBL end as SJZFBL,  m.ZFBZ as zfbz,m.zfbl as ZFBL
                from tb_zlxmxx m where m.xzqh =substr(v_kfckxzqhdm,1,2)||'0000' and m.RSBXMBM=a.xxdm and rownum<2)
              where fpid =rec_fp.fpid
              and a.xxdm is not null and a.xxdm!=a.dxdm
              and a.xmlb='1'
              and not exists(select 'x' from  tb_zlxmxx where xzqh=v_kfckxzqhdm and RSBXMBM=a.xxdm )
              and not exists(select 'x' from tb_zlxmxx where RSBXMBM=a.xxdm and xzqh =substr(v_kfckxzqhdm,1,2)||'0100')
              and exists(select 'x' from tb_zlxmxx where RSBXMBM=a.xxdm and xzqh =substr(v_kfckxzqhdm,1,2)||'0000');
          end if;

         end loop;
     end if;

     /*v2.2++???????????????????????????? end */
     /*v2.2++???????????begin*/
       --??????
        update tb_lpfpxx a set a.xgdm = case when  exists(select 'x' from tb_lpajxx b,tb_khxx c,tb_fpxxfyxx d,tb_sbshgzpzxx e where b.ajid = a.ajid
                                                               and b.bbrkhid=c.khid and d.fpid=a.fpid and e.ZSDBM=d.XXDM and e.ZSDLB=d.xmlb
                                                               and e.status='1' and e.AAA102='SY001' and e.SHYS2='1' and c.xb != '1')
                                                  then case when instr(a.xgdm,'SY001-1')>0 then a.xgdm else DECODE(a.xgdm,null,'SY001-1','','SY001-1',a.xgdm||',SY001-1') end
                                            else replace(replace(replace(a.xgdm, ',SY001-1', ''), 'SY001-1,', ''),'SY001-1', '') end
         where a.ajid = v_Ajid;
          --??????
        update tb_lpfpxx a set a.xgdm = case when  exists(select 'x' from tb_lpajxx b,tb_khxx c,tb_fpxxfyxx d,tb_sbshgzpzxx e where b.ajid = a.ajid
                                                               and b.bbrkhid=c.khid and d.fpid=a.fpid and e.ZSDBM=d.XXDM and e.ZSDLB=d.xmlb
                                                               and e.status='1' and e.AAA102='SY001' and e.SHYS2='2' and c.xb != '2')
                                                  then case when instr(a.xgdm,'SY001-2')>0 then a.xgdm else DECODE(a.xgdm,null,'SY001-2','','SY001-2',a.xgdm||',SY001-2') end
                                            else replace(replace(replace(a.xgdm, ',SY001-2', ''), 'SY001-2,', ''),'SY001-2', '') end
        where a.ajid = v_Ajid;

         --????????
         for rec_xy in(select aaa102,aaa103 from aa10 where aaa100='SBGZ' and aaa102 not in('SY001','SY008','SY009') and exists(select 'x' from   tb_sbshgzpzxx e where e.aaa102=aa10.aaa102 and e.status='1')) loop
            update tb_lpfpxx a set a.xgdm = case when  exists(select 'x' from tb_lpajxx b,tb_khxx c,tb_fpxxfyxx d,tb_sbshgzpzxx e where b.ajid = a.ajid
                                                               and b.bbrkhid=c.khid and d.fpid=a.fpid and e.ZSDBM=d.XXDM and e.ZSDLB=d.xmlb
                                                               and e.status='1' and e.AAA102=rec_xy.aaa102
                                                               and ((e.SHYS2='01' and e.SHYS2!= c.xb ) or (e.SHYS2='08' and d.ZDDM not in(select shys2 from tb_sbshgzpzxx h where nvl(h.xzqh,'xxx')=nvl(e.xzqh,'xxx') and h.aaa102=e.aaa102 and h.status='1' and h.zsdbm=e.zsdbm) )
                                                                    or (e.shys1='02' and c.CSRQ< to_char(add_months(to_date(nvl(a.ryrq,jzrq),'yyyy-mm-dd'),-216),'yyyymmdd')) --?????0-18??/
                                                                    or (e.shys1='03' and c.CSRQ<to_char(add_months(to_date(nvl(a.ryrq,jzrq),'yyyy-mm-dd'),-12),'yyyymmdd')) -- //??????0-1??
                                                                    or (e.shys1='04' and a.zdlx!='0') --????
                                                                    or (e.shys1='05' and a.zdlx!='1')--/????
                                                                    or (e.shys1='07' and d.zddm not in(select ZDDM from tb_bdtyshgzzddmpz h,tb_bdxx m,tb_fdzrmx n where h.bdid=m.bdid and m.khbdh=b.khbdh and n.fdid=b.fdid and n.zrid=h.zrid and h.YXZT='1' and h.JBLX='10'  ) ) -- //????
                                                                    ))
                                                  then case when instr(a.xgdm,rec_xy.aaa102)>0 then a.xgdm else DECODE(a.xgdm,null,rec_xy.aaa102,'',rec_xy.aaa102,a.xgdm||','||rec_xy.aaa102) end
                                            else replace(replace(replace(a.xgdm, ','||rec_xy.aaa102, ''), rec_xy.aaa102||',', ''),rec_xy.aaa102, '') end
            where a.ajid = v_Ajid;
         end loop;

     /*v2.2++???????????end*/
  ------???????------
    i_step := 61;
    SELECT MIN(T.FPID)
    INTO n_Fpid
    FROM TB_LPFPXX T
    WHERE T.AJID IN(SELECT AJID FROM TB_LPAJXX WHERE PAH=rec_ajxx.PAH);

    IF cc.DSFPFBZ IN ('1') THEN
      i_step := 62;
      INSERT INTO TB_FPQTSBZFDSFZFMXB(FPQTMXID, FPID, LX, MXLX, MXJE)
      SELECT  SEQ_FPQTMXID.NEXTVAL AS FPQTMXID, n_Fpid FPID, '2', (SELECT AAA102 FROM AA10 WHERE AAA100='DSFZFLX' AND INSTR(cc.BXGSMC,AAA103)>0),NVL(cc.PFJE,0)
      FROM DUAL;

      i_step := 63;
      UPDATE TB_LPFPXX T
      SET T.DSFZFJE = (SELECT SUM(MXJE) FROM TB_FPQTSBZFDSFZFMXB WHERE LX='2' AND FPID=n_Fpid),
      T.DSFZFLX = DECODE(T.DSFZFLX,NULL,(SELECT AAA102 FROM AA10 WHERE AAA100='DSFZFLX' AND INSTR(cc.BXGSMC,AAA103)>0),','||(SELECT AAA102 FROM AA10 WHERE AAA100='DSFZFLX' AND INSTR(cc.BXGSMC,AAA103)>0))
      WHERE T.FPID = n_Fpid;

    END IF;
   --20150404 added by yhs  ??????????????????? begin
   for rec in (select fpid,fphm from tb_lpfpxx where ajid=v_ajid order by fpid asc) loop
         preturncode :='E';
        preturnmsg :='ok';
         sp_p1_sjdr_fptccdexxft(rec.fpid,preturncode,preturnmsg);
         if preturncode='0' then
            preturnmsg:='fpid '|| to_char(rec.fpid) ||'??????????????????????!';
         else
              p_RtnCode:=-1;
              p_RtnMsg:=preturnmsg;
           --  dbms_output.put_line('fpid '|| to_char(rec.fpid) ||'??????????????????????!');
             raise myException;
         end if;

    end loop;

   --20150404 added by yhs  ??????????????????? end
    -----??????????ID????????---
        i_step := 64;
/*          UPDATE TB_LPAJXX S
    SET S.FDID = (SELECT MAX(A.FDID) -- +V1.1
                  FROM TB_FDXX A
                  WHERE TTID=S.TTID
                  AND A.BBRKHID IN(SELECT KHID FROM TB_KHXX WHERE XM = rec_ajxx.XM AND AAC147 = rec_ajxx.ZJHM AND ROWNUM=1)
                  AND A.FDSXR <= (SELECT MAX(JZRQ) FROM TB_LPFPXX M WHERE M.AJID IN(SELECT AJID FROM TB_LPAJXX WHERE PAH=rec_ajxx.PAH))
                  AND A.FDZZR >= (SELECT MAX(JZRQ) FROM TB_LPFPXX M WHERE M.AJID IN(SELECT AJID FROM TB_LPAJXX WHERE PAH=rec_ajxx.PAH))
                  AND EXISTS(SELECT 1 FROM TB_FDZRMX B,TB_ZRXX C WHERE B.ZRID=C.ZRID AND B.FDID=A.FDID \***-- +V1.1 start**\AND B.FDID = S.FDID \***-- +V1.1 end**\AND (SUBSTR(C.ZRBM,1,3) IN ('OIP')) OR (SUBSTR(C.ZRBM,1,2) IN('OP','IP')) )),
                  \***-- V1.4 start**\ \*S.KHBDH = (SELECT KHBDH
                  FROM TB_FDXX
                  WHERE FDID = S.FDID),
        S.ZLDBZ = (SELECT ZLDBZ FROM TB_FDXX WHERE FDID=S.FDID),
        S.ZBBRKHID = (SELECT ZBBRKHID FROM TB_FDXX WHERE FDID=S.FDID),*\
         \***-- V1.4 end**\
        s.sqlx = 'S1'
    WHERE S.PAH = rec_ajxx.PAH
    AND nvl(S.SFBLC,'0') = '0';*/  -- -V1.5
    --  +V1.5 start
     UPDATE  TB_LPAJXX S SET S.SQLX = 'S1'
     WHERE  S.PAH = rec_ajxx.PAH
    AND nvl(S.SFBLC,'0') = '0'/* AND S.SQLX  IS NULL*/;
    -- +V1.5 end
    /*******************-- +V1.7 start****************/
    update tb_ajqtxx t set t.barq = (select min(A.JZRQ) from tb_lpfpxx a where a.ajid = t.ajid )
where t.ajid = v_ajid and t.barq is null;
    /*******************-- +V1.7 end*******************/
    --???????ID???KhBDH  --add by ???
        UPDATE TB_LPAJXX S
    SET S.KHBDH = (select b.khbdh from tb_bdxx b where b.bdid =(select max(a.bdid) from tb_bdxx a where a.ttid = s.ttid) )
    WHERE S.PAH = rec_ajxx.PAH
    AND S.SFBLC = '1';

     --20150331 yhs  MZ150330-04 ?????????????????????? ??????????????

      select max(case when a.BQBGLX like '01%' then '1' else '0' end),max((select nvl(SFBLC,'0') from tb_lpajxx where ajid=v_ajid))  into s_Sfdzbc,s_Sfqlc from tb_bdxx a where khbdh in(select khbdh as xx from tb_lpajxx where ajid=v_ajid) and rownum<2;
      if   s_Sfqlc='0'   then --++ V1.4 ??????????????
              /***++ V1.4 start ????????????????????**/
           UPDATE TB_LPAJXX S
            SET   S.KHBDH = (SELECT KHBDH   FROM TB_FDXX  WHERE FDID = S.FDID),
                  S.ZLDBZ = (SELECT ZLDBZ FROM TB_FDXX WHERE FDID=S.FDID),
                  S.ZBBRKHID = (SELECT ZBBRKHID FROM TB_FDXX WHERE FDID=S.FDID),
                  S.ZBBRGX = (SELECT ZBBRGX FROM TB_FDXX WHERE FDID = S.FDID)
            WHERE S.ajid = v_ajid;
             /***++ V1.4 end**/
          if  s_Sfdzbc='1'   then      --++ V1.4  ???????????????
          UPDATE TB_LPAJXX S
            SET (S.SKFXM,s.LPKGFKHH,s.LPKGFYHZH) =(select ZHMC,KHYH,YHZH from tb_khxx
                                    where khid=case when /*nvl(s.ZBBRGX,'00')!='03'*/not exists(select 1 from
                                    tb_fdxx a where a.fdid = s.fdid and a.zbbrgx = '03')
                                                    then s.bbrkhid
                                                    else s.zbbrkhid
                                              end
                                               )
            WHERE S.ajid = v_ajid;
          end if ;--++ V1.4
      end if;

    --20150331 yhs end
    i_step := 7;
    UPDATE TB_WBGS_IMPORT_LOG
    SET CLSJ=SYSDATE,cljg = '1'
    WHERE wbdrbwid=p_wbdrbwid;

    i_step := 8;
    UPDATE TB_LPAJXX
    SET AJZT='02'
    WHERE PAH=rec_ajxx.PAH;
    /****-- add by zhangjunpeng start***/
    --????????????????????????0???????
    if pkg_jkbx_util.f_get_cbdqh(v_Ajid) like '11%' then
     update tb_fpfydlxx a set(
          a.HOSPITAL_FEE   ,
          a.CURE_FEE       ,
          a.SURGERY_FEE    ,
          a.EXAMINE_FEE    ,
          a.TEST_FEE       ,
          a.X_RAY_FEE      ,
          /*a.EXAMINE_FEE    ,*/
          a.WESTERN_MED_FEE,
          a.CHINESE_MED_FEE,
          a.HERBAL_MED_FEE ,
          a.REGISTER_FEE   ,
          a.MATERIAL_FEE   ,
          a.NURSE_FEE      ,
          a.TRANSFUSE_FEE  ,
          a.OXYGEN_FEE     ,
          a.BED_FEE        ,
          a.OTHER_FEE      )=(select
          sum(case when b.dxdm ='01' then  nvl(b.zdje,0) else 0 end) as HOSPITAL_FEE   ,
          sum(case when b.dxdm ='02' then  nvl(b.zdje,0) else 0 end) as CURE_FEE       ,
          sum(case when b.dxdm ='03' then  nvl(b.zdje,0) else 0 end) as SURGERY_FEE    ,
          sum(case when b.dxdm in('04' ,'07') then  nvl(b.zdje,0) else 0 end) as EXAMINE_FEE    ,
          sum(case when b.dxdm ='05' then  nvl(b.zdje,0) else 0 end) as TEST_FEE       ,
          sum(case when b.dxdm ='06' then  nvl(b.zdje,0) else 0 end) as X_RAY_FEE      ,
          /*sum(case when b.dxdm ='07' then  nvl(b.zdje,0) else 0 end) as EXAMINE_FEE    ,
          */sum(case when b.dxdm ='08' then  nvl(b.zdje,0) else 0 end) as WESTERN_MED_FEE,
          sum(case when b.dxdm ='09' then  nvl(b.zdje,0) else 0 end) as CHINESE_MED_FEE,
          sum(case when b.dxdm ='10' then  nvl(b.zdje,0) else 0 end) as HERBAL_MED_FEE ,
          sum(case when b.dxdm ='11' then  nvl(b.zdje,0) else 0 end) as REGISTER_FEE   ,
          sum(case when b.dxdm ='12' then  nvl(b.zdje,0) else 0 end) as MATERIAL_FEE   ,
          sum(case when b.dxdm ='14' then  nvl(b.zdje,0) else 0 end) as NURSE_FEE      ,
          sum(case when b.dxdm ='15' then  nvl(b.zdje,0) else 0 end) as TRANSFUSE_FEE  ,
          sum(case when b.dxdm ='16' then  nvl(b.zdje,0) else 0 end) as OXYGEN_FEE     ,
          sum(case when b.dxdm ='17' then  nvl(b.zdje,0) else 0 end) as BED_FEE        ,
          sum(case when b.dxdm ='99' then  nvl(b.zdje,0) else 0 end) as OTHER_FEE
           from tb_fpxxfyxx b where b.fpid=a.fpid ) where a.ajid=v_Ajid
       and (nvl(a.REGISTER_FEE  ,0)+nvl(a.WESTERN_MED_FEE  ,0)+nvl(a.CHINESE_MED_FEE  ,0)+nvl(a.HERBAL_MED_FEE   ,0)+nvl(a.TEST_FEE         ,0)+nvl(a.X_RAY_FEE        ,0)+nvl(a.B_SONIC_FEE      ,0)+nvl(a.CT_FEE           ,0)+nvl(a.MRI_FEE          ,0)+nvl(a.EXAMINE_FEE      ,0)+nvl(a.CURE_FEE         ,0)+nvl(a.MATERIAL_FEE     ,0)+nvl(a.SURGERY_FEE      ,0)+nvl(a.OXYGEN_FEE       ,0)+nvl(a.TRANSFUSE_FEE    ,0)+nvl(a.REMEDY_FEE       ,0)+nvl(a.PROSTH_FEE       ,0)+nvl(a.LAW_AUTH_FEE     ,0)+nvl(a.BED_FEE          ,0)+nvl(a.NURSE_FEE        ,0)+nvl(a.HOSPITAL_FEE     ,0)+nvl(a.URGENT_SAVE_FEE  ,0)+nvl(a.AMBULANCE_FEE    ,0)+nvl(a.NATION_MED_FEE   ,0)+nvl(a.SELF_MADE_FEE    ,0)+nvl(a.PRESCRIPTION_FEE ,0)+nvl(a.OTHER_FEE        ,0)) =0;

   end if;
    /****-- add by zhangjunpeng end*****/
     --20150312  ??? ?????????
   /*????????????????????? FP64
????????????????? FP65
?????????????????? FP02
??????????? FP49
????=????+????+????+?????????0.05????????0.05??????FP30
????+????=??/??1+????/???+???????0.05??????????0.05??????FP31
??????????? ???FP32
        */
         update  tb_lpfpxx a set a.xgdm=case when exists(select 'x' from tb_lpajxx where bbrxm!=nvl(a.fpxm,'xx') and ajid=a.ajid)
             then case when instr(a.xgdm,'FP02') >0 then a.xgdm else decode (a.xgdm,null ,'FP02','','FP02',a.xgdm||',FP02') end else replace(replace(replace(a.xgdm, ',FP02', ''), 'FP02,', ''),'FP02', '') end
          where ajid=v_Ajid;
          --20150315 yhs ???????????????????????
           update  tb_lpfpxx a set a.xgdm=case when   exists(select 'x' from TB_WBGS_IMPORT_FPXX b ,TB_WBGS_IMPORT_PAINFO c,tb_lpajxx d
                      where  c.WBDRBWAJID=b.WBDRBWAJID and d.pah=c.pah and d.ajid=a.ajid and nvl(d.sfblc,'0')='0'
                       and d.fdid is null ) then case when instr(a.xgdm,'FP35') >0 then a.xgdm else decode (a.xgdm,null ,'FP35','','FP35',a.xgdm||',FP35') end else replace(replace(replace(a.xgdm, ',FP35', ''), 'FP35,', ''),'FP35', '') end
          where ajid=v_Ajid and exists(select 'x' from tb_lpajxx d where  d.ajid=a.ajid and nvl(d.sfblc,'0')='0' ) ;

      update  tb_lpfpxx a set a.xgdm=case when exists(select b.fpid,sum(nvl(b.FLZFJE,0)) from tb_fpxxfyxx b where b.fpid=a.fpid group by b.fpid having sum(nvl(b.FLZFJE,0))!=nvl(a.FLZFZE,0) ) then case when instr(a.xgdm,'FP64') >0 then a.xgdm else decode (a.xgdm,null ,'FP64','','FP64',a.xgdm||',FP64') end else replace(replace(replace(a.xgdm, ',FP64', ''), 'FP64,', ''),'FP64', '') end
         where ajid=v_Ajid;

     update  tb_lpfpxx a set a.xgdm=case when exists(select b.fpid,sum(nvl(b.ZFJE,0)) from tb_fpxxfyxx b where b.fpid=a.fpid group by b.fpid having sum(nvl(b.ZFJE,0))!=nvl(a.ZFZE,0) ) then case when instr(a.xgdm,'FP65') >0 then a.xgdm else decode (a.xgdm,null ,'FP65','','FP65',a.xgdm||',FP65') end else replace(replace(replace(a.xgdm, ',FP65', ''), 'FP65,', ''),'FP65', '') end
          where ajid=v_Ajid;

     update  tb_lpfpxx a set a.xgdm=case when exists(select b.fpid,sum(nvl(b.ZDJE,0)) from tb_fpxxfyxx b where b.fpid=a.fpid group by b.fpid having sum(nvl(b.ZDJE,0))!=nvl(a.FPZE,0) ) then case when instr(a.xgdm,'FP49') >0 then a.xgdm else decode (a.xgdm,null ,'FP49','','FP49',a.xgdm||',FP49') end else replace(replace(replace(a.xgdm, ',FP49', ''), 'FP49,', ''),'FP49', '') end
         where ajid=v_Ajid;
          --???????FP34??
      update  tb_lpfpxx a set a.xgdm=case when exists(select b.fphm,b.fpze from tb_lpfpxx b where b.fphm=a.fphm and b.fpze=a.fpze and b.fpid!=a.fpid and b.ajid=a.ajid ) then case when instr(a.xgdm,'FP34') >0 then a.xgdm else decode (a.xgdm,null ,'FP34','','FP34',a.xgdm||',FP34') end else replace(replace(replace(a.xgdm, ',FP34', ''), 'FP34,', ''),'FP34', '') end
          where ajid=v_Ajid;
      --??FP30 ????=????+????+????+?????????0.05????????0.05??(???????)
       update  tb_lpfpxx a set a.xgdm=case when exists(select 'x' from tb_yyxx where yyid=a.yyid and XZQHDM  like '11%') and abs(nvl(fpze,0)-(nvl(XJZFE,0)+nvl(GRZFZFE,0)+nvl(TCZFE,0)+nvl(FJZFE,0)+nvl(SBZFE,0)+nvl(CDEJE,0)))>0.05 then case when instr(a.xgdm,'FP30') >0 then a.xgdm else decode (a.xgdm,null ,'FP30','','FP30',a.xgdm||',FP30') end else replace(replace(replace(a.xgdm, ',FP30', ''), 'FP30,', ''),'FP30', '') end
          where /*pkg_jkbx_util.f_get_cbdqh(v_Ajid) like '11%' and */ ajid=v_Ajid;
      --??FP31 ????+????=??/??1+????/???+???????0.05??????????0.05??(???????)   --1.2.1 yhs add ??????????????=0?????????
       update  tb_lpfpxx a set a.xgdm=case when  exists(select 'x' from tb_yyxx where yyid=a.yyid and XZQHDM  like '11%') and abs(nvl(XJZFE,0)+nvl(GRZFZFE,0)-(nvl(ZFYJE,0)+nvl(FLZFZE,0)+nvl(ZFZE,0)))>0.05 and (a.sjlx!='02' or (a.sjlx is null and (nvl(TCZFE,0)+nvl(FJZFE,0)+nvl(SBZFE,0)=0)))
         then case when instr(a.xgdm,'FP31') >0 then a.xgdm else decode (a.xgdm,null ,'FP31','','FP31',a.xgdm||',FP31') end  else replace(replace(replace(a.xgdm, ',FP31', ''), 'FP31,', ''),'FP31', '') end
          where /*pkg_jkbx_util.f_get_cbdqh(v_Ajid) like '11%' and */ajid=v_Ajid  ;
       --??????????? ???FP32
       update  tb_lpfpxx a set a.xgdm=case when exists(select 'x' from tb_fpxxfyxx b where b.fpid=a.fpid and (b.xxdm is null or upper(nvl(b.dxdm,'xx'))='XX' or b.tyid is null)) then case when instr(a.xgdm,'FP32') >0 then a.xgdm else decode (a.xgdm,null ,'FP32','','FP32',a.xgdm||',FP32') end else replace(replace(replace(a.xgdm, ',FP32', ''), 'FP32,', ''),'FP32', '') end
          where ajid=v_Ajid;
        --20150312  ??? ????????? end
       --FP36 ????????????????????????
        update tb_lpfpxx a set a.xgdm = case when  exists(select 1 from tb_lpajxx b where b.ajid = a.ajid and b.sqlx = 'SA') and a.zdlx = '1' then case when instr(a.xgdm,'FP36')>0 then a.xgdm else DECODE(a.xgdm,null,'FP36','','FP36',a.xgdm||',FP36') end else replace(replace(replace(a.xgdm, ',FP36', ''), 'FP36,', ''),'FP36', '') end
         where a.ajid = v_Ajid;
        --FP37 ???????????????????????
        update tb_lpfpxx a set a.xgdm = case when  exists(select 1 from tb_lpajxx b where b.ajid = a.ajid and b.sqlx = 'SB') and a.zdlx = '0'  then case when instr(a.xgdm,'FP37')>0 then a.xgdm else DECODE(a.xgdm,null,'FP37','','FP37',a.xgdm||',FP37') end else replace(replace(replace(a.xgdm, ',FP37', ''), 'FP37,', ''),'FP37', '') end
        where a.ajid = v_Ajid;
        --FP38 ???????????  DECODE(a.xgdm,'','FP38',a.xgdm||',FP38')
        update tb_lpfpxx a set a.xgdm =  case when a.zdlx = '2' then case when instr(a.xgdm,'FP38')>0 then a.xgdm else DECODE(a.xgdm,null,'FP38','','FP38',a.xgdm||',FP38') end else replace(replace(replace(a.xgdm, ',FP38', ''), 'FP38,', ''),'FP38', '') end
        where a.ajid = v_Ajid;
        --FP39 ????????
        update tb_lpfpxx a set a.xgdm = case when not exists(select 1 from tb_yyxx b where b.yyid= nvl(a.yyid,-1)) then case when instr(a.xgdm,'FP39') >0 then a.xgdm else decode(a.xgdm,null,'FP39','','FP39',a.xgdm||',FP39') end else replace(replace(replace(a.xgdm, ',FP39', ''), 'FP39,', ''),'FP39', '') end
         where a.ajid = v_Ajid;
        --FP40 (???????)
        update tb_lpfpxx a set a.xgdm = case when  exists(select 'x' from tb_yyxx where yyid=a.yyid and XZQHDM  like '11%') and  exists (select 1 from tb_fpfydlxx b where b.fpid=a.fpid and  abs(nvl(b.REGISTER_FEE  ,0)+nvl(b.WESTERN_MED_FEE  ,0)+nvl(b.CHINESE_MED_FEE  ,0)+nvl(b.HERBAL_MED_FEE   ,0)+nvl(b.TEST_FEE         ,0)+nvl(b.X_RAY_FEE        ,0)+nvl(b.B_SONIC_FEE      ,0)+nvl(b.CT_FEE           ,0)+nvl(b.MRI_FEE          ,0)+nvl(b.EXAMINE_FEE      ,0)+nvl(b.CURE_FEE         ,0)+nvl(b.MATERIAL_FEE     ,0)+nvl(b.SURGERY_FEE      ,0)+nvl(b.OXYGEN_FEE       ,0)+nvl(b.TRANSFUSE_FEE    ,0)+nvl(b.REMEDY_FEE       ,0)+nvl(b.PROSTH_FEE       ,0)+nvl(b.LAW_AUTH_FEE     ,0)+nvl(b.BED_FEE          ,0)+nvl(b.NURSE_FEE        ,0)+nvl(b.HOSPITAL_FEE     ,0)+nvl(b.URGENT_SAVE_FEE  ,0)+nvl(b.AMBULANCE_FEE    ,0)+nvl(b.NATION_MED_FEE   ,0)+nvl(b.SELF_MADE_FEE    ,0)+nvl(b.PRESCRIPTION_FEE ,0)+nvl(b.OTHER_FEE        ,0)-nvl(a.fpze,0)) >0.05) then case when instr(a.xgdm,'FP40') >0 then a.xgdm else decode(a.xgdm,null,'FP40','','FP40',a.xgdm||',FP40') end else replace(replace(replace(a.xgdm, ',FP40', ''), 'FP40,', ''),'FP40', '') end
         where /* pkg_jkbx_util.f_get_cbdqh(v_Ajid) like '11%' and */ a.ajid = v_Ajid;
          /****-- add by yhs 0411 ???????????????????????????????????????????CL77??  start***/
         update tb_lppcxx a set pczt='02' where pcid=?select lppcid from tb_lpajxx where  PAH=rec_ajxx.PAH ?
              and pczt not in('02','03','04') and not exists(select 'x' from TB_LPAJXX where wbgsid is not null
                 and wbdrrq is null);
         update tb_lpfpxx a set a.xgdm = case when nvl(a.dsfzfje,0)>0 then case when instr(a.xgdm,'FP77') >0 then a.xgdm else decode(a.xgdm,null,'FP77','','FP77',a.xgdm||',FP77') end else replace(replace(replace(a.xgdm, ',FP77', ''), 'FP77,', ''),'FP77', '') end
         where a.ajid = v_Ajid;

         /********-- +V2.1 start*********/
          update tb_lpfpxx a set a.xgdm = case when  exists( select 1 from tb_wbgs_import_painfo ak,tb_lpajxx b,tb_wbgs_import_log c,tb_ajqtxx d where ak.wbdrbwid = c.wbdrbwid and b.pah = c.pah and to_char(c.clsj,'yyyymmddhh24') =to_char(d.Sbsj,'yyyymmddhh24') and b.ajid = d.ajid and b.ajid = a.ajid and (ak.xm <> b.bbrxm or ak.zjhm <> b.bbrzjh)) then  case when instr(a.xgdm,'FP67') >0 then a.xgdm   else  decode(a.xgdm,null,'FP67','','FP67',a.xgdm||',FP67') end  else replace(replace(replace(a.xgdm, ',FP67', ''), 'FP67,', ''),'FP67', '') end
  where a.ajid = v_Ajid and not exists (select 1 from tb_lpajxx m where m.ajid = a.ajid and nvl(m.sfblc,'xx') = '1');
         /********-- +V2.1 end**********/
          /****-- add by yhs 0411 end */
            /***++ V1.4 start MZ150413-02?????????????????????????????????`????**/
         UPDATE TB_LPAJXX S
          SET   ajzt='02',LRR='system' where s.sfxnaj='1' and s.lppcid in(select lppcid from TB_LPAJXX k
           where K.ajid = v_ajid ) and s.ajzt ='01';
           /***++ V1.4 MZ150413-02 end**/
         update tb_ajqtxx t set t.SBSJ = sysdate where t.ajid = v_ajid;  -- +V1.9
    END LOOP;
    COMMIT;
EXCEPTION
  WHEN OTHERS THEN
      p_RtnCode := SQLCODE;
      p_RtnMsg := SQLERRM;
      ROLLBACK;
      update TB_WBGS_IMPORT_LOG t set t.cljg = 'N',t.sbyy = p_RtnMsg where t.wbdrbwid = p_Wbdrbwid;
      commit;
      --Pkg_Error_Log.Pro_Error_In('PROC_WBGS_IMPORT', i_step, p_RtnCode, p_RtnMsg);           -- -V1.2
      Pkg_Error_Log.Pro_Error_In('PROC_WBGS_IMPORT', i_step, p_RtnCode, p_RtnMsg||n_wbdrfpid); -- +V1.2
END PROC_WBGS_IMPORT;

/
