CREATE function      FUNC_XH_JFLY(P_JFLY in varchar2) return varchar2 is
  Result varchar2(20);
begin
  select bxgsxmbm into Result from tb_zddmbxgsdmdzb where bxgsid=712 and aaa100='JFLY' and aaa102=P_JFLY;
  return(Result);
end FUNC_XH_JFLY;

/
