CREATE FUNCTION      "SF_P1_GET_WORKDATE" (workDate in number,currDate in number) return number is
  resultDate number:=to_number(to_char(sysdate,'yyyymmdd')) ;
BEGIN

  SELECT cke123 into resultDate  FROM
			(SELECT a.*, ROWNUM rn FROM
			(select t.*  from ke30 t where t.cke124 = 1 and t.cke123 > currDate order by t.cke123) a)
				 WHERE rn = workDate;

 return(resultDate);

 EXCEPTION
        WHEN OTHERS THEN
        return(resultDate);
 END SF_P1_GET_WORKDATE;

/
