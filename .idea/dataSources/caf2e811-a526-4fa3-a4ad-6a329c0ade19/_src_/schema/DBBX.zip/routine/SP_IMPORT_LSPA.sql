CREATE PROCEDURE      "SP_IMPORT_LSPA" (Pin_userid IN varCHAR2 ,Pkhbdh in varCHAR2,PReturnCode OUT varchar2,
                              PReturnMsg    OUT varchar2) AS
  cursor cur_lspc is  select substr(a."Claim No", 1, 8) as pch,
       to_char(to_date(nvl(regdate,applicationdate), 'dd-mm-yyyy'), 'yyyymmdd') regdate,
       ????,
       a."Policy No" as wbbdh,
       count(1) as ajs
  from TEMP_Import_HIS_AJXX a
  where ???? is null /*and  exists(select 'x' from tb_khxx b,tb_fdxx c where b.khid=c.bbrkhid and b.aac147=a.nationalid)*/
  and  exists(
   select 'x' from tb_khxx b,tb_fdxx c,tb_fdzrmx f,tb_zrxx h where f.fdid=c.fdid and f.zrid=h.zrid
   and b.khid=c.bbrkhid and b.aac147=a.nationalid
   and nvl(c.wbbdh,c.khbdh)=a."Policy No"
   and ((h.zrbm   like decode(a.BenefitCode,'AHI','AIOP','SHIP','AIOP','NONSHIP','AIOP','HI','HI','IPAY','IP','IPAN','IP','OP','OP','MBRN','MAT','MBRY','MAT','error')||'%')
            or (a.BenefitCode in('OP','IP','IPAY','IPAN') and h.zrbm like 'OIP%'))--20141101 ????????????????
                 )
  and ( "Policy No"=trim(Pkhbdh) or trim(Pkhbdh) is null)
 -- and "Claim No"  like 'CL048708%'
 group by substr(a."Claim No", 1, 8),
          to_char(to_date(nvl(regdate,applicationdate), 'dd-mm-yyyy'), 'yyyymmdd'),
          ????,
          a."Policy No"
 order by pch, regdate;
    v_pch varchar2(30):='';
  v_regdate varchar2(30):='';
  cursor cur_lspa is select a.*,592 as bxgsid ,a."Claim No" as pah
   from TEMP_Import_HIS_AJXX a where a."Claim No" like v_pch||'%' and ???? is null
   and ( "Policy No"=trim(Pkhbdh) or trim(Pkhbdh) is null)
   and BenefitCode not like 'DD%' and  BenefitCode not like 'AD%'  and  BenefitCode not like 'TL%'
   --and nationalid!='410105198301023362'  --410105198301023362 ????????????????????
   and  exists(
   select 'x' from tb_khxx b,tb_fdxx c,tb_fdzrmx f,tb_zrxx h where f.fdid=c.fdid and f.zrid=h.zrid
   and b.khid=c.bbrkhid and b.aac147=a.nationalid
   and nvl(c.wbbdh,c.khbdh)=a."Policy No"
   and ((h.zrbm   like decode(a.BenefitCode,'AHI','AIOP','SHIP','AIOP','NONSHIP','AIOP','HI','HI','IPAY','IP','IPAN','IP','OP','OP','MBRN','MAT','MBRY','MAT','error')||'%')
            or (a.BenefitCode in('OP','IP','IPAY','IPAN') and h.zrbm like 'OIP%'))--20141101 ????????????????
                 )
   and to_char(to_date(nvl(regdate,applicationdate), 'dd-mm-yyyy'), 'yyyymmdd')=v_regdate -- ????????regdate???????applicationdate
   order by NationalID,LossDate asc;

  v_pcid number(16):=1;
  v_ajid number(16):=1;
  v_pcajs number(5):=0;
  v_pczpas number(5):=0;
  myexception Exception;
  v_count number:=0;

begin
 -- DBMS_OUTPUT.ENABLE(1000000);
   PReturnCode:='E';
    PReturnMsg:='Error!';
  for rec_pc in cur_lspc loop
      select seq_pcid.nextval into v_pcid from dual;
      v_pch:=rec_pc.pch;
      v_regdate:=rec_pc.regdate;
      --????????????????????
      select count(1) into v_count from tb_lppcxx where pch=rec_pc.pch;
      if v_count>0 then --????????????????????????
           select pcid into v_pcid from tb_lppcxx  where pch=rec_pc.pch;
           update tb_lppcxx set ajs=nvl(ajs,0)+ rec_pc.ajs  where pcid=v_pcid;
      else
             insert into tb_lppcxx (
              PCID     ,--NUMBER(16)                     ??ID
              PCH      ,--VARCHAR2(30)  Y                ???
              BXGSID   ,--NUMBER(16)                     ????ID
              BXGSQC   ,--VARCHAR2(200) Y                ??????
              TTID     ,--NUMBER(16)                     ??ID
              TTMC     ,--VARCHAR2(100) Y                ????
              SJRQ     ,--NUMBER(8)     Y                ????
              AJS      ,--NUMBER        Y                ???
              KHTJBH   ,--VARCHAR2(30)  Y                ??????
              KHJJR    ,--VARCHAR2(50)  Y                ?????
              SFZS     ,--VARCHAR2(1)   Y                ????
              JHSFRQ   ,--NUMBER(8)     Y                ??????
              PCJBR    ,--VARCHAR2(30)  Y                ?????
              KHFSRQ   ,--NUMBER(8)     Y                ??????
              BDID     ,--NUMBER(16)                     ??ID
              KHBDH    ,--VARCHAR2(50)                   ?????(???)
              PCFKZS   ,--VARCHAR2(2)   Y                ??????
              SFYQBZ   ,--VARCHAR2(1)   Y                ??????
              BXGSLXR  ,--VARCHAR2(30)  Y                ???????
              PCZT     ,--VARCHAR2(2)   Y                ????
              SJSFRQ   ,--NUMBER(8)     Y                ??????
              YQYY     ,--VARCHAR2(2)   Y                ????
              YQBZ     ,--VARCHAR2(500) Y                ????
              SFRID    ,--VARCHAR2(30)  Y                ???ID
              SFR      ,--VARCHAR2(30)  Y                ???
              CJSJ     ,--DATE          Y                ????
              ZJXGR    ,--VARCHAR2(30)  Y
              ZJXGSJ   ,--DATE          Y
              SLRQ     ,--NUMBER(8)     Y                ????
              LRRQ     ,--NUMBER(8)     Y                ????
              DYBZ     ,--VARCHAR2(1)   Y                ????
              DYR      ,--VARCHAR2(50)  Y                ???
              DYRQ     ,--NUMBER(8)     Y                ????
              BDYRQ    ,--NUMBER(8)     Y                ?????
              BDYR     ,--VARCHAR2(50)  Y                ????
              SEQLOGID ,--NUMBER        Y
              FPZS     ,--NUMBER(5)     Y                ????
              SFJJPC   --VARCHAR2(1)   Y                ??????0:? 1:?
              ) select v_PCID  as pcid   ,--NUMBER(16)                     ??ID
              rec_pc.PCH as pch     ,--VARCHAR2(30)  Y                ???
              592 as bxgsid   ,--NUMBER(16)                     ????ID
              (select bxgsqc from tb_bxgsxx where bxgsid=592) BXGSQC   ,--VARCHAR2(200) Y                ??????
             -- (select TTID from tb_ttxx where ttmc=rec_pc.????) as ttid     ,--NUMBER(16)                     ??ID
             b.ttid,
              b.TTMC     ,--VARCHAR2(100) Y                ????
              rec_pc.regdate SJRQ     ,--NUMBER(8)     Y                ????
              rec_pc.AJS      ,--NUMBER        Y                ???
              rec_pc.PCH KHTJBH   ,--VARCHAR2(30)  Y                ??????
              'system' KHJJR    ,--VARCHAR2(50)  Y                ?????
              '0' SFZS     ,--VARCHAR2(1)   Y                ????
              '' JHSFRQ   ,--NUMBER(8)     Y                ??????
              'system' PCJBR    ,--VARCHAR2(30)  Y                ?????
              '' KHFSRQ   ,--NUMBER(8)     Y                ??????
              b.BDID     ,--NUMBER(16)                     ??ID
              a.KHBDH    ,--VARCHAR2(50)                   ?????(???)
              '2' PCFKZS   ,--VARCHAR2(2)   Y                ??????
              '0' SFYQBZ   ,--VARCHAR2(1)   Y                ??????
              '' BXGSLXR  ,--VARCHAR2(30)  Y                ???????
              '05' PCZT     ,--VARCHAR2(2)   Y                ????
              '' SJSFRQ   ,--NUMBER(8)     Y                ??????
              '' YQYY     ,--VARCHAR2(2)   Y                ????
              '' YQBZ     ,--VARCHAR2(500) Y                ????
              'system' SFRID    ,--VARCHAR2(30)  Y                ???ID
              'system' SFR      ,--VARCHAR2(30)  Y                ???
              sysdate CJSJ     ,--DATE          Y                ????
              '' ZJXGR    ,--VARCHAR2(30)  Y
              '' ZJXGSJ   ,--DATE          Y
              rec_pc.regdate SLRQ     ,--NUMBER(8)     Y                ????
              rec_pc.regdate LRRQ     ,--NUMBER(8)     Y                ????
              '1' DYBZ     ,--VARCHAR2(1)   Y                ????
              'system' DYR      ,--VARCHAR2(50)  Y                ???
              rec_pc.regdate DYRQ     ,--NUMBER(8)     Y                ????
              '' BDYRQ    ,--NUMBER(8)     Y                ?????
              '' BDYR     ,--VARCHAR2(50)  Y                ????
              -1 SEQLOGID ,--NUMBER        Y
              rec_pc.ajs FPZS     ,--NUMBER(5)     Y                ????
              '0' SFJJPC   --VARCHAR2(1)   Y                ??????0:? 1:?
              from TB_NBBDWBBDDZPZB a,tb_bdxx b where a.KHBDH=b.KHBDH and a.WBBDH=rec_pc.wbbdh;
      end if;
              --??????????
              v_pcajs:=0;
              v_pczpas:=0;
     for rec_pa in cur_lspa loop
         select seq_ajid.nextval into v_ajid from dual;
        insert into tb_lpajxx(
        AJID        ,--NUMBER(16)                     ??ID
        LPPCID      ,--NUMBER(16)                     ????ID
        PAH         ,--VARCHAR2(30)  Y                ???
        BXGSID      ,--NUMBER(16)                     ????ID
        TTID        ,--NUMBER(16)                     ??ID
        ZTTID       ,--NUMBER(16)    Y                ???ID
        ZTTMC       ,--VARCHAR2(200) Y                ?????
        GJAJBZ      ,--VARCHAR2(1)   Y                ??????
        GLAJH       ,--VARCHAR2(30)  Y                ?????
        BBRXM       ,--VARCHAR2(30)  Y                ?????
        BBRKHID     ,--NUMBER(16)    Y                ?????ID
        BBRZJH      ,--VARCHAR2(20)  Y                ??????
        ZLDBZ       ,--VARCHAR2(1)   Y                ?/???????
        ZBBRKHID    ,--NUMBER(16)    Y                ??????ID
        KHBDH       ,--VARCHAR2(30)  Y                ????
        FDID        ,--NUMBER(16)    Y                ???
        SQRZJLX     ,--VARCHAR2(2)                    ???????
        SQRZJHM     ,--VARCHAR2(20)                   ???????
        SQRXM       ,--VARCHAR2(30)                   ?????
        SQRSJ       ,--VARCHAR2(30)  Y                ?????
        SQRDZ       ,--VARCHAR2(200) Y                ?????
        SQRYX       ,--VARCHAR2(30)  Y                ?????
        SQLX        ,--VARCHAR2(66)  Y                ????
        SQRQ        ,--NUMBER(8)     Y                ????
        BBRSCZT     ,--VARCHAR2(1)   Y                ???????
        BBRCJDM     ,--VARCHAR2(10)  Y                ???????
        BBRCJXM     ,--VARCHAR2(500) Y                ???????
        BBRCJDJ     ,--VARCHAR2(10)  Y                ???????
        BBRSWRQ     ,--NUMBER(8)     Y                ???????
        BBRYWSGFSRQ ,--NUMBER(8)     Y                ???????????
        JBID        ,--NUMBER(16)    Y                ??ID
        ZJDM        ,--VARCHAR2(20)  Y                ????
        ZJQZR       ,--NUMBER(8)     Y                ?????
        AJZT        ,--VARCHAR2(2)   Y                ????
        ZHCLRQ      ,--DATE          Y                ??????
        AJXGDM      ,--VARCHAR2(80)  Y                ??????
        AJXGLY      ,--VARCHAR2(300) Y                ??????
        XGRQ        ,--VARCHAR2(30)  Y                ????
        JARQ        ,--NUMBER(8)     Y                ????
        AJJL        ,--VARCHAR2(2)   Y                ????
        AJJLSM1     ,--VARCHAR2(10)  Y                ??????1
        AJJLSM      ,--VARCHAR2(200) Y                ??????(??)
        JBR         ,--VARCHAR2(30)  Y                ???
        AJPFJE      ,--NUMBER(16,2)  Y                ??????
        LPJSYR      ,--VARCHAR2(30)  Y                ??????
        AJPFFS      ,--VARCHAR2(1)   Y                ??????
        SFXNAJ      ,--VARCHAR2(1)            '0'     ??????
        SFZDSCZPA   ,--VARCHAR2(1)   Y        '0'     ?????????
        SCZPASJ     ,--DATE          Y                ???????
        LSSJ        ,--DATE          Y                ????
        SLRID       ,--NUMBER(19)    Y                ???id
        SLR         ,--VARCHAR2(50)  Y                ???
        LRRID       ,--NUMBER(19)    Y                ???id
        LRR         ,--VARCHAR2(50)  Y                ???
        SHRID       ,--NUMBER(19)    Y                ???ID
        SHR         ,--VARCHAR2(50)  Y                ???
        ZJRID       ,--NUMBER(19)    Y                ???ID
        ZJR         ,--VARCHAR2(50)  Y                ???
        ZJSJ        ,--DATE          Y                ????
        ZJJL        ,--VARCHAR2(1)   Y                ????
        ZJYJMS      ,--VARCHAR2(200) Y                ??????
        SSYLY       ,--VARCHAR2(200) Y                ?????
        KHSYR       ,--VARCHAR2(50)  Y                ?????
        SYJL        ,--VARCHAR2(1)   Y                ????
        SYRQ        ,--DATE          Y                ????
        SYYJMS      ,--VARCHAR2(200) Y                ??????
        BXCSSCZPABZ ,--VARCHAR2(1)   Y                ???????????
        DYSJSCBZ    ,--VARCHAR2(1)   Y                ????????
        DYSJSCSJ    ,--DATE          Y                ????????
        LPKGFKHH    ,--VARCHAR2(50)  Y                ????????
        LPKGFYHZH   ,--VARCHAR2(35)  Y                ?????????
        SKFXM       ,--VARCHAR2(50)  Y                ?????
        TQRQ        ,--DATE          Y                ????
        QCLSM       ,--VARCHAR2(300) Y                ?????
        SFRQ        ,--NUMBER(8)     Y                ????
        SEQLOGID    ,--NUMBER        Y
        DYBZ        ,--VARCHAR2(1)   Y                ????
        DYR         ,--VARCHAR2(50)  Y                ???
        DYRQ        ,--NUMBER(8)     Y                ????
        BDYRQ       ,--NUMBER(8)     Y                ?????
        BDYR        ,--VARCHAR2(50)  Y                ????
        FPS         ,--NUMBER(3)     Y                ???
        SFJJAJ      ,--VARCHAR2(1)   Y                ?????? 0? 1 ?
        CSRID       ,--NUMBER(16)    Y                ???ID
        CSR         ,--VARCHAR2(50)  Y                ???
        CSJG        ,--VARCHAR2(1)   Y                ???? 1?? ?? ???
        CSCWDM      ,--VARCHAR2(50)  Y                ?????(???)
        CSCWMS      ,--VARCHAR2(200) Y                ??????
        FSRID       ,--NUMBER(16)    Y                ???ID
        FSR         ,--VARCHAR2(50)  Y                ???
        FSJG        ,--VARCHAR2(1)   Y                ???? 1?? ?? ???
        FSCWDM      ,--VARCHAR2(50)  Y                ?????(???)
        FSCWMS      ,--VARCHAR2(200) Y                ??????
        AJSFSD      ,--VARCHAR2(1)   Y                ??????0??? 1?
        SDKSSJ      ,--DATE          Y                ??????
        DQCZR       ,--VARCHAR2(50)  Y                ?????
        ZBBRGX      ,--VARCHAR2(2)   Y                ?????????
        SFGS        ,--VARCHAR2(1)   Y                ????
        YWSGDD      ,--VARCHAR2(200) Y                ??????
        YWSGYY      ,--VARCHAR2(200) Y                ??????
        SSWBYY      )--VARCHAR2(100) Y                ??????
        select v_ajid as ajid,
        v_pcid LPPCID      ,--NUMBER(16)                     ????ID
        rec_pa.pah PAH         ,--VARCHAR2(30)  Y                ???
        rec_pa.BXGSID      ,--NUMBER(16)                     ????ID
        (select TTID from tb_lppcxx where pcid=v_pcid) TTID        ,--NUMBER(16)                     ??ID
        (select zttid from tb_zttxx  where zttmc=rec_pc.???? and nvl(ZTTBH,rec_pa."Policy No")=rec_pa."Policy No") zttid       ,--NUMBERt(16)    Y                ???ID
        rec_pc.???? ZTTMC       ,--VARCHAR2(200) Y                ?????
        '' GJAJBZ      ,--VARCHAR2(1)   Y                ??????
        '' GLAJH       ,--VARCHAR2(30)  Y                ?????
        rec_pa.name as BBRXM       ,--VARCHAR2(30)  Y                ?????
      b.khid as  BBRKHID     ,--NUMBER(16)    Y                ?????ID
      b.aac147 as   BBRZJH      ,--VARCHAR2(20)  Y                ??????
      '0'  ZLDBZ       ,--VARCHAR2(1)   Y                ?/???????
      ''  ZBBRKHID    ,--NUMBER(16)    Y                ??????ID
      (select khbdh from tb_lppcxx where pcid=v_pcid)  KHBDH       ,--VARCHAR2(30)  Y                ????
      a.fdid  FDID        ,--NUMBER(16)    Y                ???
      '01'  SQRZJLX     ,--VARCHAR2(2)                    ???????
      b.aac147 as  SQRZJHM     ,--VARCHAR2(20)                   ???????
      rec_pa.name   SQRXM       ,--VARCHAR2(30)                   ?????
      b.sjh  SQRSJ       ,--VARCHAR2(30)  Y                ?????
      b.GZDJZD  SQRDZ       ,--VARCHAR2(200) Y                ?????
      b.email  SQRYX       ,--VARCHAR2(30)  Y                ?????
      'S1'  SQLX        ,--VARCHAR2(66)  Y                ????
     to_char(to_date(rec_pa.regdate, 'dd-mm-yyyy'), 'yyyymmdd')  SQRQ        ,--NUMBER(8)     Y                ????
      '0'   BBRSCZT     ,--VARCHAR2(1)   Y                ???????
      ''  BBRCJDM     ,--VARCHAR2(10)  Y                ???????
      ''  BBRCJXM     ,--VARCHAR2(500) Y                ???????
      ''  BBRCJDJ     ,--VARCHAR2(10)  Y                ???????
      ''  BBRSWRQ     ,--NUMBER(8)     Y                ???????
      ''  BBRYWSGFSRQ ,--NUMBER(8)     Y                ???????????
      ''  JBID        ,--NUMBER(16)    Y                ??ID
      ''  ZJDM        ,--VARCHAR2(20)  Y                ????
      ''  ZJQZR       ,--NUMBER(8)     Y                ?????
      '11'  AJZT        ,--VARCHAR2(2)   Y                ????
      ''  ZHCLRQ      ,--DATE          Y                ??????
      ''  AJXGDM      ,--VARCHAR2(80)  Y                ??????
      ''  AJXGLY      ,--VARCHAR2(300) Y                ??????
      ''  XGRQ        ,--VARCHAR2(30)  Y                ????
      to_char(to_date(rec_pa.confirmdate,'dd-mm-yyyy'),'yyyymmdd')  JARQ        ,--NUMBER(8)     Y                ????
      '01'  AJJL        ,--VARCHAR2(2)   Y                ????
      ''  AJJLSM1     ,--VARCHAR2(10)  Y                ??????1
      ''  AJJLSM      ,--VARCHAR2(200) Y                ??????(??)
      ''  JBR         ,--VARCHAR2(30)  Y                ???
      rec_pa.ClaimAmount  AJPFJE      ,--NUMBER(16,2)  Y                ??????
      rec_pa.name  LPJSYR      ,--VARCHAR2(30)  Y                ??????
      '1'  AJPFFS      ,--VARCHAR2(1)   Y                ??????
      '0'  SFXNAJ      ,--VARCHAR2(1)            '0'     ??????
      '0'  SFZDSCZPA   ,--VARCHAR2(1)   Y        '0'     ?????????
      null  SCZPASJ     ,--DATE          Y                ???????
      null  LSSJ        ,--DATE          Y                ????
      ''   SLRID       ,--NUMBER(19)    Y                ???id
      ''   SLR         ,--VARCHAR2(50)  Y                ???
      ''   LRRID       ,--NUMBER(19)    Y                ???id
      ''   LRR         ,--VARCHAR2(50)  Y                ???
      ''   SHRID       ,--NUMBER(19)    Y                ???ID
      ''   SHR         ,--VARCHAR2(50)  Y                ???
      ''   ZJRID       ,--NUMBER(19)    Y                ???ID
      ''   ZJR         ,--VARCHAR2(50)  Y                ???
      ''   ZJSJ        ,--DATE          Y                ????
      ''   ZJJL        ,--VARCHAR2(1)   Y                ????
      ''   ZJYJMS      ,--VARCHAR2(200) Y                ??????
      ''   SSYLY       ,--VARCHAR2(200) Y                ?????
      ''   KHSYR       ,--VARCHAR2(50)  Y                ?????
      ''   SYJL        ,--VARCHAR2(1)   Y                ????
      ''   SYRQ        ,--DATE          Y                ????
      ''   SYYJMS      ,--VARCHAR2(200) Y                ??????
      ''   BXCSSCZPABZ ,--VARCHAR2(1)   Y                ???????????
      ''   DYSJSCBZ    ,--VARCHAR2(1)   Y                ????????
      ''   DYSJSCSJ    ,--DATE          Y                ????????
      ''  LPKGFKHH    ,--VARCHAR2(50)  Y                ????????
      ''  LPKGFYHZH   ,--VARCHAR2(35)  Y                ?????????
      rec_pa.name  SKFXM       ,--VARCHAR2(50)  Y                ?????
       to_date( to_char(to_date(rec_pa.confirmdate,'dd-mm-yyyy'),'yyyymmdd'),'yyyy-mm-dd')   TQRQ        ,--DATE          Y                ????
      ''  QCLSM       ,--VARCHAR2(300) Y                ?????
      to_char(to_date(rec_pa.confirmdate,'dd-mm-yyyy'),'yyyymmdd')  SFRQ        ,--NUMBER(8)     Y                ????
      -1  SEQLOGID    ,--NUMBER        Y
      '1'  DYBZ        ,--VARCHAR2(1)   Y                ????
      'system'  DYR         ,--VARCHAR2(50)  Y                ???
      ''  DYRQ        ,--NUMBER(8)     Y                ????
      ''  BDYRQ       ,--NUMBER(8)     Y                ?????
      ''  BDYR        ,--VARCHAR2(50)  Y                ????
      1  FPS         ,--NUMBER(3)     Y                ???
      '0'  SFJJAJ      ,--VARCHAR2(1)   Y                ?????? 0? 1 ?
      ''  CSRID       ,--NUMBER(16)    Y                ???ID
      ''  CSR         ,--VARCHAR2(50)  Y                ???
      ''  CSJG        ,--VARCHAR2(1)   Y                ???? 1?? ?? ???
      ''  CSCWDM      ,--VARCHAR2(50)  Y                ?????(???)
      ''  CSCWMS      ,--VARCHAR2(200) Y                ??????
      ''  FSRID       ,--NUMBER(16)    Y                ???ID
      ''  FSR         ,--VARCHAR2(50)  Y                ???
      ''  FSJG        ,--VARCHAR2(1)   Y                ???? 1?? ?? ???
      ''  FSCWDM      ,--VARCHAR2(50)  Y                ?????(???)
      ''  FSCWMS      ,--VARCHAR2(200) Y                ??????
      ''  AJSFSD      ,--VARCHAR2(1)   Y                ??????0??? 1?
      ''  SDKSSJ      ,--DATE          Y                ??????
      ''  DQCZR       ,--VARCHAR2(50)  Y                ?????
      '00'  ZBBRGX      ,--VARCHAR2(2)   Y                ?????????
      '0'   SFGS        ,--VARCHAR2(1)   Y                ????
      ''   YWSGDD      ,--VARCHAR2(200) Y                ??????
      rec_pa.reason  YWSGYY      ,--VARCHAR2(200) Y                ??????
      ''  SSWBYY  from tb_fdxx a,tb_khxx b where nvl(wbbdh,khbdh)=rec_pc.wbbdh and a.bbrkhid=b.khid and b.aac147=rec_pa.NationalID
      and exists(select 'x' from tb_fdzrmx f,tb_zrxx h where f.zrid=h.zrid and f.fdid=a.fdid
      and ((h.zrbm   like decode(rec_pa.BenefitCode,'AHI','AIOP','SHIP','AIOP','NONSHIP','AIOP','HI','HI','IPAY','IP','IPAN','IP','OP','OP','MBRN','MAT','MBRY','MAT','error')||'%')
            or (rec_pa.BenefitCode in('OP','IP','IPAY','IPAN') and h.zrbm like 'OIP%'))--20141101 ????????????????
                 )
      and rownum<2;
      IF SQL%rowcount=0 THEN
         DBMS_OUTPUT.PUT_LINE('TB_LPAJXX DATA ERROR!AAC147='||rec_pa.NationalID||'??????'||rec_pa.BenefitCode);
         RAISE MYEXCEPTION;
      END IF;
      v_pcajs:=v_pcajs+sql%rowcount;
      --???????
          insert into tb_zpaxx(
          ZPAID     ,--NUMBER(16)                      ???ID
          AJID      ,--NUMBER(16)                      ??ID
          ZPAH      ,--VARCHAR2(30)   Y                ?????
          JBID      ,--NUMBER(16)     Y                ??ID
          ZDDM      ,--VARCHAR2(20)   Y                ????
          ZRID      ,--NUMBER(16)                      ??ID
          PFZRDM    ,--VARCHAR2(10)   Y                ??????
          ZDZJE     ,--NUMBER(16,2)   Y                ?????
          SBZFZJE   ,--NUMBER(16,2)   Y                ???????
          ZFJE      ,--NUMBER(16,2)   Y                ????
          FLZFJE    ,--NUMBER(16,2)   Y                ??????
          QTDSFZFJE ,--NUMBER(16,2)   Y                ?????????
          BHLFY     ,--NUMBER(16,2)   Y                ?????
          BXZRWJE   ,--NUMBER(16,2)   Y                ???????
          XLLSPFJE  ,--NUMBER(16,2)   Y                ????????
          RGTZJE    ,--NUMBER(16,2)   Y                ??????
          SJPFJE    ,--NUMBER(16,2)   Y                ??????
          MPE       ,--NUMBER(16,2)   Y                ???
          XGDM      ,--VARCHAR2(100)  Y                ????
          XGDMMS    ,--VARCHAR2(1024) Y                ??????
          ZT        ,--VARCHAR2(1)    Y                ??
          ZPAJL     ,--VARCHAR2(2)    Y                ?????
          JLSM1     ,--VARCHAR2(10)   Y                ????1
          JLSM2     ,--VARCHAR2(500)  Y                ????2
          SHYYJ     ,--VARCHAR2(200)  Y                ?????
          SJGFTS    ,--NUMBER         Y                ???????
          SSXM      ,--VARCHAR2(30)   Y                ????
          SSPFBL    ,--NUMBER(5,2)    Y                ??????
          MPTS      ,--NUMBER         Y                ????
          SFSDTJ    ,--VARCHAR2(1)             '0'     ??????
          LSSJ      ,--DATE           Y                ????
          SYFPH     ,--VARCHAR2(500)  Y                ?????
          FPID      ,--NUMBER(16)     Y                ??ID
          SEQLOGID  ,--NUMBER         Y
          FDID      ,--NUMBER(16)     Y                ??????
          SBBDX     ,--VARCHAR2(1)    Y                ???????
          CDEJE     --NUMBER(16,2)   Y                ?????
          )
          select       seq_ZPAID.nextval as zpaid     ,--NUMBER(16)                      ???ID
          v_AJID      ,--NUMBER(16)                      ??ID
          rec_pa.pah||'001' as ZPAH      ,--VARCHAR2(30)   Y                ?????
          (select jbid from tb_jbkxx where jbdm=(select max(aaa102) from TB_ZDDMBXGSDMDZB where aaa100='TB_JBKXX' and bxgsxmbm=rec_pa.icd and bxgsid=592)) as JBID      ,--NUMBER(16)     Y                ??ID
          (select max(aaa102) from TB_ZDDMBXGSDMDZB where aaa100='TB_JBKXX' and bxgsxmbm=rec_pa.icd and bxgsid=592) as ZDDM      ,--VARCHAR2(20)   Y                ????
          b.ZRID      ,--NUMBER(16)                      ??ID
          c.zrbm PFZRDM    ,--VARCHAR2(10)   Y                ??????
          rec_pa.???? ZDZJE     ,--NUMBER(16,2)   Y                ?????
          '' SBZFZJE   ,--NUMBER(16,2)   Y                ???????
          '' ZFJE      ,--NUMBER(16,2)   Y                ????   ,
          '' FLZFJE    ,--NUMBER(16,2)   Y                ??????
          '' QTDSFZFJE ,--NUMBER(16,2)   Y                ?????????
          '' BHLFY     ,--NUMBER(16,2)   Y                ?????
          '' BXZRWJE   ,--NUMBER(16,2)   Y                ???????
          '' XLLSPFJE  ,--NUMBER(16,2)   Y                ????????
          '' RGTZJE    ,--NUMBER(16,2)   Y                ??????
          rec_pa.ClaimAmount SJPFJE    ,--NUMBER(16,2)   Y                ??????
          '' MPE       ,--NUMBER(16,2)   Y                ???
          '' XGDM      ,--VARCHAR2(100)  Y                ????
          '' XGDMMS    ,--VARCHAR2(1024) Y                ??????
          '1' ZT        ,--VARCHAR2(1)    Y                ??
          '01' ZPAJL     ,--VARCHAR2(2)    Y                ?????
          '' JLSM1     ,--VARCHAR2(10)   Y                ????1
          '' JLSM2     ,--VARCHAR2(500)  Y                ????2
          '' SHYYJ     ,--VARCHAR2(200)  Y                ?????
        case when nvl(b.zrbe,0)>0 and rec_pa.BenefitCode='HI' then to_char(round(rec_pa.ClaimAmount/b.zrbe)) else '' end SJGFTS    ,--NUMBER         Y                ???????
          '' SSXM      ,--VARCHAR2(30)   Y                ????
          '' SSPFBL    ,--NUMBER(5,2)    Y                ??????
          '' MPTS      ,--NUMBER         Y                ????
          '0' SFSDTJ    ,--VARCHAR2(1)             '0'     ??????
          '' LSSJ      ,--DATE           Y                ????
          '' SYFPH     ,--VARCHAR2(500)  Y                ?????
          '' FPID      ,--NUMBER(16)     Y                ??ID
          -1 SEQLOGID  ,--NUMBER         Y
          a.FDID      ,--NUMBER(16)     Y                ??????
          '0' SBBDX     ,--VARCHAR2(1)    Y                ???????
          '' CDEJE     --NUMBER(16,2)   Y                ?????
          from tb_lpajxx a,tb_fdzrmx b,tb_zrxx c where a.ajid=v_ajid and a.fdid=b.fdid and b.zrid=c.zrid
           --  and c.zrbm  like decode(rec_pa.BenefitCode,'AHI','AIOP','SHIP','AIOP','NONSHIP','AIOP','HI','HI','IPAY','IP','IPAN','IP','OP','OP','MBRN','MAT','MBRY','MAT','error')||'%'
            and (( c.zrbm   like decode(rec_pa.BenefitCode,'AHI','AIOP','SHIP','AIOP','NONSHIP','AIOP','HI','HI','IPAY','IP','IPAN','IP','OP','OP','MBRN','MAT','MBRY','MAT','error')||'%')
            or (rec_pa.BenefitCode in('OP','IP','IPAY','IPAN') and c.zrbm like 'OIP%'))  --20141101 ????????????????
              and rownum<2;
          IF SQL%rowcount!=1 THEN
             DBMS_OUTPUT.PUT_LINE('TB_ZPAXX DATA ERROR!AAC147='||rec_pa.NationalID);
             RAISE MYEXCEPTION;
          END IF;
          v_pczpas:=v_pczpas+sql%rowcount;
          --??????
          update TEMP_Import_HIS_AJXX set ????='1',????=to_char(sysdate,'yyyymmddhh') where ???? is null and  NATIONALID=rec_pa.NationalID and "Claim No"=rec_pa.pah;
     end loop;
     --???????
     if rec_pc.ajs!=v_pcajs or rec_pc.ajs!=v_pczpas then
        dbms_output.put_line('????????????'||rec_pc.pch||'?????'||to_char(rec_pc.ajs)||'?????'||to_char(v_pcajs)||'??????'||to_char(v_pczpas));
       else
          dbms_output.put_line('????'||rec_pc.pch||'?????'||to_char(rec_pc.ajs)||'?????'||to_char(v_pcajs)||'??????'||to_char(v_pczpas)||', ???????');
     end if;
    end loop;
      PReturnCode:='0';
    PReturnMsg:='????????!';
    return;
    EXCEPTION
    WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('[yhs debug] ' || 'PReturncode= ' ||'E');
    PReturnMsg := 'Error:' || sqlerrm;
    DBMS_OUTPUT.PUT_LINE(PReturnMsg);
end SP_IMPORT_LSPA;

/
