CREATE PROCEDURE      "SP_P1_30017" (report_id   In t_report_def_info.REPORTID%TYPE,
                                        pStartdate  IN varchar2, -- ??????yyyymmdd
                                        pEnddate    IN varchar2, -- ??????yyyymmdd
                                        pStatman    IN t_report_gen_info.STATMAN%TYPE, --???
                                        ptype       in varchar2, /*0 ???? ,1 ?? 2 ?? 3 ?? */ --?????
                                        POther1     IN varchar2, --??id
                                        POther2     IN varchar2, --??id
                                        POther3     IN varchar2, --??id
                                        POther4     IN varchar2, --??ID
                                        POther5     IN varchar2, --????
                                        POther6     IN varchar2, --??ID
                                        POther7     IN varchar2, --????????
                                        POther8     IN varchar2, --????????
                                        PReturnCode OUT varchar2,
                                        PReturnMsg  OUT varchar2) AS
  V_STEP_CODE  CHAR(5); --?????????????????
  vreportid    t_report_def_info.REPORTID%TYPE; --??ID
  v_start_date number := 0; --????????
  v_end_date   number := 0; --????????
  vxzqhdm      t_report_gen_info.STATORGID%TYPE; --????????????

  vstatid varchar(30); --?????????????????
  type cellType is record(
    statid  varchar2(15),
    col     number,
    r       number,
    content varchar2(1024));

  cell      cellType; --?????????????
  vdwmc     varchar2(50); --????????????
  vusername t_report_gen_info.STATMAN%TYPE; --????????
  vnd       t_report_gen_info.STATYEAR%TYPE; --????
  rowno     number := 0; --??????

  v_nxpfje number :=0;--????????????
  v_nxpfjebl varchar2(10);--????????????
  v_nvxpfje number :=0;--????????????
  v_nvxpfjebl varchar2(10);--????????????
  v_pfje number :=0;--??????
  v_pfbl varchar2(10);--????
  v_nld varchar2(10) :=0;--???


  v_sumcpje number:=0;
  v_flag varchar2(1):='0';
  v_cpid number:=0;
  begin
  V_STEP_CODE := '00000';
  PReturnMsg  := 'OK';
  PReturnCode := 'E';
  vreportid   := substr(report_id, 1, 5);
  vusername   := pStatman;
  vnd         := substr(pStartdate, 1, 4);

  v_start_date := to_number(substr(pStartdate, 1, 8));
  v_end_date   := to_number(substr(pEnddate, 1, 8));

  --???????????????????????????
  delete from t_report_data_info
   where statid in
         (select statid from T_REPORT_GEN_INFO where reportid = report_id);

  delete from T_REPORT_GEN_INFO
   where statid in
         (select statid from T_REPORT_GEN_INFO where reportid = report_id);

  V_STEP_CODE := '00001';
  --???,?T_RERORT_GEN_INFO?????????????
  --???????
  select seq_statid.nextval into vstatid from dual;

  -- ??????????
  insert into t_report_gen_info
    (STATID,
     REPORTID,
     STATORGID,
     STATORGNAME,
     STATDATE,
     STATMAN,
     STATYEAR,
     BEGINDATE,
     ENDDATE,
     STAT_OTHER,
     STAT_TYPE)
  values
    (vstatid,
     vreportid,
     '',
     '',
     to_char(sysdate, 'yyyymmdd'),
     vusername,
     vnd,
     v_start_date,
     v_end_date,
     substr(pEnddate, 1, 1),
     trim(ptype));

  /* --?????? ??excel???0?????1??,????0???*/
  --???
  insert into t_report_data_info(statid,sheet,col,r,content) values(vstatid,0,1,1,'CLFX08');

  --????
  insert into t_report_data_info(statid,sheet,col,r,content) values(vstatid,0,1,2,to_char(sysdate,'yyyymmdd'));

  --????
  select max(bxgsqc) into cell.content from tb_bxgsxx where bxgsid = trim(POther1);
  if cell.content is not null then
    insert into t_report_data_info(statid,sheet,col,r,content) values(vstatid,0,1,3,cell.content);
  end if;

  --????
  select max(ttmc) into cell.content from tb_ttxx where ttid = trim(POther2);
  if cell.content is not null then
    insert into t_report_data_info(statid,sheet,col,r,content) values (vstatid,0,1,4,cell.content);
  end if;

  --???
  select max(khbdh) into cell.content from tb_bdxx where bdid = trim(POther3);
  if cell.content is not null then
    insert into t_report_data_info(statid,sheet,col,r,content) values (vstatid,0,1,5,cell.content);
  end if;

  --????????
  insert into t_report_data_info(statid,sheet,col,r,content) values (vstatid,0,1,6,trim(pStartdate) ||'-'|| trim(pEnddate));

  --????????
  insert into t_report_data_info(statid,sheet,col,r,content) values (vstatid,0,1,7,trim(POther7) ||'-'|| trim(POther8));


  cell.statid := vstatid;
  cell.col    := 0; --?1???
  cell.r      := 10; --?12???
  --???????????????????????????????excel????????????????????

  --??????
  for rec_bxgs in (
      select a.bxgsid
        from tb_bxgsxx a,tb_ttxx b,tb_bdxx c,tb_cpxx d,tb_fdzrmx e,tb_zpaxx f,tb_cpzrdzb g,tb_khxx h,/*tb_bdcpxx i,*/tb_fdxx j,tb_lpajxx k
        where a.bxgsid = c.bxgsid
        and f.ajid=k.ajid
        and j.bbrkhid=k.bbrkhid
         and b.ttid = c.ttid
         /*and c.bdid = i.bdid
         and i.cpid = d.cpid*/
         and e.fdid=j.fdid
         and e.zrid = g.zrid
         /*and i.cpid = g.cpid*/  and d.cpid = g.cpid
         and f.zrid = g.zrid
         and h.khid = j.bbrkhid
         and j.khbdh = c.khbdh
         and j.ttid = c.ttid
         and a.bxgsid = nvl(trim(POther1),a.bxgsid)
         and b.ttid = nvl(trim(POther2),b.ttid)
         and c.bdid = nvl(trim(POther3),c.bdid)
         and c.bdsxrq >=nvl(trim(pStartdate), 19000101)
         and c.bdzzrq >= nvl(trim(pEnddate), c.bdzzrq)
         and c.bdsxrq <=nvl(trim(pEnddate), 99991231)
         and k.jarq > nvl(trim(POther7),19000101)
         and k.jarq < nvl(trim(POther8),99991231)
         group by a.bxgsid
         order by a.bxgsid
         )loop
  --????
  for rec_tt in(
    select b.ttid,b.ttmc
    from tb_bxgsxx a,tb_ttxx b,tb_bdxx c,tb_cpxx d,tb_fdzrmx e,tb_zpaxx f,tb_cpzrdzb g,tb_khxx h/*,tb_bdcpxx i*/,tb_fdxx j,tb_lpajxx k
    where a.bxgsid = c.bxgsid
         and f.ajid=k.ajid
         and j.bbrkhid=k.bbrkhid
         and b.ttid = c.ttid
         /*and c.bdid = i.bdid
         and i.cpid = d.cpid*/
         and e.fdid=j.fdid
         and e.zrid = g.zrid
         /*and i.cpid = g.cpid*/ and d.cpid = g.cpid
         and f.zrid = g.zrid
         and h.khid = j.bbrkhid
         and j.khbdh = c.khbdh
         and j.ttid = c.ttid
         and a.bxgsid = rec_bxgs.bxgsid
         and b.ttid = nvl(trim(POther2),b.ttid)
         and c.bdid = nvl(trim(POther3),c.bdid)
         and c.bdsxrq >=nvl(trim(pStartdate), 19000101)
         and c.bdzzrq >= nvl(trim(pEnddate), c.bdzzrq)
         and c.bdsxrq <=nvl(trim(pEnddate), 99991231)
         and k.jarq > nvl(trim(POther7),19000101)
         and k.jarq < nvl(trim(POther8),99991231)
         group by b.ttid,b.ttmc
         order by b.ttid
         )loop
  --????
  for rec_bd in(
    select c.bdid
    from tb_bxgsxx a,tb_ttxx b,tb_bdxx c,tb_cpxx d,tb_fdzrmx e,tb_zpaxx f,tb_cpzrdzb g,tb_khxx h,/*tb_bdcpxx i,*/tb_fdxx j,tb_lpajxx k
    where a.bxgsid = c.bxgsid
         and f.ajid=k.ajid
         and j.bbrkhid=k.bbrkhid
         and b.ttid = c.ttid
         /*and c.bdid = i.bdid
         and i.cpid = d.cpid*/
         and e.fdid=j.fdid
         and e.zrid = g.zrid
         /*and i.cpid = g.cpid*/  and d.cpid = g.cpid
         and f.zrid = g.zrid
         and h.khid = j.bbrkhid
         and j.khbdh = c.khbdh
         and j.ttid = c.ttid
         and a.bxgsid = rec_bxgs.bxgsid
         and b.ttid = rec_tt.ttid
         and c.bdid = nvl(trim(POther3),c.bdid)
         and c.bdsxrq >=nvl(trim(pStartdate), 19000101)
         and c.bdzzrq >= nvl(trim(pEnddate), c.bdzzrq)
         and c.bdsxrq <=nvl(trim(pEnddate), 99991231)
         and k.jarq > nvl(trim(POther7),19000101)
         and k.jarq < nvl(trim(POther8),99991231)
         and EXISTS(SELECT 'X' FROM TB_LPAJXX H WHERE H.AJID=F.AJID AND AJZT IN('08','09','10','11') and h.khbdh = c.khbdh )
         group by c.bdid
         order by c.bdid
         )loop

v_sumcpje:=null;
v_flag:=0;
v_cpid:=0;
  --????
  for rec_data in(
   select h.bdsxzzr,h.bxgsbh,h.bxgsmc,h.ttbh,h.khbdh,h.cpid,h.cph,h.cpmc,n.nldname,h.pfje,h.nxpfje,h.nvxpfje
   from  ( select c.bdsxrq || '-' || c.bdzzrq as bdsxzzr,a.bxgsbh,a.bxgsqc as bxgsmc,b.ttbh,c.khbdh,d.cpid,d.cph,d.cpmc,
      case when add_months(to_date(h.csrq,'yyyy-mm-dd'),0)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),48)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '0-4?'
            when add_months(to_date(h.csrq,'yyyy-mm-dd'),48)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),108)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '5-9?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),108)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),168)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '10-14?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),168)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),228)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '15-19?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),228)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),288)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '20-24?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),288)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),348)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '25-29?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),348)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),408)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '30-34?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),408)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),468)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '35-39?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),468)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),528)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '40-44?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),528)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),588)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '45-49?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),588)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),648)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '50-54?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),648)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),708)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '55-59?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),708)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),768)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '60-64?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),768)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),828)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '65-69?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),828)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),888)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '70-74?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),888)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),948)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '75-79?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),948)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')  then '80???' end as nldname,
               sum(nvl(f.sjpfje,0)) as pfje,
               sum(case when h.xb='1' then nvl(f.sjpfje,0) else 0 end ) as nxpfje,
               sum(case when h.xb='2' then nvl(f.sjpfje,0) else 0 end ) as nvxpfje
            from tb_bxgsxx a,tb_ttxx b,tb_bdxx c,tb_cpxx d,tb_fdzrmx e,tb_zpaxx f,tb_cpzrdzb g,tb_khxx h,/*tb_bdcpxx i,*/tb_fdxx j,tb_lpajxx k
            where a.bxgsid = c.bxgsid
            and f.ajid=k.ajid
            and j.bbrkhid=k.bbrkhid
            and b.ttid = c.ttid
            /*and c.bdid = i.bdid
            and i.cpid = d.cpid*/
            and e.fdid=j.fdid
            and e.zrid = g.zrid
            /*and i.cpid = g.cpid*/  and d.cpid = g.cpid
            and nvl(f.sjpfje,0)>0
            and f.zrid = g.zrid
            and h.khid = j.bbrkhid
            and j.khbdh = c.khbdh
            and j.ttid = c.ttid
            and a.bxgsid = rec_bxgs.bxgsid
            and b.ttid = rec_tt.ttid
            and c.bdid = rec_bd.bdid
            and c.bdsxrq >=nvl(trim(pStartdate), 19000101)
         and c.bdzzrq >= nvl(trim(pEnddate),  c.bdzzrq )
         and c.bdsxrq <=nvl(trim(pEnddate), 99991231)
            and k.jarq > nvl(trim(POther7),19000101)
            and k.jarq < nvl(trim(POther8),99991231)
            group by c.bdsxrq || '-' || c.bdzzrq, a.bxgsbh,a.bxgsqc,b.ttbh,c.khbdh,d.cpid,d.cph,d.cpmc,
         case when add_months(to_date(h.csrq,'yyyy-mm-dd'),0)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),48)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '0-4?'
            when add_months(to_date(h.csrq,'yyyy-mm-dd'),48)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),108)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '5-9?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),108)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),168)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '10-14?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),168)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),228)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '15-19?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),228)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),288)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '20-24?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),288)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),348)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '25-29?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),348)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),408)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '30-34?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),408)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),468)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '35-39?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),468)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),528)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '40-44?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),528)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),588)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '45-49?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),588)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),648)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '50-54?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),648)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),708)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '55-59?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),708)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),768)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '60-64?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),768)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),828)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '65-69?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),828)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),888)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '70-74?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),888)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),948)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '75-79?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),948)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')  then '80???' end
          ) h, v_jkbx_nld n
           where h.nldname=n.nldname order by h.cpid,n.xh asc
     )loop
       if rec_data.cpid!=v_cpid then
          select sum(nvl(f.sjpfje,0)) into v_sumcpje
            from tb_bxgsxx a,tb_ttxx b,tb_bdxx c,tb_cpxx d,tb_fdzrmx e,tb_zpaxx f,tb_cpzrdzb g,tb_khxx h,/*tb_bdcpxx i,*/tb_fdxx j,tb_lpajxx k
            where a.bxgsid = c.bxgsid
            and f.ajid=k.ajid
            and j.bbrkhid=k.bbrkhid
            and b.ttid = c.ttid
            /*and c.bdid = i.bdid
            and i.cpid = d.cpid*/
            and e.fdid=j.fdid
            and e.zrid = g.zrid
            /*and i.cpid = g.cpid*/  and d.cpid = g.cpid
            and nvl(f.sjpfje,0)>0
            and f.zrid = g.zrid
            and h.khid = j.bbrkhid
            and j.khbdh = c.khbdh
            and d.cpid=rec_data.cpid
            and c.bdid=rec_bd.bdid
            and c.bdsxrq >=nvl(trim(pStartdate), 19000101)
            and c.bdzzrq >= nvl(trim(pEnddate),  c.bdzzrq )
            and c.bdsxrq <=nvl(trim(pEnddate), 99991231)
            and k.jarq > nvl(trim(POther7),19000101)
            and k.jarq < nvl(trim(POther8),99991231);
        end if;

     --??????
     insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 0, cell.r, rec_data.bxgsbh);
     --??????
     insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 1, cell.r, rec_data.bxgsmc);

     --?????
     select max(e.zttbh) into  cell.content from tb_zttxx e,tb_bdxx d  where e.zttid = d.zttid and d.bdid = rec_bd.bdid;
     if cell.content is not null then
        insert into t_report_data_info (statid, sheet, col, r, content) values (cell.statid,0,2,cell.r,cell.content);
     else
        insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 2, cell.r, rec_data.ttbh);
     end if;
     --??????
     select max(e.zttmc) into  cell.content from tb_zttxx e,tb_bdxx d  where e.zttid = d.zttid and d.bdid = rec_bd.bdid;
     if cell.content is not null then
        insert into t_report_data_info (statid, sheet, col, r, content) values (cell.statid,0,3,cell.r,cell.content);
     else
     insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 3, cell.r, rec_tt.ttmc);
     end if;
     --???
     insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 4, cell.r, rec_data.khbdh);
     --????-???
     insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 5, cell.r, rec_data.bdsxzzr);
     --????
     insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 6, cell.r, rec_data.cph);
     --????
     insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 7, cell.r, rec_data.cpmc);
     --???
     insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 8, cell.r, rec_data.nldname);
     --????????????
     insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 9, cell.r, rec_data.nxpfje);
     --????????????
     insert into t_report_data_info(statid, sheet, col, r, content) select cell.statid, 0, 10, cell.r,
     case when v_sumcpje>0 then to_char(round(nvl(rec_data.nxpfje,0)/v_sumcpje*100,2))  else '' end   from dual;
     --????????????
     insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 11, cell.r, rec_data.nvxpfje);
     --????????????
     insert into t_report_data_info(statid, sheet, col, r, content) select cell.statid, 0, 12, cell.r,
     case when v_sumcpje>0 then to_char(round(nvl(rec_data.nvxpfje,0)/v_sumcpje*100,2)) else '' end   from dual;
     --??????
     insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 13, cell.r, rec_data.pfje);
     --????
     insert into t_report_data_info(statid, sheet, col, r, content) select cell.statid, 0, 14, cell.r,
     case when v_sumcpje>0 then to_char(round(nvl(rec_data.pfje,0)/v_sumcpje*100,2)) else '' end   from dual;
     cell.r :=  cell.r+1;
     v_cpid:=rec_data.cpid;
  end loop;
  --????
for bd in
  (select h.nxpfje,h.nvxpfje,h.pfje,h.nldname,
          decode(pfje,0,null,round(h.nxpfje*100/h.pfje,2)) as nxpfjebl,
          decode(pfje,0,null,round(h.nvxpfje*100/h.pfje,2)) as nvxpfjebl
  from(select sum(nvl(f.sjpfje,0)) as pfje,
               sum(case when h.xb='1' then nvl(f.sjpfje,0) else 0 end ) as nxpfje,
               sum(case when h.xb='2' then nvl(f.sjpfje,0) else 0 end ) as nvxpfje,
          case when add_months(to_date(h.csrq,'yyyy-mm-dd'),0)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),48)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '0-4?'
            when add_months(to_date(h.csrq,'yyyy-mm-dd'),48)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),108)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '5-9?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),108)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),168)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '10-14?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),168)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),228)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '15-19?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),228)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),288)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '20-24?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),288)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),348)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '25-29?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),348)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),408)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '30-34?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),408)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),468)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '35-39?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),468)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),528)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '40-44?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),528)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),588)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '45-49?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),588)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),648)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '50-54?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),648)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),708)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '55-59?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),708)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),768)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '60-64?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),768)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),828)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '65-69?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),828)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),888)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '70-74?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),888)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),948)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '75-79?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),948)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')  then '80???' end as nldname
            from tb_bxgsxx a,tb_ttxx b,tb_bdxx c,tb_cpxx d,tb_fdzrmx e,tb_zpaxx f,tb_cpzrdzb g,tb_khxx h,/*tb_bdcpxx i,*/tb_fdxx j,tb_lpajxx k
            where a.bxgsid = c.bxgsid
            and f.ajid=k.ajid
            and j.bbrkhid=k.bbrkhid
            and b.ttid = c.ttid
            /*and c.bdid = i.bdid
            and i.cpid = d.cpid*/
            and e.fdid=j.fdid
            and e.zrid = g.zrid
            /*and i.cpid = g.cpid*/ and d.cpid = g.cpid
            and nvl(f.sjpfje,0)>0
            and f.zrid = g.zrid
            and h.khid = j.bbrkhid
            and j.khbdh = c.khbdh
            and j.ttid = c.ttid
            and a.bxgsid = rec_bxgs.bxgsid
            and b.ttid = rec_tt.ttid
            and c.bdid=rec_bd.bdid
            and c.bdsxrq >=nvl(trim(pStartdate), 19000101)
            and c.bdzzrq >= nvl(trim(pEnddate),  c.bdzzrq )
            and c.bdsxrq <=nvl(trim(pEnddate), 99991231)
            and k.jarq > nvl(trim(POther7),19000101)
            and k.jarq < nvl(trim(POther8),99991231)
            group by
            case when add_months(to_date(h.csrq,'yyyy-mm-dd'),0)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),48)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '0-4?'
            when add_months(to_date(h.csrq,'yyyy-mm-dd'),48)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),108)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '5-9?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),108)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),168)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '10-14?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),168)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),228)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '15-19?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),228)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),288)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '20-24?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),288)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),348)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '25-29?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),348)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),408)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '30-34?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),408)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),468)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '35-39?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),468)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),528)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '40-44?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),528)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),588)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '45-49?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),588)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),648)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '50-54?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),648)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),708)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '55-59?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),708)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),768)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '60-64?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),768)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),828)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '65-69?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),828)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),888)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '70-74?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),888)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),948)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '75-79?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),948)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')  then '80???' end
               order by
               case when add_months(to_date(h.csrq,'yyyy-mm-dd'),0)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),48)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '0-4?'
            when add_months(to_date(h.csrq,'yyyy-mm-dd'),48)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),108)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '5-9?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),108)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),168)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '10-14?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),168)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),228)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '15-19?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),228)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),288)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '20-24?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),288)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),348)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '25-29?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),348)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),408)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '30-34?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),408)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),468)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '35-39?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),468)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),528)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '40-44?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),528)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),588)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '45-49?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),588)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),648)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '50-54?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),648)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),708)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '55-59?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),708)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),768)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '60-64?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),768)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),828)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '65-69?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),828)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),888)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '70-74?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),888)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),948)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '75-79?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),948)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')  then '80???' end)h
               )loop

  insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 4, cell.r, '?????');
  --???
  insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 8, cell.r, bd.nldname);
  --????????????
  insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 9, cell.r, bd.nxpfje);
  --????????????
  insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 10, cell.r, bd.nxpfjebl);
  --????????????
  insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 11, cell.r, bd.nvxpfje);
  --????????????
  insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 12, cell.r, bd.nvxpfjebl);
  --??????
  insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 13, cell.r, bd.pfje);
  --????
  --insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 13, cell.r, v_pfbl);
  cell.r := cell.r+1;
 end loop;
 end loop;

 --????
 for tt in(select h.nxpfje,h.nvxpfje,h.pfje,h.nldname,
        decode(pfje,0,null,round(h.nxpfje*100/h.pfje,2)) as nxpfjebl,
        decode(pfje,0,null,round(h.nvxpfje*100/h.pfje,2)) as nvxpfjebl
   --into v_nxpfje,v_nvxpfje,v_pfje,v_nxpfjebl,v_nvxpfjebl
   from  (  select sum(nvl(f.sjpfje,0)) as pfje,
               sum(case when h.xb='1' then nvl(f.sjpfje,0) else 0 end ) as nxpfje,
               sum(case when h.xb='2' then nvl(f.sjpfje,0) else 0 end ) as nvxpfje,
               case when add_months(to_date(h.csrq,'yyyy-mm-dd'),0)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),48)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '0-4?'
            when add_months(to_date(h.csrq,'yyyy-mm-dd'),48)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),108)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '5-9?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),108)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),168)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '10-14?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),168)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),228)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '15-19?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),228)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),288)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '20-24?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),288)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),348)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '25-29?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),348)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),408)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '30-34?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),408)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),468)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '35-39?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),468)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),528)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '40-44?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),528)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),588)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '45-49?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),588)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),648)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '50-54?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),648)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),708)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '55-59?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),708)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),768)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '60-64?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),768)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),828)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '65-69?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),828)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),888)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '70-74?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),888)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),948)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '75-79?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),948)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')  then '80???' end as nldname
            from tb_bxgsxx a,tb_ttxx b,tb_bdxx c,tb_cpxx d,tb_fdzrmx e,tb_zpaxx f,tb_cpzrdzb g,tb_khxx h,/*tb_bdcpxx i,*/tb_fdxx j,tb_lpajxx k
            where a.bxgsid = c.bxgsid
            and f.ajid=k.ajid
            and j.bbrkhid=k.bbrkhid
            and b.ttid = c.ttid
            /*and c.bdid = i.bdid
            and i.cpid = d.cpid*/
            and e.fdid=j.fdid
            and e.zrid = g.zrid
            /*and i.cpid = g.cpid*/  and d.cpid = g.cpid
            and nvl(f.sjpfje,0)>0
            and f.zrid = g.zrid
            and h.khid = j.bbrkhid
            and j.khbdh = c.khbdh
            and j.ttid = c.ttid
            and a.bxgsid = rec_bxgs.bxgsid
            and b.ttid = rec_tt.ttid
            and c.bdsxrq >=nvl(trim(pStartdate), 19000101)
            and c.bdzzrq >= nvl(trim(pEnddate),  c.bdzzrq )
            and c.bdsxrq <=nvl(trim(pEnddate), 99991231)
            and k.jarq > nvl(trim(POther7),19000101)
            and k.jarq < nvl(trim(POther8),99991231)
            group by case when add_months(to_date(h.csrq,'yyyy-mm-dd'),0)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),48)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '0-4?'
            when add_months(to_date(h.csrq,'yyyy-mm-dd'),48)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),108)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '5-9?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),108)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),168)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '10-14?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),168)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),228)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '15-19?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),228)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),288)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '20-24?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),288)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),348)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '25-29?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),348)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),408)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '30-34?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),408)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),468)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '35-39?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),468)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),528)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '40-44?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),528)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),588)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '45-49?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),588)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),648)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '50-54?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),648)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),708)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '55-59?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),708)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),768)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '60-64?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),768)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),828)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '65-69?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),828)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),888)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '70-74?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),888)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),948)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '75-79?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),948)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')  then '80???' end
               order by
               case when add_months(to_date(h.csrq,'yyyy-mm-dd'),0)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),48)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '0-4?'
            when add_months(to_date(h.csrq,'yyyy-mm-dd'),48)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),108)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '5-9?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),108)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),168)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '10-14?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),168)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),228)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '15-19?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),228)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),288)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '20-24?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),288)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),348)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '25-29?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),348)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),408)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '30-34?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),408)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),468)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '35-39?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),468)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),528)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '40-44?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),528)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),588)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '45-49?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),588)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),648)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '50-54?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),648)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),708)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '55-59?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),708)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),768)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '60-64?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),768)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),828)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '65-69?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),828)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),888)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '70-74?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),888)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')
            and add_months(to_date(h.csrq,'yyyy-mm-dd'),948)>=to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd') then '75-79?'
             when add_months(to_date(h.csrq,'yyyy-mm-dd'),948)<to_date(nvl(e.zrksrq,j.fdsxr),'yyyy-mm-dd')  then '80???' end )h
            )loop

  insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 2, cell.r, '?????');
  --???
  insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 8, cell.r, tt.nldname);
  --????????????
  insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 9, cell.r, tt.nxpfje);
  --????????????
  insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 10, cell.r, tt.nxpfjebl);
  --????????????
  insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 11, cell.r, tt.nvxpfje);
  --????????????
  insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 12, cell.r, tt.nvxpfjebl);
  --??????
  insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 13, cell.r, tt.pfje);
  --????
  --insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 13, cell.r, v_pfbl);
  cell.r := cell.r+1;
 end loop;
 end loop;

 --??????
 select h.nxpfje,h.nvxpfje,h.pfje,
        decode(pfje,0,null,round(h.nxpfje*100/h.pfje,2)) as nxpfjebl,
        decode(pfje,0,null,round(h.nvxpfje*100/h.pfje,2)) as nvxpfjebl
   into v_nxpfje,v_nvxpfje,v_pfje,v_nxpfjebl,v_nvxpfjebl
   from  (  select sum(nvl(f.sjpfje,0)) as pfje,
               sum(case when h.xb='1' then nvl(f.sjpfje,0) else 0 end ) as nxpfje,
               sum(case when h.xb='2' then nvl(f.sjpfje,0) else 0 end ) as nvxpfje
            from tb_bxgsxx a,tb_ttxx b,tb_bdxx c,tb_cpxx d,tb_fdzrmx e,tb_zpaxx f,tb_cpzrdzb g,tb_khxx h,/*tb_bdcpxx i,*/tb_fdxx j,tb_lpajxx k
            where a.bxgsid = c.bxgsid
            and f.ajid=k.ajid
            and j.bbrkhid=k.bbrkhid
            and b.ttid = c.ttid
            /*and c.bdid = i.bdid
            and i.cpid = d.cpid*/
            and e.fdid=j.fdid
            and e.zrid = g.zrid
            /*and i.cpid = g.cpid*/ and d.cpid = g.cpid
            and nvl(f.sjpfje,0)>0
            and f.zrid = g.zrid
            and h.khid = j.bbrkhid
            and j.khbdh = c.khbdh
            and j.ttid = c.ttid
            and a.bxgsid = rec_bxgs.bxgsid
            and c.bdsxrq >=nvl(trim(pStartdate), 19000101)
            and c.bdzzrq >= nvl(trim(pEnddate),  c.bdzzrq )
            and c.bdsxrq <=nvl(trim(pEnddate), 99991231)
            and k.jarq > nvl(trim(POther7),19000101)
            and k.jarq < nvl(trim(POther8),99991231))h;

  insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 1, cell.r, '???????');
  --????????????
  insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 9, cell.r, v_nxpfje);
  --????????????
  insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 10, cell.r, v_nxpfjebl);
  --????????????
  insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 11, cell.r, v_nvxpfje);
  --????????????
  insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 12, cell.r, v_nvxpfjebl);
  --??????
  insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 13, cell.r, v_pfje);
  --????
  --insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 13, cell.r, v_pfbl);
  cell.r := cell.r+1;
 end loop;

 --???????????
  /*9.??*/
  PReturnCode := '0'; /* ??????????????vstatid????????? */
  PReturnMsg  := vstatid;
  DBMS_OUTPUT.PUT_LINE('[LDS debug] ' || 'PReturncode= ' || PReturnCode);
  --COMMIT; ???java?????????

EXCEPTION
  WHEN OTHERS THEN
    --rollback;???java?????????????0?????????????????
    PReturnCode := 'E'; /*  ??????  */
    DBMS_OUTPUT.PUT_LINE('[yhs debug] ' || 'PReturncode= ' || PReturnCode);
    PReturnMsg := ' rownum' || cell.r || 'Error:' || sqlerrm; --???????????
    DBMS_OUTPUT.PUT_LINE(PReturnMsg);
end SP_P1_30017;

/
