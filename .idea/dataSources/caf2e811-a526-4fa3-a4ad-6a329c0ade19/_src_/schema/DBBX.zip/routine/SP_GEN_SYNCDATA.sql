CREATE PROCEDURE "SP_GEN_SYNCDATA" (PReturnCode OUT VARCHAR2, PReturnMsg OUT VARCHAR2,pSYNCDATAIN TB_YFZFB_SYNCDATA%rowtype) AS
  rec_ttfw  TB_TTFWBZXX%rowtype;
  i_Step number:=0;
  v_startdate DATE:=sysdate;
  v_enddate Date;
  v_no number:=0;
BEGIN

   p_xtl_loginfo('SP_GEN_SYNCDATA_begin');

  i_Step := 1;
   PReturnCode:='-1';
   PReturnMsg:='error!';
    INSERT INTO TB_YFZFB_SYNCDATA  (
   OPT_ID            ,--   NUMBER(16)                      NOT NULL,
   OP_TYPE           ,--   VARCHAR2(1),
   SYS_TYPE          ,--   VARCHAR2(2) NOT NULL,
   CONTENT          ,--    VARCHAR2(4000),
   OPT_OBJECT       ,--    VARCHAR2(2),
   OPT_DATETIME      ,--   DATE,
   YF_SYNC_STATUS   ,--    VARCHAR2(1),
   YF_SYNC_TIME     ,--    DATE,
   ZFB_SYNC_STATUS   ,--   VARCHAR2(1),
   ZFB_SYNC_TIME    ,--    DATE,
   OBJECT_ID      --      NUMBER(16)                      NOT NULL,
)
    values(pSYNCDATAIN.Opt_Id,pSYNCDATAIN.Op_Type,pSYNCDATAIN.Sys_Type,
    pSYNCDATAIN.Content,pSYNCDATAIN.Opt_Object,pSYNCDATAIN.Opt_Datetime,
    '0',null,'0',null,pSYNCDATAIN.Object_Id);
v_no:=v_no+1;

    PReturnCode := '0';
    PReturnMsg:='ok!';
   return;
  EXCEPTION
    WHEN OTHERS THEN
     p_xtl_loginfo('SP_GEN_SYNCDATA_exception ' || 'PReturncode= ' || PReturnCode||sqlerrm);

      --rollback;由于给java调用，无须提交事务，返回非0值后，前台会获取错误信息，回滚事务
      PReturnCode := 'E'; /*  生成报表出错  */
      DBMS_OUTPUT.PUT_LINE('[yhs debug] ' || 'PReturncode= ' || PReturnCode||sqlerrm);
      /*PReturnMsg := ' rownum' || cell.r || 'Error:' || sqlerrm; --记录生成到哪行数据错误*/
      DBMS_OUTPUT.PUT_LINE(PReturnMsg);
END SP_GEN_SYNCDATA;
/
