CREATE procedure SP_IMPORT_PSNFDZR_1(Pin_userid IN varCHAR2 ,PReturnCode OUT varchar2,
                              PReturnMsg    OUT varchar2) AS
  /*
  *@version1.2 update by zhangjunpeng 发现医保标识为“@”的时候，一表式导入不将医保标识更新到系统业务表中 20150630
  *@version1.3 update by zhangjunpeng 关于主被保险人不存在的校验的bug修复 20150720
  *@version2.3 新需求变更，采用业务类型控制,暂时还要兼顾老的数据格式导入
  version2.4 部门名称也存储临时表的部门编号的前50个字节,增加一类校验（分单终止日>生效日)
  version2.5  存在主被保人时，持卡人姓名为主被保人姓名，否则系统拦截提示：XXX行，持卡人姓名不为主被保人姓名，请确认！
              同一个人相同保单不同等级两条数据，且保单起止日期相同，系统拦截提示
  version 2.5.5 分单生效日允许大于终止日一天 0624 发布
  version 2.6 增加同一客户号变更时有多个姓名的校验,错误信息统计从视图V_TB_IMPORT_PSNFDZR_ERR获取
  version 2.7 主被保人校验时，非一表式导入的数据，如果关系为本人或为空的，系统不校验主被保人一定存在
  version 2.8 客户号不为空时，不能填xxxxx,用khid，更新时，性别、医保标识、银行信息等，如为空则不覆盖，不为空时才覆盖、性别调整为字典代码;
    对18位证件号的加个与出生日期的一致性校验，不一致的校验出来
 version 2.9  保险公司CPICFJ（947）一表式导入特别需求：
    1 原始人员名单中的归属地区与归属联社数据未存入系统，表格中数据位置为“工作所在地”和“部门编号”，导入系统后需要分别存入客户基本信息的“部门名称”“部门编号”中；
    2.个人账户余额需要存入系统，目前前台无法看到相应字段，烦请IT解决数据导入后对应值显示位置的问题。
 version 3.0 增加并发操作时数据处理控制，避免产生垃圾数据
 version 3.1 客户信息变更是，银行相关信息如不提供，不覆盖原来信息 20160914 紧急上线
 version 3.2 陕西太保）一表式导入特别需求 参照CPICFJ配置
 version 3.3 被保人特别约定选’无‘时，解除特别约定，其它如为空时，不做修改
  ***/
  V_STEP_CODE  VARCHAR2(5):='00000';
  v_start_date number := 0;
  v_end_date   number := 0;
  v_no  number:=0;
--  rec_bdxx tb_bdxx%rowtype;
  v_001zd number:=0; --是否不确定诊断，缺省为0
   v_zrlxdm varchar2(6):='xxxxxx';
   v_xtxgdm varchar2(60):=''; --系统悬挂代码
   v_zpaid number(16):=-1;
   v_fphm varchar2(400):=''; --医疗子赔案用到的所有发票号
   v_zpah varchar2(30):='';--子赔案号
   v_zrid number(16):=0; -- 赔付的责任Id
   v_zddm varchar2(20):='';
   rec_zrxx tb_zrxx%rowtype;
    v_fdid number(16):=0; -- 子陪案对应的分单Id
    v_pch number(16):=0;
    v_opcode VARCHAR2(2):= substr(TRIM(Pin_userid),instr(Pin_userid,':')+1,1);
    v_userid VARCHAR2(10):=substr(TRIM(Pin_userid),1,instr(Pin_userid,':')-1);
    rec_fdxx tb_fdxx%rowtype;
    v_khid number(16):=0;
    v_zbbrkhid  number(16):=0;
    v_dodate Date:=sysdate;
    procedure prc_createFdZRXX (pYWLSH varchar2,PRetCode OUT varchar2,
                               PRetMsg    OUT varchar2) is
     begin
           PRetCode:='-1';
           PRetMsg:='ok';
           select  seq_Fdid.nextval as fdid into v_fdid from dual;
             INSERT INTO TB_FDXX(
            FDID, TTID, KHBDH, TBDH, FDH,
          FDSXR, FDZZR, FDZT, FDZBF, BBRKHID,
          BBRNL, ZYLB, ZYDM, ZTTID, DJ,
          GZDXZQH, BBRDZID, BBRDZXX,
          ZLDBZ, ZBBRGX, ZBBRKHID, ZBBRFDH,
          FDZS1, FDZS2, DJID,
          YBDXZQH, JZDQH,Cjrq,Bdid,WBBDH,seqlogid,Bbrxh,ZBBRXH,BDGLJG/*v2.9++begin*/,fdzhye/*v2.9++end*/)
        SELECT
          v_fdid as fdid, rec_bdxx.TTID, rec_bdxx.KHBDH, rec_bdxx.TBDH,
          nvl(a.fdh,rec_bdxx.KHBDH|| trim(to_char((select nvl(count(1),0)+1 from tb_fdxx zz where zz.khbdh=a.bdh),'099999'))) as fdh,
          nvl(to_char(to_date(a.SJSXR,'yyyy-mm-dd'),'yyyymmdd') ,rec_bdxx.BDSXRQ) as FDSXR,
          nvl(to_char(to_date(a.SJZZR,'yyyy-mm-dd'),'yyyymmdd'),rec_bdxx.BDZZRQ) as FDZZR,
          '1' as fdzt,'' fdzbf,
          b.khid as BbrKhid,
        nvl(a.age,trunc(trunc(to_date(a.SJSXR,'yyyymmdd')-to_date(b.CSRQ, 'yyyymmdd'))/365)) as BBRNL ,
           '' ZYLB, b.ZYDM,
          rec_bdxx.ZTTID,
           nvl((SELECT DJBH FROM TB_BDDJXX WHERE BDID = rec_bdxx.BDID AND DJMC = a.DJ),a.dj) DJ,
          b.GZDXZQH,
          (SELECT max(T.DZID) FROM TB_KHDZXX T WHERE  T.KHID = b.KHID AND  T.YXZT = '0') DZID ,(select max(DZID) FROM TB_KHDZXX  WHERE  KHID = b.KHID AND  YXZT = '0' ) as jtdz,
         case when nvl(a.GX,'00')!='00' and (a.ZBBRZJHM is not null or a.zbbrxh is not null) then '1' else '0' end as ZLDBZ,
         case when nvl(a.GX,'00')!='00' and (a.ZBBRZJHM is not null or a.zbbrxh is not null) then  a.gx else '' end as ZBBRGX,
         case when nvl(a.GX,'00')!='00' and (a.ZBBRZJHM is not null or a.zbbrxh is not null) then
            case when a.ZBBRZJHM is not null then (select to_char(max(khid)) from tb_khxx  where aac147=a.ZBBRZJHM and xm=a.ZBBRXM)
                 when a.zbbrxh is not null then (select to_char(max(khid)) from tb_khxx t,tb_fdxx y  where khbh=a.zbbrxh and  t.khid=y.bbrkhid and y.bdid=rec_bdxx.bdid)
                 else '' end
            else '' end as ZBBRKHID ,
         '' Zbbrfdh ,
        '' FDZS1, '' FDZS2,
        (SELECT DJID FROM TB_BDDJXX WHERE BDID = rec_bdxx.BDID AND DJMC = a.DJ ),
          b.YBDXZQH, b.JZDXZQH,
          to_number(to_char(SYSDATE,'yyyymmdd')) as Cjrq,rec_bdxx.BDID,'' wbbdh,v_pch as seqlogid,a.bbrxh,a.ZBBRXH,a.BDGLJG
          /*v2.9 3.2++begin*/,case when a.bxgsid in(947,948) and a.zr1be is not null  then a.zr1be else null end as fdzhye /*v2.9 3.2++end*/
        FROM TB_BDXX rec_bdxx , TB_IMPORT_PSNFDZR a,tb_khxx b where a.bdh=rec_bdxx.khbdh and a.ywlsh=pYWLSH
        and b.aac147=a.zjhm and b.xm=a.xm --20160614 and b.aac058=A.ZJLX /*decode(a.ZJLX,'驾驶证','10','出生证','09','01')*/
       -- and nvl(b.csrq,0)=nvl(TO_NUMBER(to_char(to_date(nvl(a.CSRQ,b.csrq),'yyyy-mm-dd'),'yyyymmdd')),0) --20160614 调整为根据出生日期判断人员身份
        and b.khbh=nvl(a.bbrxh,b.khbh) --调整为根据客户编号查身份 20160614
        and a.RUN_FLAG is null and not exists(
        select 'x' from tb_fdxx n where n.bbrkhid=b.khid and n.bdid=rec_bdxx.bdid  and fdzt='1');
        v_no:=SQL%rowcount;
        --分单创建失败校验，有错误抛出 20160614 begin
        if v_no=0 then
             PRetCode:='-99';
             select '姓名为'||a.xm||'证件号为'||a.zjhm||'的分单信息生成失败，请检查!' into  PRetMsg from TB_IMPORT_PSNFDZR a where a.ywlsh=pYWLSH ;           
             RETURN;
        end if;
         --分单创建失败校验，有错误抛出 20160614 end
       dbms_output.put_line('本次新增分单数：'|| to_char(v_no));
       --分单责任明细
        INSERT INTO TB_FDZRMX(
          FDZRID, FDID, ZRXH, ZRID,
          BELX, BEDW, GMFSHYS, ZRBE,
          ZRBF, ZRBZBF, ZRFJF, ZRLJPFE, ZRLJMPE,
          ZRKSRQ, ZRJSRQ, YXBS, ZDBE, ZGBE,SEQLOGID)
        SELECT
          TO_NUMBER(SEQ_FDZRID.NEXTVAL), e.fdid, rownum, A.ZRID,
          B.BELX, B.BEDW, DECODE(A.BE, '', '', TRUNC(A.BE/B.BEDW)), A.BE,
          A.BF, NULL, NULL, NULL, NULL,
          NULL, NULL, A.YXBS, A.ZDBE, A.ZGBE,v_pch as seqlogid
          FROM TB_BDDJZRXX A, TB_ZRXX B,tb_fdxx e
          WHERE A.BDID = e.bdid
          and e.fdid=v_fdid
          AND A.DJID = e.Djid
          AND A.ZRID = B.ZRID
          and not exists(select 'x' from TB_FDZRMX where fdid=e.fdid and zrid=a.zrid);
          PRetCode:='0';
          PRetMsg:='ok';
          return;
          EXCEPTION
          WHEN OTHERS THEN
            PRetCode := 'E';
            DBMS_OUTPUT.PUT_LINE('[yhs debug] ' || 'PRetCode= ' ||
                                 PRetCode);
            PRetMsg := '错误流水号:'||trim(pYWLSH)||', 详情:' || sqlerrm;
            DBMS_OUTPUT.PUT_LINE(substrb(PRetMsg,1,255));
     end;  --内部过程定义结束
  begin
    PReturnCode:='E';
    PReturnMsg:='Error!';
    --业务处理块
    --数据校验
    if v_opcode = '0' then
      update TB_IMPORT_PSNFDZR a set a.imp_err_desc = '' where a.RUN_FLAG is null;
    end if;
    select nvl(count(1),0) into v_no from TB_IMPORT_PSNFDZR a where a.RUN_FLAG is null
         and not exists(select 'x' from TB_bdxx where khbdh=a.bdh);
    if (v_no>0 ) THEN
             UPDATE TB_IMPORT_PSNFDZR T SET T.IMP_ERR_DESC = '提供的保单号，系统中还没有建立，不能导入!'
                    WHERE T.ywlsh IN (SELECT A.ywlsh FROM TB_IMPORT_PSNFDZR A WHERE A.RUN_FLAG IS NULL
                          AND NOT EXISTS (SELECT 'x' FROM TB_BDXX WHERE KHBDH = A.BDH));
    end if;
    ---------------------
    select nvl(count(1),0) into v_no from TB_IMPORT_PSNFDZR a where a.RUN_FLAG is null
         and not exists(select 'x' from TB_bdxx b,tb_bddjzrxx c  where khbdh=a.bdh and b.bdid=c.bdid and c.Djmc=a.dj);
    if (v_no >0 ) THEN
            UPDATE TB_IMPORT_PSNFDZR T SET T.IMP_ERR_DESC = '提供的保单等级，系统中还没有建立责任信息，不能导入!'
                   WHERE T.ywlsh IN( select a.ywlsh from TB_IMPORT_PSNFDZR a where a.RUN_FLAG is null
              and not exists(select 'x' from TB_bdxx b,tb_bddjzrxx c  where khbdh=a.bdh and b.bdid=c.bdid and c.Djmc=a.dj));
    end if;
    ---------------------
    select nvl(count(1),0) INTO  v_no from TB_IMPORT_PSNFDZR a where a.RUN_FLAG is null
         and a.zbbrzjhm IS NOT NULL AND NOT EXISTS(select 'x' from TB_IMPORT_PSNFDZR c  where c.zjhm=a.zbbrzjhm)
         and not exists(select 'x' from tb_khxx d where d.aac147 = a.zbbrzjhm and d.xm = a.zbbrxm);  -- +V1.3
    if (v_no >0 ) THEN
            UPDATE TB_IMPORT_PSNFDZR T SET T.IMP_ERR_DESC = '有连带的被保人对应的主被保人不存在，不能导入!'
                  /* WHERE T.BDH IN(select a.bdh from TB_IMPORT_PSNFDZR a where a.RUN_FLAG is NULL and a.zbbrzjhm is not null
                and not exists(select 'x' from TB_IMPORT_PSNFDZR c  where c.zjhm=a.zbbrzjhm));*/
                where t.RUN_FLAG is null and t.zbbrzjhm IS NOT NULL AND NOT EXISTS(select 'x' from TB_IMPORT_PSNFDZR c
                where c.zjhm=t.zbbrzjhm) 
                and op_type is not null--v1.7++ 
                and  not exists (select 'x' from tb_khxx d where d.aac147 = t.zbbrzjhm and d.xm = t.zbbrxm); -- +V1.3
                --v1.7++ begin
       UPDATE TB_IMPORT_PSNFDZR T SET T.IMP_ERR_DESC = '有连带的被保人对应的主被保人不存在，不能导入!'                
                where t.RUN_FLAG is null and t.zbbrzjhm IS NOT NULL AND NOT EXISTS(select 'x' from TB_IMPORT_PSNFDZR c
                where c.zjhm=t.zbbrzjhm) 
                and op_type is  null and nvl(gx,'xxxx') not  in('本人','00')
                and  not exists (select 'x' from tb_khxx d where d.aac147 = t.zbbrzjhm and d.xm = t.zbbrxm);
            --v1.7++ end
    end if;
    ---------------------------
/*    select nvl(count(1),0) into v_no from TB_IMPORT_PSNFDZR where ckr is null and gx!='本人';
    if (v_no >0 ) THEN
          UPDATE TB_IMPORT_PSNFDZR T SET T.IMP_ERR_DESC = '当持卡人数据项为空并且与员工关系非“本人”时，不能导入!'
             WHERE T.ywlsh IN(select ywlsh from TB_IMPORT_PSNFDZR where ckr is null and gx!='本人');
    end if;*/
    ---------------------------
    select nvl(count(1),0) into v_no from TB_IMPORT_PSNFDZR a where a.RUN_FLAG is null  and zjhm like '%+%';
    if (v_no >0 ) THEN
          UPDATE TB_IMPORT_PSNFDZR T SET T.IMP_ERR_DESC = '证件号码有误，不能导入!'
             WHERE T.ywlsh IN(select a.ywlsh from TB_IMPORT_PSNFDZR a where a.RUN_FLAG is null  and zjhm like '%+%');
    end if;
    ---------------------------
    SELECT nvl(count(1),0) into v_no  from TB_IMPORT_PSNFDZR a where a.RUN_FLAG is null  and khhzh like '%+%';
    if (v_no >0 ) THEN
          UPDATE TB_IMPORT_PSNFDZR T SET T.IMP_ERR_DESC = '银行账户有误，不能导入!'
             WHERE T.ywlsh IN(SELECT a.ywlsh from TB_IMPORT_PSNFDZR a
             where a.RUN_FLAG is null  and khhzh like '%+%');
    end if;
    --v1.1.1++  begin 一表式导入增加分单生效日终止日校验
     SELECT nvl(count(1),0) into v_no  from TB_IMPORT_PSNFDZR a where (a.sjsxr is null or a.sjzzr is null ) and  a.RUN_FLAG is null;
    if (v_no >0 ) THEN
          UPDATE TB_IMPORT_PSNFDZR a SET a.IMP_ERR_DESC = '分单生效日或终止日错误,都不能为空!'
          where  (a.sjsxr is null or a.sjzzr is null ) and  a.RUN_FLAG is null;
    end if;
    SELECT nvl(count(1),0) into v_no  from TB_IMPORT_PSNFDZR a where (a.sjsxr is not null and a.sjzzr is not null) and  a.RUN_FLAG is null
    and not exists(select 'x' from tb_bdxx b where b.khbdh=a.BDH and b.BDZZRQ>=to_char(to_date(a.sjsxr,'yyyy-mm-dd') ,'yyyymmdd') and b.BDSXRQ<to_char(to_date(a.sjzzr,'yyyy-mm-dd')+1,'yyyymmdd'))  and  a.sjsxr <a.sjzzr;
    if (v_no >0 ) THEN
          UPDATE TB_IMPORT_PSNFDZR a SET a.IMP_ERR_DESC = '分单生效日和终止日不在大保单日期范围内!'
           where  a.RUN_FLAG is null  and  a.sjsxr <a.sjzzr
           and not exists(select 'x' from tb_bdxx b where b.khbdh=a.BDH and b.BDZZRQ>=to_char(to_date(a.sjsxr,'yyyy-mm-dd') ,'yyyymmdd') and b.BDSXRQ<to_char(to_date(a.sjzzr,'yyyy-mm-dd')+1,'yyyymmdd') );
    end if;

     UPDATE TB_IMPORT_PSNFDZR a SET a.IMP_ERR_DESC = '数据错误，分单生效日大于终止日!'
           where  a.RUN_FLAG is null and  a.sjsxr is not null and  a.sjzzr is not null
           and  a.sjsxr >a.sjzzr
           and (to_date(a.sjsxr,'yyyy-mm-dd')-to_date(a.sjzzr,'yyyy-mm-dd'))>1.5 ; --v2.5.5++
     --v1.1.1++ end
     --20160615 增加分单日期和所在大保单日期之间校验 begin
       UPDATE TB_IMPORT_PSNFDZR a SET a.IMP_ERR_DESC = '分单终止日晚于大保单终止日期!'
           where  a.RUN_FLAG is null
           and  exists(select 'x' from tb_bdxx b where b.khbdh=a.BDH and b.BDZZRQ<to_char(to_date(a.sjzzr,'yyyy-mm-dd') ,'yyyymmdd') );
        
        UPDATE TB_IMPORT_PSNFDZR a SET a.IMP_ERR_DESC = '分单生效日早于大保单生效日期!'
           where  a.RUN_FLAG is null   
           and  exists(select 'x' from tb_bdxx b where b.khbdh=a.BDH  and b.BDSXRQ>to_char(to_date(a.sjsxr,'yyyy-mm-dd'),'yyyymmdd'));  
            --生效日提前的系统增加提示，让保全人员手工处理
       
        UPDATE TB_IMPORT_PSNFDZR a SET a.IMP_ERR_DESC = '分单生效日期需要提前，请审核是否正确后手动处理!'
           where  a.RUN_FLAG is null   and NVL(a.IMP_ERR_DESC,'XXXXX') != '分单生效日早于大保单生效日期!'
           and  exists(select 'x' from tb_fdxx b,tb_khxx c where b.bbrkhid=c.khid and c.aac147=a.zjhm and c.xm=a.xm and b.bbrxh=nvl(a.bbrxh,b.bbrxh) and b.khbdh=a.bdh  and b.fdSXR>to_char(to_date(a.sjsxr,'yyyy-mm-dd'),'yyyymmdd')
            and b.fdzt  IN('1','3') );   
            --校验有连带关系的主被保人信息不存在或主被保人在后面才给出的情况
        
UPDATE TB_IMPORT_PSNFDZR a SET  a.IMP_ERR_DESC =case when  (((ZBBRXH is not null or (ZBBRXM||ZBBRZJHM is not null))
           and not ( exists(select 'x' from tb_khxx b where b.aac147=a.zbbrxm and b.xm=a.zbbrxm)
             or exists(select 'x' from tb_khxx b where b.khbh=a.zbbrxh)
             or exists(select 'x' from TB_IMPORT_PSNFDZR b where b.zjhm=a.ZBBRZJHM and b.xm=a.zbbrxm and b.ywlsh<a.ywlsh)           
           ))
           or (ZBBRXH is null and ZBBRXM||ZBBRZJHM is  null) )  then   '有连带的分单，主被保人信息必须要先提供!'
      else replace( a.IMP_ERR_DESC,'有连带的分单，主被保人信息必须要先提供!','') end 
           where  a.RUN_FLAG is null   and nvl(trim(gx),'00') not in('00','0','99',/*v2.7 begin++*/'本人'/*v2.7 end++*/);  
                              
     --20160615 end 
     --中德安联的保全数据，不能在一表式中导入 160508
     UPDATE TB_IMPORT_PSNFDZR a SET a.IMP_ERR_DESC = '中德安联的保全数据，不能在一表式中导入!'
           where  a.RUN_FLAG is null and  a.bxgsid=592 and nvl(a.RUN_FLAG,'0')='0' ;
   --20160615 重复人员信息校验 begin
    UPDATE TB_IMPORT_PSNFDZR a SET a.IMP_ERR_DESC = '人员信息重复，无法处理!'
           where  a.RUN_FLAG is null and  exists (select  d.aac147,d.xm,nvl(d.csrq,0),count(1) from tb_khxx d where d.aac147 = a.zjhm and d.xm = a.xm 
                 and nvl(d.csrq,0)=nvl(TO_NUMBER(to_char(to_date(nvl(a.CSRQ,d.csrq),'yyyy-mm-dd'),'yyyymmdd')),0)
                 group by d.aac147,d.xm,nvl(d.csrq,0) having count(1)>1
                 ) and op_type in('0');
           
    --20160615 重复人员信息校验 end
     --20160617 持卡人姓名不为主被保人姓名
    /*  UPDATE TB_IMPORT_PSNFDZR a SET  a.IMP_ERR_DESC =case when nvl(a.ckr,'x')!=nvl(a.zbbrxm,'xx')  then   '持卡人姓名不为主被保人姓名!'
      else replace( a.IMP_ERR_DESC,'持卡人姓名不为主被保人姓名!','') end 
           where  a.RUN_FLAG is null   and nvl(trim(gx),'00') not in('00','0','99') and (ZBBRXH is not null or (ZBBRXM||ZBBRZJHM is not null));          
   */       
    --20160617 同一个人相同保单有两条不同的等级且保单起止日期相同数据     
      UPDATE TB_IMPORT_PSNFDZR a SET  a.IMP_ERR_DESC =case when exists(select 'x' from tb_fdxx b,tb_khxx c,tb_bddjxx d where b.bbrkhid=c.khid and b.bdid=d.bdid and b.djid=d.djid
                                        and c.aac147=a.zjhm and b.khbdh=a.bdh and c.xm=a.xm and d.djmc!=a.dj /*and b.fdsxr=a.sjsxr and b.fdzzr=a.sjzzr*/)
                                        or exists(select b.zjhm,b.xm,b.bdh,count(distinct dj /*b.sjsxr||b.sjzzr*/) from TB_IMPORT_PSNFDZR b where b.RUN_FLAG is null and b.ywlsh<=a.ywlsh
                                         and b.zjhm=a.zjhm and b.xm=a.xm and b.bdh=a.bdh group by   b.zjhm,b.xm,b.bdh having count(distinct dj /*b.sjsxr||b.sjzzr*/)>1)
           then   '有等级变更，请人工手动调整，谢谢!'
          else replace( a.IMP_ERR_DESC,'有等级变更，请人工手动调整，谢谢!','') end 
           where  a.RUN_FLAG is null and op_type='3';  
    --v2.6++ begin 同一客户号变更时有多个姓名的校验
        UPDATE TB_IMPORT_PSNFDZR a SET  a.IMP_ERR_DESC =case when exists(select bbrxh,count(distinct xm) from TB_IMPORT_PSNFDZR b 
                                   where b.RUN_FLAG is null and b.pch=a.pch and b.bbrxh=a.bbrxh
                                       group by   b.bbrxh having count(distinct xm)>1)
           then   '同一客户号变更时有多个姓名,请核实用哪个!'
          else replace( a.IMP_ERR_DESC,'同一客户号变更时有多个姓名,请核实用哪个!','') end 
           where  a.RUN_FLAG is null and op_type!='0' and bbrxh is not null;   
    --v2.8++ begin 新增客户或修改时，如证件号中的出生日期与出生日期不一致时
        UPDATE TB_IMPORT_PSNFDZR a SET  a.IMP_ERR_DESC =case when length(trim(zjhm))=18 and substr(zjhm,7,8)!=to_char(to_date(a.csrq,'yyyy-mm-dd'),'yyyymmdd')
           then    a.IMP_ERR_DESC||' 证件号中的出生日期与出生日期不一致!'
          else replace( a.IMP_ERR_DESC,'证件号中的出生日期与出生日期不一致!','') end 
           where  a.RUN_FLAG is null and op_type in('0','1') and zjlx='01' ;  
           --v2.8++ end                  
    --20160617 错误信息输出行数
     UPDATE TB_IMPORT_PSNFDZR a SET  a.IMP_ERR_DESC =(case when op_type is null then (select to_char(count(1)+2) from TB_IMPORT_PSNFDZR b where b.pch=a.pch and b.ywlsh<=a.ywlsh)  else (select to_char(count(1)+1) from TB_IMPORT_PSNFDZR_tmp b where b.pch=a.pch and b.ywlsh<=a.ywgllsh) end )||'行,' || IMP_ERR_DESC
       where  a.RUN_FLAG is null and IMP_ERR_DESC is not null;
        --------查询错误消息记录数--------------------
    SELECT nvl(count(1),0) into v_no from /*v2.6-TB_IMPORT_PSNFDZR *//*v2.6++*/ V_TB_IMPORT_PSNFDZR_ERR /*v2.6++*/ a WHERE a.imp_err_desc IS NOT NULL and a.run_flag is null;

    IF (v_no>0) THEN
       PReturnCode:='-1';
       PReturnMsg:='校验结束，本次校验错误数据有'||to_char(v_no)||'条,您可以在错误信息中查看错误描述!';
       DBMS_OUTPUT.PUT_LINE(substrb(PReturnMsg,1,255));
       RETURN;
    END IF;
    IF v_opcode='0' AND (v_no=0) THEN
       PReturnCode:='0';
       PReturnMsg:='校验成功，可以导入!';
       RETURN;
    END IF;

    IF v_opcode='1' AND v_no<>0 THEN
       PReturnCode:='1';
       PReturnMsg:='有错误数据，请先校验修改错误数据后再导入!';
    RETURN;
    END IF;
 --------------导入-----------------------------------------------
    select to_number(to_char(sysdate,'yyyymmddhh24miss')) into v_pch from dual;
    /***** v2.3  begin  */
     --先处理按业务类型划分导入保全的数据
     for rec in(select * from TB_IMPORT_PSNFDZR a where a.RUN_FLAG is null and trim(op_type) is not null order by /*a.zjlx,a.zjhm,*/YWLSH asc for update nowait ) loop
        if rec.OP_TYPE='0' then --新保单
              --人员信息导入,原来系统中没有的人员新加入
             INSERT INTO TB_KHXX(
                    KHID, KHBH, XM, AAC058, AAC147, SCZT, XB, CSRQ, SWRQ, ZZBZ,
                ZYDJ, ZYDM, GH, KHYH, ZHMC, YHZH, KHHSZS, KHHSZSHI, FWTT,
                FWTTMC, FWZTTBH, BMBH, BMMC, YBBS, YBKH, YBD, GZDJZD, HYZK,
                EMAIL, SJH, YX, XGBZ, BBRTBYD, GZDXZQH, YBDXZQH, JZDXZQH, SFMZZYGYED,kzlx,bgsj,czsj)
              SELECT
                seq_khid.nextval as khid, nvl(a.BBRXH,'xxxxxx') as khbh, XM,decode(a.ZJLX,'驾驶证','10','出生证','09',a.ZJLX) as aac058, ZJHM, '0' as sczt,decode( a.XB,'男','1','女','2',a.XB) as xb,
                TO_NUMBER(to_char(to_date(nvl(a.CSRQ,case when a.zjlx='01' then  case when length(a.zjhm)=18 then substr(a.zjhm, 7, 8)
                                           else '19'||substr(a.zjhm, 7, 6) end else '' end),'yyyy-mm-dd'),'yyyymmdd')) as csrq,
                 '' as swrq, decode(a.zydm,null,'0','','0','1') as ZZBZ,
                '' ZYDJ, a.ZYDM,
                a.gh as  GH,
                a.khh as KHYH, a.ckr as ZHMC, a.khhzh as YHZH, nvl(a.KHHSH,case when a.KHHS is not null then substr(a.KHHS,1,2)||'0000' else '' end ) as KHHSZS,a.KHHS as KHHSZSHI,(select ttbh from tb_bdxx where khbdh=a.bdh) as FWTT ,
                (select ttmc from tb_bdxx where khbdh=a.bdh) as FWTTMC, (select max(zttbh) from tb_zttxx where zttmc=rec.zttmc) as FWZTTBH, substrb(A.BMBH,1,20),/*v2.9++begin*/case when a.bxgsid=947 then a.gzd else /*v2.9++end*/ a.bmbh end as BMMC, a.ybbs as YBBS,a.ybkh as YBKH,
                A.YBD,a.yjdz as GZDJZD, '' as HYZK,
                a.EMAIL,a.phone as SJH,'' as  YX, case when a.BBRTBYD is null then '' else '1' end as XGBZ,
                  a.BBRTBYD as BBRTBYD,
                  (SELECT c.aab301 FROM AA26 c WHERE C.AAA146 = A.GZD and rownum = 1) GZDXZQH,
                (SELECT c.aab301 FROM AA26 c WHERE C.AAA146 = A.YBD and rownum = 1) as YBDXZQH,
                (SELECT c.aab301 FROM AA26 c WHERE C.AAA146 = A.GZD and rownum = 1) JZDXZQH, '0' as SFMZZYGYED,
                nvl(a.kzlx,'0') as kzlx,a.sjsxr,sysdate as czsj
                FROM TB_IMPORT_PSNFDZR a
                 WHERE a.ywlsh=rec.YWLSH
                 and  not exists (select 'x' from tb_khxx d where d.aac147 = a.zjhm and d.xm = a.xm 
                 and ( d.csrq is null or nvl(d.csrq,0)=nvl(TO_NUMBER(to_char(to_date(nvl(rec.CSRQ,d.csrq),'yyyy-mm-dd'),'yyyymmdd')),0))   --20160614 增加出生日期限制条件
                 );
                --20160614 如果原来已存在此人，且给的客户编号不为空，则更新此人的客户编号
                v_no:=sql%rowcount;
                if v_no=0 and rec.bbrxh is not null then
                   update tb_khxx d set khbh=rec.bbrxh,d.csrq=TO_NUMBER(to_char(to_date(nvl(rec.CSRQ,d.csrq),'yyyy-mm-dd'),'yyyymmdd'))
                   ,fwtt=(select ttbh from tb_bdxx where khbdh=rec.bdh),aac058=rec.zjlx
                    where d.aac147 = rec.zjhm and d.xm = rec.xm 
                     and ( d.csrq is null or nvl(d.csrq,0)=nvl(TO_NUMBER(to_char(to_date(nvl(rec.CSRQ,d.csrq),'yyyy-mm-dd'),'yyyymmdd')),0))
                    and exists(select 'x' from tb_bdxx where  bxgsid=rec.bxgsid and khbdh=rec.bdh)
                    and rownum<2;
                end if;
                --20160614 如果原来已存在此人，且给的客户编号不为空，则更新此人的客户编号 end
                 --生成分单信息
               prc_createFdZRXX(rec.ywlsh,PReturnCode,PReturnMsg);
               if PReturnCode!='0' then
                   dbms_output.put_line(substrb('ywlsh='||rec.ywlsh||'生成分单错误:'||PReturnMsg,1,255));
                   return;
               end if;


         --更新分单责任明细保费、保额，最多更新4个责任代码,20150422 减保人员不更新( and t.tcrq is null )，后面统一处理
        /*  update TB_FDZRMX a set (zrbe,zrbf)=(select b.zr1be,b.zr1bf FROM TB_IMPORT_PSNFDZR b,TB_KHXX c,TB_FDXX t,tb_zrxx m
              where b.RUN_FLAG is null and b.zr1dm is not null and b.bdh=t.khbdh
              and    c.aac147=b.zjhm and c.xm=b.xm and c.aac058=decode(b. ZJLX,'驾驶证','10','出生证','09','01') and t.bbrkhid=c.khid
              and t.cjrq=to_char(sysdate,'yyyymmdd') and t.fdid=a.fdid and b.zr1dm=m.zrbm and m.zrid=a.zrid)
               where exists(select b.zr3be,b.zr3bf FROM TB_IMPORT_PSNFDZR b,TB_KHXX c,TB_FDXX t,tb_zrxx m   where b.RUN_FLAG is null and b.zr1dm is not null and b.bdh=t.khbdh
               and    c.aac147=b.zjhm and c.xm=b.xm  and c.aac058=decode(b. ZJLX,'驾驶证','10','出生证','09','01') and t.bbrkhid=c.khid
              and t.cjrq=to_char(sysdate,'yyyymmdd') and t.fdid=a.fdid and b.zr1dm=m.zrbm and m.zrid=a.zrid and t.tcrq is null) and seqlogid=v_pch;
              */
        end if;

        --先找出当事人id
       select max(khid)  into  v_khid from tb_khxx t where khid in (
        select b.khid from tb_khxx b  where khbh=rec.bbrxh and exists(select 'x' from tb_fdxx c where c.khbdh=rec.bdh and c.bbrkhid=b.khid)
               union all select b.khid from tb_khxx b  where b.aac147=rec.zjhm
                and b.xm=rec.xm and b.csrq=TO_NUMBER(to_char(to_date(nvl(rec.CSRQ,b.csrq),'yyyy-mm-dd'),'yyyymmdd'))
                 );
        if rec.OP_TYPE in('1') then --1客户信息变更 或 2医保状态变更
           if rec.bbrxh is not null then --根据被保人客户号更新人员信息
             --更新字段有：被保险人序号、姓名、性别、出生日期、证件类型、证件号码、与员工关系、主被保险人序号、主被保险人姓名、主被保险人证件类型、主被保险人证件号码、
             --职业类别、职业、职业代码、持卡人、开户行、银行账号、手机号、邮箱地址、邮寄地址、邮编、身故受益人（姓名、与被保人关系）、员工工号、医保所在地、工作所在地、部门编号、开户行省、开户行市、卡折类型、保单管理机构
                update TB_KHXX t set (aac058,aac147, XM, SCZT, XB, CSRQ, SWRQ, ZZBZ,
                ZYDJ, ZYDM,
                GH,
                  KHYH, ZHMC, YHZH, KHHSZS, KHHSZSHI, FWTT,
                FWTTMC, FWZTTBH, BMBH, BMMC, /*YBBS, YBKH, YBD,*/ GZDJZD, HYZK,
                EMAIL, SJH, YX, XGBZ, BBRTBYD, GZDXZQH, YBDXZQH, JZDXZQH, SFMZZYGYED,kzlx)=(
                select nvl(rec.zjlx,t.aac058) as aac058,
                 nvl(rec.zjhm,t.aac147) as aac147,
                nvl(rec.XM,t.xm) as xm, t.sczt as sczt,/*v2.8++begin*/case when a.xb is not null then /*v2.8++end*/ decode( a.XB,'男','1','女','2',a.XB) /*v2.8++begin*/ else t.xb end /*v2.8++end*/ as xb,
                TO_NUMBER(to_char(to_date(nvl(a.CSRQ,case when a.zjlx='01' then  case when length(a.zjhm)=18 then substr(a.zjhm, 7, 8)
                                           else '19'||substr(a.zjhm, 7, 6) end else '' end),'yyyy-mm-dd'),'yyyymmdd')) as csrq,
                 '' as swrq, decode(a.zydm,null,'0','','0','1') as ZZBZ,
                '' ZYDJ, a.ZYDM,
                a.gh GH,
               /*v3.1++++begin*/nvl(a.khh,t.khyh) /*v3.1++++end*/ as KHYH,/*v3.1++++begin*/nvl( a.ckr,t.zhmc) as ZHMC, /*v3.1++++begin*/nvl(a.khhzh,t.yhzh) as YHZH,
                nvl(a.KHHSH,case when a.KHHS is not null then substr(a.KHHS,1,2)||'0000' else /*v3.1++++begin*/t.khhszs /*v3.1++++begin --'' */ end ) as KHHSZS,
                /*v3.1++++begin*/ nvl( a.KHHS,t.KHHSZSHI) as KHHSZSHI,(select ttbh from tb_bdxx where khbdh=a.bdh) as FWTT ,
                (select ttmc from tb_bdxx where khbdh=a.bdh) as FWTTMC, (select max(zttbh) from tb_zttxx where zttmc=rec.zttmc)  as FWZTTBH, substrb(A.BMBH,1,20),/*v2.9++begin*/case when a.bxgsid=947 then a.gzd else /*v2.9++end*/ A.BMBH end as BMMC,/*decode( a.ybbs,'有医保','02','01') as YBBS,'未提供具体卡号' as YBKH,
                A.YBD,*/a.yjdz as GZDJZD, '' as HYZK,
                a.EMAIL,a.phone as SJH,'' as  YX,
                 --v3.3--  case when rec.BBRTBYD is null then '' else '1' end as XGBZ,
                case when rec.BBRTBYD='无' then '0'  when  rec.BBRTBYD!='无' and rec.BBRTBYD is not null   then '1'  else a.xgbz end as XGBZ,--v3.3++
               --v3.3-- rec.BBRTBYD as BBRTBYD,
                case when rec.BBRTBYD='无' then '' else nvl( rec.BBRTBYD,a.BBRTBYD) ,--v3.3++
                (SELECT c.aab301 FROM AA26 c WHERE C.AAA146 = A.GZD and rownum = 1) GZDXZQH,
                (SELECT c.aab301 FROM AA26 c WHERE C.AAA146 = A.YBD and rownum = 1) as YBDXZQH,
                nvl((SELECT c.aab301 FROM AA26 c WHERE C.AAA146 = A.GZD and rownum = 1), '') JZDXZQH, '0' as SFMZZYGYED,
                nvl(a.kzlx,'0') as kzlx
                FROM TB_IMPORT_PSNFDZR a where a.ywlsh=rec.ywlsh )
                where khid=v_khid;
              --  khbh=rec.bbrxh
              --  and exists(select 'x' from tb_fdxx x,tb_bdxx y where x.bdid=y.bdid and y.bxgsid=rec.bxgsid and x.bbrkhid=t.khid);
           else  --根据证件类型、证件号+姓名更新
                update TB_KHXX t set (khbh,aac058,aac147, XM, SCZT, XB, CSRQ, SWRQ, ZZBZ,
                ZYDJ, ZYDM,
                GH,
                  KHYH, ZHMC, YHZH, KHHSZS, KHHSZSHI, FWTT,
                FWTTMC, FWZTTBH, BMBH, BMMC, /*YBBS, YBKH, YBD,*/ GZDJZD, HYZK,
                EMAIL, SJH, YX, XGBZ, BBRTBYD, GZDXZQH, YBDXZQH, JZDXZQH, SFMZZYGYED,kzlx)=(select  nvl(rec.bbrxh,t.khbh) as khbh,
                 nvl(rec.zjlx,t.aac058) as aac058,
                 nvl(rec.zjhm,t.aac147) as aac147,
                nvl(rec.XM,t.xm) as xm, t.sczt as sczt,/*v2.8++begin*/case when a.xb is not null then /*v2.8++end*/ decode( a.XB,'男','1','女','2',/*v2.8--begin '9' v2.8--*/a.xb) /*v2.8++begin*/ else t.xb end /*v2.8++end*/ as xb,
                nvl(TO_NUMBER(to_char(to_date(a.CSRQ,'yyyy-mm-dd'),'yyyymmdd')),t.csrq)  as csrq,
                 '' as swrq, decode(a.zydm,null,'0','','0','1') as ZZBZ,
                '' ZYDJ, a.ZYDM,
                a.gh GH,
                 /*v3.1++begin*/nvl(a.khh,t.khyh) /*v3.0++end*/ as KHYH,/*v3.1++begin*/nvl( a.ckr,t.zhmc) as ZHMC, /*v3.1++begin*/nvl(a.khhzh,t.yhzh) as YHZH,
                nvl(a.KHHSH,case when a.KHHS is not null then substr(a.KHHS,1,2)||'0000' else /*v3.0++begin*/t.khhszs /*v3.0++begin --'' */ end ) as KHHSZS,
                /*v3.1++++begin*/ nvl(a.KHHS, /*v3.1++++end*/t.KHHSZSHI) as KHHSZSHI,(select ttbh from tb_bdxx where khbdh=a.bdh) as FWTT ,
                (select ttmc from tb_bdxx where khbdh=a.bdh) as FWTTMC, (select max(zttbh) from tb_zttxx where zttmc=rec.zttmc)  as FWZTTBH,  substrb(A.BMBH,1,20),/*v2.9++begin*/case when a.bxgsid=947 then a.gzd else /*v2.9++end*/ A.BMBH end as BMMC,/*decode( a.ybbs,'有医保','02','01') as YBBS,'未提供具体卡号' as YBKH,
                A.YBD,*/a.yjdz as GZDJZD, '' as HYZK,
                a.EMAIL,a.phone as SJH,'' as  YX,
              --v3.3--  case when rec.BBRTBYD is null then '' else '1' end as XGBZ,
                case when rec.BBRTBYD='无' then '0'  when  rec.BBRTBYD!='无' and rec.BBRTBYD is not null   then '1'  else a.xgbz end as XGBZ,--v3.3++
               --v3.3-- rec.BBRTBYD as BBRTBYD,
                case when rec.BBRTBYD='无' then '' else nvl( rec.BBRTBYD,a.BBRTBYD) ,--v3.3++
                (SELECT c.aab301 FROM AA26 c WHERE C.AAA146 = A.GZD and rownum = 1) GZDXZQH,
                (SELECT c.aab301 FROM AA26 c WHERE C.AAA146 = A.YBD and rownum = 1) as YBDXZQH,
                nvl((SELECT c.aab301 FROM AA26 c WHERE C.AAA146 = A.GZD and rownum = 1), '') JZDXZQH, '0' as SFMZZYGYED,
                nvl(a.kzlx,'0') as kzlx
                FROM TB_IMPORT_PSNFDZR a where a.ywlsh=rec.ywlsh )
                where khid=v_khid;-- where t.aac147=rec.zjhm and t.xm=rec.xm and t.csrq=TO_NUMBER(to_char(to_date(a.CSRQ,'yyyy-mm-dd'),'yyyymmdd'));
           end if;
           --主被保人关系变更或主被保人变更
           if rec.gx is not null or (rec.zbbrxh is not null or (rec.ZBBRZJLX is not null and rec.zbbrxm is not null or rec.ZBBRZJHM is not null) ) then
                if rec.zbbrxh is not null then
                 select max(khid) into v_zbbrkhid from tb_khxx t where t.khbh=rec.zbbrxh and FWTT in(select ttbh from tb_bdxx where khbdh=rec.bdh);
               else
                 select max(khid) into v_zbbrkhid from tb_khxx t where t.aac058=nvl(rec.ZBBRZJLX , t.aac058) and  t.xm=rec.zbbrxm and t.aac147=rec.ZBBRZJHM;
             end if;
              update tb_fdxx t set t.zbbrgx=nvl(rec.gx,t.zbbrgx),t.zbbrkhid=nvl(v_zbbrkhid,t.zbbrkhid)  where bbrkhid=v_khid and khbdh=rec.bdh;
          end if;
        end if;
        if rec.OP_TYPE in('2') then --2客户信息医保状态变更
             --更新医保待遇开始或结束时间 TB_KHXX.bgsj
              update TB_KHXX t set bgsj=rec.sjsxr,czsj=sysdate ,
              ybbs=rec.ybbs /*decode(rec.ybbs,'有医保','02','有','02','是','02','01')*/,
              ybkh=rec.YBKH,
              t.YBD=rec.ybd where  khid=v_khid
              /*v2.8++begin*/ and rec.ybbs is not null /*v2.8++end*/;
             -- null;

        end if;
          
   --20160614 分单变更前，如果客户编号不为空，则先更新此人的客户编号 begin
       if rec.OP_TYPE in('3','4') and rec.bbrxh is not null then               
                   update tb_khxx d set khbh=rec.bbrxh,d.csrq=TO_NUMBER(to_char(to_date(nvl(rec.CSRQ,d.csrq),'yyyy-mm-dd'),'yyyymmdd'))
                   ,fwtt=(select ttbh from tb_bdxx where khbdh=rec.bdh),aac058=nvl(rec.zjlx,d.aac058)
                    where d.aac147 = rec.zjhm and d.xm = rec.xm 
                    and (nvl(d.csrq,0)=nvl(TO_NUMBER(to_char(to_date(nvl(rec.CSRQ,d.csrq),'yyyy-mm-dd'),'yyyymmdd')),0) or d.csrq is null)
                    and exists(select 'x' from tb_bdxx where  bxgsid=rec.bxgsid and khbdh=rec.bdh);
        end if;
--20160614 分单变更前，如果客户编号不为空，则先更新此人的客户编号 end         
         if rec.OP_TYPE in('3') then --责任等级变更
            --将当事人原来的等级分单改为终止，新增新等级的分单
            update tb_fdxx t set fdzzr=TO_NUMBER(to_char(to_date(rec.sjsxr,'yyyy-mm-dd')-1,'yyyymmdd')),tcrq=TO_NUMBER(to_char(to_date(rec.sjsxr,'yyyy-mm-dd')-1,'yyyymmdd')),fdzt='3'
              where t.bbrkhid =v_khid
                and bdid=(select bdid from tb_bdxx where khbdh=rec.bdh)
                and t.dj not in(select djbh from tb_bddjxx x,tb_bdxx y where x.bdid=y.bdid and y.khbdh=rec.bdh and x.djmc= nvl(rec.dj,x.djmc)) and t.TCRQ is null;
            --新建1条新的等级责任的分单
          /*select  seq_Fdid.nextval as fdid into v_fdid from dual;

           INSERT INTO TB_FDXX(
            FDID, TTID, KHBDH, TBDH, FDH,
          FDSXR, FDZZR, FDZT, FDZBF, BBRKHID,
          BBRNL, ZYLB, ZYDM, ZTTID, DJ,
          GZDXZQH, BBRDZID, BBRDZXX,
          ZLDBZ, ZBBRGX, ZBBRKHID, ZBBRFDH,
          FDZS1, FDZS2, DJID,
          YBDXZQH, JZDQH,Cjrq,Bdid,WBBDH,seqlogid,Bbrxh,ZBBRXH)
        SELECT
          v_fdid as fdid, rec_bdxx.TTID, rec_bdxx.KHBDH, rec_bdxx.TBDH,
          nvl(rec.fdh,rec_bdxx.KHBDH|| trim(to_char((select nvl(count(1),0)+1 from tb_fdxx zz where zz.khbdh=rec.bdh),'099999')) as fdh,
          nvl(to_char(to_date(a.SJSXR,'yyyy-mm-dd'),'yyyymmdd') ,rec_bdxx.BDSXRQ) as FDSXR,
          nvl(to_char(to_date(a.SJZZR,'yyyy-mm-dd'),'yyyymmdd'),rec_bdxx.BDZZRQ) as FDZZR,
          '1' as fdzt,'' fdzbf,
          b.khid as BbrKhid,
        nvl(rec.age,trunc(trunc(to_date(a.SJSXR,'yyyymmdd')-to_date(b.CSRQ, 'yyyymmdd'))/365)) as BBRNL ,
           '' ZYLB, b.ZYDM,
          rec_bdxx.ZTTID,
           nvl((SELECT DJBH FROM TB_BDDJXX WHERE BDID = rec_bdxx.BDID AND DJMC = a.DJ),a.dj) DJ,
          b.GZDXZQH,
          (SELECT max(T.DZID) FROM TB_KHDZXX T WHERE  T.KHID = b.KHID AND  T.YXZT = '0') DZID ,(select max(DZID) FROM TB_KHDZXX  WHERE  KHID = b.KHID AND  YXZT = '0' ) as jtdz,
         case when nvl(a.GX,'本人')!='本人' and a.ZBBRZJHM is not null then '1' else '0' end as ZLDBZ,
         case when nvl(a.GX,'本人')!='本人' and a.ZBBRZJHM is not null then  decode(a.gx,'本人','00','配偶','01','子女','03','99') else ''end as ZBBRGX,
         case when nvl(a.GX,'本人')!='本人' and a.ZBBRZJHM is not null then (select to_char(max(khid)) from tb_khxx  where aac147=a.ZBBRZJHM) else '' end as ZBBRKHID ,
         '' Zbbrfdh ,
        '' FDZS1, '' FDZS2,
        (SELECT DJID FROM TB_BDDJXX WHERE BDID = rec_bdxx.BDID AND DJMC = a.DJ ) as djid,
          b.YBDXZQH, b.JZDXZQH,
          to_number(to_char(SYSDATE,'yyyymmdd')) as Cjrq,rec_bdxx.BDID,'' wbbdh,v_pch as seqlogid,a.bbrxh,a.ZBBRXH
        FROM TB_BDXX rec_bdxx , TB_IMPORT_PSNFDZR a,tb_khxx b where a.bdh=rec_bdxx.khbdh and a.ywlsh=rec.ywlsh
        and b.khid=v_khid;
        and a.RUN_FLAG is null ;
        v_no:=SQL%rowcount;
       dbms_output.put_line('本次新增分单数：'|| to_char(v_no));*/

       --分单责任明细
      /*  INSERT INTO TB_FDZRMX(
          FDZRID, FDID, ZRXH, ZRID,
          BELX, BEDW, GMFSHYS, ZRBE,
          ZRBF, ZRBZBF, ZRFJF, ZRLJPFE, ZRLJMPE,
          ZRKSRQ, ZRJSRQ, YXBS, ZDBE, ZGBE,SEQLOGID)
        SELECT
          TO_NUMBER(SEQ_FDZRID.NEXTVAL), e.fdid, rownum, A.ZRID,
          B.BELX, B.BEDW, DECODE(A.BE, '', '', TRUNC(A.BE/B.BEDW)), A.BE,
          A.BF, NULL, NULL, NULL, NULL,
          NULL, NULL, A.YXBS, A.ZDBE, A.ZGBE,v_pch as seqlogid
        FROM TB_BDDJZRXX A, TB_ZRXX B,tb_fdxx e
        WHERE A.BDID = e.bdid
        and e.fdid=v_fdid
        AND A.DJID = e.Djid
        AND A.ZRID = B.ZRID
        and not exists(select 'x' from TB_FDZRMX where fdid=e.fdid);*/
         /* v_no:=SQL%rowcount;
         dbms_output.put_line('本次新增分单责任数：'|| to_char(v_no));*/
         prc_createFdZRXX(rec.ywlsh,PReturnCode,PReturnMsg);
           if PReturnCode!='0' then
                       dbms_output.put_line(substrb('ywlsh='||rec.ywlsh||'生成分单错误:'||PReturnMsg,1,255));
                       return;
                   end if;
        end if;
        if rec.OP_TYPE in('4') then --保单有效期变更
           --取原来保单信息
             --20160615 如不存在新保单号下的分单，新增处理
             select count(1) into v_no from tb_fdxx t where fdid=(select max(fdid) from tb_fdxx k where k.bbrkhid=v_khid and k.bdid=(select bdid from tb_bdxx where khbdh=rec.bdh)
                and k.dj in(select djbh from tb_bddjxx x,tb_bdxx y where x.bdid=y.bdid and y.khbdh=rec.bdh and x.djmc= nvl(rec.dj,x.djmc)));
           if v_no>0 then --存在原来分单     
               select * into rec_fdxx from tb_fdxx t where fdid=(select max(fdid) from tb_fdxx k where k.bbrkhid=v_khid and k.bdid=(select bdid from tb_bdxx where khbdh=rec.bdh)
                    and k.dj in(select djbh from tb_bddjxx x,tb_bdxx y where x.bdid=y.bdid and y.khbdh=rec.bdh and x.djmc= nvl(rec.dj,x.djmc)));
               if rec_fdxx.fdid is not null then
                   -- 新保单终止日期<原来的保单终止日期，终止日期变更为新的终止日期（减保）
                   if rec.sjzzr<rec_fdxx.fdzzr then  --做终止处理
                      update tb_fdxx t set t.fdzzr=rec.sjzzr ,tcrq=rec.sjzzr,fdzt='3' where fdid=rec_fdxx.fdid ;
                   end if;
                if rec.sjsxr>rec_fdxx.fdzzr then  
                  --新保单的起始日期>终止日期，或生效日大于已有分单的终止日，已有分单终止，终止日期不变
                  --（始终保留同一人在大保单同一等级只有一个有效分单）新增保单
                   update tb_fdxx t set tcrq= t.fdzzr,fdzt='3' where fdid=rec_fdxx.fdid ;
                   --新增分单
                      prc_createFdZRXX(rec.ywlsh,PReturnCode,PReturnMsg);
                       if PReturnCode!='0' then
                       dbms_output.put_line(substrb('ywlsh='||rec.ywlsh||'生成分单错误:'||PReturnMsg,1,255));
                       return;
                   end if;
                end if;
                --新保单的起止日期在原保单的起止日期区间内，原保单的失效日期为新保单生效日期的前一天，再新增一条新保单
                if rec.sjsxr<rec_fdxx.fdzzr and rec.sjsxr>rec_fdxx.fdsxr and rec.sjzzr<=rec_fdxx.fdzzr then
                    update tb_fdxx t set t.fdzzr=TO_NUMBER(to_char(to_date(rec.sjsxr,'yyyy-mm-dd')-1,'yyyymmdd')),tcrq=rec.sjsxr,fdzt='3' where fdid=rec_fdxx.fdid ;
                   prc_createFdZRXX(rec.ywlsh,PReturnCode,PReturnMsg);
                    if PReturnCode!='0' then
                       dbms_output.put_line(substrb('ywlsh='||rec.ywlsh||'生成分单错误:'||PReturnMsg,1,255));
                       return;
                   end if;
                end if;
                --新保单的起始日期在与原分单相同，终止日期不同的，直接修改原来的分单的终止日期 20160614
                if  rec.sjsxr=rec_fdxx.fdsxr and rec.sjzzr!=rec_fdxx.fdzzr then
                   update tb_fdxx t set t.fdzzr=rec.sjzzr where fdid=rec_fdxx.fdid;
                end if;
              end if;
            else  --不存在分单，新增
                prc_createFdZRXX(rec.ywlsh,PReturnCode,PReturnMsg);
                  if PReturnCode!='0' then
                       dbms_output.put_line(substrb('ywlsh='||rec.ywlsh||'生成分单错误:'||PReturnMsg,1,255));
                       return;
                   end if;
            end if;
        end if;
         update    TB_IMPORT_PSNFDZR a  set a.run_flag='1',DO_DATE=v_dodate where a.RUN_FLAG is null and ywlsh=rec.ywlsh ;
     end loop;
    /*v2.8++ begin */ 
    update tb_khxx  set khbh =to_char(khid)  where khbh='xxxxxx' and (aac147,xm) in( select zjhm,xm from  TB_IMPORT_PSNFDZR where DO_DATE=v_dodate and run_flag='1'  );
    /*v2.8++ end*/ 
     --更新分单总保费
     update   TB_FDXX t set t.fdzbf=(select nvl(sum(nvl(zrbf,0)),0) from tb_fdzrmx h where h.fdid=t.fdid) where t.khbdh in(select bdh from TB_IMPORT_PSNFDZR b where DO_DATE=v_dodate) ;
     --更新保单总保费
     update   TB_bDXX t set t.bf=(select nvl(sum(nvl(fdzbf,0)),0) from tb_fdxx h where h.khbdh=t.khbdh) where t.khbdh in(select bdh from TB_IMPORT_PSNFDZR b where DO_DATE=v_dodate) ;
     --更新临时表处理状态
     update TB_IMPORT_PSNFDZR_TMP set run_flag='1' where pch in(select pch from TB_IMPORT_PSNFDZR where DO_DATE=v_dodate and run_flag='1');
/*
  --处理完毕更新处理标志和日期
    update    TB_IMPORT_PSNFDZR a  set a.run_flag='1',DO_DATE=sysdate where a.RUN_FLAG is null
    and  a.bdh in(select khbdh from tb_fdxx b where b.seqlogid=v_pch);*/

    --如果存在按老格式导入的保全数据，则调用原来的存储过程SP_IMPORT_PSNFDZR_OLD   begin
      select nvl(count(1),0) into v_no from TB_IMPORT_PSNFDZR a where a.RUN_FLAG is null and op_type is  null;
    if (v_no>0  and v_opcode='1') THEN
       SP_IMPORT_PSNFDZR_OLD(Pin_userid ,PReturnCode,PReturnMsg);
       if PReturnCode!='0' then
          RETURN;
      end if;
    end if;
      --如果存在按老格式导入的保全数据，则调用原来的存储过程SP_IMPORT_PSNFDZR_OLD   end
     /***** v2.3  end  */
     v_no:=SQL%rowcount;
     dbms_output.put_line('本次总导入人员数：'|| to_char(v_no));
    PReturnCode:='0';
    PReturnMsg:='数据导入处理成功!';
    EXCEPTION
  WHEN OTHERS THEN
    PReturnCode := 'E';
    DBMS_OUTPUT.PUT_LINE('[yhs debug] ' || 'PReturncode= ' ||
                         PReturnCode);
    PReturnMsg := 'Error:' || sqlerrm;
    DBMS_OUTPUT.PUT_LINE(substrb(PReturnMsg,1,255));
  end   SP_IMPORT_PSNFDZR_1;

/
