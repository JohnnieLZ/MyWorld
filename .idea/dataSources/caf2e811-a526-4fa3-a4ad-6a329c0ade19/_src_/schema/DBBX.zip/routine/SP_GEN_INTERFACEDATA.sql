CREATE PROCEDURE      "SP_GEN_INTERFACEDATA" (PReturnCode OUT VARCHAR2, PReturnMsg OUT VARCHAR2) AS
  rec_ttfw  TB_TTFWBZXX%rowtype;
  i_Step number:=0;
  v_startdate DATE:=sysdate;
  v_enddate Date;
  v_no number:=0;
BEGIN
  i_Step := 1;
    FOR c_Jaaj IN (
      SELECT A.AJID,A.TTID,A.DYRQ
      FROM TB_LPAJXX A
      WHERE A.AJZT = '11'
      and a.pah not like 'CL%'
      AND NOT EXISTS (SELECT 'x' FROM TB_LPGRFWGZB WHERE AJID = A.AJID)) loop

  i_Step := 2;

      SELECT *
      INTO rec_ttfw
      FROM TB_TTFWBZXX
      WHERE TTID = c_Jaaj.TTID;

  i_Step := 3;
    INSERT INTO TB_LPGRFWGZB
    (FWID, AJID,
     SFXYYJ, XYDXLB, SLDXFSSJ, SLDXFSZT,
     WTDXFSNR, WTDXFSSJ, WTDXFSZT, WCDXFSSJ, WCDXFSZT,
     GRXJYS, SCDYRQ, DYCS, SEQLOGID,
     YJFSSJ    ,--DATE          Y                ??????
YJFSZT    ,--VARCHAR2(1)   Y                1 ?? 0 ??
SDDATE    ,--NUMBER(8)     Y                ??????
YJLX      ,--VARCHAR2(50)  Y                ??????
WTJYJFSZT ,--VARCHAR2(1)   Y                ?????????
SLJYJFSZT ,--VARCHAR2(1)   Y                ????????
WCJYJFSZT)  --VARCHAR2(1)   Y                ????????? )
    SELECT
    SEQ_FWID.NEXTVAL, c_Jaaj.AJID,
    rec_ttfw.SFXYYJ, CASE WHEN rec_ttfw.SFXYDX='1' THEN rec_ttfw.DXLB else '' end as XYDXLB, NULL, '',
     '', NULL, '', NULL, '',
     rec_ttfw.GRXJYS, c_Jaaj.DYRQ, '', null,
     null,NULL,to_char(sysdate,'yyyymmdd'),
     rec_ttfw.yjlx as YJLX,
     '0' WTJYJFSZT ,'0' SLJYJFSZT,'0' WCJYJFSZT
    FROM DUAL;
v_no:=v_no+1;
    END LOOP;

  i_Step := 4;
    PReturnCode := '0'; /* ??????????????vstatid????????? */
   /* PReturnMsg  := vstatid;*/
    DBMS_OUTPUT.PUT_LINE('[LDS debug] ' || 'PReturncode= ' || PReturnCode);
    --COMMIT; ???java?????????
   v_enddate:=sysdate;
   insert into tb_auto_task_log(
    RUN_ID ,--    NUMBER(10)
    RWLX    ,--   VARCHAR2(100) Y                ????
    RUNDATE  ,--  VARCHAR2(20)  Y                ????YYYYMMDDHH24
    START_DATE ,--DATE          Y                ????
    END_DATE  ,-- DATE          Y                ????????
    YWBS     ,--  NUMBER(10)    Y                ??????
    BZ  )   --    VARCHAR2(200) Y                ??
  select seq_aaz002.nextval as run_id,'SP_GEN_INTERFACEDATA',to_char(sysdate,'yyyymmdd') as rundate,
  v_startdate, v_enddate,v_no,'??????????????' from dual;
  EXCEPTION
    WHEN OTHERS THEN
      --rollback;???java?????????????0?????????????????
      PReturnCode := 'E'; /*  ??????  */
      DBMS_OUTPUT.PUT_LINE('[yhs debug] ' || 'PReturncode= ' || PReturnCode||sqlerrm);
      /*PReturnMsg := ' rownum' || cell.r || 'Error:' || sqlerrm; --???????????*/
      DBMS_OUTPUT.PUT_LINE(PReturnMsg);
END SP_GEN_INTERFACEDATA;

/
