CREATE function      FUNC_ZPAID_ZDLX(P_ZPAID in number) return varchar2 is
   rett_var varchar2(2):='';
   res_data tb_zddmbxgsdmdzb%rowtype;
begin
   select * into res_data from tb_zddmbxgsdmdzb a where a.bxgsid=712 and a.aaa100='ZRDM' and a.aaa102 = (select pfzrdm from tb_zpaxx n where n.zpaid=P_ZPAID);
          if res_data.qtsm5='0' then
            rett_var := res_data.qtsm4;
          else
            select distinct b.zdlx into rett_var from tb_lpfpxx b,tb_zpaxx c where b.fpid=c.fpid and c.zpaid=P_ZPAID;
            if rett_var='1' then
              rett_var :='B';
            else
              rett_var :='A';
            end if;
          end if;
  return(rett_var);
end FUNC_ZPAID_ZDLX;

/
