CREATE PROCEDURE      SP_CHECK_ZDDM(PIN_AJID IN varCHAR2,PReturnCode OUT varchar2, PReturnMsg OUT varchar2) AS
 nBdid    NUMBER(16) := 0;
 i_Count NUMBER(9) := 0;
 i_step  NUMBER(9) := 0;
 s_Jblx  VARCHAR2(2);
 s_Zddm  VARCHAR2(300);
 CURSOR c_Zpaxx(sAjid VARCHAR2) IS
   SELECT T.ZPAID, T.JBID, T.ZRID, T.ZDDM
   FROM TB_ZPAXX T
   WHERE T.AJID = sAjid
   AND T.FPID IS NOT NULL;

 BEGIN
    PReturnCode:='E';
    PReturnMsg:='Error!';
    ----???????????
    i_step := 1;
    IF TRIM(PIN_AJID) IS NULL THEN
    PRETURNCODE := 'E';
        PRETURNMSG := '??ID????';
        RETURN;
    END IF;

    ----????ID
    i_step := 2;
    BEGIN
     SELECT nvl(C.BDID,(select bdid from tb_fdxx where fdid=b.fdid))
      INTO nBdid
      FROM TB_LPPCXX C,TB_LPAJXX B
      WHERE  C.PCID=B.LPPCID
    AND B.AJID = PIN_AJID;
  EXCEPTION
    WHEN OTHERS THEN
          PRETURNCODE := 'E';
          PRETURNMSG := '??????ID';
          RETURN;
  END;

    FOR cc IN c_Zpaxx(PIN_AJID) LOOP

      BEGIN
      SELECT max(A.JBLX)
        INTO s_Jblx
        FROM TB_BDTYSHGZZDDMPZ A
        WHERE A.BDID = nBdid
        AND A.JBID = cc.JBID
        AND A.ZRID = cc.ZRID;
    EXCEPTION
      WHEN OTHERS THEN
            s_Jblx := '';
    END;


    if s_Jblx is not null and length(s_Jblx)>0 then
        BEGIN
        SELECT AAA103
          INTO s_Zddm
          FROM AA10
          WHERE AAA100 = 'JBLB'
          AND AAA102 = s_Jblx;
      EXCEPTION
        WHEN OTHERS THEN
              s_Zddm := 'aa10?????????????';
      END;
      UPDATE TB_ZPAXX
        SET XGDM =case when trim(XGDM) is not null then XGDM || ',' || DECODE(s_Jblx, '11', 'CL29', '0', 'CL30', '1', 'CL31', '2', 'CL32', '3', 'CL33', '4', 'CL34', '5', 'CL35', '6', 'CL36', '7', 'CL37', '8', 'CL38', '9','CL39','10','CL45','12','CL63','13','CL59','41','CL60',/*@version 1.2++ begin */'14','CL83','15','CL84','16','CL85',/*@version 1.2++ end*/
          /*@version 1.4++ begin */'18','CL97',/*@version 1.4++ end*/'')
         else DECODE(s_Jblx, '11', 'CL29', '0', 'CL30', '1', 'CL31', '2', 'CL32', '3', 'CL33', '4', 'CL34', '5', 'CL35', '6', 'CL36', '7', 'CL37', '8', 'CL38', '9','CL39','10','CL45','12','CL63','13','CL59','41','CL60',/*@version 1.2++ begin */'14','CL83','15','CL84','16','CL85',/*@version 1.2++ end*//*@version 1.4++ begin */'18','CL97',/*@version 1.4++ end*/'') end,
          XGDMMS =case when XGDMMS is not null then  XGDMMS || ','|| s_Zddm || ':'|| cc.ZDDM else  s_Zddm || ':'|| cc.ZDDM end
        WHERE ZPAID = cc.ZPAID;
    end if;

  END LOOP;
 /* v1.3 ++ begin */
  --?????SY008,SY009???????????????????????
    update TB_ZPAXX a set a.xgdm = case when  exists(select 'x' from tb_zpaxxdzb b,tb_fpxxfyxx d,tb_sbshgzpzxx e where b.xxid = d.xxid
                                                                 and b.zpaid=a.zpaid and e.ZSDBM=d.XXDM and e.ZSDLB=d.xmlb
                                                                 and e.status='1' and e.AAA102='SY008' and d.ZDDM not in(select shys2 from tb_sbshgzpzxx h where nvl(h.xzqh,'xxx')=nvl(e.xzqh,'xxx') and h.aaa102=e.aaa102 and h.status='1' and h.zsdbm=e.zsdbm) )
                                                    then case when instr(a.xgdm,'SY008')>0 then a.xgdm else DECODE(a.xgdm,null,'SY008','','SY008',a.xgdm||',SY008') end
                                             else replace(replace(replace(a.xgdm, ',SY008', ''), 'SY008,', ''),'SY008', '') end
               where  a.ajid =PIN_AJID and fpid is not null and pfzrdm not like 'HI%';
               --sy009??????
    update TB_ZPAXX a set a.xgdm = case when  exists(select 'x' from tb_zpaxxdzb b,tb_fpxxfyxx d,tb_sbshgzpzxx e where b.xxid = d.xxid
                                                                 and b.zpaid=a.zpaid and e.ZSDBM=d.XXDM and e.ZSDLB=d.xmlb
                                                                 and e.status='1' and e.AAA102='SY009' and e.shys1='09' and d.ZDDM not in(select ZDDM  as xxx from
                                                                     tb_bdtyshgzzddmpz  h,tb_fdxx y  where h.bdid=y.bdid and y.fdid=a.fdid  and h.zrid=a.zrid  and h.jblx=e.SHYS2 and h.YXZT='1'))
                                                    then case when instr(a.xgdm,'SY009')>0 then a.xgdm else DECODE(a.xgdm,null,'SY009','','SY009',a.xgdm||',SY009') end
                                             else replace(replace(replace(a.xgdm, ',SY009', ''), 'SY009,', ''),'SY009', '') end
               where  a.ajid =PIN_AJID and fpid is not null and pfzrdm not like 'HI%';
   /* v1.3 ++ end */
    PReturnCode:='0';--????
    PReturnMsg:='check success!';
    RETURN;
  EXCEPTION
  WHEN OTHERS THEN
    PReturnCode := 'E';
    DBMS_OUTPUT.PUT_LINE('[yhs debug] ' || 'PReturncode= ' ||
                         PReturnCode);
    PReturnMsg := 'Error:' || sqlerrm;
    DBMS_OUTPUT.PUT_LINE(PReturnMsg);
END SP_CHECK_ZDDM;

/
