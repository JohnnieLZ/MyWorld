CREATE PROCEDURE      "SP_P1_30016" (report_id   In t_report_def_info.REPORTID%TYPE,
                                        pStartdate  IN varchar2, -- ??????yyyymmdd
                                        pEnddate    IN varchar2, -- ??????yyyymmdd
                                        pStatman    IN t_report_gen_info.STATMAN%TYPE, --???
                                        ptype       in varchar2, /*0 ???? ,1 ?? 2 ?? 3 ?? */ --?????
                                        POther1     IN varchar2, --??id
                                        POther2     IN varchar2, --??id
                                        POther3     IN varchar2, --??id
                                        POther4     IN varchar2, --??ID
                                        POther5     IN varchar2, --????
                                        POther6     IN varchar2, --??ID
                                        POther7     IN varchar2, --??
                                        POther8     IN varchar2, --??
                                        PReturnCode OUT varchar2,
                                        PReturnMsg  OUT varchar2) AS
  V_STEP_CODE  CHAR(5); --?????????????????
  vreportid    t_report_def_info.REPORTID%TYPE; --??ID
  v_start_date number := 0; --????????
  v_end_date   number := 0; --????????
  vxzqhdm      t_report_gen_info.STATORGID%TYPE; --????????????

  vstatid varchar(30);--?????????????????
  type cellType is record (
    statid varchar2(15),
    col    number,
    r      number,
    content varchar2(1024));

  cell       cellType;--??excel??????
  vdwmc      varchar2(50);--????????????
  vusername  t_report_gen_info.STATMAN%TYPE;--????????
  vnd        t_report_gen_info.STATYEAR%TYPE;--??????
  rowno      number := 0;--??????

begin
  V_STEP_CODE := '00000';
  PReturnMsg  := 'OK';
  PReturnCode := 'E';
  vreportid   := substr(report_id, 1, 5);
  vusername   := pStatman;
  vnd         := substr(pStartdate, 1, 4);

  v_start_date := to_number(substr(pStartdate, 1, 8));
  v_end_date   := to_number(substr(pEnddate, 1, 8));

  --????????????????????????????
  delete from t_report_data_info
    where statid in
          (select statid from T_REPORT_GEN_INFO where reportid = report_id);

  delete from t_report_gen_info
    where statid in
          (select statid from T_REPORT_GEN_INFO where reportid = report_id);

  V_STEP_CODE := '00001';
  --?????T_REPORT_GEN_INFO????????????
  --???????
  select seq_statid.nextval into vstatid from dual;

  --??????????
  insert into T_REPORT_GEN_INFO
    (STATID,
     REPORTID,
     STATORGID,
     STATORGNAME,
     STATDATE,
     STATMAN,
     STATYEAR,
     BEGINDATE,
     ENDDATE,
     STAT_OTHER,
     STAT_TYPE)
   values
     (vstatid,
      vreportid,
      '',
      '',
      to_char(sysdate, 'yyyymmdd'),
      vusername,
      vnd,
      v_start_date,
      v_end_date,
      substr(pEnddate, 1, 1),
      trim(ptype));
  /*--?????? excel??0???????????0????????*/

  --????
  insert into t_report_data_info(statid,sheet,col,r,content) values(vstatid,0,1,0,to_char(sysdate,'yyyymmdd'));

  --????
  select max(bxgsqc) into cell.content from tb_bxgsxx where bxgsid = trim(POther1);
  if cell.content is not null then
    insert into t_report_data_info(statid,sheet,col,r,content) values(vstatid,0,1,1,cell.content);
  end if;

  --????
  select max(ttmc) into cell.content from tb_ttxx where ttid = trim(POther2);
  if cell.content is not null then
    insert into t_report_data_info(statid,sheet,col,r,content) values (vstatid,0,1,2,cell.content);
  end if;

  --???
  select max(khbdh) into cell.content from tb_bdxx where bdid = trim(POther3);
  if cell.content is not null then
    insert into t_report_data_info(statid,sheet,col,r,content) values (vstatid,0,1,3,cell.content);
  end if;

  --????????
  insert into t_report_data_info(statid,sheet,col,r,content) values (vstatid,0,1,4,trim(pStartdate) ||'-'|| trim(pEnddate));

  cell.statid := vstatid;
  cell.col    := 0;--?1???
  cell.r      :=8;--?9???
  --???????????????????????????????excel???????????????
 for vrow in(
  select a.bxgsqc as bxgs,b.khbdh as khbdh,b.bdsxrq as bdsxrq,b.bdzzrq as bdzzrq,c.ttbh as tbtth,c.ttmc as tbttmc,
    d.cph as cph,d.cpmc as cpmc,e.zrbm as zrh,e.zrmc as zrmc,f.be as be,g.bbrxm as bbrxm,
    (select aac058 from tb_khxx where khid=g.bbrkhid) as bbrzjlx,g.bbrzjh as bbrzjh,h.bbrnl as bbrnl,h.zbbrgx as zbbrgx,
    (select xm from tb_khxx where khid=h.zbbrkhid) as zbbrxm,
    (select aaa103 from tb_khxx,aa10 where AA10.AAA100='ZJLX' and tb_khxx.khid=h.zbbrkhid and tb_khxx.aac058=aa10.aaa102) as zbbrzjlx,
    (select aac147 from tb_khxx where khid=h.zbbrkhid) as zbbrzjh,g.zttid as ztth,g.zttmc as zttmc,i.bmmc as bm,i.gh as gh
  from tb_bxgsxx a,tb_bdxx b,tb_ttxx c,tb_cpxx d,tb_zrxx e,tb_bddjzrxx f,tb_lpajxx g,tb_fdxx h,tb_khxx i,tb_bdcpxx k
  where a.bxgsid=nvl(trim(POther1),a.bxgsid) and b.ttid=nvl(trim(POther2),b.ttid) and b.bdid=nvl(trim(POther3),b.bdid)
  and a.bxgsid = b.bxgsid
  and b.ttid=c.ttid
  and k.bdid=b.bdid
  and k.cpid=d.cpid
  and b.bdid=f.bdid
  and e.zrid=f.zrid
  and i.khid=h.zbbrkhid
  and h.khbdh=b.khbdh
  )loop

    --????
    insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0,0,cell.r,vrow.bxgs);
    --?????
    insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0,1,cell.r,vrow.khbdh);
    --??????
    insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0,2,cell.r,vrow.bdsxrq);
    --??????
    insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0,3,cell.r,vrow.bdzzrq);
    --?????
    insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0,4,cell.r,vrow.tbtth);
    --??????
    insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0,5,cell.r,vrow.tbttmc);
    --???
    insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0,6,cell.r,vrow.cph);
    --????
    insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0,7,cell.r,vrow.cpmc);
    --???
    insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0,8,cell.r,vrow.zrh);
    --????
    insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0,9,cell.r,vrow.zrmc);
    --??
    insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0,10,cell.r,vrow.be);
    --??????
    insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0,11,cell.r,vrow.bbrxm);
    --????????
    insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0,12,cell.r,vrow.bbrzjlx);
    --???????
    insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0,13,cell.r,vrow.bbrzjh);
    --??????
    insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0,14,cell.r,vrow.bbrnl);
    --????????
    insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0,15,cell.r,vrow.zbbrgx);
    --?????????
    insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0,16,cell.r,vrow.zbbrxm);
    --???????????
    insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0,17,cell.r,vrow.zbbrzjlx);
    --??????????
    insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0,18,cell.r,vrow.zbbrzjh);
    --????
    insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0,19,cell.r,vrow.ztth);
    --?????
    insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0,20,cell.r,vrow.zttmc);
    --??
    insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0,21,cell.r,vrow.bm);
    --??
    insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0,22,cell.r,vrow.gh);

    cell.r   := cell.r + 1;     --??+1,???????1?
  end loop;

  --???????????

  /*9.??*/
  PReturnCode := '0'; /* ??????????????vstatid????????? */
  PReturnMsg  := vstatid;
  DBMS_OUTPUT.PUT_LINE('[LDS debug] ' || 'PReturncode= ' || PReturnCode);
  --COMMIT; ???java?????????

  EXCEPTION
  WHEN OTHERS THEN
    --rollback;???java?????????????0?????????????????
    PReturnCode := 'E'; /*  ??????  */
    DBMS_OUTPUT.PUT_LINE('[yhs debug] ' || 'PReturncode= ' ||PReturnCode);
    PReturnMsg := ' rownum' || cell.r  || 'Error:' || sqlerrm; --???????????
    DBMS_OUTPUT.PUT_LINE(PReturnMsg);
end SP_P1_30016;

/
