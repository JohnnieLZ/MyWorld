CREATE function      FUNC_KCFYJS(ajid_I in NUMBER) return number is
  Result number;
  TYPE judgement_type IS RECORD(
      zbbrgx tb_fdxx.zbbrgx%TYPE,
      fdid  tb_fdxx.fdid%TYPE,
      khbdh tb_fdxx.khbdh%TYPE
   );
   judgement_value judgement_type;
begin
  select a.zbbrgx,a.fdid,a.khbdh into judgement_value from tb_fdxx a,tb_lpajxx b where a.fdid=b.fdid and b.ajid=ajid_I;
  if  then

    else

      end if;

select * from aa10 where aaa100='ZBBRGX'
  return(Result);
end FUNC_KCFYJS;

/
