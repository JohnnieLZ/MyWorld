CREATE PROCEDURE      "SP_P1_30014_WMN" (report_id   In t_report_def_info.REPORTID%TYPE,
                                        pStartdate  IN varchar2, -- ??????yyyymmdd
                                        pEnddate    IN varchar2, -- ??????yyyymmdd
                                        pStatman    IN t_report_gen_info.STATMAN%TYPE, --???
                                        ptype       in varchar2, /*0 ???? ,1 ?? 2 ?? 3 ?? */ --?????
                                        POther1     IN varchar2, --??id
                                        POther2     IN varchar2, --??id
                                        POther3     IN varchar2, --??id
                                        POther4     IN varchar2, --??ID
                                        POther5     IN varchar2, --????
                                        POther6     IN varchar2, --??ID
                                        POther7     IN varchar2, --??
                                        POther8     IN varchar2, --??
                                        PReturnCode OUT varchar2,
                                        PReturnMsg  OUT varchar2) AS
  V_STEP_CODE  CHAR(5); --?????????????????
  vreportid    t_report_def_info.REPORTID%TYPE; --??ID
  v_start_date number := 0; --????????
  v_end_date   number := 0; --????????
  vxzqhdm      t_report_gen_info.STATORGID%TYPE; --????????????

  vstatid varchar(30); --?????????????????
  type cellType is record(
    statid  varchar2(15),
    col     number,
    r       number,
    content varchar2(1024));

  cell      cellType; --?????????????
  vdwmc     varchar2(50); --????????????
  vusername t_report_gen_info.STATMAN%TYPE; --????????
  vnd       t_report_gen_info.STATYEAR%TYPE; --????
  rowno     number := 0; --??????



begin
  V_STEP_CODE := '00000';
  PReturnMsg  := 'OK';
  PReturnCode := 'E';
  vreportid   := substr(report_id, 1, 5);
  vusername   := pStatman;
  vnd         := substr(pStartdate, 1, 4);

  v_start_date := to_number(substr(pStartdate, 1, 8));
  v_end_date   := to_number(substr(pEnddate, 1, 8));

  --???????????????????????????
  delete from t_report_data_info
   where statid in
         (select statid from T_REPORT_GEN_INFO where reportid = report_id);

  delete from T_REPORT_GEN_INFO
   where statid in
         (select statid from T_REPORT_GEN_INFO where reportid = report_id);

  V_STEP_CODE := '00001';
  --???,?T_RERORT_GEN_INFO?????????????
  --???????
  select seq_statid.nextval into vstatid from dual;

  -- ??????????
  insert into t_report_gen_info
    (STATID,
     REPORTID,
     STATORGID,
     STATORGNAME,
     STATDATE,
     STATMAN,
     STATYEAR,
     BEGINDATE,
     ENDDATE,
     STAT_OTHER,
     STAT_TYPE)
  values
    (vstatid,
     vreportid,
     '',
     '',
     to_char(sysdate, 'yyyymmdd'),
     vusername,
     vnd,
     v_start_date,
     v_end_date,
     substr(pEnddate, 1, 1),
     trim(ptype));

   /* --?????? ??excel???0?????1??,????0???*/

  --????
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,1,3,to_char(sysdate,'yyyymmdd'));

  --????
  select max(bxgsqc) into cell.content from tb_bxgsxx where bxgsid=trim(POther1);
  if cell.content is not null then
    insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,1,7,cell.content);
  end if;

  --????
  select max(ttmc) into cell.content from tb_ttxx where ttid = trim(POther2);
  if cell.content is not null then
    insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,1,8,cell.content);
  end if;

  --????
  select max(khbdh) into cell.content from tb_bdxx where bdid = trim(POther3);
  if cell.content is not null then
    insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,1,8,cell.content);
  end if;



  cell.statid := vstatid;
  cell.col    := 0; --?1???
  cell.r      := 10; --?11???
  --???????????????????????????????excel????????????????????

  --?????????
  for rec_bxgs in(Select a.bxgsid, a.bxgsqc
            from TB_BXGSXX a ,TB_TTXX b,TB_BDXX c,TB_CPXX d , TB_BDCPXX e
            where a.bxgsid = c.bxgsid
            and c.ttid = b.ttid
            and c.bdid = e.bdid
            and d.cpid = e.cpid
            ) loop
       for rec_ttxx in(select a.ttbh ,a.ttmc ,a.ttid
            from TB_TTXX a,TB_BDXX b,TB_CPXX c , TB_BDCPXX d, TB_BXGSXX e
            where a.ttid = b.ttid
            and b.bdid = d.bdid
            and c.cpid = d.cpid
            and e.bxgsid = rec_bxgs.bxgsid
            and b.bxgsid = e.bxgsid
            ) loop
          for rec_bdxx in(select a.bdid,a.khbdh , a.bdsxrq ,a.bdzzrq
              from TB_BDXX a ,TB_CPXX b , TB_BDCPXX c, TB_BXGSXX d ,TB_TTXX e
              where  a.bdid = c.bdid
              and b.cpid = b.cpid
              and d.bxgsid = rec_bxgs.bxgsid
              and e.ttid = rec_ttxx.ttid
              and a.bxgsid = d.bxgsid
              and a.ttid = e.ttid
              group by a.bdid,a.khbdh , a.bdsxrq ,a.bdzzrq
              ) loop
            for rec_cpxx in(select  b.cph ,b.cpmc ,count(distinct e.bbrkhid) as tbrs ,count(distinct f.bbrkhid) as cxrs,
                 trunc(count(distinct e.bbrkhid)/count(distinct e.bbrkhid)) as cxl
                 from TB_BDXX a,TB_CPXX b , TB_BDCPXX c ,TB_BXGSXX d ,TB_FDXX e ,TB_LPAJXX f ,TB_TTXX g
                 where a.bdid = rec_bdxx.bdid
                 and b.cpid = c.cpid
                 and d.bxgsid = rec_bxgs.bxgsid
                 and e.khbdh = a.khbdh
                 and g.ttid = rec_ttxx.ttid
                 and a.bxgsid = d.bxgsid
                 and a.ttid = e.ttid
                 group by a.bdid, a.khbdh,a.bdsxrq ,a.bdzzrq , b.cph ,b.cpmc
                 ) loop

                     --??????
                     cell.content := rec_bxgs.bxgsqc;
                     if cell.content is not null then
                     insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,0,cell.r,cell.content);
                     end if;

                     --?????
                     cell.content := rec_ttxx.ttbh;
                     if cell.content is not null then
                     insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,1,cell.r,cell.content);
                     end if;

                     --??????
                     cell.content := rec_ttxx.ttmc;
                     if cell.content is not null then
                     insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,2,cell.r,cell.content);
                     end if;

                     --?????
                     cell.content := rec_bdxx.khbdh;
                     if cell.content is not null then
                     insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,3,cell.r,cell.content);
                     end if;

                     --?????
                     cell.content := rec_bdxx.bdsxrq;
                     if cell.content is not null then
                     insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,4,cell.r,cell.content);
                     end if;

                     --?????
                     cell.content := rec_bdxx.bdzzrq;
                     if cell.content is not null then
                     insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,5,cell.r,cell.content);
                     end if;

                     --???
                     cell.content := rec_cpxx.cph;
                     if cell.content is not null then
                     insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,6,cell.r,cell.content);
                     end if;

                     --???
                     cell.content := rec_cpxx.cpmc;
                     if cell.content is not null then
                     insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,7,cell.r,cell.content);
                     end if;

                     --????
                     cell.content := rec_cpxx.tbrs;
                     if cell.content is not null then
                     insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,8,cell.r,cell.content);
                     end if;

                     --????
                     cell.content := rec_cpxx.cxrs;
                     if cell.content is not null then
                     insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,9,cell.r,cell.content);
                     end if;

                     --???
                     cell.content := rec_cpxx.cxl;
                     if cell.content is not null then
                     insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,10,cell.r,cell.content);
                     end if;

                     cell.r :=  cell.r+1;
                  end loop;
                   /*?????*/
                   insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,3,cell.r,'????');

                   select count(distinct a.bbrkhid) into cell.content
                   from tb_fdxx a,tb_bdxx b
                   where b.bdid=rec_bdxx.bdid and a.ttid = rec_ttxx.ttid and b.ttid = a.ttid;
                   insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,8,cell.r,cell.content);

                   select count(distinct a.bbrkhid) into cell.content
                   from Tb_Lpajxx a,tb_bdxx b
                   where b.bdid=rec_bdxx.bdid and a.ttid = rec_ttxx.ttid and b.ttid = a.ttid ;
                   insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,9,cell.r,cell.content);

                   cell.r :=  cell.r+1;
           end loop ;
               /*?????*/
               insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,1,cell.r,'????');

               select count(distinct bbrkhid) into cell.content from tb_fdxx a,tb_ttxx b where b.ttid=rec_ttxx.ttid and a.ttid = b.ttid;
               insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,8,cell.r,cell.content);

               select count(distinct a.bbrkhid) into cell.content from Tb_Lpajxx a,tb_ttxx b where b.ttid = rec_ttxx.ttid and a.ttid = b.ttid;
               insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,9,cell.r,cell.content);

               cell.r :=  cell.r+1;
       end loop ;
           /*???????*/
           insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,0,cell.r,'??????');
           select count(distinct bbrkhid) into cell.content from tb_fdxx a,tb_bxgsxx b where b.bxgsid = rec_bxgs.bxgsid;

           insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,8,cell.r,cell.content);
           select count(distinct a.bbrkhid) into cell.content from Tb_Lpajxx a,tb_bxgsxx b where b.bxgsid = rec_bxgs.bxgsid and a.bxgsid = b.bxgsid;
           insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,9,cell.r,cell.content);
           cell.r :=  cell.r+1;


    end loop;



  --???????????
  /*9.??*/
  PReturnCode := '0'; /* ??????????????vstatid????????? */
  PReturnMsg  := vstatid;
  DBMS_OUTPUT.PUT_LINE('[LDS debug] ' || 'PReturncode= ' || PReturnCode);
  --COMMIT; ???java?????????

EXCEPTION
  WHEN OTHERS THEN
    --rollback;???java?????????????0?????????????????
    PReturnCode := 'E'; /*  ??????  */
    DBMS_OUTPUT.PUT_LINE('[yhs debug] ' || 'PReturncode= ' || PReturnCode);
    PReturnMsg := ' rownum' || cell.r || 'Error:' || sqlerrm; --???????????
    DBMS_OUTPUT.PUT_LINE(PReturnMsg);
end SP_P1_30014_wmn;

/
