CREATE PROCEDURE "SP_P1_OTHERCASECHECK"(PIN_AJID    IN varCHAR2,
                                                   Pin_userid  IN varCHAR2,
                                                   PReturnCode OUT varchar2,
                                                   PReturnMsg  OUT varchar2) AS
  /*
  *@version 1.1  其它地区医保大病审核理算逻辑实现
  */
  v_no     number := 0;
  rec_ajxx tb_lpajxx%rowtype;
  --一个案件生成1子赔案
  cursor cur_ylzpa is
    select k.bdid as mpts,
           k.bdsxrq,
           k.bdzzrq,
           min(a.fpid) as fpid,
           min(a.ZDLX) as zdlx,
           min(a.YYID) as yyid,
           min(nvl(ryrq, jzrq)) as jzrq,
           min(fprq) as jsrq,
           sum(nvl(a.fpze, 0)) as zdje, --     NUMBER(16,2)  Y                账单总金额
           sum(nvl(a.tczfe, 0) + nvl(a.fjzfe, 0) + nvl(a.SBZFE, 0)) as SBZFJE, -- 社保支付总金额
           sum(nvl(ZFZE, 0)) as zfje, --      NUMBER(16,2)  Y                自费金额
           sum(nvl(a.flzfze, 0)) as FLZFJE, --  NUMBER(16,2)  Y                分类自负金额
           sum(nvl(ZFYJE, 0)) as ZFYJE, --  自付金额
           sum(nvl(a.bhlfy, 0)) as BHLFY --   NUMBER(16,2)  Y                不合理费用
      from TB_LPFPXX a, tb_bdxx k
     where k.bxgsid = 572
       and a.fprq >= k.bdsxrq
       and a.fprq <= k.bdzzrq
       and k.BDZT = '1'
       and a.ajid = to_number(trim(PIN_AJID))
     group by k.bdid, k.bdsxrq, k.bdzzrq;
  --having sum(nvl(a.fpze, 0)) >= 0; 去掉发票总额判断，使所有类型的发票总额都可以理算

  v_zpaid   number(16) := -1;
  v_fphm    varchar2(500) := ''; --医疗子赔案用到的所有发票号
  v_jsrq    number(16) := 0; -- 结算日期
  v_lspfje  number(16, 2) := 0; --历史赔付金额
  v_lsje    number(16, 2) := 0; --本案可理算金额
  v_bhlje   number(16, 2) := 0; --剔除总金额
  v_sjpfje  number(16, 2) := 0; --计算所得实际赔付金额
  v_tempje1 number(16, 4) := 0; --临时金额变量1
  v_tempje2 number(16, 4) := 0; --临时金额变量1
  v_zfje    number(16, 2) := 0; --自费总额+自负总额=自付金额

begin
  PReturnCode := 'E';
  PReturnMsg  := 'Error!';
  select *
    into rec_ajxx
    from tb_lpajxx
   where ajid = to_number(trim(PIN_AJID));
  if rec_ajxx.bxgsid = 572 then
    --苏州大病系统子赔案生成并理算

    --  如果一张发票结算期对应有两个有效的保单，不能生成结算信息，系统给出提示。
    select count(1), min(a.fprq)
      into v_no, v_jsrq
      from tb_lpfpxx a
     where a.ajid = to_number(trim(PIN_AJID))
       and exists (select count(1)
              from tb_bdxx b
             where b.bxgsid = 572
               and a.fprq >= b.bdsxrq
               and a.fprq <= b.bdzzrq
               and b.bdzt = '1' having count(1) > 1);
    if v_no > 0 then
      PReturnCode := '-99';
      PReturnMsg  := '存在结算日期为' || to_char(v_jsrq) ||
                     '的发票，对应有两个及以上的有效的保单，请只保留一个有效保单后再操作!';
      return;
    end if;

    delete from TB_ZPAXXDZB
     where zpaid in (select zpaid as xxx
                       from tb_zpaxx
                      where ajid = to_number(trim(PIN_AJID))
                        and nvl(SFSDTJ, '0') = '0');

    delete from TB_ZPALSGZDZB a
     where a.ZPAID in (select zpaid as xxx
                         from tb_zpaxx
                        where ajid = to_number(trim(PIN_AJID))
                          and nvl(SFSDTJ, '0') = '0');

    delete from tb_zpaxx
     where ajid = to_number(trim(PIN_AJID))
       and nvl(SFSDTJ, '0') = '0';

    --先回填案件发票的剔除金额
    update tb_lpfpxx a
       set a.bhlfy = (select sum(nvl(bhlje, 0))
                        from tb_fpxxfyxx
                       where fpid = a.fpid)
     where a.ajid = to_number(trim(PIN_AJID));

    --大病险子赔案生成并理算
    v_no := 0;
    for recylzpa in cur_ylzpa loop
      v_no := v_no + 1;
      --生成子赔案信息表，初步统计下总金额，后面理算好后在更新
      select seq_ZPAID.nextval into v_zpaid from dual;

      --理算公式：（本次自付金额+历史自付金额-本次剔除金-历史剔除金）元按照分级累进方式计算后（+800元）-历史赔付金额=本次大病赔付金额
      insert into tb_zpaxx
        (ZPAID, --NUMBER(16)                     子赔案ID
         ZPAH, --JSD+YYYYMMDD+5位流水号              子赔案号
         AJID, --NUMBER(16)                     案件ID
         JBID, --NUMBER(16)                     疾病ID
         ZDDM, --VARCHAR2(10)  Y                诊断代码
         ZRID, --NUMBER(16)                     责任ID
         PFZRDM, --VARCHAR2(4)   Y                赔付责任代码
         ZDZJE, --NUMBER(16,2)  Y                账单总金额
         SBZFZJE, --NUMBER(16,2)  Y                社保支付总金额
         ZFJE, --NUMBER(16,2)  Y                自费金额
         FLZFJE, --NUMBER(16,2)  Y                分类自负金额
         QTDSFZFJE, --NUMBER(16,2)  Y                其他第三方支付金额
         BHLFY, --NUMBER(16,2)  Y                不合理费用
         XGDM, --VARCHAR2(100) Y                悬挂代码
         ZT,
         fpid,
         fdid --VARCHAR2(1)   Y                状态
        ,
         mpts --v2.0++ 结算单所属保单ID
         )
        select v_zpaid as ZPAID,
               rec_ajxx.pah || trim(to_char(v_no, '099')) as zpah,
               to_number(trim(PIN_AJID)),
               '' as jbid,
               '' as zddm,
               '' as zrid,
               recylzpa.zdlx as PFZRDM,
               recylzpa.zdje as zdzje,
               recylzpa.SBZFJE,
               recylzpa.ZFJE,
               recylzpa.FLZFJE,
               null as QTDSFZFJE,
               recylzpa.BHLFY,
               '' as XGDM,
               '0' as zt,
               recylzpa.fpid,
               '' as fdid /*v2.0++*/,
               recylzpa.mpts /*v2.0++ end*/
          from dual;

      -- v1.4.5++ end
      --生成子赔案与发票对照表
      insert into tb_zpaxxdzb
        (XXDZID, --NUMBER(16)                   细项对照ID
         ZPAID, --NUMBER(16)                   子赔案ID
         XXID, --NUMBER(16)                   细项ID
         XXJFLY, --VARCHAR2(4) Y                细项拒付理由
         AJID) --NUMBER(16)                   案件ID
        select seq_XXDZID.nextval as XXDZID,
               v_zpaid as ZPAID,
               a.fpid,
               '' as XXJFLY,
               a.ajid as AJID
          from TB_LPFPXX a
         where a.ajid = to_number(trim(PIN_AJID))
              -- and a.fprq>=recylzpa.bdsxrq and a.fprq<=recylzpa.bdzzrq
           and not exists
         (select 'x' from tb_zpaxxdzb where xxid = a.fpid);
      --更新子赔案用到的所有发票号码,根据细项找不同发票号码，去掉后面个‘，’;
      v_fphm := '';
      for rec in (select distinct a.fphm
                    from TB_LPFPXX   a,
                         tb_zpaxxdzb b,
                         tb_zpaxx    c,
                         tb_fpxxfyxx d
                   where a.fpid = d.fpid
                     and b.xxid = d.xxid
                     and b.zpaid = c.zpaid
                     and c.zpaid = v_zpaid
                  /* and (a.yyid,a.zdlx,nvl(a.ryrq,a.jzrq),c.zddm) in(
                                                                                                                select yyid ,zdlx,nvl(ryrq,jzrq),case when instr(jbdm,c.zddm)>0 then c.zddm else jbdm end from TB_LPFPXX g where g.fpid=c.fpid)
                                                                                                                 group by a.fphm*/
                  ) loop
        v_fphm := substr(v_fphm || rec.fphm || ',', 1, 500);
      end loop;
      --子赔案理算begin
      --取分级理算金额   （本次自付金额+历史自付金额-本次剔除金-历史剔除金）当年度历史赔付金额
      /*
      select sum(nvl(c.zfze,0)+nvl(c.zfyje,0)),sum(nvl(c.bhlfy,0)),sum(nvl(b.sjpfje,0))  into v_lsje,v_bhlje,v_lspfje
      from tb_lpajxx a,tb_zpaxx b ,tb_lpfpxx c
      where a.bxgsid=rec_ajxx.bxgsid
            and a.ajid=b.ajid and b.ajid=c.ajid and a.bbrkhid=rec_ajxx.bbrkhid
            and c.fprq like substr(recylzpa.jsrq,1,4)||'%'
            and (a.ajid=to_number(trim(PIN_AJID)) or a.ajzt in ('08','11'));
      */
      --统计自付金额和不合理金额
      select sum(nvl(b.zfze, 0) + nvl(b.zfyje, 0)), sum(nvl(b.bhlfy, 0))
        into v_lsje, v_bhlje
        from tb_lpajxx a, tb_lpfpxx b
       where a.bxgsid = rec_ajxx.bxgsid
         and a.ajid = b.ajid
         and a.bbrkhid = rec_ajxx.bbrkhid
         and b.fprq like substr(recylzpa.jsrq, 1, 4) || '%'
         and (a.ajid = to_number(trim(PIN_AJID)) or a.ajzt in ('08', '11'));
      --统计历史赔付金额
      select nvl(sum(b.sjpfje), 0)
        into v_lspfje
        from tb_lpajxx a, tb_zpaxx b
       where a.bxgsid = rec_ajxx.bxgsid
         and a.ajid = b.ajid
         and a.bbrkhid = rec_ajxx.bbrkhid
         and a.ajzt in ('08', '11')
         and exists
       (select 1
                from tb_lpfpxx c, tb_zpaxxdzb d
               where c.ajid = a.ajid
                 and c.fpid = d.xxid
                 and d.zpaid = b.zpaid
                 and c.fprq like substr(recylzpa.jsrq, 1, 4) || '%');
      --理算金额基数=本次自付金额+历史自付金额-本次剔除金-历史剔除金=v_lsje-v_bhlje
      
      --统计当前案件的发票总额，自费总额，自负总额，和自费+自负的自付金额
      select sum(nvl(b.zfze, 0) + nvl(b.zfyje, 0))
        into v_zfje
        from tb_lpfpxx b
       where b.ajid = to_number(trim(PIN_AJID));
    
     --如果当前案件自付金额(自费+自负)小于0就直接理算为0；
      if v_zfje < 0 then
        v_sjpfje := 0;
      else
        v_lsje := v_lsje - v_bhlje;
        -- 理算基数按照分级累进方式计算后（+800元）-历史赔付金额=本次大病赔付金额
        /*1） 不足六千元部分，赔付0%
        2）  六千元以上至一万元（含）以内部分，赔付40%；
        3）  一万元以上至两万元（含）以内部分，赔付50%；
        4）  两万元以上至五万元（含）以内部分，赔付60%；
        5）  五万元以上至十万元（含）以内部分，赔付70%；
        6）  十万元以上的部分，赔付80%
        */
        v_sjpfje  := 0;
        v_tempje1 := 0; --级距计算值先初始化
        v_tempje2 := v_lsje; --记录商可用的级距计算金额，没计算一条规则，减去计算额，直到规则循环完毕
        for rec in (select jjqsd, jjjsd, jsbl
                      from V_SZDBFDPFBLPZ
                     where jjqsd < v_lsje
                     order by jjqsd asc) loop
          if (nvl(rec.jjjsd, 0) - nvl(rec.jjqsd, 0)) < v_tempje2 then
            --级距结束段<剩余可理算金额
            v_sjpfje  := v_sjpfje +
                         (nvl(rec.jjjsd, 0) - nvl(rec.jjqsd, 0)) * rec.jsbl / 100;
            v_tempje2 := v_tempje2 -
                         (nvl(rec.jjjsd, 0) - nvl(rec.jjqsd, 0));
          else
            --级距结束段>剩余可理算金额
            v_sjpfje  := v_sjpfje + v_tempje2 * rec.jsbl / 100;
            v_tempje2 := 0;
          end if;
          exit when v_tempje2 <= 0;
        end loop;
        if v_lsje > 6000 then
          v_sjpfje := v_sjpfje + 800 - v_lspfje; --分级计算结果+800元-历史赔付金额=本次大病赔付金额;
        else
          v_sjpfje := v_sjpfje - v_lspfje;
        end if;
        if v_sjpfje < 0 then
          v_sjpfje := 0;
        end if;
      end if;  
      update tb_zpaxx
         set zt       = '1',
             SYFPH    = substr(v_fphm, 1, length(trim(v_fphm)) - 1),
             XLLSPFJE = v_sjpfje,
             sjpfje   = v_sjpfje,
             lssj     = sysdate
       where zpaid = v_zpaid;
    end loop;
    --更新整案赔付金额
    update tb_lpajxx a
       set a.bxcssczpabz = '0',
           a.AJPFJE      = (select sum(nvl(SJPFJE, 0))
                              from tb_zpaxx
                             where ajid = a.ajid
                               and nvl(zpajl, '01') != '02')
     where ajid = rec_ajxx.ajid;
  end if;
  PReturnCode := '0';
  PReturnMsg  := '案件审核处理成功!';

EXCEPTION
  WHEN OTHERS THEN
    PReturnCode := 'E';
    DBMS_OUTPUT.PUT_LINE('[yhs debug] ' || 'PReturncode= ' || PReturnCode);
    PReturnMsg := 'Error:' || sqlerrm;
    DBMS_OUTPUT.PUT_LINE(PReturnMsg);
end SP_P1_OTHERCASECHECK;

/
