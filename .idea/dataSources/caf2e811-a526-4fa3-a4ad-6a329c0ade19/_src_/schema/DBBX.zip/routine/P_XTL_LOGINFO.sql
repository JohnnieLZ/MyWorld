CREATE procedure p_xtl_loginfo(msg varchar2
                                          ) is
  pragma AUTONOMOUS_TRANSACTION;
begin
  insert into t_xtl_errlog values (sys_guid(), msg, sysdate);
  commit;
end;
/
