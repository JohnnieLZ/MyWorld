CREATE FUNCTION      "SF_P1_GET_KHZRLJPFE" (pKhid in number,pZrid in number,pKhbdh in varchar2) return number is
  sumpfje number:=0 ;
BEGIN

   select sum(nvl(sjpfje,0)) into sumpfje from TB_ZPAxx b,TB_lpajxx a where  a.ajid=b.ajid and a.khbdh=pKhbdh
                      and nvl(b.zpajl,'01')!='02' and a.ajzt in('08','09','10','11')
                      and a.BBRKHID=pKhid and b.zrid=pZrid;
 return(sumpfje);

 EXCEPTION
        WHEN OTHERS THEN
        return(sumpfje);
 END SF_P1_GET_KHZRLJPFE;

/
