CREATE procedure      SP_IMPORT_PSNFDZR_OLD(Pin_userid IN varCHAR2 ,PReturnCode OUT varchar2,
                              PReturnMsg    OUT varchar2) AS
  /*
  *@version1.2 update by zhangjunpeng ????????@????????????????????????? 20150630
  *@version1.3 update by zhangjunpeng ??????????????bug?? 20150720
  *@version1.4 update by yhs 20151214???SP_IMPORT_PSNFDZR_1??????SP_IMPORT_PSNFDZR_OLD????????????????optype is null),?????
  ????optype????????????
  ***/
  V_STEP_CODE  VARCHAR2(5):='00000';
  v_start_date number := 0;
  v_end_date   number := 0;
  v_no  number:=0;
  rec_bdxx tb_bdxx%rowtype;
  v_001zd number:=0; --???????????0

   v_zrlxdm varchar2(6):='xxxxxx';
   v_xtxgdm varchar2(60):=''; --??????
   v_zpaid number(16):=-1;
   v_fphm varchar2(400):=''; --?????????????
   v_zpah varchar2(30):='';--????
   v_zrid number(16):=0; -- ?????Id
   v_zddm varchar2(20):='';
   rec_zrxx tb_zrxx%rowtype;
    v_fdid number(16):=0; -- ????????Id
    v_pch number(16):=0;
    v_opcode VARCHAR2(2):= substr(TRIM(Pin_userid),instr(Pin_userid,':')+1,1);
    v_userid VARCHAR2(10):=substr(TRIM(Pin_userid),1,instr(Pin_userid,':')-1);

  begin
    PReturnCode:='E';
    PReturnMsg:='Error!';
    --?????
   -- v1.4begin
     -- ?????  ????optype????????????
    select nvl(count(1),0) into v_no from TB_IMPORT_PSNFDZR a where a.RUN_FLAG is null and op_type is not null;
    if (v_no>0 ) THEN
       PReturnCode:='-1';
       PReturnMsg:='?????????????????????????????????!';
       DBMS_OUTPUT.PUT_LINE(PReturnMsg);
       RETURN;
    end if;
    -- v1.4 end
    --????
    if v_opcode = '0' then
      update TB_IMPORT_PSNFDZR a set a.imp_err_desc = '' where a.RUN_FLAG is null;
    end if;
    select nvl(count(1),0) into v_no from TB_IMPORT_PSNFDZR a where a.RUN_FLAG is null
         and not exists(select 'x' from TB_bdxx where khbdh=a.bdh);
    if (v_no>0 ) THEN
             UPDATE TB_IMPORT_PSNFDZR T SET T.IMP_ERR_DESC = '????????????????????!'
                    WHERE T.ywlsh IN (SELECT A.ywlsh FROM TB_IMPORT_PSNFDZR A WHERE A.RUN_FLAG IS NULL
                          AND NOT EXISTS (SELECT 'x' FROM TB_BDXX WHERE KHBDH = A.BDH));
    end if;
    ---------------------
    select nvl(count(1),0) into v_no from TB_IMPORT_PSNFDZR a where a.RUN_FLAG is null
         and not exists(select 'x' from TB_bdxx b,tb_bddjzrxx c  where khbdh=a.bdh and b.bdid=c.bdid and c.Djmc=a.dj);
    if (v_no >0 ) THEN
            UPDATE TB_IMPORT_PSNFDZR T SET T.IMP_ERR_DESC = '?????????????????????????!'
                   WHERE T.ywlsh IN( select a.ywlsh from TB_IMPORT_PSNFDZR a where a.RUN_FLAG is null
              and not exists(select 'x' from TB_bdxx b,tb_bddjzrxx c  where khbdh=a.bdh and b.bdid=c.bdid and c.Djmc=a.dj));
    end if;
    ---------------------
    select nvl(count(1),0) INTO  v_no from TB_IMPORT_PSNFDZR a where a.RUN_FLAG is null
         and a.zbbrzjhm IS NOT NULL AND NOT EXISTS(select 'x' from TB_IMPORT_PSNFDZR c  where c.zjhm=a.zbbrzjhm)
         and not exists(select 'x' from tb_khxx d where d.aac147 = a.zbbrzjhm and d.xm = a.zbbrxm);  -- +V1.3
    if (v_no >0 ) THEN
            UPDATE TB_IMPORT_PSNFDZR T SET T.IMP_ERR_DESC = '??????????????????????!'
                  /* WHERE T.BDH IN(select a.bdh from TB_IMPORT_PSNFDZR a where a.RUN_FLAG is NULL and a.zbbrzjhm is not null
                and not exists(select 'x' from TB_IMPORT_PSNFDZR c  where c.zjhm=a.zbbrzjhm));*/
                where t.RUN_FLAG is null and t.zbbrzjhm IS NOT NULL AND NOT EXISTS(select 'x' from TB_IMPORT_PSNFDZR c
                where c.zjhm=t.zbbrzjhm)
                and  not exists (select 'x' from tb_khxx d where d.aac147 = t.zbbrzjhm and d.xm = t.zbbrxm); -- +V1.3

    end if;
    ---------------------------
/*    select nvl(count(1),0) into v_no from TB_IMPORT_PSNFDZR where ckr is null and gx!='??';
    if (v_no >0 ) THEN
          UPDATE TB_IMPORT_PSNFDZR T SET T.IMP_ERR_DESC = '???????????????????????????!'
             WHERE T.ywlsh IN(select ywlsh from TB_IMPORT_PSNFDZR where ckr is null and gx!='??');
    end if;*/
    ---------------------------
    select nvl(count(1),0) into v_no from TB_IMPORT_PSNFDZR a where a.RUN_FLAG is null  and zjhm like '%+%';
    if (v_no >0 ) THEN
          UPDATE TB_IMPORT_PSNFDZR T SET T.IMP_ERR_DESC = '???????????!'
             WHERE T.ywlsh IN(select a.ywlsh from TB_IMPORT_PSNFDZR a where a.RUN_FLAG is null  and zjhm like '%+%');
    end if;
    ---------------------------
    SELECT nvl(count(1),0) into v_no  from TB_IMPORT_PSNFDZR a where a.RUN_FLAG is null  and khhzh like '%+%';
    if (v_no >0 ) THEN
          UPDATE TB_IMPORT_PSNFDZR T SET T.IMP_ERR_DESC = '???????????!'
             WHERE T.ywlsh IN(SELECT a.ywlsh from TB_IMPORT_PSNFDZR a
             where a.RUN_FLAG is null  and khhzh like '%+%');
    end if;
    --v1.1.1++  begin ?????????????????
     SELECT nvl(count(1),0) into v_no  from TB_IMPORT_PSNFDZR a where (a.sjsxr is null or a.sjzzr is null ) and  a.RUN_FLAG is null;
    if (v_no >0 ) THEN
          UPDATE TB_IMPORT_PSNFDZR a SET a.IMP_ERR_DESC = '???????????!'
          where  (a.sjsxr is null or a.sjzzr is null ) and  a.RUN_FLAG is null;
    end if;
    SELECT nvl(count(1),0) into v_no  from TB_IMPORT_PSNFDZR a where (a.sjsxr is not null and a.sjzzr is not null) and  a.RUN_FLAG is null
    and not exists(select 'x' from tb_bdxx b where b.khbdh=a.BDH and b.BDZZRQ>=to_char(to_date(a.sjsxr,'yyyy-mm-dd') ,'yyyymmdd') and b.BDSXRQ<=to_char(to_date(a.sjzzr,'yyyy-mm-dd'),'yyyymmdd')) ;
    if (v_no >0 ) THEN
          UPDATE TB_IMPORT_PSNFDZR a SET a.IMP_ERR_DESC = '???????????????????!'
           where  a.RUN_FLAG is null
           and not exists(select 'x' from tb_bdxx b where b.khbdh=a.BDH and b.BDZZRQ>=to_char(to_date(a.sjsxr,'yyyy-mm-dd') ,'yyyymmdd') and b.BDSXRQ<=to_char(to_date(a.sjzzr,'yyyy-mm-dd'),'yyyymmdd') );
    end if;

     UPDATE TB_IMPORT_PSNFDZR a SET a.IMP_ERR_DESC = '???????????????!'
           where  a.RUN_FLAG is null and  a.sjsxr is not null and  a.sjzzr is not null
           and  a.sjsxr >a.sjzzr ;
     --v1.1.1++ end
    --------?????????--------------------
    SELECT nvl(count(1),0) into v_no from TB_IMPORT_PSNFDZR a WHERE a.imp_err_desc IS NOT NULL and a.run_flag is null;

    IF (v_no>0) THEN
       PReturnCode:='-1';
       PReturnMsg:='??????????????'||to_char(v_no)||'?,???????????????!';
       DBMS_OUTPUT.PUT_LINE(PReturnMsg);
       RETURN;
    END IF;
    IF v_opcode='0' AND (v_no=0) THEN
       PReturnCode:='0';
       PReturnMsg:='?????????!';
       RETURN;
    END IF;

    IF v_opcode='1' AND v_no<>0 THEN
       PReturnCode:='1';
       PReturnMsg:='????????????????????!';
    RETURN;
    END IF;
 --------------??-----------------------------------------------
    select to_number(to_char(sysdate,'yyyymmddhh24miss')) into v_pch from dual;
    /***********************************-- +V1.2 start************************************/
 update TB_KHXX t set ( XM, SCZT, XB, CSRQ, SWRQ, ZZBZ,
          ZYDJ, ZYDM, GH, KHYH, ZHMC, YHZH, KHHSZS, KHHSZSHI, FWTT,
          FWTTMC, FWZTTBH, BMBH, BMMC, /*YBBS, YBKH, YBD,*/ GZDJZD, HYZK,
          EMAIL, SJH, YX, XGBZ, BBRTBYD, GZDXZQH, YBDXZQH, JZDXZQH, SFMZZYGYED)=(select
           XM, '0' as sczt,decode( a.XB,'?','1','?','2','9') as xb, TO_NUMBER(to_char(to_date(a.CSRQ,'yyyy-mm-dd'),'yyyymmdd')) as csrq,
           '' as swrq, decode(a.zydm,null,'0','','0','1') as ZZBZ,
          '' ZYDJ, a.ZYDM,
          '' GH,
          a.khh as KHYH, a.ckr as ZHMC, a.khhzh as YHZH, '310000' as KHHSZS,'' as KHHSZSHI,(select ttbh from tb_bdxx where khbdh=a.bdh) as FWTT ,
          (select ttmc from tb_bdxx where khbdh=a.bdh) as FWTTMC, '' as FWZTTBH,A.BMBH,'' as BMMC,/*decode( a.ybbs,'???','02','01') as YBBS,
          decode( a.ybbs,'???',t.ybkh,'') as YBKH,
          A.YBD,*/a.yjdz as GZDJZD, '' as HYZK,
          a.EMAIL,a.phone as SJH,'' as  YX, '' as XGBZ, '' as BBRTBYD,'310000' GZDXZQH,(SELECT c.aab301 FROM AA26 c WHERE C.AAA146 = A.YBD and rownum = 1) as YBDXZQH,'310000' JZDXZQH, '0' as SFMZZYGYED
          FROM TB_IMPORT_PSNFDZR a where a.zjhm=t.aac147  and a.xm =t.xm and decode(a. ZJLX,'???','10','???','09','01')=t.aac058 and run_flag is null and a.ybbs = '@')
         where exists(  select 'x' FROM TB_IMPORT_PSNFDZR a where a.RUN_FLAG is null and
            t.aac147=a.zjhm and t.xm=a.xm and t.aac058=decode(a. ZJLX,'???','10','???','09','01') and a.ybbs = '@'
         );
     v_no:=SQL%rowcount;
    dbms_output.put_line('????????'||     to_char(v_no));
    --??????,?????????????
    INSERT INTO TB_KHXX(
              KHID, KHBH, XM, AAC058, AAC147, SCZT, XB, CSRQ, SWRQ, ZZBZ,
          ZYDJ, ZYDM, GH, KHYH, ZHMC, YHZH, KHHSZS, KHHSZSHI, FWTT,
          FWTTMC, FWZTTBH, BMBH, BMMC, /*YBBS, YBKH, YBD,*/ GZDJZD, HYZK,
          EMAIL, SJH, YX, XGBZ, BBRTBYD, GZDXZQH, YBDXZQH, JZDXZQH, SFMZZYGYED)
        SELECT
          seq_khid.nextval as khid, 'xxxxxx' as khbh, XM,decode(a. ZJLX,'???','10','???','09','01') as aac058, ZJHM, '0' as sczt,decode( a.XB,'?','1','?','2','9') as xb, TO_NUMBER(to_char(to_date(a.CSRQ,'yyyy-mm-dd'),'yyyymmdd')) as csrq,
           '' as swrq, decode(a.zydm,null,'0','','0','1') as ZZBZ,
          '' ZYDJ, a.ZYDM,
          '' GH,
          a.khh as KHYH, a.ckr as ZHMC, a.khhzh as YHZH, '310000' as KHHSZS,'' as KHHSZSHI,(select ttbh from tb_bdxx where khbdh=a.bdh) as FWTT ,
          (select ttmc from tb_bdxx where khbdh=a.bdh) as FWTTMC, '' as FWZTTBH, A.BMBH,'' as BMMC,/*decode( a.ybbs,'???','02','01') as YBBS,'???????' as YBKH,
          A.YBD,*/a.yjdz as GZDJZD, '' as HYZK,
          a.EMAIL,a.phone as SJH,'' as  YX, '' as XGBZ, '' as BBRTBYD,'310000' GZDXZQH,(SELECT c.aab301 FROM AA26 c WHERE C.AAA146 = A.YBD and rownum = 1) as YBDXZQH,'310000' JZDXZQH, '0' as SFMZZYGYED
          FROM TB_IMPORT_PSNFDZR a
           WHERE a.RUN_FLAG is null and not exists(select 'x' from TB_KHXX where aac147=a.zjhm and xm=a.xm and aac058=decode(a. ZJLX,'???','10','???','09','01') ) and a.ybbs = '@';
           v_no:=SQL%rowcount;
    dbms_output.put_line('????????'||     to_char(v_no));

    /***********************************-- +V1.2 end**************************************/
    --???????????
    update TB_KHXX t set ( XM, SCZT, XB, CSRQ, SWRQ, ZZBZ,
          ZYDJ, ZYDM, GH, KHYH, ZHMC, YHZH, KHHSZS, KHHSZSHI, FWTT,
          FWTTMC, FWZTTBH, BMBH, BMMC, YBBS, YBKH, YBD, GZDJZD, HYZK,
          EMAIL, SJH, YX, XGBZ, BBRTBYD, GZDXZQH, YBDXZQH, JZDXZQH, SFMZZYGYED)=(select
           XM, '0' as sczt,decode( a.XB,'?','1','?','2','9') as xb, TO_NUMBER(to_char(to_date(a.CSRQ,'yyyy-mm-dd'),'yyyymmdd')) as csrq,
           '' as swrq, decode(a.zydm,null,'0','','0','1') as ZZBZ,
          '' ZYDJ, a.ZYDM,
          '' GH,
          a.khh as KHYH, a.ckr as ZHMC, a.khhzh as YHZH, '310000' as KHHSZS,'' as KHHSZSHI,(select ttbh from tb_bdxx where khbdh=a.bdh) as FWTT ,
          (select ttmc from tb_bdxx where khbdh=a.bdh) as FWTTMC, '' as FWZTTBH,A.BMBH,'' as BMMC,decode( a.ybbs,'???','02','01') as YBBS,
          decode( a.ybbs,'???',t.ybkh,'') as YBKH,
          A.YBD,a.yjdz as GZDJZD, '' as HYZK,
          a.EMAIL,a.phone as SJH,'' as  YX, '' as XGBZ, '' as BBRTBYD,'310000' GZDXZQH,(SELECT c.aab301 FROM AA26 c WHERE C.AAA146 = A.YBD and rownum = 1) as YBDXZQH,'310000' JZDXZQH, '0' as SFMZZYGYED
          FROM TB_IMPORT_PSNFDZR a where a.zjhm =t.aac147  and a.xm = t.xm and decode(a. ZJLX,'???','10','???','09','01')=t.aac058 and run_flag is null  and nvl(a.ybbs,'XX') <> '@' /*-- + V1.2*/)
         where exists(  select 'x' FROM TB_IMPORT_PSNFDZR a where a.RUN_FLAG is null and
            a.zjhm =t.aac147  and a.xm = t.xm  and t.aac058=decode(a. ZJLX,'???','10','???','09','01')  and nvl(a.ybbs,'XX') <> '@' /*-- + V1.2*/
         );
     v_no:=SQL%rowcount;
    dbms_output.put_line('????????'||     to_char(v_no));
    --??????,?????????????
    INSERT INTO TB_KHXX(
              KHID, KHBH, XM, AAC058, AAC147, SCZT, XB, CSRQ, SWRQ, ZZBZ,
          ZYDJ, ZYDM, GH, KHYH, ZHMC, YHZH, KHHSZS, KHHSZSHI, FWTT,
          FWTTMC, FWZTTBH, BMBH, BMMC, YBBS, YBKH, YBD, GZDJZD, HYZK,
          EMAIL, SJH, YX, XGBZ, BBRTBYD, GZDXZQH, YBDXZQH, JZDXZQH, SFMZZYGYED)
        SELECT
          seq_khid.nextval as khid, 'xxxxxx' as khbh, XM,decode(a. ZJLX,'???','10','???','09','01') as aac058, ZJHM, '0' as sczt,decode( a.XB,'?','1','?','2','9') as xb, TO_NUMBER(to_char(to_date(a.CSRQ,'yyyy-mm-dd'),'yyyymmdd')) as csrq,
           '' as swrq, decode(a.zydm,null,'0','','0','1') as ZZBZ,
          '' ZYDJ, a.ZYDM,
          '' GH,
          a.khh as KHYH, a.ckr as ZHMC, a.khhzh as YHZH, '310000' as KHHSZS,'' as KHHSZSHI,(select ttbh from tb_bdxx where khbdh=a.bdh) as FWTT ,
          (select ttmc from tb_bdxx where khbdh=a.bdh) as FWTTMC, '' as FWZTTBH, A.BMBH,'' as BMMC,decode( a.ybbs,'???','02','01') as YBBS,'???????' as YBKH,
          A.YBD,a.yjdz as GZDJZD, '' as HYZK,
          a.EMAIL,a.phone as SJH,'' as  YX, '' as XGBZ, '' as BBRTBYD,'' GZDXZQH,(SELECT c.aab301 FROM AA26 c WHERE C.AAA146 = A.YBD and rownum = 1) as YBDXZQH,'' JZDXZQH, '0' as SFMZZYGYED
          FROM TB_IMPORT_PSNFDZR a
           WHERE a.RUN_FLAG is null and not exists(select 'x' from TB_KHXX where a.zjhm =aac147  and a.xm = xm  and aac058=decode(a. ZJLX,'???','10','???','09','01') ) and nvl(a.ybbs,'XX') <> '@'/*-- + V1.2*/;
           v_no:=SQL%rowcount;
    dbms_output.put_line('????????'||     to_char(v_no));
    update TB_KHXX set khbh=to_char(khid),seqlogid=v_pch where khbh='xxxxxx' ;
    --??????

           --???????????
       update TB_FDXX a set (fdsxr,fdzzr,TCRQ)=(select  nvl(to_char(to_date(n.SJSXR,'yyyy-mm-dd'),'yyyymmdd') ,a.fdsxr) as FDSXR,
          nvl(to_char(to_date(n.SJZZR,'yyyy-mm-dd'),'yyyymmdd'),a.fdzzr) as FDZZR,case when to_char(to_date(n.SJZZR,'yyyy-mm-dd'),'yyyymmdd')<=a.fdzzr then  to_char(to_date(n.SJZZR,'yyyy-mm-dd'),'yyyymmdd') else null end as tcrq  from  TB_IMPORT_PSNFDZR n,tb_khxx b
         where a.bbrkhid=b.khid and n.RUN_FLAG is null  and a.khbdh=n.bdh
         and n.zjhm=b.aac147 and n.xm=b.xm )
         , seqlogid=v_pch     --20150422 ??seqlogid??????????????????
          where a.khbdh in(
            select khbdh  from  TB_IMPORT_PSNFDZR n where n.RUN_FLAG is null) and  exists(
       select 'x' from  TB_IMPORT_PSNFDZR n,tb_khxx b
         where a.bbrkhid=b.khid and n.RUN_FLAG is null  and a.khbdh=n.bdh
         and n.zjhm=b.aac147 and n.xm=b.xm );
         v_no:=SQL%rowcount;
         dbms_output.put_line('????????'||to_char(v_no));
         --?????????????
    select count(1) into v_no from tb_fdxx where khbdh in(select bdh from TB_IMPORT_PSNFDZR a WHERE a.RUN_FLAG is null);
     INSERT INTO TB_FDXX(
            FDID, TTID, KHBDH, TBDH, FDH,
          FDSXR, FDZZR, FDZT, FDZBF, BBRKHID,
          BBRNL, ZYLB, ZYDM, ZTTID, DJ,
          GZDXZQH, BBRDZID, BBRDZXX,
          ZLDBZ, ZBBRGX, ZBBRKHID, ZBBRFDH,
          FDZS1, FDZS2, DJID,
          YBDXZQH, JZDQH,Cjrq,Bdid,WBBDH,seqlogid)
        SELECT
          seq_Fdid.nextval as fdid, rec_bdxx.TTID, rec_bdxx.KHBDH, rec_bdxx.TBDH,
          rec_bdxx.KHBDH|| trim(to_char(v_no+rownum,'099999')) as fdh,
          nvl(to_char(to_date(a.SJSXR,'yyyy-mm-dd'),'yyyymmdd') ,rec_bdxx.BDSXRQ) as FDSXR,
          nvl(to_char(to_date(a.SJZZR,'yyyy-mm-dd'),'yyyymmdd'),rec_bdxx.BDZZRQ) as FDZZR,
          '1' as fdzt,'' fdzbf,
          b.khid as BbrKhid,
          trunc(trunc(to_date(rec_bdxx.BDSXRQ,'yyyymmdd')-to_date(b.CSRQ, 'yyyymmdd'))/365) as BBRNL ,
           '' ZYLB, b.ZYDM,
          rec_bdxx.ZTTID,
           nvl((SELECT DJBH FROM TB_BDDJXX WHERE BDID = rec_bdxx.BDID AND DJMC = a.DJ),a.dj) DJ,
          b.GZDXZQH,
          (SELECT max(T.DZID) FROM TB_KHDZXX T WHERE  T.KHID = b.KHID AND  T.YXZT = '0') DZID ,(select max(DZID) FROM TB_KHDZXX  WHERE  KHID = b.KHID AND  YXZT = '0' ) as jtdz,
         case when nvl(a.GX,'??')!='??' and a.ZBBRZJHM is not null then '1' else '0' end as ZLDBZ,
         case when nvl(a.GX,'??')!='??' and a.ZBBRZJHM is not null then  decode(a.gx,'??','00','??','01','??','03','99') else ''end as ZBBRGX,
         case when nvl(a.GX,'??')!='??' and a.ZBBRZJHM is not null then (select to_char(max(khid)) from tb_khxx  where aac147=a.ZBBRZJHM) else '' end as ZBBRKHID ,
         '' Zbbrfdh ,
        '' FDZS1, '' FDZS2,
        (SELECT DJID FROM TB_BDDJXX WHERE BDID = rec_bdxx.BDID AND DJMC = a.DJ ),
          b.YBDXZQH, b.JZDXZQH,
          to_number(to_char(SYSDATE,'yyyymmdd')) as Cjrq,rec_bdxx.BDID,'' wbbdh,v_pch as seqlogid
        FROM TB_BDXX rec_bdxx , TB_IMPORT_PSNFDZR a,tb_khxx b where a.bdh=rec_bdxx.khbdh
        and b.aac147=a.zjhm and b.xm=a.xm and b.aac058=decode(a. ZJLX,'???','10','???','09','01')
        and a.RUN_FLAG is null and not exists(
       select 'x' from tb_fdxx n where n.bbrkhid=b.khid and n.bdid=rec_bdxx.bdid and fdzt='1');
        v_no:=SQL%rowcount;
       dbms_output.put_line('????????'||     to_char(v_no));



       --??????
        INSERT INTO TB_FDZRMX(
          FDZRID, FDID, ZRXH, ZRID,
          BELX, BEDW, GMFSHYS, ZRBE,
          ZRBF, ZRBZBF, ZRFJF, ZRLJPFE, ZRLJMPE,
          ZRKSRQ, ZRJSRQ, YXBS, ZDBE, ZGBE,SEQLOGID)
        SELECT
          TO_NUMBER(SEQ_FDZRID.NEXTVAL), e.fdid, rownum, A.ZRID,
          B.BELX, B.BEDW, DECODE(A.BE, '', '', TRUNC(A.BE/B.BEDW)), A.BE,
          A.BF, NULL, NULL, NULL, NULL,
          NULL, NULL, A.YXBS, A.ZDBE, A.ZGBE,v_pch as seqlogid
        FROM TB_BDDJZRXX A, TB_ZRXX B,tb_fdxx e
        WHERE A.BDID = e.bdid
        and e.Cjrq=to_number(to_char(SYSDATE,'yyyymmdd'))
        and e.khbdh in(select bdh from TB_IMPORT_PSNFDZR a where a.RUN_FLAG is null)
        AND A.DJID = e.Djid
        AND A.ZRID = B.ZRID
        and not exists(select 'x' from TB_FDZRMX where fdid=e.fdid);
          v_no:=SQL%rowcount;
         dbms_output.put_line('??????????'|| to_char(v_no));
         --??????????????????4?????,20150422 ???????( and t.tcrq is null )???????
            update TB_FDZRMX a set (zrbe,zrbf)=(select b.zr1be,b.zr1bf FROM TB_IMPORT_PSNFDZR b,TB_KHXX c,TB_FDXX t,tb_zrxx m
              where b.RUN_FLAG is null and b.zr1dm is not null and b.bdh=t.khbdh
              and    c.aac147||c.xm=b.zjhm||b.xm and c.aac058=decode(b. ZJLX,'???','10','???','09','01') and t.bbrkhid=c.khid
              and t.cjrq=to_char(sysdate,'yyyymmdd') and t.fdid=a.fdid and b.zr1dm=m.zrbm and m.zrid=a.zrid)
               where exists(select b.zr3be,b.zr3bf FROM TB_IMPORT_PSNFDZR b,TB_KHXX c,TB_FDXX t,tb_zrxx m   where b.RUN_FLAG is null and b.zr1dm is not null and b.bdh=t.khbdh
               and    c.aac147=b.zjhm and c.xm=b.xm  and c.aac058=decode(b. ZJLX,'???','10','???','09','01') and t.bbrkhid=c.khid
              and t.cjrq=to_char(sysdate,'yyyymmdd') and t.fdid=a.fdid and b.zr1dm=m.zrbm and m.zrid=a.zrid and t.tcrq is null) and seqlogid=v_pch;

           update TB_FDZRMX a set (zrbe,zrbf)=(select b.zr2be,b.zr2bf FROM TB_IMPORT_PSNFDZR b,TB_KHXX c,TB_FDXX t,tb_zrxx m   where b.RUN_FLAG is null and b.zr2dm is not null and b.bdh=t.khbdh
              and    c.aac147||c.xm=b.zjhm||b.xm and c.aac058=decode(b. ZJLX,'???','10','???','09','01') and t.bbrkhid=c.khid
              and t.cjrq=to_char(sysdate,'yyyymmdd') and t.fdid=a.fdid and b.zr2dm=m.zrbm and m.zrid=a.zrid)   where exists(select b.zr3be,b.zr3bf FROM TB_IMPORT_PSNFDZR b,TB_KHXX c,TB_FDXX t,tb_zrxx m
               where b.RUN_FLAG is null and b.zr2dm is not null and b.bdh=t.khbdh
              and    c.aac147=b.zjhm and c.xm=b.xm  and c.aac058=decode(b. ZJLX,'???','10','???','09','01') and t.bbrkhid=c.khid
              and t.cjrq=to_char(sysdate,'yyyymmdd') and t.fdid=a.fdid and b.zr2dm=m.zrbm and m.zrid=a.zrid and t.tcrq is null) and seqlogid=v_pch;

              update TB_FDZRMX a set (zrbe,zrbf)=(select b.zr3be,b.zr3bf FROM TB_IMPORT_PSNFDZR b,TB_KHXX c,TB_FDXX t,tb_zrxx m   where b.RUN_FLAG is null and b.zr3dm is not null and b.bdh=t.khbdh
               and    c.aac147=b.zjhm and c.xm=b.xm  and c.aac058=decode(b. ZJLX,'???','10','???','09','01') and t.bbrkhid=c.khid
              and t.cjrq=to_char(sysdate,'yyyymmdd') and t.fdid=a.fdid and b.zr3dm=m.zrbm and m.zrid=a.zrid and t.tcrq is null)   where exists(select b.zr3be,b.zr3bf FROM TB_IMPORT_PSNFDZR b,TB_KHXX c,TB_FDXX t,tb_zrxx m
              where b.RUN_FLAG is null and b.zr3dm is not null and b.bdh=t.khbdh
              and    c.aac147=b.zjhm and c.xm=b.xm  and c.aac058=decode(b. ZJLX,'???','10','???','09','01') and t.bbrkhid=c.khid
              and t.cjrq=to_char(sysdate,'yyyymmdd') and t.fdid=a.fdid and b.zr3dm=m.zrbm and m.zrid=a.zrid and t.tcrq is null) and seqlogid=v_pch;

              update TB_FDZRMX a set (zrbe,zrbf)=(select b.zr4be,b.zr4bf FROM TB_IMPORT_PSNFDZR b,TB_KHXX c,TB_FDXX t,tb_zrxx m   where b.RUN_FLAG is null and b.zr4dm is not null and b.bdh=t.khbdh
               and    c.aac147=b.zjhm and c.xm=b.xm  and c.aac058=decode(b. ZJLX,'???','10','???','09','01') and t.bbrkhid=c.khid
              and t.cjrq=to_char(sysdate,'yyyymmdd') and t.fdid=a.fdid and b.zr4dm=m.zrbm and m.zrid=a.zrid)   where exists(select b.zr3be,b.zr3bf FROM TB_IMPORT_PSNFDZR b,TB_KHXX c,TB_FDXX t,tb_zrxx m
              where b.RUN_FLAG is null and b.zr4dm is not null and b.bdh=t.khbdh
               and    c.aac147=b.zjhm and c.xm=b.xm  and c.aac058=decode(b. ZJLX,'???','10','???','09','01') and t.bbrkhid=c.khid
              and t.cjrq=to_char(sysdate,'yyyymmdd') and t.fdid=a.fdid and b.zr4dm=m.zrbm and m.zrid=a.zrid and t.tcrq is null) and seqlogid=v_pch;
         --20150422 yhs ??????????????????????.??? fesco???????????????????
         update TB_FDZRMX a set (a.zrbf,a.zrksrq,a.ZRJSRQ)=(select case when  a.zrbf-(case when b.zr4dm=m.zrbm then to_number(nvl(b.zr4bf,'0')) else 0 end+case when b.zr3dm=m.zrbm then to_number(nvl(b.zr3bf,'0')) else 0 end
                                                                             +case when b.zr2dm=m.zrbm then to_number(nvl(b.zr2bf,'0')) else 0 end+case when b.zr1dm=m.zrbm then to_number(nvl(b.zr1bf,'0')) else 0 end)<=0 then 0
                                                               else a.zrbf-(case when b.zr4dm=m.zrbm then to_number(nvl(b.zr4bf,'0')) else 0 end+case when b.zr3dm=m.zrbm then to_number(nvl(b.zr3bf,'0')) else 0 end
                                                                             +case when b.zr2dm=m.zrbm then to_number(nvl(b.zr2bf,'0')) else 0 end+case when b.zr1dm=m.zrbm then to_number(nvl(b.zr1bf,'0')) else 0 end)
                                                          end ,t.fdsxr,t.fdzzr  as fdzzr
                                                      FROM TB_IMPORT_PSNFDZR b,TB_KHXX c,TB_FDXX t,tb_zrxx m
               where b.RUN_FLAG is null  and b.bdh=t.khbdh
               and    c.aac147=b.zjhm and c.xm=b.xm  and c.aac058=decode(b. ZJLX,'???','10','???','09','01') and t.bbrkhid=c.khid
             /* and t.cjrq=to_char(sysdate,'yyyymmdd')*/ and t.fdid=a.fdid  and m.zrid=a.zrid and t.tcrq is not null and t.seqlogid=v_pch)
              where exists(select b.zr3be,b.zr3bf FROM TB_IMPORT_PSNFDZR b,TB_KHXX c,TB_FDXX t,tb_zrxx m
                    where b.RUN_FLAG is null  and b.bdh=t.khbdh
                     and    c.aac147=b.zjhm and c.xm=b.xm  and c.aac058=decode(b. ZJLX,'???','10','???','09','01') and t.bbrkhid=c.khid
                   /* and t.cjrq=to_char(sysdate,'yyyymmdd')*/ and t.fdid=a.fdid and (b.zr4dm=m.zrbm or b.zr3dm=m.zrbm or b.zr2dm=m.zrbm or b.zr1dm=m.zrbm)
                     and m.zrid=a.zrid and t.tcrq is not null and t.ttid=1301 and t.seqlogid=v_pch);



         --???????
         update   TB_FDXX t set t.fdzbf=(select nvl(sum(nvl(zrbf,0)),0) from tb_fdzrmx h where h.fdid=t.fdid) where t.khbdh in(select bdh from TB_IMPORT_PSNFDZR b where b.RUN_FLAG  is null) and (cjrq=to_char(sysdate,'yyyymmdd') or  t.seqlogid=v_pch) ;

         --???????
         update   TB_bDXX t set t.bf=(select nvl(sum(nvl(fdzbf,0)),0) from tb_fdxx h where h.khbdh=t.khbdh) where t.khbdh in(select bdh from TB_IMPORT_PSNFDZR b where b.RUN_FLAG  is null) ;


      --?????????????
       update    TB_IMPORT_PSNFDZR a  set a.run_flag='1',DO_DATE=sysdate where a.RUN_FLAG is null;

        --????????????? TB_KHXX.bgsj
         update TB_KHXX a set bgsj=(select max(fdsxr) from tb_fdxx where bbrkhid=a.khid ),czsj=sysdate where khid in(select bbrkhid from  TB_FDXX t
           where  t.khbdh in(select bdh from TB_IMPORT_PSNFDZR b where b.RUN_FLAG ='1' and do_date>=to_date(to_char(sysdate,'yyyymmdd'),'yyyy-mm-dd') and nvl(b.ybbs,'XX') <> '@' /**-- +1.2***/
           ) and t.cjrq=to_char(sysdate,'yyyymmdd'));

          v_no:=SQL%rowcount;
         dbms_output.put_line('?????????'|| to_char(v_no));
    PReturnCode:='0';
    PReturnMsg:='????????!';
    EXCEPTION
  WHEN OTHERS THEN
    PReturnCode := 'E';
    DBMS_OUTPUT.PUT_LINE('[yhs debug] ' || 'PReturncode= ' ||
                         PReturnCode);
    PReturnMsg := 'Error:' || sqlerrm;
    DBMS_OUTPUT.PUT_LINE(PReturnMsg);
  end   SP_IMPORT_PSNFDZR_OLD;

/
