CREATE function      FUNC_YBNPFJE_NDLJ_KHID(P_KHID in number) return number is
  Result number;
  vResult number;
  CURSOR v_ajids is select ajid from tb_lpajxx where bbrkhid=P_KHID and  SUBSTR(JARQ,1,4) = TO_CHAR(SYSDATE,'YYYY') and ajzt='11';
begin
  for v_ajid in v_ajids loop
    select nvl((select SUM(T.PFE) FROM TB_ZPALSGZDZB T ,TB_BDZRLSGZSZ N,TB_ZPAXX S WHERE T.LSGZID=N.LSGZID AND LSGZJB='1'
            AND N.FYLB NOT IN ('S','F') AND T.ZPAID=S.ZPAID AND S.AJID=v_ajid.ajid AND S.ZPAJL<>'02'
            and t.lsgzid not in (select f.lsgzid from TB_DBLSGZEJYYJDZ f,TB_BDZRLSGZSZ k,TB_ZPALSGZDZB h,TB_ZPAXX z,(select t.lsgzid FROM TB_ZPALSGZDZB T ,TB_ZPAXX S WHERE T.LSGZJB='2'
            AND T.ZPAID=S.ZPAID AND S.AJID=v_ajid.ajid AND S.ZPAJL<>'02') g where f.ejlsgzid=g.lsgzid and k.lsgzid=f.lsgzid and h.lsgzid=k.lsgzid and z.zpaid=h.zpaid and h.lsgzjb='1' and k.fylb not in ('S','F') and z.ajid=v_ajid.ajid)),0)
            +
            nvl((select sum(l.pfe) from TB_ZPALSGZDZB l,
             (select h.lsgzid,h.zpaid from TB_DBLSGZEJYYJDZ f,TB_BDZRLSGZSZ k,TB_ZPALSGZDZB h,TB_ZPAXX z,tb_bdzrejlsgzsz g where f.lsgzid=k.lsgzid and f.ejlsgzid=g.ejlsgzid
            and h.zpaid=z.zpaid and h.lsgzid=g.ejlsgzid and h.lsgzjb='2' and k.fylb not in ('S','F') and z.zpajl<>'02' and z.ajid=v_ajid.ajid group by h.lsgzid,h.zpaid) v
            where l.lsgzid=v.lsgzid and l.zpaid=v.zpaid),0) into Result from dual;
     Result := Result+vResult;
  end loop;
  return(Result);
end FUNC_YBNPFJE_NDLJ_KHID;

/
