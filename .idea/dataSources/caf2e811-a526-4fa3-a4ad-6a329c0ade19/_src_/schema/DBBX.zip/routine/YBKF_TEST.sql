CREATE PROCEDURE        "YBKF_TEST"

AS

  row_khxx tb_khxx%rowtype
  /
