CREATE procedure SP_P1_COMPUTESUBCASE(PIN_ZPAID IN varCHAR2,Pin_userid IN varCHAR2 ,Pin_flag IN varCHAR2 , PReturnCode OUT varchar2,
                              PReturnMsg    OUT varchar2) AS
  V_STEP_CODE  VARCHAR2(5):='00000';
  v_start_date number := 0;
  v_end_date   number := 0;
  v_no  number:=0;
  rec_zpaxx tb_zpaxx%rowtype; --案件信息
  v_001zd number:=0; --是否不确定诊断，缺省为0
  v_mpe  Number(16,2):=0;--免赔额变量
  v_bdid Number(16):=0;--保单ID变量
   v_zrlxdm varchar2(6):='xxxxxx';
   v_xtxgdm varchar2(100):=''; --系统悬挂代码
   v_xgdmsm  varchar2(1024):='';--悬挂代码描述
   rec_bdxx tb_bdxx%rowtype;--保单信息记录集合
   rec_ajxx tb_lpajxx%rowtype;
   rec_fpxx tb_lpfpxx%rowtype;
   Rec_Fpxxfyxx Tb_Fpxxfyxx%rowtype; --发票细项费用记录集合
   v_zyts number(10):=0; --住院天数
   v_zdlx varchar2(2):='';
   v_sql varchar2(2048):=''; --动态sql语句变量
   v_sbbdx varchar2(1):='';
   v_dsfbdx varchar2(1):='';
   v_bdxbz varchar2(1):='';--0 都不比大小 1 按社保支付比大小 2 按第三方支付比大小
   TYPE c1 IS REF CURSOR;
   v_Cur  c1;
   v_jsqmpe number(16,4):=0; --计算前免赔额
   v_jsqxe number(16,4):=0; --计算前累计额
   v_jshmpe number(16,4):=0;--计算后免赔赔额
   v_tempje number(16,4):=0;--临时金额变量
   v_tempje1 number(16,4):=0;--临时金额变量1
   v_tempje2 number(16,4):=0;--临时金额变量1
   v_pfje number(16,4):=0.00; --每笔细项账单赔付金额
   v_lsje  number(16,4):=0;--单条对则可理算金额
   v_bdxzfje  number(16,2):=0;--比大小计算时对应的1级配置赔付总和
  -- rec_bdxpz tb_bdzrbdxlsgzsz%rowtype;--保单责任比大小配置记录
 --  rec_jtlsgzpz TB_BDZRFYLLSGZPZ%rowtype;
   rec_fdzrmx tb_fdzrmx%rowtype;
   v_temp1 number:=0;--临时天数变量
   v_mpts number:=0;--免赔天数变量
   v_jjlb varchar2(1):='1';--缺省按金额计算级距
   v_xelx varchar2(1):='x';--限额类型
   rec_zrxx tb_zrxx%rowtype;
   v_oszn varchar2(1):='0';--欧尚子女上海医院结算 1 是 2 欧尚子女非上海就诊 0 不是欧尚子女相关责任理算
   v_sbjsbl number(6,2):=0.00;--社保结算比例
   v_bxbl number(10,4):=0.0000;--v1.5++报销比例
  begin
    PReturnCode:='E';
    PReturnMsg:='Error!';
    --业务处理块
    if (PIN_zpaid is null ) then
      PReturnCode:='-1';
      PReturnMsg:='参数输入错误!';
      return;
    end if;
    select * into rec_zpaxx from tb_zpaxx where zpaid=to_number(trim(PIN_ZPAID));
    select * into rec_ajxx from tb_lpajxx where  ajid =(select ajid from tb_zpaxx where zpaid=to_number(trim(PIN_ZPAID)));

         /*清空账单对照信息及之前赔付信息 重新计算*/
         update TB_ZPAXXDZB a set HLHFLPFJE=null,HLBHFLPFJE=null,ZFFYPFJE=null,HLHFLLSGZID=null,HLBHFLLSGZID=null,ZFFYLSGZID=null,FLZFLSGZID=null,
           SYMPE=null,XXLSJE=null,XXPFJE=null,FLZFPFJE=null
            where a.zpaid=to_number(trim(PIN_ZPAID));
         /*情况子赔案理算规则对照*/
         update tb_lpfpxx a set pfje=null,FDBFY=null,bhlfy=(select sum(case when nvl(z.bhlje,0)=0 then z.zdje else z.bhlje end )  from tb_fpxxfyxx z where z.fpid=a.fpid) where a.fpid in(select xxid from tb_zpaxxdzb where zpaid=to_number(trim(PIN_ZPAID)));

         delete from TB_ZPALSGZDZB where zpaid=to_number(trim(PIN_ZPAID));
         select * into rec_fpxx from tb_lpfpxx where fpid=rec_zpaxx.fpid;
         select zdlx into v_zdlx from tb_lpfpxx where fpid=rec_zpaxx.fpid;
        --对该保单、责任的一级理算规则从小到大顺序进行循环扫描，依次计算赔付金额
        v_lsje:=0;
      --逐张发票理算
           for rec_xx in( select h.* from tb_lpfpxx h where h.fpid in(select xxid from tb_zpaxxdzb where zpaid=to_number(trim(PIN_ZPAID))) order by h.fpid asc ) loop
             --1 计算大病费用  其中非大病费用需进行区分，若存在红会金额，则非大病费用 = 剔除费用 *（医院比例）。
             --医院比例按照医院的不同，以及账单类型的不同存在不同的比例。
             if nvl(rec_xx.cdeje,0)>0 then   --判断存在红会支付金额
                --根据结算日期年度和医院等级获取剔除费用比例，数据配置在aa10的YYDJBXBL字典中
                 select to_number(aaa103) into v_sbjsbl from aa10 k where aaa100='YYDJBXBL' and k.aae030<=rec_xx.FPRQ and k.aae031>=rec_xx.FPRQ and substr(k.aaa102,length(k.aaa102) - 1,2)=(select jb||rec_xx.zdlx from tb_yyxx where yyid=rec_xx.yyid);
                  rec_xx.FDBFY:= rec_xx.bhlfy*v_sbjsbl/100;
             else   --不存在红会支付金额
                  rec_xx.FDBFY:=  rec_xx.bhlfy    ;
             end if;
             --v1.5++begin
              select nvl(to_number(aaa103),50.00)/100 into v_bxbl from aa10 where aaa100='DBBXBXBLSZ' and rec_xx.fprq>= aae030 and rec_xx.fprq<=aae031; 
             --v1.5 end
             --2 计算发票赔付金额 理赔金额 = 【（发票总金额 — 自费 —分类自负 — 非大病费用）/ （发票总金额 — 自费 — 分类自负）】* （发票总金额 — 自费 — 分类自负 — 统筹 — 红会 —其他补助）* 50%
             v_bdxzfje:=nvl(rec_xx.tczfe,0)+ nvl(rec_xx.fjzfe,0)+nvl(rec_xx.SBZFE,0) ;--统筹支付总额
             --/*v1.2++begin*/
            if abs(nvl(rec_xx.fpze,0)-nvl(rec_xx.zfze,0)-nvl(rec_xx.flzfze,0))<0.00099 then
            	  rec_xx.pfje:=0;
            else	    /*v1.2++end*/ 
              rec_xx.pfje:=round(round((nvl(rec_xx.fpze,0)-nvl(rec_xx.zfze,0)-nvl(rec_xx.flzfze,0)-nvl(rec_xx.FDBFY,0))/(1.0000*(nvl(rec_xx.fpze,0)-nvl(rec_xx.zfze,0)-nvl(rec_xx.flzfze,0))),4)*(nvl(rec_xx.fpze,0)-nvl(rec_xx.zfze,0)-nvl(rec_xx.flzfze,0)-v_bdxzfje-nvl(rec_xx.cdeje,0)-nvl(rec_xx.DSFZFJE,0))*/*v1.5--0.5000*//*v1.5++*/v_bxbl/*v1.5++*/,2);
            end if; --v1.2++
         
             update tb_lpfpxx set FDBFY=rec_xx.FDBFY,pfje= decode(sign(rec_xx.pfje),1,rec_xx.pfje,0) where fpid= rec_xx.fpid;

             --更新TB_ZPAXXDZB 发票赔付情况
             update TB_ZPAXXDZB set XXPFJE=rec_xx.pfje where zpaid= rec_zpaxx.zpaid and xxid=rec_xx.fpid;

           end loop;
           --3 更新子赔案赔付情况
                --将理算结果更新到子赔案begin
        update tb_zpaxx a set a.XLLSPFJE=nvl((select sum(nvl(b.pfje,0)) from tb_lpfpxx b where b.fpid in (select xxid from tb_zpaxxdzb where zpaid=to_number(trim(PIN_ZPAID)))),0),
              a.lssj=sysdate where a.zpaid= to_number(trim(PIN_ZPAID));

         update tb_zpaxx a set a.sjpfje=nvl(a.XLLSPFJE,0)-nvl(a.rgtzje,0) where a.zpaid= to_number(trim(PIN_ZPAID));

     --v1.9拒赔的子赔案，实际赔付金额都按0计算 20160307
     update tb_zpaxx set sjpfje=0 where  ajid=rec_zpaxx.ajid and zpaid= to_number(trim(PIN_ZPAID)) and zpajl='02' and sjpfje>0; --v1.9++
     --拒赔的子赔案，所有发票赔付金额都为0
    -- update tb_lpfpxx b set pfje=0 where fpid in(select xxid from tb_zpaxxdzb x,tb_zpaxx y where y.zpaid=x.zpaid and y.zpaid= to_number(trim(PIN_ZPAID)) and zpajl='02'   ) and  ajid=rec_zpaxx.ajid ;
     --计算完毕后更新整案赔付金额
     update tb_lpajxx a set  a.AJPFJE=(select sum(nvl(SJPFJE,0)) from tb_zpaxx where ajid=a.ajid and nvl(zpajl,'01')!='02') where ajid=rec_zpaxx.ajid;
    PReturnCode:='0';
    PReturnMsg:='案件理算处理成功!';
    EXCEPTION
  WHEN OTHERS THEN
  	/*v1.2++begin*/
    if   v_Cur%isOpen then
        close  v_Cur;
    end if;
    /*v1.2++end*/
    PReturnCode := '-99';
    DBMS_OUTPUT.PUT_LINE('[yhs debug] ' || 'PReturncode= ' ||
                         PReturnCode);
    PReturnMsg := 'Error:' || sqlerrm;
    DBMS_OUTPUT.PUT_LINE(PReturnMsg);
  end   SP_P1_COMPUTESUBCASE;
/
