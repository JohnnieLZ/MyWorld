CREATE PROCEDURE      "PROC_ALCLOSE_EXPORT" (p_Xh IN VARCHAR2, p_Pch IN VARCHAR2, p_Wbbdh IN VARCHAR2, p_RtnCode OUT NUMBER, p_RtnMsg OUT VARCHAR2) IS
  /**
    *@version1.1 update by  ?????tb_fpfydlxx?????????????? 2015-5-7
    *@version1.2 update by zhangjunpeng  ?????????BPO_ENTRY_USER??????`TPA? 2015-6-15
    *@version1.3 update by zhangjunpeng ???????????????  2015-6-19
    ******/
  i_Count  NUMBER(9) := 0;
  i_step  NUMBER(9) := 0;
  sPch  VARCHAR2(11);
  sJbms  VARCHAR2(1024):='';
  sJbmc   VARCHAR2(200);
  sLetter_Desc VARCHAR2(1024);
  sLpsm   VARCHAR2(200);
  sWjm  VARCHAR2(30);
  sSql varchar2(4000);
  sBatchno VARCHAR2(30);
  v_sqlstr  varchar2(1000);
  v_dname   VARCHAR2(50);
  CURSOR c_Pcxx IS
    SELECT  DISTINCT(S.PCH)as PCH,NVL(T.WBBDH,T.KHBDH)AS WBBDH
    FROM TB_LPAJXX A, TB_LPFPXX B, TB_LPPCXX S,TB_FDXX T
    WHERE A.AJID = B.AJID
    --AND A.SFRQ >= TO_CHAR(SYSDATE-10,'YYYYMMDD')
    --AND A.AJZT IN ('08', '09')
    AND A.AJZT IN ('09')
    AND S.PCID = A.LPPCID
    AND S.BXGSID='592'
    AND ((S.PCH=p_Pch AND p_Pch IS NOT NULL) OR (p_Pch IS NULL))
    AND (A.AJJL NOT IN('06','07') OR A.AJJL IS NULL)
    AND A.FDID=T.FDID
    AND NVL(T.WBBDH,T.KHBDH)=p_Wbbdh
    ORDER BY S.PCH,NVL(t.wbbdh,T.KHBDH);

  CURSOR c_Paxx(p_Pch VARCHAR2) IS
    SELECT G.ajid, FUNC_BXGSDM_PZ('TB_JBKXX', G.JBDM, '592', '0',NULL,NULL) JBDM, G.ZDLX,G.ZPAH,G.PFZRDM,ROWNUM AS XH FROM(
      SELECT distinct NVL(a.zddm,'R68') AS JBDM,A.ZPAID,DECODE(SUBSTR(A.PFZRDM,1,3),'MAT','',B.ZDLX)ZDLX,A.ZPAH,L.AJID,A.PFZRDM
        FROM TB_LPFPXX B, /*TABLE(SF_SPLITSTR(B.JBDM,','))H*/TB_ZPAXX A,TB_LPPCXX K,TB_LPAJXX L,TB_FDXX S,
        (SELECT S.ZPAID,M.FPID FROM TB_ZPAXXDZB S,TB_FPXXFYXX M WHERE S.XXID=M.XXID
        AND S.AJID IN(SELECT AA.AJID FROM TB_LPAJXX AA,TB_LPPCXX BB WHERE AA.AJZT='09' AND (AA.AJJL NOT IN('06','07') OR AA.AJJL IS NULL) AND AA.LPPCID=BB.PCID AND ((BB.PCH=p_Pch AND p_Pch IS NOT NULL) OR (p_Pch IS NULL))
        )
        GROUP BY S.ZPAID,M.FPID
        UNION ALL
        SELECT ZPAID,FPID FROM(
        SELECT A.ZPAID,MAX(NVL(A.FPID,S.FPID)) FPID FROM TB_ZPAXX A,TB_LPFPXX S
        WHERE A.AJID=S.AJID
        --AND A.ZPAID=18579
        AND ((A.SFSDTJ='1') OR(A.PFZRDM LIKE 'HI%'))
        AND (S.FPID,A.ZPAID) NOT IN(SELECT M.FPID,T.ZPAID FROM TB_ZPAXXDZB T,TB_FPXXFYXX M WHERE T.XXID = M.XXID AND T.AJID IN(SELECT A.AJID
      FROM TB_LPAJXX A, TB_LPFPXX B, TB_LPPCXX T, TB_FPFYDLXX C
        WHERE T.PCID = A.LPPCID
        AND A.BXGSID = '592'
        AND B.AJID = A.AJID
        AND B.FPID = C.FPID(+)
        AND A.AJZT='09'
        AND (A.AJJL NOT IN('06','07') OR A.AJJL IS NULL))
        )GROUP BY A.ZPAID,A.AJID)

        )G
        WHERE G.ZPAID=A.ZPAID
        AND G.FPID=B.FPID
        AND K.PCID=L.LPPCID
        AND L.AJID=B.AJID
        AND L.FDID=S.FDID
        AND NVL(S.WBBDH,S.KHBDH)=p_Wbbdh
        AND ((K.PCH=p_Pch AND p_Pch IS NOT NULL) OR (p_Pch IS NULL))
        --and b.fpid=a.fpid
        --AND L.SFRQ >= TO_CHAR(SYSDATE-10,'YYYYMMDD')
      --AND L.AJZT IN ('08', '09')
      AND L.AJZT IN ('09')
        ORDER BY ZPAH

        )G;

  CURSOR c_Ajxx IS
    SELECT  distinct(A.AJID) AJID
    FROM TB_LPAJXX A, TB_LPPCXX S,TB_FDXX T
    WHERE 1=1
    --A.SFRQ >= TO_CHAR(SYSDATE-10,'YYYYMMDD')
    --AND A.AJZT IN ('08', '09')
    AND A.AJZT IN ('09')
    AND S.PCID = A.LPPCID
    AND S.BXGSID='592'
    --AND S.PCH='Allianz20140911002'
    AND (A.AJJL NOT IN('06','07') OR A.AJJL IS NULL)
    AND A.FDID=T.FDID
    AND NVL(T.WBBDH,T.KHBDH)=p_Wbbdh;

  CURSOR c_Pasm(p_Zpah VARCHAR2,p_Zdlx VARCHAR2) IS
    SELECT  DISTINCT(A.CLAIM_INFO_DESC),A.CLAIM_LETTER_DESC
    FROM TB_AL_CLOSE_FPXX A,TB_AL_CLOSE_AJXX B
    WHERE A.PCH = sPch
    AND A.FPID=B.FPID
    AND A.PCH=B.PCH
    AND A.WD_SUBCLAIM_NO = p_Zpah
    AND A.WD_SUBCLAIM_NO = B.WD_SUBCLAIM_NO
    and A.ZDLX=p_Zdlx;

  CURSOR c_Fpxx(p_Ajid VARCHAR2) IS
    SELECT DISTINCT NVL(A.ZDDM,'R68') AS JBDM,A.ZPAID,B.ZDLX,A.ZPAH,A.ZPAJL,A.PFZRDM,A.SJPFJE,A.MPE
    FROM TB_LPFPXX B, TB_ZPAXX A,
    (SELECT S.ZPAID,M.FPID FROM TB_ZPAXXDZB S,TB_LPAJXX AA, TB_FPXXFYXX M WHERE S.XXID=M.XXID AND S.AJID=p_Ajid
    AND AA.AJZT='09' AND (AA.AJJL NOT IN('06','07') OR AA.AJJL IS NULL)
      GROUP BY S.ZPAID,M.FPID
    UNION ALL
    SELECT ZPAID,FPID FROM(
  SELECT A.ZPAID,MAX(NVL(A.FPID,S.FPID)) FPID FROM TB_ZPAXX A,TB_LPFPXX S
  WHERE A.AJID=S.AJID
  AND A.AJID=p_Ajid
  AND ((A.SFSDTJ='1') OR(A.PFZRDM LIKE 'HI%'))
  AND (S.FPID,A.ZPAID) NOT IN(SELECT M.FPID,T.ZPAID FROM TB_ZPAXXDZB T,TB_FPXXFYXX M WHERE T.XXID = M.XXID AND T.AJID IN(SELECT A.AJID
FROM TB_LPAJXX A, TB_LPFPXX B, TB_LPPCXX T, TB_FPFYDLXX C
  WHERE T.PCID = A.LPPCID
  AND A.BXGSID = '592'
  AND B.AJID = A.AJID
  AND B.FPID = C.FPID(+)
  ))GROUP BY A.ZPAID,A.AJID)

    )G
    WHERE B.AJID = p_Ajid
    AND G.ZPAID=A.ZPAID
    AND G.FPID=B.FPID;
BEGIN
  --0.?????
    i_step := 0;
    i_Count := 0;
    p_RtnCode := 0;
    v_dname := 'E:\zdal\returndata';
    --v_dname := '\\10.1.63.178\D:\Software';
    p_RtnMsg := '????';

     --????????
     i_step := 1;
     SELECT FUNC_GENERATE_LSH ('0110')
     INTO  sPch
     FROM DUAL;

     ---???????????
     i_step := 2;
     INSERT INTO TB_AL_CLOSE_CZJL(PCH, SJRQ, KSSJ, JSSJ)
     VALUES(sPch, TO_CHAR(SYSDATE,'YYYYMMDD'), SYSDATE, NULL);
  /***************************-- +V1.3 start*************************/
  update tb_zpaxx a
          set a.SFYYB =case when  exists (select 'x' from tb_fdxx c,tb_tmp_fdzrxx d,tb_khxx f
             where c.fdid=a.fdid and c.fdh=d.fdh /*and d.clzt = '03'*/ and c.khbdh=d.khbdh and  d.zrbm like 'SHIP%'
             and c.bbrkhid = f.khid and f.xm = trim(d.bbr_xm) and f.aac147 = trim(d.bbr_zjhm)
             and ((select e.jzrq from tb_lpfpxx e where e.fpid = a.fpid) between d.fdsxr  and d.fdzzr))
                          then   '1'
                     else  ''
                   end
        where  a.pfzrdm  like 'AIOP%'
          and a.fpid is not null
          AND EXISTS(SELECT 1 FROM TB_LPAJXX M WHERE M.AJID =A.AJID AND m.ajzt = '09'
              AND m.BXGSID='592'AND (m.AJJL NOT IN('06','07') OR m.AJJL IS NULL) and m.bbrkhid is not null and m.fdid is not null);

       update tb_zpaxx a
          set a.SFYYB =case when  exists (select 'x' from tb_fdxx c,tb_tmp_fdzrxx d,tb_khxx f
             where c.fdid=a.fdid and c.fdh=d.fdh /*and d.clzt = '03'*/ and c.khbdh=d.khbdh and  d.zrbm like 'MBRY%'
             and c.bbrkhid = f.khid and f.xm = trim(d.bbr_xm) and f.aac147 = trim(d.bbr_zjhm)
             and ((select e.jzrq from tb_lpfpxx e where e.fpid = a.fpid) between d.fdsxr  and d.fdzzr) )
                          then   '1'
                     else  ''
                   end
        where a.pfzrdm  like 'MAT%'
          and a.fpid is not null
          AND EXISTS(SELECT 1 FROM TB_LPAJXX M WHERE M.AJID =A.AJID AND m.ajzt = '09'
              AND m.BXGSID='592'AND (m.AJJL NOT IN('06','07') OR m.AJJL IS NULL) and m.bbrkhid is not null and m.fdid is not null);


       update tb_zpaxx a
          set a.SFYYB =case when  exists (select 'x' from tb_fdxx c,tb_tmp_fdzrxx d,tb_khxx f
             where c.fdid=a.fdid and c.fdh=d.fdh /*and d.clzt = '03'*/ and c.khbdh=d.khbdh and  d.zrbm like 'IPAY%'
             and c.bbrkhid = f.khid and f.xm = trim(d.bbr_xm) and f.aac147 = trim(d.bbr_zjhm)
             and ((select e.jzrq from tb_lpfpxx e where e.fpid = a.fpid) between d.fdsxr  and d.fdzzr) )
                          then   '1'
                     else  ''
                   end
        where ( a.pfzrdm  like 'IP%' OR a.pfzrdm  like 'OP%' OR a.pfzrdm  like 'OIP%')
          and a.fpid is not null
          AND EXISTS(SELECT 1 FROM TB_LPAJXX M WHERE M.AJID =A.AJID AND m.ajzt = '09'
              AND m.BXGSID='592'AND (m.AJJL NOT IN('06','07') OR m.AJJL IS NULL) and m.bbrkhid is not null and m.fdid is not null);

        --???????????????????????? update by zhangjunpeng 20150724
         update tb_zpaxx a set a.SFYYB =   '1'
        where  a.pfzrdm  like 'AIOP%'
          and a.fpid is not null
          and a.zpajl= '02'
          AND EXISTS(SELECT 1 FROM TB_LPAJXX M WHERE M.AJID =A.AJID AND m.ajzt = '09'
              AND m.BXGSID='592'AND (m.AJJL NOT IN('06','07') OR m.AJJL IS NULL) and m.bbrkhid is not null and m.fdid is not null)
           AND exists (select 'x' from tb_fdxx c,tb_tmp_fdzrxx d,tb_khxx f
             where c.fdid=a.fdid and c.fdh=d.fdh  and c.khbdh=d.khbdh and  d.zrbm like 'SHIP%'
             and c.bbrkhid = f.khid and f.xm = trim(d.bbr_xm) and f.aac147 = trim(d.bbr_zjhm)
             and (  (select e.jzrq from tb_lpfpxx e where e.fpid = a.fpid) < d.fdsxr  or
             (select e.jzrq from tb_lpfpxx e where e.fpid = a.fpid)> d.fdzzr
             ) ) ;

       update tb_zpaxx a set a.SFYYB ='1'
        where a.pfzrdm  like 'MAT%'
          and a.fpid is not null
          and a.zpajl = '02'
          AND EXISTS(SELECT 1 FROM TB_LPAJXX M WHERE M.AJID =A.AJID AND m.ajzt = '09'
              AND m.BXGSID='592'AND (m.AJJL NOT IN('06','07') OR m.AJJL IS NULL) and m.bbrkhid is not null and m.fdid is not null)
          AND exists (select 'x' from tb_fdxx c,tb_tmp_fdzrxx d,tb_khxx f
             where c.fdid=a.fdid and c.fdh=d.fdh and c.khbdh=d.khbdh and  d.zrbm like 'MBRY%'
             and c.bbrkhid = f.khid and f.xm = trim(d.bbr_xm) and f.aac147 = trim(d.bbr_zjhm)
             and (  (select e.jzrq from tb_lpfpxx e where e.fpid = a.fpid) < d.fdsxr  or
             (select e.jzrq from tb_lpfpxx e where e.fpid = a.fpid)> d.fdzzr
             ) );

       update tb_zpaxx a set a.SFYYB =  '1'
        where ( a.pfzrdm  like 'IP%' OR a.pfzrdm  like 'OP%' OR a.pfzrdm  like 'OIP%')
          and a.fpid is not null
          and a.zpajl = '02'
          AND EXISTS(SELECT 1 FROM TB_LPAJXX M WHERE M.AJID =A.AJID AND m.ajzt = '09'
              AND m.BXGSID='592'AND (m.AJJL NOT IN('06','07') OR m.AJJL IS NULL) and m.bbrkhid is not null and m.fdid is not null)
          AND exists (select 'x' from tb_fdxx c,tb_tmp_fdzrxx d,tb_khxx f
             where c.fdid=a.fdid and c.fdh=d.fdh  and c.khbdh=d.khbdh and  d.zrbm like 'IPAY%'
             and c.bbrkhid = f.khid and f.xm = trim(d.bbr_xm) and f.aac147 = trim(d.bbr_zjhm)
             and (  (select e.jzrq from tb_lpfpxx e where e.fpid = a.fpid) < d.fdsxr  or
             (select e.jzrq from tb_lpfpxx e where e.fpid = a.fpid)> d.fdzzr
             ) );

         --update tb_zpaxx t set t.sfyyb = '1' where t.ajid in (500012);
         --update tb_zpaxx t set t.sfyyb = null where t.ajid in (499231);

              /*  MERGE into TB_KHXX M USING (
        SELECT B.BBRKHID,DECODE(C.SFYYB,'1','02','01') AS YBBS FROM TB_LPAJXX B,
        (SELECT T.AJID,T.SFYYB FROM TB_ZPAXX T
        WHERE EXISTS(
        SELECT 1 FROM TB_LPAJXX A WHERE A.AJID = T.AJID AND a.ajzt = '09'
                      AND a.BXGSID='592'AND (a.AJJL NOT IN('06','07') OR a.AJJL IS NULL) and a.bbrkhid is not null and a.fdid is not null
        )GROUP BY  T.AJID,T.SFYYB) C WHERE B.AJID = C.AJID) n
        on (m.khid = n.bbrkhid)
        when matched then
          update set m.ybbs = n.ybbs;*/
          /*
                    MERGE into TB_KHXX M USING (
        SELECT B.BBRKHID,MAX(DECODE(C.SFYYB,'1','02','01')) AS YBBS FROM TB_LPAJXX B,
        (SELECT T.AJID,T.SFYYB FROM TB_ZPAXX T
        WHERE EXISTS(
        SELECT 1 FROM TB_LPAJXX A WHERE A.AJID = T.AJID AND a.ajzt = '09'
                      AND a.BXGSID='592'AND (a.AJJL NOT IN('06','07') OR a.AJJL IS NULL) and a.bbrkhid is not null and a.fdid is not null
        )GROUP BY  T.AJID,T.SFYYB) C WHERE B.AJID = C.AJID GROUP BY B.BBRKHID) n
        on (m.khid = n.bbrkhid)
        when matched then
          update set m.ybbs = n.ybbs;*/

  /***************************-- +V1.3 end***************************/
  i_step := 21;
  UPDATE TB_KHXX S
  SET (S.KHHSZSHI) = (SELECT MAX(H.KHHSZSHI) FROM TB_KHXX H,TB_LPAJXX M,TB_LPPCXX G WHERE H.KHID=M.ZBBRKHID AND M.LPPCID=G.PCID AND M.BXGSID = '592' AND ((G.PCH=p_Pch AND p_Pch IS NOT NULL) OR (p_Pch IS NULL))
  AND M.AJZT IN ('09'))
  WHERE S.KHHSZS IS NULL
  AND S.KHID IN(SELECT A.BBRKHID FROM TB_LPAJXX A,TB_LPPCXX B WHERE A.ZLDBZ='1' AND B.PCID=A.LPPCID AND A.BXGSID = '592' AND ((B.PCH=p_Pch AND p_Pch IS NOT NULL) OR (p_Pch IS NULL))
    AND A.AJZT IN ('09'));

  ----add by jyy 2014-10-18 ?????
  /*UPDATE TB_KHXX S
   SET (S.KHHSZSHI, S.KHHSZS) =
       (SELECT MAX(z.xzqhdm), SUBSTR(MAX(z.xzqhdm), 1, 2) || '0000'
          FROM TB_KHXX H, TB_LPAJXX M, TB_LPPCXX G,
         ( select ajid,max(xzqhdm) as xzqhdm from (select j.ajid,L.xzqhdm,count(1) as jls from tb_lpajxx j,tb_zpaxx k,tb_lpfpxx O,tb_yyxx L
             where j.ajid=k.ajid and k.fpid=o.fpid and o.yyid=L.yyid
             group by j.ajid,L.xzqhdm
           ) y where (y.ajid,y.xzqhdm,jls) in(select ajid,xzqhdm,max(jls) as jls from (select j.ajid,L.xzqhdm,count(1) as jls from tb_lpajxx j,tb_zpaxx k,tb_lpfpxx O,tb_yyxx L
             where j.ajid=k.ajid and k.fpid=o.fpid and o.yyid=L.yyid
             group by j.ajid,L.xzqhdm
           ) group by ajid,xzqhdm ) group by ajid) z
         WHERE H.KHID = M.BBRKHID
           AND M.LPPCID = G.PCID and m.ajid=z.ajid
           AND M.BXGSID = '592'
           --AND M.SFRQ >= TO_CHAR(SYSDATE - 10, 'YYYYMMDD')
           AND ((G.PCH=p_Pch AND p_Pch IS NOT NULL) OR (p_Pch IS NULL))
           AND M.AJZT IN ('09'))
 WHERE S.KHHSZS IS NULL
    AND S.KHID IN (SELECT A.BBRKHID
                    FROM TB_LPAJXX A, TB_LPPCXX B
                   WHERE B.PCID = A.LPPCID
                     AND A.BXGSID = '592'
                     --AND A.SFRQ >= TO_CHAR(SYSDATE - 10, 'YYYYMMDD')
                     AND ((B.PCH=p_Pch AND p_Pch IS NOT NULL) OR (p_Pch IS NULL))
                     AND A.AJZT IN ('09'));*/
    ---ADD BY JYY 2014-10-18 ??????????????????????
        UPDATE TB_KHXX S
   SET (S.KHHSZSHI, S.KHHSZS) =
       (SELECT KHHSZSHI,KHHSZS FROM(
       (SELECT DISTINCT(MAX(KHHSZSHI))KHHSZSHI,MAX(KHHSZS)KHHSZS,KHID FROM(
       (SELECT MAX(z.xzqhdm) AS KHHSZSHI, (SUBSTR(MAX(z.xzqhdm), 1, 2) || '0000') KHHSZS,M.AJID,H.KHID
          FROM TB_KHXX H, TB_LPAJXX M, TB_LPPCXX G,
         ( select ajid,max(xzqhdm) as xzqhdm from (select j.ajid,L.xzqhdm,count(1) as jls from tb_lpajxx j,tb_zpaxx k,tb_lpfpxx O,tb_yyxx L
             where j.ajid=k.ajid and k.fpid=o.fpid and o.yyid=L.yyid
             group by j.ajid,L.xzqhdm
             union all
             select j.ajid,L.xzqhdm,count(1) as jls from tb_lpajxx j,tb_zpaxx k,tb_lpfpxx o,tb_yyxx l
             where j.ajid=k.ajid  and o.yyid=L.yyid
             and (k.zpaid,o.fpid) in(SELECT ZPAID,FPID FROM(
  SELECT A.ZPAID,MAX(NVL(A.FPID,S.FPID)) FPID FROM TB_ZPAXX A,TB_LPFPXX S
  WHERE A.AJID=S.AJID
  AND ((A.SFSDTJ='1') OR(A.PFZRDM LIKE 'HI%'))
  AND (S.FPID,A.ZPAID) NOT IN(SELECT M.FPID,T.ZPAID FROM TB_ZPAXXDZB T,TB_FPXXFYXX M WHERE T.XXID = M.XXID AND T.AJID IN(SELECT A.AJID
FROM TB_LPAJXX A, TB_LPFPXX B, TB_LPPCXX T, TB_FPFYDLXX C
  WHERE T.PCID = A.LPPCID
  AND A.BXGSID = '592'
  AND B.AJID = A.AJID
  AND B.FPID = C.FPID(+)
  AND A.AJZT='09'
  AND (A.AJJL NOT IN('06','07') OR A.AJJL IS NULL))
  )GROUP BY A.ZPAID,A.AJID))
  group by j.ajid,L.xzqhdm
           ) y where (y.ajid,y.xzqhdm,jls) in(select ajid,xzqhdm,max(jls) as jls from (select j.ajid,L.xzqhdm,count(1) as jls from tb_lpajxx j,tb_zpaxx k,tb_lpfpxx O,tb_yyxx L
             where j.ajid=k.ajid and k.fpid=o.fpid and o.yyid=L.yyid
             group by j.ajid,L.xzqhdm
             union all
             select j.ajid,L.xzqhdm,count(1) as jls from tb_lpajxx j,tb_zpaxx k,tb_lpfpxx o,tb_yyxx l
             where j.ajid=k.ajid  and o.yyid=L.yyid
             and (k.zpaid,o.fpid) in(SELECT ZPAID,FPID FROM(
  SELECT A.ZPAID,MAX(NVL(A.FPID,S.FPID)) FPID FROM TB_ZPAXX A,TB_LPFPXX S
  WHERE A.AJID=S.AJID
  AND ((A.SFSDTJ='1') OR(A.PFZRDM LIKE 'HI%'))
  AND (S.FPID,A.ZPAID) NOT IN(SELECT M.FPID,T.ZPAID FROM TB_ZPAXXDZB T,TB_FPXXFYXX M WHERE T.XXID = M.XXID AND T.AJID IN(SELECT A.AJID
FROM TB_LPAJXX A, TB_LPFPXX B, TB_LPPCXX T, TB_FPFYDLXX C
  WHERE T.PCID = A.LPPCID
  AND A.BXGSID = '592'
  AND B.AJID = A.AJID
  AND B.FPID = C.FPID(+)
  AND A.AJZT='09'
  AND (A.AJJL NOT IN('06','07') OR A.AJJL IS NULL))
  )GROUP BY A.ZPAID,A.AJID))
  group by j.ajid,L.xzqhdm
           ) group by ajid,xzqhdm ) group by ajid) z
         WHERE H.KHID = M.BBRKHID
           AND M.LPPCID = G.PCID and m.ajid=z.ajid
           AND M.BXGSID = '592'
           --AND G.PCH='Allianz20141010013'
          AND ((G.PCH=p_Pch AND p_Pch IS NOT NULL) OR (p_Pch IS NULL))
          AND M.AJZT IN ('09') GROUP BY M.AJID,H.KHID))P WHERE EXISTS(SELECT 1 FROM TB_LPAJXX TT,TB_LPPCXX SS WHERE TT.LPPCID=SS.PCID AND TT.BXGSID='592' AND TT.AJZT='09' AND ((SS.PCH=p_Pch AND p_Pch IS NOT NULL) OR (p_Pch IS NULL)) /*AND TT.BBRKHID=S.KHID*/ AND TT.AJID=P.AJID)GROUP BY P.KHID)
           )K WHERE K.KHID=S.KHID)
  WHERE EXISTS(SELECT 1 FROM TB_LPAJXX TT,TB_LPPCXX SS WHERE TT.LPPCID=SS.PCID AND TT.BXGSID='592' AND TT.AJZT='09'AND ((SS.PCH=p_Pch AND p_Pch IS NOT NULL) OR (p_Pch IS NULL)) AND TT.BBRKHID=S.KHID )
  AND ((S.KHHSZS IS NULL) OR(S.KHHSZSHI IS NULL));

    i_step := 22;
    UPDATE TB_ZPAXX A
SET A.SFYYB = '1'
WHERE EXISTS(SELECT 1 FROM TB_FDXX S,TB_LPAJXX T,TB_TMP_FDZRXX M WHERE S.FDID=T.FDID AND S.WBBDH=M.WBBDH AND T.BBRXM=M.BBR_XM
AND M.BBR_ZJHM=T.BBRZJH AND M.ZRBM IN('IPAY','MBRY','SHIP') AND T.AJID=A.AJID)
AND NVL(A.SFSDTJ,'0')='1'
AND A.AJID IN(SELECT A.AJID FROM TB_LPAJXX A, TB_LPPCXX S,TB_FDXX T
    WHERE 1=1
    --A.SFRQ >= TO_CHAR(SYSDATE-10,'YYYYMMDD')
    --AND A.AJZT IN ('08', '09')
    AND A.AJZT IN ('09')
    AND S.PCID = A.LPPCID
    AND S.BXGSID='592'
    --AND S.PCH='Allianz20140911002'
    AND (A.AJJL NOT IN('06','07') OR A.AJJL IS NULL)
    AND A.FDID=T.FDID
    AND NVL(T.WBBDH,T.KHBDH)=p_Wbbdh);

     --?????????
     i_step := 3;
     INSERT INTO TB_AL_CLOSE_AJXX(
       YWLSH, PCH, LPPCID, AJID,
    WD_BATCH_NO, WD_CLAIM_NO, WD_SUBCLAIM_NO, CASE_STATUS,
    CLAIM_CASE_NO, SUB_CASE_NO, POLICY_REF,
    SUB_POLICY_REF, CLAIM_ACCEPT_DATE, CLAIM_REG_DATE,
    CLAIM_APPROVE_DATE, BPO_ENTRY_USER, BPO_VAL_USER,
    CAUSE_OF_LOSS, LOSS_TYPE, CAUSE_OF_LOSS_BJ,
    COVER_CODE, BENEFIT_CODE, BEN_RECEIPT_AMT,
    THIRD_PAY_AMT, CLAIM_TIMES, CLAIM_LETTER_DESC,
    CLAIM_DECISION, BENIFIARY_NAME, REL_TO_INS,
    BANK_CATEGORY_ID, ACCOUNT_PROVINCE, ACCOUNT_CITY, ACCOUNT_NO,
    PAYOUT_AMT, FPID, SYFPH, RECEIPT_NO, AREA, EXPORT_DATE, LOSS_DATE_FOR_BJ)
  SELECT
    FUNC_GENERATE_LSH('0108'), sPch, S.PCID, A.AJID,
    S.PCH, A.PAH, NVL(B.ZPAH,'????'), (SELECT A.AAA103 FROM AA10 A WHERE A.AAA100 = 'AJZT' AND A.AAA102=A.AJZT),
    NULL, TRIM(S.KHTJBH)||SUBSTR(A.PAH,LENGTH(A.PAH)-2,3), NVL(C.WBBDH,C.KHBDH),
    SUBSTR(C.FDH,1,8), TO_DATE(S.SLRQ,'YYYYMMDD'), TO_DATE(S.SJRQ,'YYYYMMDD'),
    NVL(TO_DATE(A.JARQ,'YYYYMMDD'),SYSDATE), /*NVL(A.CSR, -- -V1.2*/'TPA'/*)*/,'TPA',
    FUNC_BXGSDM_PZ('YWSGYY', NVL(A.YWSGYY,'01'), '592', '0',NULL,NULL),DECODE(SUBSTR(FUNC_IS_BJBD(C.FDID),1,2),'11', FUNC_GENERATE_LOSS_TYPE(B.PFZRDM),NULL), DECODE(SUBSTR(FUNC_IS_BJBD(C.FDID),1,2),'11', FUNC_BXGSDM_PZ('TB_JBKXX', A.SSWBYY, '592', '0',NULL,NULL),NULL),
    (SELECT MAX(CAE186) FROM AA53 WHERE CAE189='ALZRXZDZ' AND CAE191='592' AND CAE187=FUNC_BXGSDM_PZ('ZRDM', B.PFZRDM, '592', '0',B.SFYYB,M.ZDLX)), FUNC_BXGSDM_PZ('ZRDM', B.PFZRDM, '592', '0',B.SFYYB,M.ZDLX),M.FPZE,
    (NVL(TCZFE,0)+NVL(FJZFE,0)+NVL(SBZFE,0)+NVL(DSFZFJE,0)),1,(DECODE(B.ZPAJL,'02',(SELECT A.AAA103 FROM aa10 A WHERE A.AAA100 = 'JFLY' AND A.AAA102=B.JLSM1) || ','||B.JLSM2,'')),
    FUNC_BXGSDM_PZ('AJJL', (SELECT AAA102 FROM AA10 WHERE AAA100='AJJL' AND AAA102=B.ZPAJL), '592', '0',NULL,NULL), DECODE((SELECT NVL(ZBBRGX,'00') FROM TB_FDXX WHERE FDID=A.FDID),'03',(SELECT XM FROM TB_KHXX WHERE KHID=A.ZBBRKHID),NVL(A.SKFXM,(SELECT XM FROM TB_KHXX WHERE KHID=A.BBRKHID)))AS SKFXM, FUNC_BXGSDM_PZ('ZBBRGX', DECODE((SELECT NVL(ZBBRGX,'00') FROM TB_FDXX WHERE FDID=A.FDID),'03','03','00'), '592', '0',NULL,NULL),
    FUNC_GET_BANKID('592',NVL(A.LPKGFKHH,(SELECT KHYH FROM TB_KHXX WHERE KHID=A.BBRKHID))),
    SUBSTR(CASE WHEN EXISTS(SELECT KHHSZShi FROM TB_KHXX j,AA26 k  WHERE KHID= A.BBRKHID AND j.KHHSZShi=K.AAA146) THEN (SELECT SUBSTR(AAB301,1,4) FROM AA26 k WHERE K.AAA146=(SELECT KHHSZSHI FROM TB_KHXX WHERE KHID= A.BBRKHID))
        ELSE (SELECT KHHSZSHI FROM TB_KHXX WHERE KHID= A.BBRKHID) END ,1,2)||'00' AS KHHSZS,
     CASE WHEN EXISTS(SELECT KHHSZShi FROM TB_KHXX j,AA26 k  WHERE KHID= A.BBRKHID AND j.KHHSZShi=K.AAA146) THEN (SELECT SUBSTR(AAB301,1,4) FROM AA26 k WHERE K.AAA146=(SELECT KHHSZSHI FROM TB_KHXX WHERE KHID= A.BBRKHID))
        ELSE (SELECT SUBSTR(KHHSZSHI,1,4) FROM TB_KHXX WHERE KHID= A.BBRKHID) END AS KHHSZShi,
     --DECODE(A.ZLDBZ,'0',NVL(A.LPKGFYHZH,(SELECT YHZH FROM TB_KHXX WHERE KHID=A.BBRKHID)),'1',DECODE((SELECT ZBBRGX FROM TB_FDXX WHERE FDID=A.FDID),'03',(SELECT YHZH FROM TB_KHXX WHERE KHID=A.ZBBRKHID),NVL(A.LPKGFYHZH,(SELECT YHZH FROM TB_KHXX WHERE KHID=A.BBRKHID)))),
    DECODE((SELECT ZBBRGX FROM TB_FDXX WHERE FDID=A.FDID),'03',(SELECT YHZH FROM TB_KHXX WHERE KHID=A.ZBBRKHID),NVL(A.LPKGFYHZH,(SELECT YHZH FROM TB_KHXX WHERE KHID=A.BBRKHID))),
    NVL(A.AJPFJE,0), M.FPID, B.SYFPH, M.FPHM, NVL(A.YWSGDD,(SELECT XZQHMC FROM TB_YYXX WHERE YYID=M.YYID)), SYSDATE, DECODE(SUBSTR(FUNC_IS_BJBD(C.FDID),1,2),'11', TO_DATE(M.JZRQ,'YYYYMMDD'),NULL)
  FROM TB_LPPCXX S, TB_LPAJXX A, TB_ZPAXX B, TB_FDXX C, TB_ZRXX D, TB_LPFPXX M,
  (SELECT T.ZPAID,M.FPID FROM TB_ZPAXXDZB T,TB_FPXXFYXX M WHERE
T.XXID = M.XXID
AND AJID IN(SELECT A.AJID
FROM TB_LPAJXX A, TB_LPFPXX B, TB_LPPCXX T, TB_FPFYDLXX C
  WHERE T.PCID = A.LPPCID
  AND A.BXGSID = '592'
  AND B.AJID = A.AJID
  AND B.FPID = C.FPID(+)
  AND A.AJZT='09'
  AND (A.AJJL NOT IN('06','07') OR A.AJJL IS NULL))
  GROUP BY T.ZPAID,M.FPID
  UNION ALL
  SELECT ZPAID,FPID FROM(
  SELECT A.ZPAID,MAX(NVL(A.FPID,S.FPID)) FPID FROM TB_ZPAXX A,TB_LPFPXX S
  WHERE A.AJID=S.AJID
  AND ((A.SFSDTJ='1') OR(A.PFZRDM LIKE 'HI%'))
  AND (S.FPID,A.ZPAID) NOT IN(SELECT M.FPID,T.ZPAID FROM TB_ZPAXXDZB T,TB_FPXXFYXX M WHERE T.XXID = M.XXID AND T.AJID IN(SELECT A.AJID
FROM TB_LPAJXX A, TB_LPFPXX B, TB_LPPCXX T, TB_FPFYDLXX C
  WHERE T.PCID = A.LPPCID
  AND A.BXGSID = '592'
  AND B.AJID = A.AJID
  AND B.FPID = C.FPID(+)
  AND A.AJZT='09'
  AND (A.AJJL NOT IN('06','07') OR A.AJJL IS NULL))
  )GROUP BY A.ZPAID,A.AJID)
  )N
    WHERE 1=1
    AND ((S.PCH=p_Pch AND p_Pch IS NOT NULL) OR (p_Pch IS NULL))
    --S.khbdh in('PICC-CHBK')
    AND A.BXGSID = '592'
    AND N.FPID=M.FPID
    AND N.ZPAID=B.ZPAID
    --AND A.SFRQ >= TO_CHAR(SYSDATE-10,'YYYYMMDD')
  AND A.AJZT IN ('09')
  AND S.PCID = A.LPPCID
  AND A.AJID = B.AJID
  AND A.FDID = C.FDID
  AND B.ZRID = D.ZRID
  AND M.AJID = B.AJID
  AND (A.AJJL NOT IN('06','07') OR A.AJJL IS NULL)
  AND NVL(C.WBBDH,C.KHBDH)=p_Wbbdh;
  --AND ((A.AJJL NOT IN('06') AND A.AJJLSM1 NOT IN('02','03')) OR (A.AJJL NOT IN('07')) OR A.AJJL IS NULL);

  --?????????
     i_step := 4;
  INSERT INTO TB_AL_CLOSE_FPXX(
    YWLSH, PCH, AJID, FPID,
    FPHM, DATE_OF_LOSS, CLAIM_HOSPITAL,
    IN_HOSPITAL_DATE, OUT_HOSPITAL_DATE,SELF_PAID_AMT,
    CLAIM_INFO_DESC, ACCOUNT_PROVINCE, ACCOUNT_CITY,
    HOSPITAL_CODE, BILL_AMOUNT, RECEIPT_TYPE,
    SOCIAL_AMOUNT, SOCIAL_WHOLE_AMOUNT, FUND_AMT,
    SPECIAL_DESEASE, PERSONAL_PAID_1,
    PERSONAL_PAID_2, PERSONAL_PAID_3,
    THIRD_PARTY_AMT, ICD_CODE, DIAGNOSIS,
    SURGERY_CODE, SURGERY_TYPE, SERVICE_DATE_FROM,
    SERVICE_DATE_TO, I_O_2, ZDLX, SOCIAL_PAID_AMT,
    REGISTER_FEE, WESTERN_MED_FEE, CHINESE_MED_FEE,
    HERBAL_MED_FEE, TEST_FEE, X_RAY_FEE,
    B_SONIC_FEE, CT_FEE, MRI_FEE,
    EXAMINE_FEE, CURE_FEE, MATERIAL_FEE,
    SURGERY_FEE, OXYGEN_FEE, TRANSFUSE_FEE,
    REMEDY_FEE, PROSTH_FEE, LAW_AUTH_FEE,
    OTHER_FEE, BED_FEE, HOSPITAL_DAYS,
    NURSE_FEE, HOSPITAL_FEE, URGENT_SAVE_FEE,
    AMBULANCE_FEE, NATION_MED_FEE, SELF_MADE_FEE,
    PRESCRIPTION_FEE, EXPORT_DATE, PFZRDM, WD_SUBCLAIM_NO)
  SELECT
    FUNC_GENERATE_LSH('0109'), sPch, A.AJID, B.FPID,
    B.FPHM, TO_DATE(B.JZRQ,'YYYYMMDD'),FUNC_BXGSDM_PZ('TB_YYXX', b.YYID, '592', '0',NULL,NULL),
    TO_DATE(B.RYRQ,'YYYYMMDD'), TO_DATE(B.CYRQ,'YYYYMMDD'), NVL(B.ZFZE,0),
    NULL, (SELECT SUBSTR(AAB301,1,4) FROM AA26 WHERE AAB301 = (SELECT SUBSTR(XZQHDM,1,2)||'0000' FROM TB_YYXX WHERE YYID=B.YYID)),(SELECT SUBSTR(AAB301,1,4) FROM AA26 WHERE AAB301 = (SELECT SUBSTR(XZQHDM,1,4)||'00' FROM TB_YYXX WHERE YYID=B.YYID)),
    FUNC_BXGSDM_PZ('TB_YYXX', B.YYID, '592', '0',NULL,NULL), NVL(B.FPZE,0), FUNC_BXGSDM_PZ('SJLX', ((SELECT T.AAA102 FROM AA10 T WHERE T.AAA100='SJLX' AND T.AAA102=B.SJLX)||'-'||(SELECT T.AAA102 FROM AA10 T WHERE T.AAA100='ZDLX' AND T.AAA102=B.ZDLX)), '592', '0',NULL,NULL),
    NVL(B.FPZE,0)-NVL(B.FLZFZE,0)-NVL(B.ZFZE,0),NVL(B.TCZFE,0),DECODE(NVL(B.QTSBLX,0),'07',SBZFE),
    NVL(DECODE(B.SJLX, '03', B.FPZE),0), NVL(B.ZFYJE,0),
    NVL(B.FLZFZE,0),NVL(B.ZFZE,0),
    NVL(B.DSFZFJE,0),FUNC_BXGSDM_PZ('TB_JBKXX', NVL(M.ZDDM,'R68'), '592', '0',NULL,NULL), NULL,
    B.SSDM, (SELECT DISTINCT CZA001 FROM AA10 WHERE AAA100='SSDM' AND AAA102=B.SSDM),TO_DATE(B.JZRQ,'YYYYMMDD'),
    TO_DATE(NVL(B.CYRQ,B.JZRQ),'YYYYMMDD'),(select AAA103 from aa10 where aaa100='ZDLX' AND AAA102=B.ZDLX),B.ZDLX, NVL(FJZFE,0)+NVL(SBZFE,0),
    NVL(C.REGISTER_FEE,0), NVL(C.WESTERN_MED_FEE,0),NVL(C.CHINESE_MED_FEE,0),
    NVL(C.HERBAL_MED_FEE,0), NVL(C.TEST_FEE,0),NVL(C.X_RAY_FEE,0),
    NVL(C.B_SONIC_FEE,0),NVL(C.CT_FEE,0),NVL(C.MRI_FEE,0),
    NVL(C.EXAMINE_FEE,0), NVL(C.CURE_FEE,0), NVL(C.MATERIAL_FEE,0),
    NVL(C.SURGERY_FEE,0), NVL(C.OXYGEN_FEE,0), NVL(C.TRANSFUSE_FEE,0),
    NVL(C.REMEDY_FEE,0), NVL(C.PROSTH_FEE,0), NVL(C.LAW_AUTH_FEE,0),
    NVL(C.OTHER_FEE,0), NVL(C.BED_FEE,0), B.ZYTS,
    NVL(C.NURSE_FEE,0), NVL(C.HOSPITAL_FEE,0), NVL(C.URGENT_SAVE_FEE,0),
    NVL(C.AMBULANCE_FEE,0), NVL(C.NATION_MED_FEE,0), NVL(C.SELF_MADE_FEE,0),
    NVL(C.PRESCRIPTION_FEE,0),SYSDATE,M.PFZRDM ,M.ZPAH
  FROM TB_LPAJXX A, TB_LPFPXX B, TB_LPPCXX T, TB_FPFYDLXX C,TB_FDXX S,TB_ZPAXX M,
(SELECT T.ZPAID,M.FPID FROM TB_ZPAXXDZB T,TB_FPXXFYXX M WHERE
T.XXID = M.XXID
AND AJID IN(SELECT A.AJID
FROM TB_LPAJXX A, TB_LPFPXX B, TB_LPPCXX T, TB_FPFYDLXX C
  WHERE T.PCID = A.LPPCID
  AND A.BXGSID = '592'
  AND B.AJID = A.AJID
  AND B.FPID = C.FPID(+)
  AND A.AJZT='09'
  AND (A.AJJL NOT IN('06','07') OR A.AJJL IS NULL))
  GROUP BY T.ZPAID,M.FPID
  UNION ALL
  SELECT ZPAID,FPID FROM(
  SELECT A.ZPAID,MAX(NVL(A.FPID,S.FPID)) FPID FROM TB_ZPAXX A,TB_LPFPXX S
  WHERE A.AJID=S.AJID
  AND ((A.SFSDTJ='1') OR(A.PFZRDM LIKE 'HI%'))
  AND (S.FPID,A.ZPAID) NOT IN(SELECT M.FPID,T.ZPAID FROM TB_ZPAXXDZB T,TB_FPXXFYXX M WHERE T.XXID = M.XXID AND T.AJID IN(SELECT A.AJID
FROM TB_LPAJXX A, TB_LPFPXX B, TB_LPPCXX T, TB_FPFYDLXX C
  WHERE T.PCID = A.LPPCID
  AND A.BXGSID = '592'
  AND B.AJID = A.AJID
  AND B.FPID = C.FPID(+)
  AND A.AJZT='09'
  AND (A.AJJL NOT IN('06','07') OR A.AJJL IS NULL))
  )GROUP BY A.ZPAID,A.AJID)
  )N
  WHERE T.PCID = A.LPPCID
  AND A.BXGSID = '592'
  AND ((T.PCH=p_Pch AND p_Pch IS NOT NULL) OR (p_Pch IS NULL))
  AND B.AJID = A.AJID
  AND B.FPID = C.FPID(+)
  --AND A.SFRQ >= TO_CHAR(SYSDATE-10,'YYYYMMDD')
  AND A.AJZT IN ('09')
  AND (A.AJJL NOT IN('06','07') OR A.AJJL IS NULL)
  AND A.FDID=S.FDID
  AND N.FPID=B.FPID
  --AND N.FPID=C.FPID  -- -V1.1
  AND M.ZPAID=N.ZPAID
  AND M.AJID=B.AJID
  AND NVL(S.WBBDH,S.KHBDH)=p_Wbbdh;

    i_step := 5;
  UPDATE TB_AL_CLOSE_FPXX A
  SET A.DIAGNOSIS = (SELECT BZW FROM TB_JBKXX WHERE JBDM = (SELECT DECODE(M.ZDDM,'001','R68','','R68',M.ZDDM) FROM TB_ZPAXX M WHERE M.ZPAH=A.WD_SUBCLAIM_NO))
  WHERE A.PCH = sPch;



  FOR cc IN c_Ajxx LOOP
    sJbms := '';
    FOR cjbxx IN c_Fpxx(cc.AJID) LOOP
      BEGIN
        SELECT JBMC
        INTO  sJbmc
        FROM TB_JBKXX
        WHERE JBDM = cjbxx.JBDM;
      EXCEPTION
          WHEN NO_DATA_FOUND THEN
              sJbmc := '';
        END;

        i_step := 6;
      UPDATE TB_AL_CLOSE_FPXX T
      SET T.CLAIM_INFO_DESC = sJbmc||(SELECT decode(substr(t.pfzrdm,1,3),'MAT','??',A.AAA103) FROM AA10 A,TB_LPFPXX B WHERE A.AAA100='ZDLX' AND A.AAA102=B.ZDLX AND B.FPID = T.FPID)
      WHERE T.AJID = cc.AJID
      AND T.PCH=sPch
      AND T.WD_SUBCLAIM_NO = cjbxx.ZPAH;
      --sJbms :=substrb( sJbms || sJbmc,1,1024);
      ---?????????????????????,?????????
      IF cjbxx.ZPAJL NOT IN('02') AND cjbxx.SJPFJE<>0 THEN
        UPDATE TB_AL_CLOSE_FPXX A
        --SET A.CLAIM_LETTER_DESC = SF_P1_GET_STRGZSM1(cjbxx.zpaid)
        SET A.CLAIM_LETTER_DESC = '?????????????,?????????'
        WHERE A.AJID = cc.AJID
        AND A.PCH=sPch
        AND A.WD_SUBCLAIM_NO = cjbxx.ZPAH
        AND A.PFZRDM=cjbxx.PFZRDM;
      END IF;

      ----???????0????????0??????XX?+???????2???????0???????+???????2???????????????????????,?????????
      IF cjbxx.ZPAJL NOT IN('02') AND cjbxx.SJPFJE=0 THEN
        IF NVL(TRIM(cjbxx.MPE),0)<>0  THEN
          UPDATE TB_AL_CLOSE_FPXX A
          SET A.CLAIM_LETTER_DESC = '???:'||cjbxx.MPE||'?'||(SELECT DECODE(TRIM(JLSM2),NULL,'',','||TRIM(JLSM2))FROM TB_ZPAXX WHERE ZPAID=cjbxx.ZPAID)
          WHERE A.AJID = cc.AJID
          AND A.PCH=sPch
          AND A.WD_SUBCLAIM_NO = cjbxx.zpaH
          AND A.PFZRDM=cjbxx.PFZRDM;
        ELSE
            UPDATE TB_AL_CLOSE_FPXX A
            ---SET A.CLAIM_LETTER_DESC = '????'||(SELECT DECODE(TRIM(JLSM2),NULL,'',','||TRIM(JLSM2))FROM TB_ZPAXX WHERE ZPAID=cjbxx.ZPAID)
            SET A.CLAIM_LETTER_DESC='?????????????,?????????'
            WHERE A.AJID = cc.AJID
            AND A.PCH=sPch
            AND A.WD_SUBCLAIM_NO = cjbxx.zpaH
            AND A.PFZRDM=cjbxx.PFZRDM;
        END IF;
      END IF;

      IF cjbxx.PFZRDM LIKE 'HI%' THEN
        UPDATE TB_AL_CLOSE_FPXX S
        SET S.CLAIM_LETTER_DESC = '???????????'
        WHERE S.AJID = cc.AJID
        AND S.PCH=sPch
        AND S.WD_SUBCLAIM_NO=cjbxx.zpaH
        AND cjbxx.PFZRDM=S.PFZRDM;
      END IF;

      sLetter_Desc := '';
      FOR cpasm IN c_Pasm(cjbxx.ZPAH,cjbxx.ZDLX) LOOP

        IF (INSTR(sLetter_Desc,cpasm.CLAIM_LETTER_DESC) = 0) OR (INSTR(sLetter_Desc,cpasm.CLAIM_LETTER_DESC) IS NULL) THEN
          sLetter_Desc := sLetter_Desc || cpasm.CLAIM_LETTER_DESC || ',';

        END IF;
      END LOOP;
      sLetter_Desc :=substr( sLetter_Desc,1,LENGTH(sLetter_Desc)-1);
      UPDATE TB_AL_CLOSE_FPXX T
      SET T.CLAIM_LETTER_DESC = sLetter_Desc
      WHERE T.AJID = cc.AJID
      AND T.ZDLX = cjbxx.ZDLX
      AND T.WD_SUBCLAIM_NO=cjbxx.ZPAH
      AND T.PFZRDM=cjbxx.PFZRDM;
    END LOOP;

  END LOOP;

  ---?????
  i_step := 7;
  INSERT INTO TB_AL_CLOSE_EXPORT
    (YWLSH, PCH,
    WD_BATCH_NO, WD_CLAIM_NO, WD_SUBCLAIM_NO,
    CASE_STATUS, CLAIM_CASE_NO, SUB_CASE_NO,
    POLICY_REF, SUB_POLICY_REF, CLAIM_ACCEPT_DATE,
    CLAIM_REG_DATE, CLAIM_APPROVE_DATE, BPO_ENTRY_USER,
    BPO_VAL_USER, DATE_OF_LOSS, CLAIM_HOSPITAL,
    IN_HOSPITAL_DATE, OUT_HOSPITAL_DATE, CAUSE_OF_LOSS,
    LOSS_TYPE, LOSS_DATE_FOR_BJ, CAUSE_OF_LOSS_BJ,
    COVER_CODE, BENEFIT_CODE, BEN_RECEIPT_AMT,
    SELF_PAID_AMT, THIRD_PAY_AMT, CLAIM_TIMES,
    CLAIM_INFO_DESC, CLAIM_LETTER_DESC, CLAIM_DECISION,
    BENIFIARY_NAME, REL_TO_INS, BANK_CATEGORY_ID,
    ACCOUNT_PROVINCE, ACCOUNT_CITY, ACCOUNT_NO,
    PAYOUT_AMT, RECEIPT_NO, HOSPITAL_CODE,
    AREA, BILL_AMOUNT, RECEIPT_TYPE,
    SOCIAL_AMOUNT, SOCIAL_WHOLE_AMOUNT, FUND_AMT,
    SPECIAL_DESEASE, PERSONAL_PAID_1, PERSONAL_PAID_2,
    PERSONAL_PAID_3, THIRD_PARTY_AMT, ICD_CODE,
    DIAGNOSIS, SURGERY_CODE, SURGERY_TYPE,
    SERVICE_DATE_FROM, SERVICE_DATE_TO, I_O_2,
    SOCIAL_PAID_AMT, REGISTER_FEE, WESTERN_MED_FEE,
    CHINESE_MED_FEE, HERBAL_MED_FEE, TEST_FEE,
    X_RAY_FEE, B_SONIC_FEE, CT_FEE,
    MRI_FEE, EXAMINE_FEE, CURE_FEE,
    MATERIAL_FEE, SURGERY_FEE, OXYGEN_FEE,
    TRANSFUSE_FEE, REMEDY_FEE, PROSTH_FEE,
    LAW_AUTH_FEE, OTHER_FEE, BED_FEE,
    HOSPITAL_DAYS, NURSE_FEE, HOSPITAL_FEE,
    URGENT_SAVE_FEE, AMBULANCE_FEE, NATION_MED_FEE,
    SELF_MADE_FEE, PRESCRIPTION_FEE, EXPORT_DATE, AJID, ZDLX, JBDM
    )
  SELECT
    FUNC_GENERATE_LSH('0107'), sPch,
    A.WD_BATCH_NO, A.WD_CLAIM_NO, NVL(A.WD_SUBCLAIM_NO,'????'),
    A.CASE_STATUS, A.CLAIM_CASE_NO, A.SUB_CASE_NO,
    A.POLICY_REF, A.SUB_POLICY_REF, A.CLAIM_ACCEPT_DATE,
    A.CLAIM_REG_DATE, A.CLAIM_APPROVE_DATE, A.BPO_ENTRY_USER,
    A.BPO_VAL_USER, B.DATE_OF_LOSS, B.CLAIM_HOSPITAL,
    B.IN_HOSPITAL_DATE, B.OUT_HOSPITAL_DATE, A.CAUSE_OF_LOSS,
    A.LOSS_TYPE, A.LOSS_DATE_FOR_BJ, A.CAUSE_OF_LOSS_BJ,
    A.COVER_CODE, A.BENEFIT_CODE, A.BEN_RECEIPT_AMT,
    B.SELF_PAID_AMT, A.THIRD_PAY_AMT, A.CLAIM_TIMES,
    B.CLAIM_INFO_DESC, NVL(A.CLAIM_LETTER_DESC,B.CLAIM_LETTER_DESC), A.CLAIM_DECISION,
    A.BENIFIARY_NAME, A.REL_TO_INS, A.BANK_CATEGORY_ID,
    A.ACCOUNT_PROVINCE, A.ACCOUNT_CITY, A.ACCOUNT_NO,
    NVL(A.PAYOUT_AMT,0), A.RECEIPT_NO, B.HOSPITAL_CODE,
    A.AREA, B.BILL_AMOUNT, B.RECEIPT_TYPE,
    B.SOCIAL_AMOUNT, B.SOCIAL_WHOLE_AMOUNT, B.FUND_AMT,
    B.SPECIAL_DESEASE, B.PERSONAL_PAID_1, B.PERSONAL_PAID_2,
    B.PERSONAL_PAID_3, B.THIRD_PARTY_AMT, B.ICD_CODE,
    B.DIAGNOSIS, B.SURGERY_CODE, B.SURGERY_TYPE,
    B.SERVICE_DATE_FROM, B.SERVICE_DATE_TO, B.I_O_2,
    B.SOCIAL_PAID_AMT, B.REGISTER_FEE, B.WESTERN_MED_FEE,
    B.CHINESE_MED_FEE, B.HERBAL_MED_FEE, B.TEST_FEE,
    B.X_RAY_FEE, B.B_SONIC_FEE, B.CT_FEE,
    B.MRI_FEE, B.EXAMINE_FEE, B.CURE_FEE,
    B.MATERIAL_FEE, B.SURGERY_FEE, B.OXYGEN_FEE,
    B.TRANSFUSE_FEE, B.REMEDY_FEE, B.PROSTH_FEE,
    B.LAW_AUTH_FEE, B.OTHER_FEE, B.BED_FEE,
    B.HOSPITAL_DAYS, B.NURSE_FEE, B.HOSPITAL_FEE,
    B.URGENT_SAVE_FEE, B.AMBULANCE_FEE, B.NATION_MED_FEE,
    B.SELF_MADE_FEE, B.PRESCRIPTION_FEE,SYSDATE, A.AJID, C.ZDLX, B.ICD_CODE
  FROM TB_AL_CLOSE_AJXX A, TB_AL_CLOSE_FPXX B, TB_LPFPXX C
  WHERE A.AJID = B.AJID
  AND A.FPID = B.FPID
  AND A.PCH = B.PCH
  AND A.PCH = sPch
  AND B.FPID = C.FPID
  AND A.WD_SUBCLAIM_NO=B.WD_SUBCLAIM_NO;

  ----??CLAIM_CASE_NO
  FOR cc IN c_Pcxx LOOP
    ---?????
    i_step := 71;
    UPDATE TB_AL_CLOSE_EXPORT B
    SET B.CLAIM_CASE_NO = (SELECT DISTINCT (SUBSTR(NVL(T.CLAIM_CASE_NO,'CL7'), 1, 3) ||
                                          TRIM(TO_CHAR(NVL(TO_NUMBER(SUBSTR(T.CLAIM_CASE_NO,
                                                                             4,
                                                                             5)),
                                                            0) + 1,
                                                        '00000')))
                            FROM TB_AL_CLOSE_EXPORT T
                           WHERE NVL(T.CLAIM_CASE_NO,'CL700000') IN
                                 (SELECT NVL(MAX(A.CLAIM_CASE_NO),'CL700000')
                                    FROM TB_AL_CLOSE_EXPORT A WHERE A.CLAIM_CASE_NO LIKE 'CL7%'))
    WHERE B.WD_BATCH_NO = cc.PCH
    AND B.POLICY_REF=cc.WBBDH
    AND B.PCH=sPch;
     FOR ccpaxx IN c_Paxx(cc.PCH) LOOP
       i_step := 72;
       SELECT COUNT(1)
       INTO i_Count
       FROM TB_AL_CLOSE_EXPORT T
       WHERE T.WD_SUBCLAIM_NO=CCPAXX.ZPAH
       AND T.BENEFIT_CODE IN('MBRY','MBRN')
       AND T.PCH=sPch;
       ----add by jyy 2014-10-20 ??????????????? ??????
       ----??? ??????
       IF i_Count > 0 THEN
         UPDATE TB_AL_CLOSE_EXPORT S
        SET S.SUB_CASE_NO = S.CLAIM_CASE_NO||TRIM(TO_CHAR(ccpaxx.XH,'000'))
       WHERE S.AJID = ccpaxx.AJID
       AND S.WD_SUBCLAIM_NO = ccpaxx.ZPAH
       ---AND S.ZDLX = ccpaxx.ZDLX
       AND S.PCH = sPch;

       -----???
       ELSE
         UPDATE TB_AL_CLOSE_EXPORT S
        SET S.SUB_CASE_NO = S.CLAIM_CASE_NO||TRIM(TO_CHAR(ccpaxx.XH,'000'))
       WHERE S.AJID = ccpaxx.AJID
       AND S.WD_SUBCLAIM_NO = ccpaxx.ZPAH
       AND S.ZDLX = ccpaxx.ZDLX
       AND S.PCH = sPch;

       END IF;

    END LOOP;


  END LOOP;

  i_step := 73;
   UPDATE TB_AL_CLOSE_EXPORT S
   SET S.PAYOUT_AMT = (SELECT NVL(T.SJPFJE,0) FROM TB_ZPAXX T WHERE  T.ZPAH = S.WD_SUBCLAIM_NO AND T.AJID=S.AJID)
   WHERE S.PCH = sPch;

  i_step := 74;
    UPDATE TB_AL_CLOSE_EXPORT S
 SET S.PAYOUT_AMT=(
 SELECT G.PAYOUT_AMT FROM(
SELECT SUM(NVL(PAYOUT_AMT,0))PAYOUT_AMT,WD_CLAIM_NO,SUB_CASE_NO,PCH FROM(
 SELECT DISTINCT(WD_CLAIM_NO),WD_SUBCLAIM_NO,SUB_CASE_NO,PAYOUT_AMT,PCH
                                 FROM TB_AL_CLOSE_EXPORT
                                WHERE PCH = sPch)
                                GROUP BY WD_CLAIM_NO,SUB_CASE_NO,PCH)G
 WHERE G.SUB_CASE_NO = S.SUB_CASE_NO AND G.PCH=S.PCH

               )
      WHERE S.PCH=sPch;

   ---?DATE_OF_LOSS???????????????----
  i_step := 80;
  UPDATE TB_AL_CLOSE_EXPORT AA
   SET AA.DATE_OF_LOSS = (SELECT H.DATE_OF_LOSS
                            FROM (SELECT MIN(T.DATE_OF_LOSS) AS DATE_OF_LOSS,
                                         T.SUB_CASE_NO,
                                         T.PCH
                                    FROM TB_AL_CLOSE_EXPORT T
                                   GROUP BY T.SUB_CASE_NO, T.PCH) H
                           WHERE H.PCH = AA.PCH
                             AND H.SUB_CASE_NO = AA.SUB_CASE_NO)
   WHERE AA.PCH = sPch;

  i_step := 81;
  UPDATE TB_AL_CLOSE_EXPORT AA
     SET AA.LOSS_DATE_FOR_BJ = (SELECT H.LOSS_DATE_FOR_BJ
                                FROM (SELECT MIN(T.LOSS_DATE_FOR_BJ) AS LOSS_DATE_FOR_BJ,
                                             T.SUB_CASE_NO,
                                             T.PCH
                                        FROM TB_AL_CLOSE_EXPORT T
                                       GROUP BY T.SUB_CASE_NO, T.PCH) H
                               WHERE H.PCH = AA.PCH
                                 AND H.SUB_CASE_NO = AA.SUB_CASE_NO)
   WHERE AA.PCH = sPch;



  -----??SUB_CASE_NO?????????001??
  --i_step := 89;
  --UPDATE TB_AL_CLOSE_EXPORT S
  --SET S.SUB_CASE_NO = TRIM(SUBSTR(S.CLAIM_CASE_NO,1,8))||(SELECT TRIM(XH) FROM(
  --SELECT WD_CLAIM_NO,TO_CHAR(ROWNUM,'000') AS XH FROM(
  --SELECT WD_CLAIM_NO,ROWNUM FROM(
  --SELECT DISTINCT(A.WD_CLAIM_NO)WD_CLAIM_NO,A.WD_BATCH_NO,C.ZDLX FROM TB_AL_CLOSE_EXPORT A, TB_LPAJXX B, TB_LPFPXX C WHERE A.PCH=sPch
  --AND A.WD_CLAIM_NO = B.PAH AND B.AJID=C.AJID
  --ORDER BY WD_CLAIM_NO ASC,C.ZDLX
  --)))G WHERE G.WD_CLAIM_NO = S.WD_CLAIM_NO AND G.WD_BATCH_NO = S.WD_BATCH_NO)
  --WHERE A.PCH=sPch;
  UPDATE TB_AL_CLOSE_EXPORT
  SET CLAIM_INFO_DESC = REPLACE(CLAIM_INFO_DESC,',','?'),
  CLAIM_LETTER_DESC = REPLACE(REPLACE(CLAIM_LETTER_DESC,',','?'),' ','')
  WHERE PCH=sPch;

  -----?????
  i_step := 82;
  update tb_al_close_export c
  set c.wlj='Y'
  WHERE C.YWLSH IN(
  SELECT YWLSH FROM(
  select g.wd_claim_no,min(ywlsh)as ywlsh from(
  select t.wd_claim_no,t.ywlsh from tb_al_close_export t  where t.pch=sPch
  and t.DESCRIPTION IS  NULL  ORDER BY t.CLAIM_CASE_NO ASC,t.SUB_CASE_NO ASC,t.ywlsh asc)g group by g.wd_claim_no));

  i_step := 821;
  UPDATE TB_AL_CLOSE_EXPORT C
  SET C.WLJ='N'
  WHERE C.WLJ IS NULL
  AND C.PCH=sPch;
  --
  -----?????????
  i_step := 822;
  update tb_al_close_export c
  set c.cgfps=(select m.cgfps from(
  select decode(sign(count(1)-8),0,'0','-1','0',count(1)-8) as cgfps,s.wd_claim_no from(
  select t.wd_claim_no,t.ywlsh from tb_al_close_export t  where t.pch=sPch
  and t.DESCRIPTION IS  NULL  ORDER BY t.CLAIM_CASE_NO ASC,t.SUB_CASE_NO ASC,t.ywlsh asc)s
  group by s.wd_claim_no)m where C.wlj='Y' AND M.wd_claim_no=C.wd_claim_no)
  where C.PCH=sPch
  AND C.WLJ='Y';
  --
  i_step := 823;
  UPDATE tb_al_close_export c
  SET C.CGFPS='0'
  where C.PCH=sPch
  AND C.WLJ='N';
  i_step := 83;
  UPDATE TB_AL_CLOSE_EXPORT
  SET DESCRIPTION = '????????????????????'
  WHERE PCH=sPch
  AND WD_BATCH_NO IN (SELECT WD_BATCH_NO FROM (SELECT DISTINCT(WD_BATCH_NO),COUNT(1)
  FROM TB_AL_CLOSE_EXPORT
  WHERE PCH=sPch
  AND ((COVER_CODE IS NULL) OR(BENEFIT_CODE IS NULL)OR(ICD_CODE IS NULL)OR(CLAIM_LETTER_DESC IS NULL)OR(CLAIM_CASE_NO IS NULL)OR(SUB_CASE_NO IS NULL))
  HAVING COUNT(1)>1
  GROUP BY WD_BATCH_NO));

  ----???????????????????????
   i_step := 84;
  UPDATE TB_AL_CLOSE_EXPORT
  SET DESCRIPTION = '??????????????????????????????'
  WHERE PCH=sPch
  AND WD_BATCH_NO IN (SELECT WD_BATCH_NO FROM (SELECT DISTINCT(WD_BATCH_NO),COUNT(1)
  FROM TB_AL_CLOSE_EXPORT
  WHERE PCH=sPch
  AND CLAIM_DECISION NOT IN('0')
  AND ((BANK_CATEGORY_ID IS NULL)OR(ACCOUNT_NO IS NULL) OR(ACCOUNT_PROVINCE IS NULL) OR(ACCOUNT_CITY IS NULL) )
  HAVING COUNT(1)>1
  GROUP BY WD_BATCH_NO));
  i_step := 9;
  UPDATE TB_AL_CLOSE_CZJL
  SET JSSJ = SYSDATE
  WHERE PCH = sPch;


  -----???????????????
  i_step := 82;
  UPDATE TB_LPAJXX A
  SET A.WBPAZH = (SELECT DISTINCT(CLAIM_CASE_NO) FROM TB_AL_CLOSE_EXPORT WHERE AJID = A.AJID AND PCH=sPch),
    A.WBPAFH = (SELECT MIN(SUB_CASE_NO) FROM TB_AL_CLOSE_EXPORT WHERE AJID = A.AJID AND PCH=sPch)||'-'||(SELECT SUBSTR(MAX(SUB_CASE_NO),9,3) FROM TB_AL_CLOSE_EXPORT WHERE AJID = A.AJID AND PCH=sPch)
  WHERE EXISTS(SELECT 1 FROM TB_AL_CLOSE_EXPORT WHERE AJID = A.AJID AND PCH=sPch);



  ----???????CSV?????  ,WLJ as ???,CGFPS as ??8????

  COMMIT;
  i_step := 10;
  SELECT 'RETURN_'||TO_CHAR(SYSDATE,'YYYYMMDD')||'_'||to_char(sysdate+numtodsinterval(p_Xh,'SECOND'),'hh24miss')||'.CSV'
  INTO sWjm
  FROM DUAL;

  BEGIN
    sSql := 'select WD_BATCH_NO, WD_CLAIM_NO, WD_SUBCLAIM_NO,CASE_STATUS,CLAIM_CASE_NO,SUB_CASE_NO, POLICY_REF AS POLICY_REF, SUB_POLICY_REF AS SUB_POLICY_REF, to_char(CLAIM_ACCEPT_DATE,'||''''||'YYYYMMDD'||''''||')AS CLAIM_ACCEPT_DATE, TO_CHAR(CLAIM_REG_DATE,'||''''||'YYYYMMDD'||''''||')AS CLAIM_REG_DATE, TO_CHAR(CLAIM_APPROVE_DATE,'||''''||'YYYYMMDD'||''''||')AS CLAIM_APPROVE_DATE, BPO_ENTRY_USER, BPO_VAL_USER, TO_CHAR(DATE_OF_LOSS,'||''''||'YYYYMMDD'||''''||')AS DATE_OF_LOSS, CLAIM_HOSPITAL, TO_CHAR(IN_HOSPITAL_DATE,'||''''||'YYYYMMDD'||''''||') IN_HOSPITAL_DATE, TO_CHAR(OUT_HOSPITAL_DATE,'||''''||'YYYYMMDD'||''''||')OUT_HOSPITAL_DATE, HOSPITAL_DAYS, CAUSE_OF_LOSS,LOSS_TYPE, TO_CHAR(LOSS_DATE_FOR_BJ,'||''''||'YYYYMMDD'||''''||')LOSS_DATE_FOR_BJ, CAUSE_OF_LOSS_BJ, COVER_CODE, BENEFIT_CODE, BEN_RECEIPT_AMT, SELF_PAID_AMT, THIRD_PAY_AMT, CLAIM_TIMES, CLAIM_INFO_DESC, CLAIM_LETTER_DESC, CLAIM_DECISION, BENIFIARY_NAME, REL_TO_INS, BANK_CATEGORY_ID, ACCOUNT_PROVINCE,ACCOUNT_CITY, ACCOUNT_NO, PAYOUT_AMT, RECEIPT_NO, HOSPITAL_CODE, AREA, BILL_AMOUNT, RECEIPT_TYPE, SOCIAL_AMOUNT, SOCIAL_WHOLE_AMOUNT, FUND_AMT, SPECIAL_DESEASE, PERSONAL_PAID_1, PERSONAL_PAID_2,PERSONAL_PAID_3, THIRD_PARTY_AMT, ICD_CODE, DIAGNOSIS,SURGERY_CODE,SURGERY_TYPE,TO_CHAR(SERVICE_DATE_FROM,'||''''||'YYYYMMDD'||''''||')SERVICE_DATE_FROM,TO_CHAR(SERVICE_DATE_TO,'||''''||'YYYYMMDD'||''''||')SERVICE_DATE_TO,I_O_2,SOCIAL_PAID_AMT,REGISTER_FEE,WESTERN_MED_FEE,CHINESE_MED_FEE,HERBAL_MED_FEE,TEST_FEE,X_RAY_FEE,B_SONIC_FEE,CT_FEE,MRI_FEE,EXAMINE_FEE,CURE_FEE,MATERIAL_FEE,SURGERY_FEE,OXYGEN_FEE,TRANSFUSE_FEE,REMEDY_FEE,PROSTH_FEE,LAW_AUTH_FEE,OTHER_FEE,BED_FEE,NURSE_FEE,HOSPITAL_FEE,URGENT_SAVE_FEE,AMBULANCE_FEE,NATION_MED_FEE,SELF_MADE_FEE,PRESCRIPTION_FEE,WLJ AS ???,CGFPS AS ??8????   from TB_AL_CLOSE_EXPORT WHERE PCH='||sPch || ' AND DESCRIPTION IS  NULL ORDER BY CLAIM_CASE_NO ASC,SUB_CASE_NO ASC,YWLSH asc';
    --i_step := 101;
    --EXECUTE IMMEDIATE 'create directory MYDIR as '||''''||v_dname||'''';
    --execute immediate v_sqlstr;
    --i_step := 102;
    --EXECUTE IMMEDIATE 'grant read,write on directory MYDIR to public';
    i_step := 11;
    sql_to_csv(sSql,'MYDIR',sWjm);
    --EXECUTE IMMEDIATE 'DROP directory MYDIR';
    i_step := 8;
  ---??????????????????????????????????11?
  UPDATE TB_LPAJXX A
  SET A.AJZT = '11'
  WHERE A.AJID IN(SELECT A.AJID FROM TB_AL_CLOSE_AJXX A,TB_AL_CLOSE_EXPORT B WHERE A.PCH=sPch AND A.PCH=B.PCH AND A.WD_BATCH_NO=B.WD_BATCH_NO
  AND A.WD_CLAIM_NO=B.WD_CLAIM_NO AND A.WD_SUBCLAIM_NO=B.WD_SUBCLAIM_NO
  AND B.DESCRIPTION IS NULL);
  COMMIT;
  END;
  RETURN;
EXCEPTION
  WHEN OTHERS THEN
      p_RtnCode := SQLCODE;
      p_RtnMsg := SQLERRM;
      ROLLBACK;
      Pkg_Error_Log.Pro_Error_In('PROC_ALCLOSE_EXPORT', i_step, p_RtnCode, p_RtnMsg);
END PROC_ALCLOSE_EXPORT;

/
