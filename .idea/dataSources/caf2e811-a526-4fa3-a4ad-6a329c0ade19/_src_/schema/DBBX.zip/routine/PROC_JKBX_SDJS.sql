CREATE PROCEDURE      "PROC_JKBX_SDJS" IS
	i_step  NUMBER(9);
	p_RtnCode NUMBER;
	p_RtnMsg VARCHAR2(512);
	CURSOR c_Sdsj IS
		SELECT  DISTINCT(a.PCH)as PCH
		FROM TB_LOCK_IMPORT A
		WHERE  A.ZT = '0';
BEGIN
	i_step := 1;
	FOR cc IN c_Sdsj LOOP
		--IF cc.PCH IN('2','3') THEN
			PROC_LOCK_IMOPRT(cc.PCH,p_RtnCode,p_RtnMsg);
			PROC_LOCK(cc.PCH,p_RtnCode,p_RtnMsg);
			PROC_UNLOCK(cc.PCH,p_RtnCode,p_RtnMsg);
		--END IF;

	END LOOP;
EXCEPTION
	WHEN OTHERS THEN
        p_RtnCode := SQLCODE;
        p_RtnMsg := SQLERRM;
        ROLLBACK;
        Pkg_Error_Log.Pro_Error_In('PROC_JKBX_SDJS', i_step, p_RtnCode, p_RtnMsg);
END PROC_JKBX_SDJS;

/
