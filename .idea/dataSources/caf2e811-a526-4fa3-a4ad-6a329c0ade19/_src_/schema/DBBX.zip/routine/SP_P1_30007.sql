CREATE PROCEDURE      "SP_P1_30007" (report_id   In t_report_def_info.REPORTID%TYPE,
                                        pStartdate  IN varchar2, -- ??????yyyymmdd
                                        pEnddate    IN varchar2, -- ??????yyyymmdd
                                        pStatman    IN t_report_gen_info.STATMAN%TYPE, --???
                                        ptype       in varchar2, /*0 ???? ,1 ?? 2 ?? 3 ?? */ --?????
                                        POther1     IN varchar2, --??id
                                        POther2     IN varchar2, --??id
                                        POther3     IN varchar2, --??id
                                        POther4     IN varchar2, --??ID
                                        POther5     IN varchar2, --????
                                        POther6     IN varchar2, --??ID
                                        POther7     IN varchar2, --??
                                        POther8     IN varchar2, --??
                                        PReturnCode OUT varchar2,
                                        PReturnMsg  OUT varchar2) AS
  V_STEP_CODE  CHAR(5); --?????????????????
  vreportid    t_report_def_info.REPORTID%TYPE; --??ID
  v_start_date number := 0; --????????
  v_end_date   number := 0; --????????
  vxzqhdm      t_report_gen_info.STATORGID%TYPE; --????????????

  vstatid varchar(30); --?????????????????
  type cellType is record(
    statid  varchar2(15),
    col     number,
    r       number,
    content varchar2(1024));

  cell      cellType; --?????????????
  vdwmc     varchar2(50); --????????????
  vusername t_report_gen_info.STATMAN%TYPE; --????????
  vnd       t_report_gen_info.STATYEAR%TYPE; --????
  rowno     number := 0; --??????

  v_tthjzs number :=0;--????
  v_bdhjzs number :=0;--????
  v_ryhjzs number :=0;--????
  v_bfjezs number :=0;--???????

  vv_bdhjzs number :=0;--???????
  vv_ryhjzs number :=0;--??????


begin
  V_STEP_CODE := '00000';
  PReturnMsg  := 'OK';
  PReturnCode := 'E';
  vreportid   := substr(report_id, 1, 5);
  vusername   := pStatman;
  vnd         := substr(pStartdate, 1, 4);

  v_start_date := to_number(substr(pStartdate, 1, 8));
  v_end_date   := to_number(substr(pEnddate, 1, 8));

  --???????????????????????????
  delete from t_report_data_info
   where statid in
         (select statid from T_REPORT_GEN_INFO where reportid = report_id);

  delete from T_REPORT_GEN_INFO
   where statid in
         (select statid from T_REPORT_GEN_INFO where reportid = report_id);

  V_STEP_CODE := '00001';
  --???,?T_RERORT_GEN_INFO?????????????
  --???????
  select seq_statid.nextval into vstatid from dual;

  -- ??????????
  insert into t_report_gen_info
    (STATID,
     REPORTID,
     STATORGID,
     STATORGNAME,
     STATDATE,
     STATMAN,
     STATYEAR,
     BEGINDATE,
     ENDDATE,
     STAT_OTHER,
     STAT_TYPE)
  values
    (vstatid,
     vreportid,
     '',
     '',
     to_char(sysdate, 'yyyymmdd'),
     vusername,
     vnd,
     v_start_date,
     v_end_date,
     substr(pEnddate, 1, 1),
     trim(ptype));

  /* --?????? ??excel???0?????1??,????0???*/

   --???
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid, 0,1, 1, 'CLGL03');

  --????
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,1,2,to_char(sysdate,'yyyymmdd'));

  --????
  select max(bxgsqc) into cell.content from tb_bxgsxx where bxgsid=trim(POther1);
  if cell.content is not null then
    insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,1,4,cell.content);
  end if;
--????
 insert into t_report_data_info
      (statid, sheet, col, r, content)
    values    (vstatid,       0,       1,      3, trim(pStartdate)||'--'||trim(pEnddate));

  cell.statid := vstatid;
  cell.col    := 0; --?1???
  cell.r      := 7; --?8???
  --???????????????????????????????excel????????????????????

  for rec_bxgs in(
             select a.ttid,c.bxgsqc,
                  count(1) as col3,--????
                  round(avg(to_date(a.sfrq,'yyyy-mm-dd')-to_date(b.JHSFRQ,'yyyy-mm-dd')),2) as col4, --????
                  sum(case when ( a.sfrq<=b.JHSFRQ or (b.SFYQBZ='1' and b.YQYY='1')) then 1 else 0 end ) col5 ,--??????
                  sum(case when ( a.sfrq<=b.JHSFRQ or (b.SFYQBZ='1' and b.YQYY='1')) then 1 else 0 end )/count(1) as co16, --??????
                  sum(case when b.SFYQBZ='1' and nvl(b.YQYY,'2')!='1'  then 1 else 0 end ) col7, --??????
                  sum(case when b.SFYQBZ='1' and nvl(b.YQYY,'2')!='1'  then 1 else 0 end ) /count(1) as co18--?????
              from tb_lpajxx a,tb_lppcxx b,tb_bxgsxx c
              where a.bxgsid=c.bxgsid and a.lppcid=b.pcid and a.ajzt in('08','09','10')
                and a.sfrq is not null
                        and a.bxgsid = nvl(trim(POther1),a.bxgsid)
                        and a.sfrq > nvl(trim(pStartdate),19000101)
                        and a.sfrq < nvl(trim(pEnddate),99991231)
              group by rollup  ((a.ttid,c.bxgsqc))
       ) loop

              if rec_bxgs.ttid is null and rec_bxgs.bxgsqc is null then --?????
                   insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,0,cell.r,'??  ');
              else
                       --??????
                        cell.content := rec_bxgs.bxgsqc;
                        insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,0,cell.r,cell.content);
                        --????
                        insert into t_report_data_info (statid, sheet, col, r, content) select vstatid,0,1,cell.r,ttmc from tb_ttxx where ttid=rec_bxgs.ttid;

                        --????
                        insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,3,cell.r,rec_bxgs.col4);


                        --??????
                         insert into t_report_data_info (statid, sheet, col, r, content) select  vstatid,0,5,cell.r,case when rec_bxgs.col3 is null then '' else (to_char(round(nvl(rec_bxgs.col5,0)/rec_bxgs.col3*100,2))||'%') end as content  from dual;
                          --?????
                        select  case when rec_bxgs.col3 is null then '' else to_char(round(nvl( rec_bxgs.col7,0)/rec_bxgs.col3*100,2)||'%') end as content  into   cell.content from dual;
                        insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,7,cell.r,cell.content);


              end if;
               --????
                insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,2,cell.r,rec_bxgs.col3);
               --??????
                cell.content := rec_bxgs.col5;
                insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,4,cell.r,cell.content);
                --??????
                insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,6,cell.r,rec_bxgs.col7);
              cell.r :=  cell.r+1;
      end loop;



  --???????????
  /*9.??*/
  PReturnCode := '0'; /* ??????????????vstatid????????? */
  PReturnMsg  := vstatid;
  DBMS_OUTPUT.PUT_LINE('[LDS debug] ' || 'PReturncode= ' || PReturnCode);
  --COMMIT; ???java?????????

EXCEPTION
  WHEN OTHERS THEN
    --rollback;???java?????????????0?????????????????
    PReturnCode := 'E'; /*  ??????  */
    DBMS_OUTPUT.PUT_LINE('[yhs debug] ' || 'PReturncode= ' || PReturnCode);
    PReturnMsg := ' rownum' || cell.r || 'Error:' || sqlerrm; --???????????
    DBMS_OUTPUT.PUT_LINE(PReturnMsg);
end SP_P1_30007;

/
