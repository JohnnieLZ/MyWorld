CREATE PROCEDURE      "PRO_JOB_PRINT"
as
   begin
       --dbms_output.put_line('系统时间：' || to_char(sysdate, 'dd-mm-yyyy hh24:mi:ss'));
       insert into tab_time_cade values(sysdate);
       end;

/
