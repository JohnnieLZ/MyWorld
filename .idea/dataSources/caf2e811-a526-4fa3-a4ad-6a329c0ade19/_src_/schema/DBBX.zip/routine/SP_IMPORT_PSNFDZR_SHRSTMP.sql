CREATE procedure      SP_IMPORT_PSNFDZR_SHRSTMP(zpch IN varCHAR2 ,PReturnCode OUT varchar2,
                              PReturnMsg OUT varchar2) as
n number := 0;
m number := 0;
v_khid number := 0;
ybbs_tt number := 0;
dj_tt varchar2(100) := '';
bdsxrq_tt varchar2(100) := '';
bdzzrq_tt varchar2(100) := '';
bdgljg_tt varchar2(100) := '';
zbbxr_khbh varchar2(100) := '';
zjlx_tt varchar2(100) := '';
gx_tt varchar2(100) := '';
zbbr_xm varchar2(100) := '';
list_y TB_IMPORT_PSNFDZR%rowtype;
list_khxx tb_khxx%rowtype;
list_fdxx tb_fdxx%rowtype;
----????  TB_IMPORT_PSNFDZR_TMP  ??????????  list???
cursor list is select * from TB_IMPORT_PSNFDZR_TMP a where run_flag is null and pch=zpch;
begin
    PReturnCode:='E';
    PReturnMsg:='Error!';
    select nvl(count(1),0) into n from TB_IMPORT_PSNFDZR_TMP where RUN_FLAG is null and PCH=zpch;
    ----TB_IMPORT_PSNFDZR_TMP ?????????
    if(n > 0) then
         for list_x in list loop
           ----khh?????zjlx,zjhm,xm????
           if ((list_x.bbrxh is not null and nvl(list_x.bbrxh,'99')<> '99') or((list_x.zjlx is not null and nvl(list_x.zjlx,'99')<>'99')and (list_x.zjhm is not null and nvl(list_x.zjhm,'99')<>'99')and (list_x.xm is not null and nvl(list_x.xm,'99')<>'99')))then
           ----????ID+??????+??????????
           ----?????????
             select nvl(count(1),0) into m from(select 1 from Tb_import_psnfdzr a where a.bxgsid = list_x.bxgsid and a.bbrxh = list_x.bbrxh and a.bdh = list_x.bdh);
           ----???????
             select max(khid) into v_khid from tb_khxx t where khid in (select b.khid from tb_khxx b  where khbh=list_x.bbrxh and exists(select 'x' from tb_fdxx c where c.khbdh=list_x.bdh and c.bbrkhid=b.khid)
               union all select b.khid from tb_khxx b  where t.aac147=list_x.zjhm
                and t.xm=list_x.xm and t.csrq=TO_NUMBER(to_char(to_date(nvl(list_x.csrq,t.csrq),'yyyy-mm-dd'),'yyyymmdd')));
             ----0 ????  ????ID+??????+???  ????????????
             if(m = 0 and v_khid is null and (list_x.dj is not null and nvl(list_x.dj,'99') <> '99'))then----????????
                  insert into Tb_import_psnfdzr (
                              OP_TYPE,OP_FLAG,YWLSH,PCH,BDH,XM,XB,ZJLX,ZJHM,YBBS,GX,ZBBRXM,ZY,CKR,KHH,KHHZH,DJ,SJSXR,SJZZR,OPDATE,RUN_FLAG,BBRXH,ZBBRXH,BXGSMC,KHHSH,KZLX,BDGLJG,CLLX,BXGSID
                         )
                         values(
                              0,list_x.OP_FLAG,(select FUNC_GENERATE_LSH('0102') as ywlsh from dual),list_x.PCH,list_x.BDH,list_x.XM,to_char(to_number(list_x.XB)+1),nvl((select max(aaa102) from tb_zddmbxgsdmdzb where bxgsid='713'and aaa100 = 'ZJLX' and bxgsxmbm = list_x.ZJLX),'99'),list_x.ZJHM,case list_x.YBBS when '0' then '02'when '1' then '01' end,nvl((SELECT max(aaa102) FROM TB_ZDDMBXGSDMDZB WHERE BXGSID='713' AND aaa100='ZBBRGX'AND bxgsxmbm = list_x.GX),'99'),list_x.ZBBRXM,nvl(replace(list_x.zy,'-',''),''),replace(list_x.CKR,'?',''),replace(list_x.KHH,'?',''),replace(list_x.KHHZH,'?',''),
                              list_x.DJ,replace(list_x.SJSXR,'-',''),replace(to_char(to_date(list_x.SJZZR,'yyyy-mm-dd')-1,'yyyy-mm-dd'),'-',''),list_x.OPDATE,nvl(list_x.RUN_FLAG,''),list_x.BBRXH,list_x.ZBBRXH,list_x.BXGSMC,replace(list_x.KHHSH,'?',''),list_x.KZLX,list_x.BDGLJG,nvl(list_x.CLLX,''),list_x.BXGSID
                         );
                  delete TB_IMPORT_PSNFDZR_TMP where ywlsh = list_x.ywlsh;
              ----???????????????????
              elsif(m > 0) then
                       ----1 ??????
                      select * into list_y from (select * from TB_IMPORT_PSNFDZR a where a.bxgsid = list_x.bxgsid and a.bbrxh = list_x.bbrxh and a.bdh = list_x.bdh order by ywlsh desc) where rownum = 1;
                      select * into zjlx_tt from (select max(aaa102) from tb_zddmbxgsdmdzb where bxgsid='713'and aaa100 = 'ZJLX' and bxgsxmbm = list_x.ZJLX);
                      select * into gx_tt from (SELECT max(aaa102) FROM TB_ZDDMBXGSDMDZB WHERE BXGSID='713' AND aaa100='ZBBRGX'AND bxgsxmbm = list_x.GX);
                       if(list_x.bbrxh <> list_y.bbrxh or list_x.xm <> list_y.xm or to_char(to_number(list_x.xb)+1) <> list_y.xb or nvl(zjlx_tt,'99') <> list_y.zjlx or list_x.zjhm <> list_y.zjhm or nvl(gx_tt,'99') <> list_y.gx or list_x.zbbrxh <> list_y.zbbrxh or list_x.zbbrxm <> list_y.zbbrxm or list_x.ckr <> list_y.ckr or list_x.khh <> list_y.khh or list_x.khhzh <> list_y.khhzh or list_x.khhsh <> list_y.khhsh or list_x.kzlx <> list_y.kzlx or list_x.bdgljg <> list_y.bdgljg or nvl(gx_tt,'99') <> list_fdxx.zbbrgx)then
                         insert into Tb_import_psnfdzr (
                              OP_TYPE,OP_FLAG,YWLSH,PCH,BDH,XM,XB,ZJLX,ZJHM,YBBS,GX,ZBBRXM,ZY,CKR,KHH,KHHZH,DJ,SJSXR,SJZZR,OPDATE,RUN_FLAG,BBRXH,ZBBRXH,BXGSMC,KHHSH,KZLX,BDGLJG,CLLX,BXGSID
                         )
                         values(
                              1,list_x.OP_FLAG,(select FUNC_GENERATE_LSH('0102') as ywlsh from dual),list_x.PCH,list_x.BDH,list_x.XM,to_char(to_number(list_x.XB)+1),nvl((select max(aaa102) from tb_zddmbxgsdmdzb where bxgsid='713'and aaa100 = 'ZJLX' and bxgsxmbm = list_x.ZJLX),'99'),list_x.ZJHM,case list_x.YBBS when '0' then '02'when '1' then '01' end,nvl((SELECT max(aaa102) FROM TB_ZDDMBXGSDMDZB WHERE BXGSID='713' AND aaa100='ZBBRGX'AND bxgsxmbm = list_x.GX),'99'),list_x.ZBBRXM,nvl(replace(list_x.zy,'-',''),''),replace(list_x.CKR,'?',''),replace(list_x.KHH,'?',''),replace(list_x.KHHZH,'?',''),
                              list_x.DJ,replace(list_x.SJSXR,'-',''),replace(to_char(to_date(list_x.SJZZR,'yyyy-mm-dd')-1,'yyyy-mm-dd'),'-',''),list_x.OPDATE,nvl(list_x.RUN_FLAG,''),list_x.BBRXH,list_x.ZBBRXH,list_x.BXGSMC,replace(list_x.KHHSH,'?',''),list_x.KZLX,list_x.BDGLJG,nvl(list_x.CLLX,''),list_x.BXGSID
                         );
                       end if;
                       ----2 ??????
                       if((list_x.YBBS is not null and nvl(list_x.YBBS,'99') <> '99')and(case list_x.YBBS when '0' then '02'when '1' then '01' end <> list_y.YBBS))then
                         insert into Tb_import_psnfdzr (
                              OP_TYPE,OP_FLAG,YWLSH,PCH,BDH,XM,XB,ZJLX,ZJHM,YBBS,GX,ZBBRXM,ZY,CKR,KHH,KHHZH,DJ,SJSXR,SJZZR,OPDATE,RUN_FLAG,BBRXH,ZBBRXH,BXGSMC,KHHSH,KZLX,BDGLJG,CLLX,BXGSID
                         )
                         values(
                              2,list_x.OP_FLAG,(select FUNC_GENERATE_LSH('0102') as ywlsh from dual),list_x.PCH,list_x.BDH,list_x.XM,to_char(to_number(list_x.XB)+1),nvl((select max(aaa102) from tb_zddmbxgsdmdzb where bxgsid='713'and aaa100 = 'ZJLX' and bxgsxmbm = list_x.ZJLX),'99'),list_x.ZJHM,case list_x.YBBS when '0' then '02'when '1' then '01' end,nvl((SELECT max(aaa102) FROM TB_ZDDMBXGSDMDZB WHERE BXGSID='713' AND aaa100='ZBBRGX'AND bxgsxmbm = list_x.GX),'99'),list_x.ZBBRXM,nvl(replace(list_x.zy,'-',''),''),replace(list_x.CKR,'?',''),replace(list_x.KHH,'?',''),replace(list_x.KHHZH,'?',''),
                              list_x.DJ,replace(list_x.SJSXR,'-',''),replace(to_char(to_date(list_x.SJZZR,'yyyy-mm-dd')-1,'yyyy-mm-dd'),'-',''),list_x.OPDATE,nvl(list_x.RUN_FLAG,''),list_x.BBRXH,list_x.ZBBRXH,list_x.BXGSMC,replace(list_x.KHHSH,'?',''),list_x.KZLX,list_x.BDGLJG,nvl(list_x.CLLX,''),list_x.BXGSID
                         );
                        end if;
                       ----3 ??????
                        if((list_x.dj is not null and nvl(list_x.dj,'99') <> '99') and (list_x.dj <> list_y.dj))then----??????????
                         insert into Tb_import_psnfdzr (
                              OP_TYPE,OP_FLAG,YWLSH,PCH,BDH,XM,XB,ZJLX,ZJHM,YBBS,GX,ZBBRXM,ZY,CKR,KHH,KHHZH,DJ,SJSXR,SJZZR,OPDATE,RUN_FLAG,BBRXH,ZBBRXH,BXGSMC,KHHSH,KZLX,BDGLJG,CLLX,BXGSID
                         )
                         values(
                              3,list_x.OP_FLAG,(select FUNC_GENERATE_LSH('0102') as ywlsh from dual),list_x.PCH,list_x.BDH,list_x.XM,to_char(to_number(list_x.XB)+1),nvl((select max(aaa102) from tb_zddmbxgsdmdzb where bxgsid='713'and aaa100 = 'ZJLX' and bxgsxmbm = list_x.ZJLX),'99'),list_x.ZJHM,case list_x.YBBS when '0' then '02'when '1' then '01' end,nvl((SELECT max(aaa102) FROM TB_ZDDMBXGSDMDZB WHERE BXGSID='713' AND aaa100='ZBBRGX'AND bxgsxmbm = list_x.GX),'99'),list_x.ZBBRXM,nvl(replace(list_x.zy,'-',''),''),replace(list_x.CKR,'?',''),replace(list_x.KHH,'?',''),replace(list_x.KHHZH,'?',''),
                              list_x.DJ,replace(list_x.SJSXR,'-',''),replace(to_char(to_date(list_x.SJZZR,'yyyy-mm-dd')-1,'yyyy-mm-dd'),'-',''),list_x.OPDATE,nvl(list_x.RUN_FLAG,''),list_x.BBRXH,list_x.ZBBRXH,list_x.BXGSMC,replace(list_x.KHHSH,'?',''),list_x.KZLX,list_x.BDGLJG,nvl(list_x.CLLX,''),list_x.BXGSID
                         );
                        end if;
                       ----4 ???????
                        if((list_x.SJSXR is not null and nvl(list_x.SJSXR,'99') <> '99')and(list_x.SJZZR is not null and nvl(list_x.SJZZR,'99') <> '99')and(replace(list_x.SJSXR,'-','') <> list_y.SJSXR or replace(to_char(to_date(list_x.SJZZR,'yyyy-mm-dd')-1,'yyyy-mm-dd'),'-','') <> list_y.SJZZR))then
                         insert into Tb_import_psnfdzr (
                              OP_TYPE,OP_FLAG,YWLSH,PCH,BDH,XM,XB,ZJLX,ZJHM,YBBS,GX,ZBBRXM,ZY,CKR,KHH,KHHZH,DJ,SJSXR,SJZZR,OPDATE,RUN_FLAG,BBRXH,ZBBRXH,BXGSMC,KHHSH,KZLX,BDGLJG,CLLX,BXGSID
                         )
                         values(
                              4,list_x.OP_FLAG,(select FUNC_GENERATE_LSH('0102') as ywlsh from dual),list_x.PCH,list_x.BDH,list_x.XM,to_char(to_number(list_x.XB)+1),nvl((select max(aaa102) from tb_zddmbxgsdmdzb where bxgsid='713'and aaa100 = 'ZJLX' and bxgsxmbm = list_x.ZJLX),'99'),list_x.ZJHM,case list_x.YBBS when '0' then '02'when '1' then '01' end,nvl((SELECT max(aaa102) FROM TB_ZDDMBXGSDMDZB WHERE BXGSID='713' AND aaa100='ZBBRGX'AND bxgsxmbm = list_x.GX),'99'),list_x.ZBBRXM,nvl(replace(list_x.zy,'-',''),''),replace(list_x.CKR,'?',''),replace(list_x.KHH,'?',''),replace(list_x.KHHZH,'?',''),
                              list_x.DJ,replace(list_x.SJSXR,'-',''),replace(to_char(to_date(list_x.SJZZR,'yyyy-mm-dd')-1,'yyyy-mm-dd'),'-',''),list_x.OPDATE,nvl(list_x.RUN_FLAG,''),list_x.BBRXH,list_x.ZBBRXH,list_x.BXGSMC,replace(list_x.KHHSH,'?',''),list_x.KZLX,list_x.BDGLJG,nvl(list_x.CLLX,''),list_x.BXGSID
                         );
                        end if;
                      delete TB_IMPORT_PSNFDZR_TMP where ywlsh = list_x.ywlsh;
              ----??????????????????????????
              elsif(m = 0 and v_khid is not null and nvl(v_khid,'99') <> '99') then
                        ----1 ??????
                          ----?????
                          select * into list_khxx from tb_khxx where khid = v_khid;
                          ----?????
                          select * into list_fdxx from tb_fdxx where khbdh = list_x.bdh and bbrkhid = v_khid;
                          select * into zjlx_tt from (select max(aaa102) from tb_zddmbxgsdmdzb where bxgsid='713'and aaa100 = 'ZJLX' and bxgsxmbm = list_x.ZJLX);
                          if(list_fdxx.zbbrkhid is not null)then
                                select khbh into zbbxr_khbh from tb_khxx where khid = list_fdxx.zbbrkhid;
                                select xm into zbbr_xm from tb_khxx where  khid = list_fdxx.zbbrkhid;
                                select * into zjlx_tt from (select max(aaa102) from tb_zddmbxgsdmdzb where bxgsid='713'and aaa100 = 'ZJLX' and bxgsxmbm = list_x.ZJLX);
                                select * into gx_tt from (SELECT max(aaa102) FROM TB_ZDDMBXGSDMDZB WHERE BXGSID='713' AND aaa100='ZBBRGX'AND bxgsxmbm = list_x.ybbrgx);
                                if(list_x.xm <> list_khxx.xm or to_char(to_number(list_x.xb)+1) <> list_khxx.xb or  nvl(zjlx_tt,'99') <> list_khxx.AAC058 or list_x.zjhm <> list_khxx.AAC147 or list_x.bbrxh <> list_khxx.khbh or list_x.khhzh <> list_khxx.yhzh or list_x.khhsh <> list_khxx.KHHSZS or list_x.khh <> list_khxx.KHYH or list_x.kzlx <> list_khxx.kzlx or list_x.ckr <> list_khxx.ZHMC or list_x.bdgljg <> list_fdxx.bdgljg or nvl(gx_tt,'99') <> list_fdxx.zbbrgx or list_x.zbbrxh <> zbbxr_khbh or list_x.zbbrxm <> zbbr_xm)then
                                insert into Tb_import_psnfdzr (
                                      OP_TYPE,OP_FLAG,YWLSH,PCH,BDH,XM,XB,ZJLX,ZJHM,YBBS,GX,ZBBRXM,ZY,CKR,KHH,KHHZH,DJ,SJSXR,SJZZR,OPDATE,RUN_FLAG,BBRXH,ZBBRXH,BXGSMC,KHHSH,KZLX,BDGLJG,CLLX,BXGSID
                                 )
                                 values(
                                      1,list_x.OP_FLAG,(select FUNC_GENERATE_LSH('0102') as ywlsh from dual),list_x.PCH,list_x.BDH,list_x.XM,to_char(to_number(list_x.XB)+1),nvl((select max(aaa102) from tb_zddmbxgsdmdzb where bxgsid='713'and aaa100 = 'ZJLX' and bxgsxmbm = list_x.ZJLX),'99'),list_x.ZJHM,case list_x.YBBS when '0' then '02'when '1' then '01' end,nvl((SELECT max(aaa102) FROM TB_ZDDMBXGSDMDZB WHERE BXGSID='713' AND aaa100='ZBBRGX'AND bxgsxmbm = list_x.GX),'99'),list_x.ZBBRXM,nvl(replace(list_x.zy,'-',''),''),replace(list_x.CKR,'?',''),replace(list_x.KHH,'?',''),replace(list_x.KHHZH,'?',''),
                                      list_x.DJ,replace(list_x.SJSXR,'-',''),replace(to_char(to_date(list_x.SJZZR,'yyyy-mm-dd')-1,'yyyy-mm-dd'),'-',''),list_x.OPDATE,nvl(list_x.RUN_FLAG,''),list_x.BBRXH,list_x.ZBBRXH,list_x.BXGSMC,replace(list_x.KHHSH,'?',''),list_x.KZLX,list_x.BDGLJG,nvl(list_x.CLLX,''),list_x.BXGSID
                                 );
                               end if;
                          else
                               if(list_x.xm <> list_khxx.xm or to_char(to_number(list_x.xb)+1) <> list_khxx.xb or nvl(zjlx_tt,'99') <> list_khxx.AAC058 or list_x.zjhm <> list_khxx.AAC147 or list_x.bbrxh <> list_khxx.khbh or list_x.khhzh <> list_khxx.yhzh or list_x.khhsh <> list_khxx.KHHSZS or list_x.khh <> list_khxx.KHYH or list_x.kzlx <> list_khxx.kzlx or list_x.ckr <> list_khxx.ZHMC or list_x.bdgljg <> list_fdxx.bdgljg or nvl(list_x.ybbrgx,'99') <> list_fdxx.zbbrgx)then
                                insert into Tb_import_psnfdzr (
                                      OP_TYPE,OP_FLAG,YWLSH,PCH,BDH,XM,XB,ZJLX,ZJHM,YBBS,GX,ZBBRXM,ZY,CKR,KHH,KHHZH,DJ,SJSXR,SJZZR,OPDATE,RUN_FLAG,BBRXH,ZBBRXH,BXGSMC,KHHSH,KZLX,BDGLJG,CLLX,BXGSID
                                 )
                                 values(
                                      1,list_x.OP_FLAG,(select FUNC_GENERATE_LSH('0102') as ywlsh from dual),list_x.PCH,list_x.BDH,list_x.XM,to_char(to_number(list_x.XB)+1),nvl((select max(aaa102) from tb_zddmbxgsdmdzb where bxgsid='713'and aaa100 = 'ZJLX' and bxgsxmbm = list_x.ZJLX),'99'),list_x.ZJHM,case list_x.YBBS when '0' then '02'when '1' then '01' end,nvl((SELECT max(aaa102) FROM TB_ZDDMBXGSDMDZB WHERE BXGSID='713' AND aaa100='ZBBRGX'AND bxgsxmbm = list_x.GX),'99'),list_x.ZBBRXM,nvl(replace(list_x.zy,'-',''),''),replace(list_x.CKR,'?',''),replace(list_x.KHH,'?',''),replace(list_x.KHHZH,'?',''),
                                      list_x.DJ,replace(list_x.SJSXR,'-',''),replace(to_char(to_date(list_x.SJZZR,'yyyy-mm-dd')-1,'yyyy-mm-dd'),'-',''),list_x.OPDATE,nvl(list_x.RUN_FLAG,''),list_x.BBRXH,list_x.ZBBRXH,list_x.BXGSMC,replace(list_x.KHHSH,'?',''),list_x.KZLX,list_x.BDGLJG,nvl(list_x.CLLX,''),list_x.BXGSID
                                 );
                                 end if;
                          end if;
                        ----??????????
                        select bdgljg into bdgljg_tt from tb_fdxx where khbdh = list_x.bdh and bbrkhid = v_khid;
                        ----2 ??????
                        select ybbs into ybbs_tt from tb_khxx where khid = v_khid;
                        if((list_x.YBBS is not null and nvl(list_x.YBBS,'99') <> '99')and(case list_x.YBBS when '0' then '02'when '1' then '01' end <> ybbs_tt))then
                        insert into Tb_import_psnfdzr (
                              OP_TYPE,OP_FLAG,YWLSH,PCH,BDH,XM,XB,ZJLX,ZJHM,YBBS,GX,ZBBRXM,ZY,CKR,KHH,KHHZH,DJ,SJSXR,SJZZR,OPDATE,RUN_FLAG,BBRXH,ZBBRXH,BXGSMC,KHHSH,KZLX,BDGLJG,CLLX,BXGSID
                         )
                         values(
                              2,list_x.OP_FLAG,(select FUNC_GENERATE_LSH('0102') as ywlsh from dual),list_x.PCH,list_x.BDH,list_x.XM,to_char(to_number(list_x.XB)+1),nvl((select max(aaa102) from tb_zddmbxgsdmdzb where bxgsid='713'and aaa100 = 'ZJLX' and bxgsxmbm = list_x.ZJLX),'99'),list_x.ZJHM,case list_x.YBBS when '0' then '02'when '1' then '01' end,nvl((SELECT max(aaa102) FROM TB_ZDDMBXGSDMDZB WHERE BXGSID='713' AND aaa100='ZBBRGX'AND bxgsxmbm = list_x.GX),'99'),list_x.ZBBRXM,nvl(replace(list_x.zy,'-',''),''),replace(list_x.CKR,'?',''),replace(list_x.KHH,'?',''),replace(list_x.KHHZH,'?',''),
                              list_x.DJ,replace(list_x.SJSXR,'-',''),replace(to_char(to_date(list_x.SJZZR,'yyyy-mm-dd')-1,'yyyy-mm-dd'),'-',''),list_x.OPDATE,nvl(list_x.RUN_FLAG,''),list_x.BBRXH,list_x.ZBBRXH,list_x.BXGSMC,replace(list_x.KHHSH,'?',''),list_x.KZLX,list_x.BDGLJG,nvl(list_x.CLLX,''),list_x.BXGSID
                         );
                        end if;
                        ----3 ??????
                        select djmc into dj_tt from tb_bddjxx where djid=(select djid from tb_fdxx where bbrkhid = v_khid and khbdh = list_x.bdh)and rownum=1;
                        if(list_x.dj is not null and nvl(list_x.dj,'99') <> '99' and list_x.dj <> dj_tt)then
                        insert into Tb_import_psnfdzr (
                              OP_TYPE,OP_FLAG,YWLSH,PCH,BDH,XM,XB,ZJLX,ZJHM,YBBS,GX,ZBBRXM,ZY,CKR,KHH,KHHZH,DJ,SJSXR,SJZZR,OPDATE,RUN_FLAG,BBRXH,ZBBRXH,BXGSMC,KHHSH,KZLX,BDGLJG,CLLX,BXGSID
                         )
                         values(
                              3,list_x.OP_FLAG,(select FUNC_GENERATE_LSH('0102') as ywlsh from dual),list_x.PCH,list_x.BDH,list_x.XM,to_char(to_number(list_x.XB)+1),nvl((select max(aaa102) from tb_zddmbxgsdmdzb where bxgsid='713'and aaa100 = 'ZJLX' and bxgsxmbm = list_x.ZJLX),'99'),list_x.ZJHM,case list_x.YBBS when '0' then '02'when '1' then '01' end,nvl((SELECT max(aaa102) FROM TB_ZDDMBXGSDMDZB WHERE BXGSID='713' AND aaa100='ZBBRGX'AND bxgsxmbm = list_x.GX),'99'),list_x.ZBBRXM,nvl(replace(list_x.zy,'-',''),''),replace(list_x.CKR,'?',''),replace(list_x.KHH,'?',''),replace(list_x.KHHZH,'?',''),
                              list_x.DJ,replace(list_x.SJSXR,'-',''),replace(to_char(to_date(list_x.SJZZR,'yyyy-mm-dd')-1,'yyyy-mm-dd'),'-',''),list_x.OPDATE,nvl(list_x.RUN_FLAG,''),list_x.BBRXH,list_x.ZBBRXH,list_x.BXGSMC,replace(list_x.KHHSH,'?',''),list_x.KZLX,list_x.BDGLJG,nvl(list_x.CLLX,''),list_x.BXGSID
                         );
                        end if;
                        ----4 ???????
                        select bdsxrq into bdsxrq_tt from tb_bdxx where khbdh = list_x.bdh;
                        select bdzzrq into bdzzrq_tt from tb_bdxx where khbdh = list_x.bdh;
                        if(to_number(replace(list_x.sjzzr,'-','')) > to_number(bdzzrq_tt))then
                              PReturnCode:='1';
                              PReturnMsg := '?????????????????';
                              RETURN;
                        end if;
                        if((replace(list_x.sjsxr,'-','') <> bdsxrq_tt) or (replace(list_x.sjzzr,'-','') <> bdzzrq_tt))then
                        insert into Tb_import_psnfdzr (
                              OP_TYPE,OP_FLAG,YWLSH,PCH,BDH,XM,XB,ZJLX,ZJHM,YBBS,GX,ZBBRXM,ZY,CKR,KHH,KHHZH,DJ,SJSXR,SJZZR,OPDATE,RUN_FLAG,BBRXH,ZBBRXH,BXGSMC,KHHSH,KZLX,BDGLJG,CLLX,BXGSID
                         )
                         values(
                              4,list_x.OP_FLAG,(select FUNC_GENERATE_LSH('0102') as ywlsh from dual),list_x.PCH,list_x.BDH,list_x.XM,to_char(to_number(list_x.XB)+1),nvl((select max(aaa102) from tb_zddmbxgsdmdzb where bxgsid='713'and aaa100 = 'ZJLX' and bxgsxmbm = list_x.ZJLX),'99'),list_x.ZJHM,case list_x.YBBS when '0' then '02'when '1' then '01' end,nvl((SELECT max(aaa102) FROM TB_ZDDMBXGSDMDZB WHERE BXGSID='713' AND aaa100='ZBBRGX'AND bxgsxmbm = list_x.GX),'99'),list_x.ZBBRXM,nvl(replace(list_x.zy,'-',''),''),replace(list_x.CKR,'?',''),replace(list_x.KHH,'?',''),replace(list_x.KHHZH,'?',''),
                              list_x.DJ,replace(list_x.SJSXR,'-',''),replace(to_char(to_date(list_x.SJZZR,'yyyy-mm-dd')-1,'yyyy-mm-dd'),'-',''),list_x.OPDATE,nvl(list_x.RUN_FLAG,''),list_x.BBRXH,list_x.ZBBRXH,list_x.BXGSMC,replace(list_x.KHHSH,'?',''),list_x.KZLX,list_x.BDGLJG,nvl(list_x.CLLX,''),list_x.BXGSID
                         );
                        end if;
                      delete TB_IMPORT_PSNFDZR_TMP where ywlsh = list_x.ywlsh;
              end if;
            end if;
          end loop;
          else
     PReturnCode:='1';
     PReturnMsg := 'tmp???????'||zpch||'??RUN_FLAG?????';
     RETURN;
   end if;
    PReturnCode:='0';
    PReturnMsg:='????????!';
    EXCEPTION
  WHEN OTHERS THEN
    PReturnCode := 'E';
    DBMS_OUTPUT.PUT_LINE('[ddl debug] ' || 'PReturncode= ' ||
                         PReturnCode);
    PReturnMsg := 'Error:' || sqlerrm;
    DBMS_OUTPUT.PUT_LINE(PReturnMsg);
end SP_IMPORT_PSNFDZR_SHRSTMP;

/
