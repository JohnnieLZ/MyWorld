CREATE function      func_xxdm(xxdm in varchar2,xxidx in varchar2)

    return varchar2 is

    str varchar2(100);
    num number;
    begin
    num := length(xxdm);

    IF num = 2 THEN
    select fyxx.clfmc into str from tb_fpxxfyxx fyxx where fyxx.xxid = xxidx;
    ELSE
    select fyxx.xxmc into str from tb_fpxxfyxx fyxx where fyxx.xxid = xxidx ;
    END IF;
    return str;
     end;

/
