CREATE PROCEDURE      "SP_CHECK_ZLXM" (PIN_AJID IN varCHAR2,PReturnCode OUT varchar2, PReturnMsg OUT varchar2) AS
 nBdid 	 NUMBER(16) := 0;
 i_Count NUMBER(9) := 0;
 i_step  NUMBER(9) := 0;
 sXgdm   VARCHAR2(100):= '';
 sXmbm   VARCHAR2(20) := '';
 sXgdmms VARCHAR2(1024) := '';
 CURSOR c_Zpaxx(sAjid VARCHAR2) IS
 	SELECT T.ZPAID, T.ZRID
 	FROM TB_ZPAXX T
 	WHERE T.AJID = sAjid
 	AND T.FPID IS NOT NULL;

 CURSOR c_Zlxmpz(n_Bdid NUMBER, n_Zrid NUMBER, n_Zpaid NUMBER) IS
   SELECT ZLXMLB, COUNT(*), MAX(ZLXMID) AS ZLXMID
    FROM TB_BDTYSHGZZLXMPZ where BDID=n_Bdid and zrid=n_Zrid and ZLXMID in(
    SELECT  TYID  FROM TB_FPXXFYXX a,tb_zpaxxdzb b where a.xxid=b.xxid
                        and b.zpaid =n_Zpaid and a.xmlb='1')
/*   WHERE (BDID, ZRID, ZLXMID) IN(SELECT n_Bdid, n_Zrid, TYID
                        FROM TB_FPXXFYXX
                       WHERE FPID IN (SELECT FPID
                                       FROM TB_LPFPXX A
                                      WHERE A.AJID = PIN_AJID
                                        AND (SELECT SYFPH FROM TB_ZPAXX WHERE ZPAID = n_Zpaid) LIKE '%' || A.FPHM || '%')
                     AND XMLB = '1')*/
   GROUP BY ZLXMLB;

 BEGIN
    PReturnCode:='E';
    PReturnMsg:='Error!';
    ----???????????
    i_step := 1;
    IF TRIM(PIN_AJID) IS NULL THEN
    PRETURNCODE := 'E';
        PRETURNMSG := '??ID????';
        RETURN;
    END IF;

    ----????ID
    i_step := 2;
    BEGIN
    SELECT nvl(C.BDID,(select bdid from tb_fdxx where fdid=b.fdid))
      INTO nBdid
      FROM TB_LPPCXX C,TB_LPAJXX B
      WHERE  C.PCID=B.LPPCID
    AND B.AJID = PIN_AJID;
  EXCEPTION
    WHEN OTHERS THEN
          PRETURNCODE := 'E';
          PRETURNMSG := '??????ID';
          RETURN;
  END;

  FOR cc IN c_Zpaxx(PIN_AJID) LOOP
    sXgdm := '';
    sXgdmms := '';
    FOR c1 IN c_Zlxmpz(nBdid, cc.ZRID, cc.ZPAID ) LOOP
      IF c1.ZLXMLB = '01' THEN
        sXgdm := sXgdm || ',CL40';
      ELSIF c1.ZLXMLB = '02' THEN
        sXgdm := sXgdm || ',CL41';
      ELSIF c1.ZLXMLB = '03' THEN
        sXgdm := sXgdm || ',CL42';
      ELSIF c1.ZLXMLB = '04' THEN
        sXgdm := sXgdm || ',CL43';
      ----?????????????05???
      END IF;

      BEGIN
        SELECT XMBM
          INTO sXmbm
          FROM TB_ZLXMXX
          WHERE  ZLXMID = c1.ZLXMID;
      EXCEPTION
        WHEN OTHERS THEN
              sXmbm := '';
      END;
      sXgdmms := sXgdmms || ',' ||sXmbm;

    END LOOP;
    if instr(sXgdm,',')=1 then --???','?????
          sXgdm:=substr(sXgdm,2,length(trim(sXgdm))-1);
          sXgdmms:=substr(sXgdmms,2,length(trim(sXgdmms))-1);
    end if;

    IF LENGTH(TRIM(sXgdm)) IS NOT NULL THEN
      UPDATE TB_ZPAXX
      SET XGDM =case when xgdm is  null then sXgdm else XGDM||','||sXgdm end ,
        XGDMMS =case when XGDMMS is null then sXgdmms else XGDMMS||','||sXgdmms end
        WHERE ZPAID = cc.ZPAID;
    END IF;
  END LOOP;


    PReturnCode:='0';--????
    PReturnMsg:='check success!';
    return;
  EXCEPTION
  WHEN OTHERS THEN
    PReturnCode := 'E';
    DBMS_OUTPUT.PUT_LINE('[yhs debug] ' || 'PReturncode= ' ||
                         PReturnCode);
    PReturnMsg := 'Error:' || sqlerrm;
    DBMS_OUTPUT.PUT_LINE(PReturnMsg);
END SP_CHECK_ZLXM;

/
