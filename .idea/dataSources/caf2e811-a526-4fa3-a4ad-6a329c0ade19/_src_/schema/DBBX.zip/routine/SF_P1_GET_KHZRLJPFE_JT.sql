CREATE function      SF_P1_GET_KHZRLJPFE_JT(pKhid in number,pZrid in number,pKhbdh in varchar2) return number is
  sumsjgfts number:=0 ;
BEGIN

   select sum(nvl(SJGFTS,0)) into sumsjgfts from TB_ZPAxx b,TB_lpajxx a where  a.ajid=b.ajid and a.khbdh=pKhbdh
                      and nvl(b.zpajl,'01')!='02' and a.ajzt in('08','09','10','11')
                      AND B.PFZRDM LIKE 'HI%'
                      and a.BBRKHID=pKhid and b.zrid=pZrid;
 return(sumsjgfts);

 EXCEPTION
        WHEN OTHERS THEN
        return(sumsjgfts);
 END SF_P1_GET_KHZRLJPFE_JT;

/
