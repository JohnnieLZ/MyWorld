CREATE PROCEDURE      "SP_P1_30022" (report_id     In t_report_def_info.REPORTID%TYPE,
                                     pStartdate    IN varchar2,-- ??????yyyymmdd
                                     pEnddate      IN varchar2,-- ??????yyyymmdd
                                     pStatman      IN t_report_gen_info.STATMAN%TYPE,--???
                                     ptype         in varchar2, /*0 ???? ,1 ?? 2 ?? 3 ?? */--?????
                                     POther1   IN varchar2,--??id
                                     POther2   IN varchar2,--??id
                                     POther3   IN varchar2,--??id
                                     POther4   IN varchar2,--??ID
                                     POther5   IN varchar2,--????
                                     POther6   IN varchar2,--??ID
                                     POther7   IN varchar2,--??
                                     POther8   IN varchar2,--??
                                     PReturnCode   OUT varchar2,
                                     PReturnMsg    OUT varchar2) AS

  V_STEP_CODE  CHAR(5);--?????????????????
  vreportid    t_report_def_info.REPORTID%TYPE;--??ID
  v_start_date number := 0;--????????
  v_end_date   number := 0;--????????
  vxzqhdm   t_report_gen_info.STATORGID%TYPE; --????????????

  vstatid varchar(30); --?????????????????
  type cellType is record(
    statid  varchar2(15),
    col     number,
    r       number,
    content varchar2(1024));

  cell      cellType; --?????????????
  vdwmc     varchar2(50); --????????????
  vusername t_report_gen_info.STATMAN%TYPE; --????????
  vnd       t_report_gen_info.STATYEAR%TYPE; --????
  rowno     number := 0; --??????

begin
  V_STEP_CODE := '00000';
  PReturnMsg  := 'OK';
  PReturnCode := 'E';
  vreportid   := substr(report_id, 1, 5);
  vusername   := pStatman;
  vnd         := substr(pStartdate, 1, 4);

  v_start_date := to_number(substr(pStartdate, 1, 8));
  v_end_date   := to_number(substr(pEnddate, 1, 8));

  --???????????????????????????
  delete from t_report_data_info
   where statid in
         (select statid from T_REPORT_GEN_INFO where reportid = report_id);

  delete from T_REPORT_GEN_INFO
   where statid in
         (select statid from T_REPORT_GEN_INFO where reportid = report_id);

  V_STEP_CODE := '00001';
  --???,?T_RERORT_GEN_INFO?????????????
  --???????
  select seq_statid.nextval into vstatid from dual;

  -- ??????????
  insert into t_report_gen_info
    (STATID,
     REPORTID,
     STATORGID,
     STATORGNAME,
     STATDATE,
     STATMAN,
     STATYEAR,
     BEGINDATE,
     ENDDATE,
     STAT_OTHER,
     STAT_TYPE)
  values
    (vstatid,
     vreportid,
     '',
     '',
     to_char(sysdate, 'yyyymmdd'),
     vusername,
     vnd,
     v_start_date,
     v_end_date,
     substr(pEnddate, 1, 1),
     trim(ptype));

   --???
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid, 0,2, 2, 'CLGL05');

   --????
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,1,3,to_char(sysdate,'yyyymmdd'));

  cell.statid := vstatid;
  cell.col    := 0;--??????
  cell.r      := 6;--??7???

  --???????????????????????????????excel????????????????????

  for rec_zj in(
        select a.shr as shr,e.cae249 as zjr,b.bxgsqc as bxgs,c.ttmc as tbtt,d.khbdh as bdh,a.pah as pah,
        row_number()over(partition by a.pah order by e.aaz001 desc) as thcs,
        e.aae217 as thsj,e.aae013 as thyy
          from tb_lpajxx a,tb_bxgsxx b,tb_ttxx c,tb_bdxx d,ae02 e
        where b.bxgsid = d.bxgsid
          and c.ttid = d.ttid
          and d.khbdh = a.khbdh
          and e.aaz001 = a.ajid
          and e.cae220 = '031'
          and e.aaa121 = 'P10405'
          and e.aae014 = '2' order by a.pah
          )loop

          --???
          cell.content := rec_zj.shr;
          if cell.content is not null then
            insert into t_report_data_info (statid,sheet,col,r,content)values(vstatid,0,0,cell.r,cell.content);
          end if;
          --???
          cell.content := rec_zj.zjr;
          if cell.content is not null then
            insert into t_report_data_info (statid,sheet,col,r,content)values(vstatid,0,1,cell.r,cell.content);
          end if;
          --????
          cell.content := rec_zj.bxgs;
          if cell.content is not null then
            insert into t_report_data_info (statid,sheet,col,r,content)values(vstatid,0,2,cell.r,cell.content);
          end if;
          --????
          cell.content := rec_zj.tbtt;
          if cell.content is not null then
            insert into t_report_data_info (statid,sheet,col,r,content)values(vstatid,0,3,cell.r,cell.content);
          end if;
          --???
          cell.content := rec_zj.bdh;
          if cell.content is not null then
            insert into t_report_data_info (statid,sheet,col,r,content)values(vstatid,0,4,cell.r,cell.content);
          end if;
          --???
          cell.content := rec_zj.pah;
          if cell.content is not null then
            insert into t_report_data_info (statid,sheet,col,r,content)values(vstatid,0,5,cell.r,cell.content);
          end if;
          --????
          cell.content := rec_zj.thcs;
          if cell.content is not null then
            insert into t_report_data_info (statid,sheet,col,r,content)values(vstatid,0,6,cell.r,cell.content);
          end if;
          --????
          cell.content := rec_zj.thsj;
          if cell.content is not null then
            insert into t_report_data_info (statid,sheet,col,r,content)values(vstatid,0,7,cell.r,cell.content);
          end if;
          --????
          cell.content := rec_zj.thyy;
          if cell.content is not null then
            insert into t_report_data_info (statid,sheet,col,r,content)values(vstatid,0,8,cell.r,cell.content);
          end if;
          cell.r   := cell.r + 1;     --??+1,???????1?
  end loop;

   --???????????
  /*9.??*/
  PReturnCode := '0'; /* ??????????????vstatid????????? */
  PReturnMsg  := vstatid;
  DBMS_OUTPUT.PUT_LINE('[LDS debug] ' || 'PReturncode= ' || PReturnCode);
  --COMMIT; ???java?????????

EXCEPTION
  WHEN OTHERS THEN
    --rollback;???java?????????????0?????????????????
    PReturnCode := 'E'; /*  ??????  */
    DBMS_OUTPUT.PUT_LINE('[yhs debug] ' || 'PReturncode= ' || PReturnCode);
    PReturnMsg := ' rownum' || cell.r || 'Error:' || sqlerrm; --???????????
    DBMS_OUTPUT.PUT_LINE(PReturnMsg);
end SP_P1_30022;

/
