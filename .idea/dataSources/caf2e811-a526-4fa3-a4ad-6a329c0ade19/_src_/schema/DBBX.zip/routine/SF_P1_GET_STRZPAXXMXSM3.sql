CREATE function      SF_P1_GET_STRZPAXXMXSM3(p_FPID in varchar2) return varchar2 is
cursor cur_rec is
 select jlsm from (select (select aaa103 from aa10 where aaa100='JFLY' and aaa102=a.jlsm1)||a.jlsm2 as jlsm from tb_zpaxx a,tb_zpaxxdzb b,tb_fpxxfyxx c where a.zpaid=b.zpaid
and b.xxid=c.xxid and (a.jlsm1 is not null or a.jlsm2 is not null) and c.fpid=p_FPID) group by jlsm;

Result varchar2(4096):='' ;
BEGIN

 if length(trim(p_FPID))=0 then
    Result:='?';

  end if;

  for rec in cur_rec loop
    if rec.jlsm is not null then
     Result:=Result||rec.jlsm||',';
    end if;
  end loop;
 -- dbms_output.put_line(Result);
  Result:=substr(Result,1,length(trim(Result))-1);

return(Result);
END SF_P1_GET_STRZPAXXMXSM3;

/
