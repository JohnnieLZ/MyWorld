CREATE function      FUNC_ZPAXX_FEEITEMCANDN(P_FLAG IN VARCHAR2,P_AAA102 IN VARCHAR2,P_BXGSID in NUMBER,P_AAA100 in VARCHAR2,P_QTSM1 IN VARCHAR2,P_QTSM2 IN VARCHAR2)
 return VARCHAR2 is
  Result VARCHAR2(30);
begin
  IF P_FLAG='C' THEN
    select bxgsxmbm into Result from tb_zddmbxgsdmdzb where bxgsid=P_BXGSID and aaa100=P_AAA100 and aaa102=P_AAA102 and qtsm1=P_QTSM1 and qtsm2=P_QTSM2;
  ELSE
    select bxgsxmmc into Result from tb_zddmbxgsdmdzb where bxgsid=P_BXGSID and aaa100=P_AAA100 and aaa102=P_AAA102 and qtsm1=P_QTSM1 and qtsm2=P_QTSM2;
  END if;
  return(Result);
end FUNC_ZPAXX_FEEITEMCANDN;

/
