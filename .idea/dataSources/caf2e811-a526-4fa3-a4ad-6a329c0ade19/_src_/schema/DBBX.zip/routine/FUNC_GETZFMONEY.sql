CREATE FUNCTION      FUNC_GETZFMONEY(p_ajid in varchar2,p_getdutycode in varchar2) return varchar2 is
Result   VARCHAR2(2048):='' ;--??????????
Result1   VARCHAR2(2048):='' ;--???????
sMpe     NUMBER(16,2):=0;
sZfy     NUMBER(16,2):=0;----???
sTcygf  NUMBER(16,2):=0;---?????
sYbzf    NUMBER(16,2):=0;----??????
sZfmx    NUMBER(16,2):=0;------????
sZdsm    VARCHAR2(5):='';
sZdlx    VARCHAR2(2):='';
sMplx    VARCHAR2(10):='';
sJsbl    NUMBER(3):=0;----????
sSjpfje  NUMBER(16,2):=0;
sXgdm  VARCHAR2(100):='';
sJfly    varchar2(10):='';
sCpmc    varchar2(32):='';
sXLLSPFJE NUMBER(16,2):=0;---????????
sSbbdx  VARCHAR2(1):='';
nZvbdx1  NUMBER(16,2):=0;---???????1
nZvbdx2  NUMBER(16,2):=0;---???????2
i_Count NUMBER(2):=0;
nYpzfy  NUMBER(16,2):=0;----?????
nYp_zf  NUMBER(16,2):=0;----????
nQt_zf  NUMBER(16,2):=0;----????
nQtzfy  NUMBER(16,2):=0;----?????
nyppfje  NUMBER(16,2):=0;----??????
nqtfpfje  NUMBER(16,2):=0;----??????
nMpts      NUMBER(3):=0;----????
nSjgfts    NUMBER(3):=0;----??????
nZrbe      NUMBER(12,2):=0;----????
n_tsc      NUMBER(3):=0;
sZpajl    VARCHAR2(2):='';-----?????
sJLSM1    VARCHAR2(10):='';
sJlsm      VARCHAR2(100):='';----???????
p_Zrdm    VARCHAR2(10):='';----??????
p_Zpaid  varchar2(30):=p_ajid;
cursor cur_rec is
select max(a.zpaid) as zpaid,max(a.zpajl) as zpajl,
max(a.PFZRDM) as pfzrdm ,
sum(nvl(a.ZDZJE    ,0)) as  ZDZJE      ,--  ?????
sum(nvl(a.SBZFZJE  ,0)) as  SBZFZJE    ,--  ???????
sum(nvl(a.ZFJE     ,0)) as  ZFJE       ,--  ????
sum(nvl(a.FLZFJE   ,0)) as  FLZFJE     ,--  ??????
sum(nvl(a.QTDSFZFJE,0)) as  QTDSFZFJE  ,--  ?????????
sum(nvl(a.BHLFY    ,0)) as  BHLFY      ,--  ?????
sum(nvl(a.BXZRWJE  ,0)) as  BXZRWJE    ,--  ???????
sum(nvl(a.XLLSPFJE ,0)) as  XLLSPFJE   ,--  ????????
sum(nvl(a.RGTZJE   ,0)) as  RGTZJE     ,--  ??????
sum(nvl(a.SJPFJE   ,0)) as  SJPFJE     ,--  ??????
sum(nvl(a.MPE      ,0)) as  MPE    ,    --  ???
max(a.SBBDX) as SBBDX,
max(a.XGDM) as XGDM,
max(bk.zdlx) as zdlx,
MAX(nvl(bk.ryrq,bk.jzrq))as jzrq
from tb_zpaxx  a ,tb_lpfpxx bk where a.ajid=p_ajid and a.fpid is not null
and a.fpid = bk.fpid
and exists(
SELECT 1 FROM TB_LPAJXX ak,TB_FDXX b,tb_zddmbxgsdmdzb c,tb_bddjxx d,tb_bdxx e where
ak.fdid = b.fdid and b.djid =d.djid and b.bdid = e.bdid and c.qtsm2 = e.khbdh||'@'||d.djbh
and c.bxgsid  = 946 and c.aaa100 = 'ZRDM' AND c.QTSM1 = p_getdutycode  AND ak.AJID = p_ajid
and c.aaa102 = a.pfzrdm)
order by a.zpaid asc;

cursor cur_rec_1 is
select zpaid
from tb_zpaxx  a  where ajid=p_ajid and fpid is not null
and exists(
SELECT 1 FROM TB_LPAJXX ak,TB_FDXX b,tb_zddmbxgsdmdzb c,tb_bddjxx d,tb_bdxx e where
ak.fdid = b.fdid and b.djid =d.djid and b.bdid = e.bdid and c.qtsm2 = e.khbdh||'@'||d.djbh
and c.bxgsid  = 946 and c.aaa100 = 'ZRDM' AND c.QTSM1 = p_getdutycode  AND ak.AJID = p_ajid
and c.aaa102 = a.pfzrdm)
order by zpaid asc;

v_type varchar2(2):='0';--???????1 ??????? 2 ???????? 3 ?????? 4 ???? 5 ????..
--???????????????????

BEGIN

  IF LENGTH(TRIM(p_Zpaid))=0 THEN
      Result:='?';
  END IF;

  Result1:='';
  for rec in cur_rec loop
        result:='';
        sZdsm:='';
         p_Zrdm:=rec.pfzrdm;
         sSbbdx:=rec.sbbdx;
         sZpajl:=rec.zpajl;
        sXgdm:=nvl(rec.xgdm,'xxxxxx');
      IF rec.zdlx = '0' THEN
         sZdsm:= '??';
      ELSE
         sZdsm:= '??';
      END IF;
      IF p_Zrdm LIKE 'MAT%' THEN
        sZdsm:='??';
      END IF;
      SELECT max( DECODE(NVL(nvl(BLJShMPLX,BLJSQMPLX),'1'),'2','???','4','???','')) INTO sMplx
         FROM tb_zpalsgzdzb A,TB_ZPAXX B WHERE A.ZPAID=B.ZPAID AND a.zpaid=rec.zpaid;
      SELECT max(decode(n.sfyyb,'1',nvl( nvl(m.syybkjsbl,m.jsbl),0),nvl(nvl(m.bsyybkjsbl,m.jsbl),0))) into sJsbl
      FROM tb_zpalsgzdzb S,TB_BDZRLSGZSZ M,tb_zpaxx n WHERE S.LSGZID=m.lsgzid  and s.zpaid=n.zpaid AND S.ZPAID=rec.zpaid;
     FOR rec_1 in cur_rec_1 loop
      sZfmx:=sZfmx+FUNC_GETMONEY_XX_SUM(rec_1.zpaid,'1');
     end loop;
  ----????????,????
/*    IF sSbbdx not IN('1','2') and sXgdm not like '%CL23%' and  sXgdm not like '%X56%' THEN
      \*IF p_Zrdm LIKE 'MAT%' THEN
         sZdsm:='??';
      END IF; *\
      IF sMpe <>0 AND sZpajl <> '02' THEN --????
          Result := '????'||sZdsm||'???[  ????'||to_char(rec.zdzje)||'?-  ??????'||to_char(rec.sbzfzje)||'?- ???????'||to_char(rec.zfje)||'?-   ?'||sMplx||'???'||to_char(rec.mpe)||'?]*'||sJsbl||'%='||to_char(rec.Sjpfje)||'? ?'||'?????'||sZfmx||';';
      else
          Result := '????'||sZdsm||'???[  ????'||to_char(rec.zdzje)||'?-  ??????'||to_char(rec.sbzfzje)||'?- ???????'||to_char(rec.zfje)||'?]*'||sJsbl||'%='||to_char(rec.Sjpfje)||'? ?'||'?????'||sZfmx||';';
      end if;
    end if;
    ----????????
      if    sXgdm  like '%X56%' THEN  --????????
         Result := '????'||sZdsm||'???[  ????'||to_char(rec.zdzje)||'?-  ??????'||to_char(rec.sbzfzje)||'?-   ???????'||to_char(rec.zfje)||'?-  ?'||sMplx||'???'||to_char(rec.mpe)||'?]*'||sJsbl||'%='||to_char(rec.XLLSPFJE)||'? ?'||'??'||sCpmc||'????? '||to_char(rec.Sjpfje)||' \??????????????'||to_char(rec.Sjpfje)||'???????'||sZfmx||';';
      end if;
      ----??????,???????---
      if sXgdm  not like '%X56%' and sSbbdx IN('1','2') THEN
        nZvbdx1:=nvl(rec.zdzje,0)-nvl(rec.sbzfzje,0)-nvl(rec.zfje,0);
        nZvbdx2:=(nvl(rec.zdzje,0)-nvl(rec.sbzfzje,0)-nvl(rec.mpe,0))*(sJsbl/100);
        Result := '????'||sZdsm||'???,?????????[  ????'||to_char(rec.zdzje)||'?-  ??????'||to_char(rec.sbzfzje)||'?-   ???????'||to_char(rec.zfje)||'?]='||to_char(nZvbdx1)||'?,??????????[???? '||to_char(rec.zdzje)||'?- ???????'||to_char(rec.zfje)||'?-?'||sMplx||'???'||sMpe||'?]*'||sJsbl||'%='||to_char(nZvbdx2)||'?,????????'||to_char(rec.sbzfzje)||'???????'||sZfmx||'????????'||to_char(rec.sjpfje)||' ??';
      end if;
      Result1:=substr(Result1||Result,1,2048);*/
  end loop;
  --???????
  /*for rec2 in (select a.zpaid,a.sjpfje from tb_zpaxx a where a.ajid=p_ajid and a.pfzrdm like 'HI%'
    and exists(
SELECT 1 FROM TB_LPAJXX ak,TB_FDXX b,tb_zddmbxgsdmdzb c,tb_bddjxx d,tb_bdxx e where
ak.fdid = b.fdid and b.djid =d.djid and b.bdid = e.bdid and c.qtsm2 = e.khbdh||'@'||d.djbh
and c.bxgsid  = 946 and c.aaa100 = 'ZRDM' AND c.QTSM1 = p_getdutycode  AND ak.AJID = a.ajid
and c.aaa102 = a.pfzrdm) order by zpaid asc) loop
     Result:='';
     p_Zpaid:=rec2.zpaid;
     sSjpfje:=rec2.sjpfje;
       ----????---
       BEGIN
         SELECT MPTS,nvl(SJGFTS,0)
         INTO nMpts,nSjgfts
         FROM TB_ZPAXX
         WHERE ZPAID=p_Zpaid;
       EXCEPTION
      WHEN NO_DATA_FOUND THEN
        nMpts := NULL;
        nSjgfts :=NULL;
      END;


       select nvl((nSjgfts-nMpts),0) into n_tsc from dual;
       BEGIN
         SELECT A.ZRBE
        INTO nZrbe
        FROM TB_FDZRMX A
        WHERE EXISTS(SELECT 1 FROM TB_LPAJXX B WHERE B.AJID IN(SELECT AJID FROM TB_ZPAXX WHERE ZPAID=p_Zpaid) AND B.FDID=A.FDID)
        AND EXISTS(SELECT 1 FROM TB_ZRXX C WHERE C.ZRBM IN(SELECT PFZRDM FROM TB_ZPAXX WHERE ZPAID=p_Zpaid) AND C.ZRID=A.ZRID);
       EXCEPTION
      WHEN NO_DATA_FOUND THEN
        nZrbe := NULL;
      END;

       IF nMpts is null THEN
         Result :='??????????????'||sSjpfje||'??'||nZrbe||'?/?*'||nSjgfts||'?)';
       ELSE
         Result :='??????????????'||sSjpfje||'?['||nZrbe||'?/?*'||n_tsc||'??????)'|| nSjgfts||' ?-'||nMpts||'????';
       END IF;
        Result1:=substr(Result1||Result,1,2048);
    END loop;*/

return(sZfmx);
EXCEPTION
    WHEN OTHERS THEN return 'EEEEEEEEEEEEEEEE';
END FUNC_GETZFMONEY;

/
