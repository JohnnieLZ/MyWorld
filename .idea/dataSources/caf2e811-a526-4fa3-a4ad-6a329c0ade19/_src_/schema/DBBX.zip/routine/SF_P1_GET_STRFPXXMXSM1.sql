CREATE function      SF_P1_GET_STRFPXXMXSM1(p_ZPAID in varchar2,p_type in varchar2) return varchar2 is
cursor cur_rec is select trim(a.xxmc) as aaa103,decode(p_type,'2',a.flzfje,a.zdje) as zdje  from tb_fpxxfyxx a, tb_zpaxxdzb b where a.xxid=b.xxid and a.fpid=to_number(p_ZPAID)
 and ((p_type='1' and a.zfje>0 and b.ZFFYLSGZID is  null) or (p_type='2' and a.flzfje>0 and b.HLBHFLLSGZID is not null) or (p_type='3' and a.BHLJE>0))
 order by XMLB,xxdm;

Result varchar2(4096):='' ;
BEGIN

 if length(trim(p_ZPAID))=0 then
    Result:='?';

  end if;

  for rec in cur_rec loop
     Result:=Result||rec.aaa103||':'||trim(to_char(rec.zdje,'9999990.00'))||'?,';
  end loop;
  Result:=substr(Result,1,length(trim(Result))-1);
--dbms_output.put_line(Result);
return(Result);
END SF_P1_GET_STRFPXXMXSM1;

/
