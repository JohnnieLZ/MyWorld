CREATE PROCEDURE      "PROC_TBALCLOSE_EXPORT" (p_RtnCode OUT NUMBER, p_RtnMsg OUT VARCHAR2) IS
/**
  *@version 1.1 update by zhangjunpeng TBAL?????????????????????--?   2015-04-29
  *@version 1.2 update by zhangjunpeng TBAL????????????  2015-5-5
  *@version 1.3 update by zhangjunpeng ????????????????????`99? 2015-5-22
  *@version 1.4 update by zhangjunpeng MZ150608-04 ??????benefit_person?<bankbranch>?<banksubbranch>?????? 2015-6-12
  *@version 1.5 update by zhangjunpeng ????????? 20150707
  *@version 1.6 update by zhangjunpeng ???????????xml????java???? 20150712
  *@version 1.7 update by zhangjunpeng ??????????????  20150714
  *@version 1.8 update by zhangjunpeng MZ150717-04????????????  20150720
  ***/
  i_Count  NUMBER(9) := 0;
  i_step  NUMBER(9) := 0;
  sPch  VARCHAR2(11);
  sFilename  VARCHAR2(32);
  v_dname   VARCHAR2(50);
  sSql    VARCHAR2(100);
  sWtjWjm  varchar2(32);
  CURSOR c_Sjxx IS
    SELECT  A.YWLSH,A.AJID, A.JBDM, A.JZRQ,A.YYID,A.ZDLX
    FROM TB_TBAL_CLOSE_SJXX A
    WHERE A.PCH=sPch;

  CURSOR c_Spcxx IS
    SELECT DISTINCT sPch,BATCHNO
    FROM TB_TBAL_CLOSE_AJXX
    WHERE PCH = sPch;

  CURSOR c_Fpxx(p_Sjywlsh VARCHAR2) IS
    SELECT  A.AJID, A.SJYWLSH,A.FPID
    FROM TB_TBAL_CLOSE_FPXX A
    WHERE A.PCH=sPch
    AND A.SJYWLSH=p_Sjywlsh;

BEGIN
  --0.?????
    p_RtnCode := 0;
    p_RtnMsg := '????';
    v_dname := 'E:\ReturnData\TBAL';
      --????????
     i_step := 1;
     SELECT FUNC_GENERATE_LSH ('0116')
     INTO  sPch
     FROM DUAL;

    ---???????????
     i_step := 2;
     INSERT INTO TB_AL_CLOSE_CZJL(PCH, SJRQ, KSSJ, JSSJ,YXZT)
     VALUES(sPch, TO_CHAR(SYSDATE,'YYYYMMDD'), SYSDATE, NULL,'0');

     i_step := 3;
     -----???????
     INSERT INTO TB_TBAL_CLOSE_AJXX(
       YWLSH, BXGSID,PCH,PAH,
      BATCHNO, AJID, CLAIMNO, EXPTIME, CUSTMCO, ACC_DATE,
      FIRST_DATE, ACC_ADDR_TYPE, ACC_SUBTYPE, ACC_INFO, CLAIMACC, BBRXM, BBRXB, BBRZJLX, BBRZJHM,
      RELATIONSHIP, NOTICE_DATE,
      IDTYPE, IDNO, SQRXM, SQRXB,
      MOBILEPHONE, TELEPHONE, SQRYX, ADDR, ZIP, SYRSL,
      BFTYPE,sqrcsrq,YBH,
      BBR_Id_begdate, BBR_Id_enddate, SQR_Id_begdate, SQR_Id_enddate, bankbranch, banksubbranch, JOB, organization, email_accept,
      AJPFFS, BANKTYPE, ACCTNO, INS_CORP, POLI_NAME, POLI_NO, PAY_CORP, PAY_AMOUNT, EXPORT_DATE)
    SELECT
      FUNC_GENERATE_LSH('0113'),'945',sPch,B.PAH,
      A.PCH, B.AJID, B.WBPAZH, TO_CHAR(TO_DATE(A.sjrq,'YYYY-MM-DD'),'YYYY-MM-DD'),(SELECT TTBH FROM TB_TTXX WHERE TTID=A.TTID)AS CUSTMCO,NVL(TO_CHAR(TO_DATE(C.CXRQ,'YYYY-MM-DD'),'YYYY-MM-DD'),'9999-12-31'),
      (SELECT NVL(TO_CHAR(TO_DATE(MIN(S.JZRQ),'YYYY-MM-DD'),'YYYY-MM-DD'),'9999-12-31') FROM TB_LPFPXX S WHERE S.AJID=B.AJID),NVL(DECODE(INSTR(B.YWSGDD,'??'),'1','1',DECODE(INSTR(B.YWSGDD,'?????'),'1','3',DECODE(INSTR(B.YWSGDD,'???'),'1','2',''))),'1'),FUNC_BXGSDM_PZ('CXLX', B.YWSGYY, '945', '0',NULL,NULL),C.CXJG, B.SQLX,B.BBRXM, FUNC_BXGSDM_PZ('XB', C.AAC004, '945', '0',NULL,NULL),nvl(FUNC_BXGSDM_PZ('ZJLX',case when pkg_jkbx_util.f_is_date(B.BBRZJH) = 'Y' then '99' else /****-- +V 1.3****/ decode(C.AAC058,'1','01',C.AAC058) end/****add by zjp ?????????????????01 ???****/, '945', '0',NULL,NULL),'a'),nvl(B.BBRZJH,/*b.sqrzjhm -- +V 1.1*/'--'),
      FUNC_BXGSDM_PZ('ZBBRGX', B.ZBBRGX, '945', '0',NULL,NULL), NVL(TO_CHAR(TO_DATE(B.SQRQ,'YYYY-MM-DD'),'YYYY-MM-DD'),'??'),
      FUNC_BXGSDM_PZ('ZJLX', nvl(decode(B.SQRZJLX,'1','01',B.SQRZJLX),'01'), '945', '0',NULL,NULL),/*NVL( -- -V1.1*/B.SQRZJHM/*,B.BBRZJH) -- -V1.1*//****add by zjp ???????????????????******/,B.SQRXM,FUNC_BXGSDM_PZ('XB', C.SQRXB, '945', '0',NULL,NULL),
      B.SQRSJ, NULL,B.SQRYX,B.SQRDZ,C.SQRYB,NVL(C.SYRSL,1),
      NVL(FUNC_BXGSDM_PZ('LKRLX', c.LKRLX, '945', '0',NULL,NULL),'1'),DECODE(B.SQRZJLX,'07','',(SUBSTR(B.SQRZJHM,7?4)||'-'||SUBSTR(B.SQRZJHM,11?2)||'-'||SUBSTR(B.SQRZJHM,13?2))),(SELECT YBKH FROM TB_KHXX WHERE KHID=B.BBRKHID),
    /*wangpengfei  MZ150410-02  start*/
    CASE WHEN C.BBRZJYXQS LIKE '9999%' THEN '' ELSE
        DECODE(TRIM(C.BBRZJYXQS),'','',SUBSTR(C.BBRZJYXQS,1,4)||'-'||SUBSTR(C.BBRZJYXQS,5,2)||'-'||SUBSTR(C.BBRZJYXQS,7,2))
      END AS BBR_Id_begdate,
    CASE WHEN C.BBRZJYXQZ LIKE '9999%' THEN '' ELSE
        DECODE(TRIM(C.BBRZJYXQZ),'','',SUBSTR(C.BBRZJYXQZ,1,4)||'-'||SUBSTR(C.BBRZJYXQZ,5,2)||'-'||SUBSTR(C.BBRZJYXQZ,7,2))
       END AS BBR_Id_enddate,
    CASE WHEN C.SQRZJYXQS LIKE '9999%' THEN '' ELSE
        DECODE(TRIM(C.SQRZJYXQS),'','',SUBSTR(C.SQRZJYXQS,1,4)||'-'||SUBSTR(C.SQRZJYXQS,5,2)||'-'||SUBSTR(C.SQRZJYXQS,7,2))
       END AS SQR_Id_begdate,
    CASE WHEN C.SQRZJYXQZ LIKE '9999%' THEN '' ELSE
        DECODE(TRIM(C.SQRZJYXQZ),'','',SUBSTR(C.SQRZJYXQZ,1,4)||'-'||SUBSTR(C.SQRZJYXQZ,5,2)||'-'||SUBSTR(C.SQRZJYXQZ,7,2))
       END AS SQR_Id_enddate,
     -- DECODE(TRIM(C.BBRZJYXQS),'','',SUBSTR(C.BBRZJYXQS,1,4)||'-'||SUBSTR(C.BBRZJYXQS,5,2)||'-'||SUBSTR(C.BBRZJYXQS,7,2)),
     -- DECODE(TRIM(C.BBRZJYXQZ),'','',SUBSTR(C.BBRZJYXQZ,1,4)||'-'||SUBSTR(C.BBRZJYXQZ,5,2)||'-'||SUBSTR(C.BBRZJYXQZ,7,2)),
     -- DECODE(TRIM(C.SQRZJYXQS),'','',SUBSTR(C.SQRZJYXQS,1,4)||'-'||SUBSTR(C.SQRZJYXQS,5,2)||'-'||SUBSTR(C.SQRZJYXQS,7,2)),
     -- DECODE(TRIM(C.SQRZJYXQZ),'','',SUBSTR(C.SQRZJYXQZ,1,4)||'-'||SUBSTR(C.SQRZJYXQZ,5,2)||'-'||SUBSTR(C.SQRZJYXQZ,7,2)),
      /*wangpengfei  end*/
     -- C.LPKGFFH,C.LPKGFZH,C.BBRZY,C.BBRGZDW ,DECODE(C.SFYYJSDZYJ,'1','Y','N') ,  -- -V1.4
      pkg_jkbx_util.f_get_branchcode('945',C.LPKGFFH,'0'),pkg_jkbx_util.f_get_branchcode('945',C.LPKGFZH,'1'),C.BBRZY,C.BBRGZDW ,DECODE(C.SFYYJSDZYJ,'1','Y','N') ,    -- +V1.4
      FUNC_BXGSDM_PZ('ZFFS', B.AJPFFS, '945', '0',NULL,NULL),FUNC_GET_BANKID('945',B.LPKGFKHH),B.LPKGFYHZH,NULL,NULL,NULL,NULL,NULL,SYSDATE
    FROM TB_LPPCXX A,TB_LPAJXX B, TB_AJQTXX C
    WHERE A.PCID=B.LPPCID
    AND A.BXGSID=945
    AND B.AJZT='22'
    AND B.SFBLC='1'
    AND C.AJID=B.AJID
   -- and pah in('TBAL20150327001093','TBAL20150330013028','TBAL20150330003023') --added by yhs for test no data change
    order by b.pah asc
    ;

    -----???????---
    i_step := 4;
    INSERT INTO TB_TBAL_CLOSE_SJXX(
      YWLSH, PCH, AJID, JBDM, JZRQ, YYID, ZDLX, HOSPITAL_INFO,HOSPITAL_NAME,
      RYRQ, CYRQ, ZYTS, BBRSWRQ, SCJDRQ,
      JZKS, DOCTOR, ZJDM,
      SSDM, MEDICAL_TYPE, BILL_CNT, EXPORT_DATE)
    SELECT
      FUNC_GENERATE_LSH('0114'),sPch, S.AJID,JBDM,TO_CHAR(TO_DATE(S.JZRQ,'YYYY-MM-DD'),'YYYY-MM-DD'),S.YYID,S.ZDLX, FUNC_BXGSDM_PZ('TB_YYXX', S.YYID, '945', '0',NULL,NULL),DECODE(FUNC_BXGSDM_PZ('TB_YYXX', S.YYID, '945', '0',NULL,NULL),NULL,(SELECT YYMC FROM TB_YYXX WHERE YYID=S.YYID), FUNC_BXGSDM_PZ('TB_YYXX', S.YYID, '945', '1',NULL,NULL)),
      NULL,NULL,NULL,NULL,NULL,
      NULL,NULL,NULL,
      NULL,NULL,NULL,SYSDATE
      FROM
      (SELECT DISTINCT C.AJID,SUBSTR(C.JBDM,1,decode(sign(instr(C.JBDM,',')),0,length(C.JBDM),INSTR(C.JBDM,',')-1))JBDM,C.JZRQ,C.YYID,C.ZDLX/**,C.JZKS**/
      FROM  TB_LPPCXX A,TB_LPAJXX B,TB_LPFPXX C
      WHERE A.PCID=B.LPPCID
      AND A.BXGSID=945
      AND B.AJZT='22'
      AND B.SFBLC='1'
      AND C.AJID=B.AJID
      GROUP BY C.AJID,C.JZRQ,C.YYID,SUBSTR(C.JBDM,1,decode(sign(instr(C.JBDM,',')),0,length(C.JBDM),INSTR(C.JBDM,',')-1)),C.ZDLX,C.FPID/**,C.JZKS**/)S;

    i_step := 41;
     UPDATE TB_TBAL_CLOSE_SJXX AA
     SET AA.JZKS = (SELECT MAX(T.JZKS) FROM TB_LPFPXX T WHERE T.AJID=AA.AJID
                           AND SUBSTR(T.JBDM,1,decode(sign(instr(T.JBDM,',')),0,length(T.JBDM),INSTR(T.JBDM,',')-1))=AA.JBDM
                           AND T.JZRQ=TO_CHAR(TO_DATE(replace(AA.JZRQ,'-',''),'YYYYMMDD'),'YYYYMMDD') AND T.YYID=AA.YYID AND T.ZDLX=AA.ZDLX)
     WHERE AA.PCH=sPch;

    i_step := 5;
    UPDATE TB_TBAL_CLOSE_SJXX A
    SET A.RYRQ = (SELECT distinct TO_CHAR(TO_DATE(B.RYRQ,'YYYY-MM-DD'),'YYYY-MM-DD') FROM TB_LPFPXX B WHERE B.ZDLX='1' AND B.AJID=A.AJID AND B.YYID=A.YYID AND to_char(to_date(B.JZRQ,'yyyy-mm-dd'),'yyyy-mm-dd')=A.JZRQ AND B.ZDLX=A.ZDLX AND B.JBDM=A.JBDM),
    A.CYRQ = (SELECT distinct TO_CHAR(TO_DATE(B.CYRQ,'YYYY-MM-DD'),'YYYY-MM-DD') FROM TB_LPFPXX B WHERE B.ZDLX='1' AND B.AJID=A.AJID AND B.YYID=A.YYID AND to_char(to_date(B.JZRQ,'yyyy-mm-dd'),'yyyy-mm-dd')=A.JZRQ AND B.ZDLX=A.ZDLX AND B.JBDM=A.JBDM),
    A.ZYTS = (SELECT distinct B.ZYTS FROM TB_LPFPXX B WHERE B.AJID=A.AJID AND B.YYID=A.YYID AND to_char(to_date(B.JZRQ,'yyyy-mm-dd'),'yyyy-mm-dd')=A.JZRQ AND B.ZDLX=A.ZDLX AND B.JBDM=A.JBDM),
    A.BBRSWRQ = (SELECT distinct TO_CHAR(TO_DATE(B.BBRSWRQ,'YYYY-MM-DD'),'YYYY-MM-DD') FROM TB_LPAJXX B WHERE B.AJID=A.AJID),
    A.SCJDRQ  =(SELECT distinct TO_CHAR(TO_DATE(B.SCJDRQ,'YYYY-MM-DD'),'YYYY-MM-DD') FROM TB_AJQTXX B WHERE B.AJID=A.AJID),
    A.ZJDM = '',
    A.SSDM = (SELECT DISTINCT B.SSDM FROM TB_LPFPXX B WHERE B.AJID=A.AJID AND B.YYID=A.YYID AND to_char(to_date(B.JZRQ,'yyyy-mm-dd'),'yyyy-mm-dd')=A.JZRQ AND B.ZDLX=A.ZDLX AND B.JBDM=A.JBDM),
    A.MEDICAL_TYPE = (SELECT /*DISTINCT*/ min(FUNC_BXGSDM_PZ('YBBS', B.SJLX, '945', '0',NULL,NULL)) FROM TB_LPFPXX B WHERE B.AJID=A.AJID AND B.YYID=A.YYID AND to_char(to_date(B.JZRQ,'yyyy-mm-dd'),'yyyy-mm-dd')=A.JZRQ AND B.ZDLX=A.ZDLX AND B.JBDM=A.JBDM),
    A.BILL_CNT = (SELECT COUNT(1) FROM TB_LPFPXX B WHERE B.AJID=A.AJID AND B.YYID=A.YYID AND to_char(to_date(B.JZRQ,'yyyy-mm-dd'),'yyyy-mm-dd')=A.JZRQ AND B.ZDLX=A.ZDLX AND B.JBDM=A.JBDM)
    WHERE A.PCH=sPch;


    -----?????----
    FOR cc IN c_Sjxx LOOP
      i_step := 6;
      INSERT INTO TB_TBAL_CLOSE_FPXX(
        YWLSH, PCH, AJID, SJYWLSH, FPID,
        BILL_SNO , BILL_TYPE, CURRENCY ,
        CURR_RATE, BILL_AMT , BILL_DATE,
        sum_medicalpay1, sum_medicalpay2, sum_selfpay, sum_classification, sum_thirdpay,
        EXPORT_DATE)
      SELECT
        FUNC_GENERATE_LSH('0115'),sPch,S.AJID,cc.YWLSH,S.FPID,
        S.FPHM,FUNC_BXGSDM_PZ('ZDLX', S.ZDLX, '945', '0',NULL,NULL), DECODE(NVL(S.FPHBLX,'CNY'),'CNY','CNY','999'),
        '1', S.FPZE,TO_CHAR(TO_DATE(S.JZRQ,'YYYY-MM-DD'),'YYYY-MM-DD'),
        S.TCZFE, S.FJZFE,S.ZFZE,S.FLZFZE,S.DSFZFJE,
        SYSDATE
      FROM TB_LPFPXX S
      WHERE S.AJID=CC.AJID
      AND  NVL(SUBSTR(s.JBDM,1,decode(sign(instr(s.JBDM,',')),0,length(s.JBDM),INSTR(s.JBDM,',')-1)),'X')=NVL(CC.JBDM,'X')
      AND  to_char(to_date(s.JZRQ,'yyyy-mm-dd'),'yyyy-mm-dd')=CC.JZRQ
      AND S.YYID=CC.YYID
      AND S.ZDLX=CC.ZDLX;

      FOR ccfp IN c_Fpxx(cc.YWLSH) LOOP
        INSERT INTO TB_TBAL_CLOSE_HZXM(
          YWLSH, PCH, AJID, SJYWLSH, FPID,
          hz_item_code, hz_item_name, payment,
          selfpay, classification, medicalpay, thirdpay, payback,
          EXPORT_DATE)
        SELECT
          FUNC_GENERATE_LSH('0117'),sPch,cc.AJID,cc.YWLSH,ccfp.FPID,
          (SELECT DECODE(B.XZQHDM,'110000',FUNC_BXGSDM_PZ('BJDXDM', M.DXDM, '945', '0',NULL,NULL),FUNC_BXGSDM_PZ('DXDM', M.DXDM, '945', '0',NULL,NULL)) FROM TB_LPFPXX A,TB_YYXX B WHERE A.YYID=B.YYID AND A.FPID=ccfp.FPID),M.DXMC,M.ZDZJE,
          --M.ZFJE,0,0,0,0,
          M.ZFJE,0,0,0,0,
          SYSDATE
        FROM (SELECT T.DXDM,T.DXMC,T.FPID,SUM(T.ZDJE)ZDZJE,SUM(T.ZFJE)ZFJE FROM TB_FPXXFYXX T WHERE T.ZDJE<>0 GROUP BY T.DXDM,T.DXMC,T.FPID)M
        WHERE M.FPID=ccfp.FPID;

        ----????????
        INSERT INTO TB_TBAL_CLOSE_YPQD(
          YWLSH, PCH, AJID, SJYWLSH, FPID,
          DRUG_CODE, DRUG_NAME, DRUG_STD, DRUG_TYPE, DRUG_UNIT, DRUG_UNIT_AMT,
          DRUG_TOTAL, DRUG_PAY,
          MEDICAL_TYPE, SELFPAY_RATE, SELFPAY_AMT, REJECT_FLAG, REJECT_REASON,
          EXPORT_DATE,Drug_Bill_Code,Drug_Bill_Name)
        SELECT
          FUNC_GENERATE_LSH('0118'),sPch,cc.AJID,cc.YWLSH,ccfp.FPID,
          T.DRUG_CODE,T.DRUG_NAME,T.DRUG_STD,t.DRUG_TYPE,T.DRUG_UNIT,T.DRUG_UNIT_AMT,
          T.DRUG_TOTAL,T.DRUG_PAY,
          (SELECT AAA103 FROM AA10 WHERE AAA100='SBZFLB' AND AAA102=T.MEDICAL_TYPE)MEDICAL_TYPE,T.SELFPAY_RATE,T.SELFPAY_AMT,NULL,NULL,
          SYSDATE
          ,(SELECT DECODE(B.XZQHDM,'110000',FUNC_BXGSDM_PZ('BJDXDM', T.DXDM, '945', '0',NULL,NULL),FUNC_BXGSDM_PZ('DXDM', T.DXDM, '945', '0',NULL,NULL)) FROM TB_LPFPXX A,TB_YYXX B WHERE A.YYID=B.YYID AND A.FPID=ccfp.FPID),T.DXMC  -- +V1.8
        FROM
            /***************-- ????????????????  add  by  zhangjunpeng 2015-03-30************************/
          (SELECT /***-- +V1.5**/(SELECT YPID FROM TB_YPJBXX WHERE JBYPBM = nvl(M.Clfbm,M.XXDM) AND ROWNUM = 1) DRUG_CODE,nvl(M.CLFMC,M.XXMC) DRUG_NAME,M.MXXMGG DRUG_STD,'' AS DRUG_TYPE,M.MXXMDW DRUG_UNIT,M.MXXMDJ DRUG_UNIT_AMT,M.MXXMSL DRUG_TOTAL,
            M.ZDJE DRUG_PAY,
            /*CASE WHEN M.ZFJE =M.ZDJE THEN '2' ELSE '1' END AS MEDICAL_TYPE,*/
            NVL(M.SBZFLB,'0')  AS MEDICAL_TYPE,M.SJZFBL SELFPAY_RATE,
            /*wangpengfei  ????  start */
            nvl(M.FLZFJE,0)+nvl(M.Zfje,0) SELFPAY_AMT,
            /* wangpengfei  end */
            M.FPID,M.DXDM,M.DXMC
            FROM TB_FPXXFYXX M WHERE M.DXDM IN('08','09','10') AND M.ZDJE<>0)T
        WHERE T.FPID=ccfp.FPID;

        ---????
        INSERT INTO TB_TBAL_CLOSE_QTFY(
          YWLSH, PCH, AJID, SJYWLSH, FPID,
          ITEM_CODE,ITEM_NAME, ITEM_SUB_CODE, ITEM_SUB_NAME, ITEM_SUB_MEDICAL_TYPE,
          MEDICAL_CODE, ITEM_PAY, SELF_PAY_RATE, SELF_PAY_AMT, ITEM_UNIT_PAY,
          SUB_REJECT_FLAG, SUB_REJECT_REASON, EXPORT_DATE)
        SELECT
          FUNC_GENERATE_LSH('0119'),sPch,cc.AJID,cc.YWLSH,ccfp.FPID,
          (SELECT DECODE(B.XZQHDM,'110000',FUNC_BXGSDM_PZ('BJDXDM', N.ITEM_CODE, '945', '0',NULL,NULL),FUNC_BXGSDM_PZ('DXDM', N.ITEM_CODE, '945', '0',NULL,NULL)) FROM TB_LPFPXX A,TB_YYXX B WHERE A.YYID=B.YYID AND A.FPID=ccfp.FPID),N.ITEM_NAME,N.ITEM_SUB_CODE,N.ITEM_SUB_NAME,(SELECT AAA103 FROM AA10 WHERE AAA100='SBZFLB' AND AAA102=N.ITEM_SUB_MEDICAL_TYPE)ITEM_SUB_MEDICAL_TYPE,
          N.MEDICAL_CODE,N.ITEM_PAY,N.SELF_PAY_RATE,N.SELF_PAY_AMT,N.ITEM_UNIT_PAY,
          NULL,NULL,SYSDATE
        FROM (SELECT N.FPID,N.DXDM ITEM_CODE,N.DXMC ITEM_NAME,CASE WHEN N.DXDM = '12'AND N.XXDM = '12' THEN N.CLFBM ELSE N.XXDM END AS ITEM_SUB_CODE,CASE WHEN N.DXDM = '12'AND N.XXDM = '12' THEN N.CLFMC ELSE N.XXMC END AS ITEM_SUB_NAME,
            /*CASE WHEN N.ZFJE =N.ZDJE THEN '2' ELSE '1' END AS ITEM_SUB_MEDICAL_TYPE,*/
            NVL(N.SBZFLB,'0')  AS ITEM_SUB_MEDICAL_TYPE,N.XXDM AS MEDICAL_CODE,N.ZDJE ITEM_PAY,
            N.SJZFBL SELF_PAY_RATE,decode(N.sbzflb,'2',N.zfje,'1',N.flzfje,'0','','')/*N.FLZFJE -- -1.7*/ SELF_PAY_AMT,N.MXXMDJ AS ITEM_UNIT_PAY
            FROM TB_FPXXFYXX N WHERE N.DXDM NOT IN('08','09','10') AND N.ZDJE<>0)N
      WHERE N.FPID=ccfp.FPID;
      END LOOP;

    END LOOP;

    UPDATE TB_TBAL_CLOSE_SJXX S
    SET JBDM = FUNC_BXGSDM_PZ('TB_JBKXX', S.JBDM, '945', '0',NULL,NULL)
    WHERE S.PCH=sPch;

    FOR cc IN c_Spcxx LOOP
      i_step := 7;
      --SP_XMLFILE(cc.sPch,cc.BATCHNO,p_RtnCode,p_RtnMsg,sFilename);
      --IF sFilename IS NOT NULL THEN
        i_step := 8;
        UPDATE TB_TBAL_CLOSE_AJXX A
        SET A.dcwjm = /*sFilename*/(  SELECT 'VBPO' ||to_char(SYSDATE, 'yyyymmdd') || TRIM(TO_CHAR(NVL(MAX(TO_NUMBER(SUBSTR(B.DCWJM,13,3))),0)+1,'000')) ||'.xml' FROM
  TB_AL_CLOSE_CZJL c,TB_TBAL_CLOSE_AJXX B
  WHERE c.PCH=B.PCH AND B.BXGSID=945
  AND c.SJRQ=TO_CHAR(SYSDATE,'YYYYMMDD')
  AND c.YXZT='0')
        WHERE A.PCH = cc.sPch
        AND A.BATCHNO = cc.BATCHNO;

        i_step := 9;
        UPDATE TB_LPAJXX
        SET AJZT='11'
        WHERE AJID IN(SELECT AJID FROM TB_TBAL_CLOSE_AJXX WHERE PCH=cc.sPch AND BATCHNO=cc.BATCHNO);

        --SELECT REPLACE(sFilename,'.xml','.csv') into sWtjWjm from dual;
      --END IF;

      -----???????????????CSV??
      SELECT COUNT(1) INTO i_Count from tb_error_yxaj a where A.SJLY='T' AND A.CLZT='0' AND A.CWPCH=cc.BATCHNO;
      IF i_Count > 0 THEN
        i_step := 10;
        sSql := 'select a.WBPAH from tb_error_yxaj a where a.sjly=''T''and a.clzt=''0'' and cwpch='''||cc.BATCHNO||'''';
        i_step := 101;
        EXECUTE IMMEDIATE 'create directory MYDIR as '||''''||v_dname||'''';
        --execute immediate v_sqlstr;
        i_step := 102;
        EXECUTE IMMEDIATE 'grant read,write on directory MYDIR to public';
        i_step := 11;
        sql_to_csv(sSql,'MYDIR',sWtjWjm);
        EXECUTE IMMEDIATE 'DROP directory MYDIR';

        i_step := 12;
        UPDATE tb_error_yxaj
        SET CLZT='1'
        WHERE CWPCH=cc.BATCHNO;
      END IF;

    END LOOP;
    ----????????????????????????????TB_AJQTXX?
    i_step := 13;
      UPDATE TB_AJQTXX A
      SET A.SFXYSCYX='1'
      WHERE EXISTS(SELECT 1 FROM TB_IMAGE_LINKS B WHERE SUBSTR(B.IMG_PATH,1,1)='W' AND B.AJID=A.AJID)
      AND EXISTS(SELECT 1 FROM TB_TBAL_CLOSE_AJXX T WHERE T.PCH=sPch AND T.AJID=A.AJID);
    /******************-- +V1.2 start*********************/
    update tb_lppcxx a set pczt='04',SJSFRQ=(
select max(to_char(EXPORT_DATE,'yyyymmdd')) from tb_lpajxx b,tb_tbal_close_ajxx c where b.ajid=c.ajid and b.lppcid=a.pcid)
 where a.pch like  'TBAL%'  and exists(select 'x' from tb_lpajxx where lppcid=pcid and ajzt='11')
and not exists(select 'x' from tb_lpajxx where lppcid=pcid and ajzt!='11')
and exists (SELECT 1 FROM TB_TBAL_CLOSE_AJXX T,tb_lpajxx e WHERE T.PCH=sPch AND T.AJID=e.AJID and e.lppcid = a.pcid);
    /******************-- +V1.2 end***********************/
    IF p_RtnMsg IS NULL THEN
      p_RtnMsg:='????';
    END IF;
    UPDATE TB_AL_CLOSE_CZJL
    SET JSSJ = SYSDATE
    WHERE PCH=sPch;
    COMMIT;
EXCEPTION
  WHEN OTHERS THEN
      p_RtnCode := SQLCODE;
      p_RtnMsg := SQLERRM;
      ROLLBACK;
     Pkg_Error_Log.Pro_Error_In('PROC_TBALCLOSE_EXPORT', i_step, p_RtnCode, p_RtnMsg);
END PROC_TBALCLOSE_EXPORT;

/
