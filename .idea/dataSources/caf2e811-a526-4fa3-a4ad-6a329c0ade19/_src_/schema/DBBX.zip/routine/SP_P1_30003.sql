CREATE PROCEDURE      "SP_P1_30003" (report_id   In t_report_def_info.REPORTID%TYPE,
                                        pStartdate  IN varchar2, -- ???????????yyyymmdd
                                        pEnddate    IN varchar2, -- ??????????yyyymmdd
                                        pStatman    IN t_report_gen_info.STATMAN%TYPE, --???
                                        ptype       in varchar2, /*0 ???? ,1 ?? 2 ?? 3 ?? */ --?????
                                        POther1     IN varchar2, --??id
                                        POther2     IN varchar2, --??id
                                        POther3     IN varchar2, --??id
                                        POther4     IN varchar2, --??ID
                                        POther5     IN varchar2, --????
                                        POther6     IN varchar2, --??ID
                                        POther7     IN varchar2, --??
                                        POther8     IN varchar2, --??
                                        PReturnCode OUT varchar2,
                                        PReturnMsg  OUT varchar2) AS
  V_STEP_CODE  CHAR(5); --?????????????????
  vreportid    t_report_def_info.REPORTID%TYPE; --??ID
  v_start_date number := 0; --????????
  v_end_date   number := 0; --????????
  vxzqhdm      t_report_gen_info.STATORGID%TYPE; --????????????

  vstatid varchar(30); --?????????????????
  type cellType is record(
    statid  varchar2(15),
    col     number,
    r       number,
    content varchar2(1024));

  cell      cellType; --?????????????
  vdwmc     varchar2(50); --????????????
  vusername t_report_gen_info.STATMAN%TYPE; --????????
  vnd       t_report_gen_info.STATYEAR%TYPE; --????
  rowno     number := 0; --??????

  v_tthjzs number :=0;--????
  v_bdhjzs number :=0;--????
  v_ryhjzs number :=0;--????
  v_jhbfje number :=0;--?????????

  vv_bdhjzs number :=0;--???????
  vv_ryhjzs number :=0;--????
  vv_bdrshj number :=0;--??????

  vv_rshj number := 0 ;--??????
  vv_bfhj number := 0 ;--????



begin
  V_STEP_CODE := '00000';
  PReturnMsg  := 'OK';
  PReturnCode := 'E';
  vreportid   := substr(report_id, 1, 5);
  vusername   := pStatman;
  vnd         := substr(pStartdate, 1, 4);

  v_start_date := to_number(substr(pStartdate, 1, 8));
  v_end_date   := to_number(substr(pEnddate, 1, 8));

  --???????????????????????????
  delete from t_report_data_info
   where statid in
         (select statid from T_REPORT_GEN_INFO where reportid = report_id);

  delete from T_REPORT_GEN_INFO
   where statid in
         (select statid from T_REPORT_GEN_INFO where reportid = report_id);

  V_STEP_CODE := '00001';
  --???,?T_RERORT_GEN_INFO?????????????
  --???????
  select seq_statid.nextval into vstatid from dual;

  -- ??????????
  insert into t_report_gen_info
    (STATID,
     REPORTID,
     STATORGID,
     STATORGNAME,
     STATDATE,
     STATMAN,
     STATYEAR,
     BEGINDATE,
     ENDDATE,
     STAT_OTHER,
     STAT_TYPE)
  values
    (vstatid,
     vreportid,
     '',
     '',
     to_char(sysdate, 'yyyymmdd'),
     vusername,
     vnd,
     v_start_date,
     v_end_date,
     substr(pEnddate, 1, 1),
     trim(ptype));

  /* --?????? ??excel???0?????1??,????0???*/

   --???
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,1,2,'MB002');

  --????
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,1,3,to_char(sysdate,'yyyymmdd'));

  --???????
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,1,7,trim(pStartdate) ||'-'|| trim(pEnddate));

  --????
  select max(bxgsqc) into cell.content from tb_bxgsxx where bxgsid=trim(POther1);
  if cell.content is not null then
    insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,1,4,cell.content);
  end if;

  --??
  select count(distinct c.ttid) as tthjzs,
         count(distinct b.khbdh) as bdhjzs,
         count(distinct e.bbrkhid) as ryhjzs,
         nvl(sum(nvl(h.zrbf, 0)), 0) as bf
    into v_tthjzs, v_bdhjzs, v_ryhjzs, v_jhbfje
    from tb_bxgsxx  a,
                    tb_bdxx    b,
                    tb_ttxx    c,
                    --tb_zttxx   d,
                    tb_fdxx    e,
                 --   tb_bdcpxx  f,
                    tb_cpzrdzb g,
                    tb_fdzrmx  h,
                    tb_cpxx    j
              where a.bxgsid = b.bxgsid
                and b.ttid = c.ttid
               -- and b.bdid = f.bdid
               -- and f.cpid = j.cpid
                and b.khbdh = e.khbdh
                and j.cpid = g.cpid
                and g.zrid = h.zrid
                and h.fdid = e.fdid
                --and b.bdzt = '3'
     and b.bxgsid = nvl(trim(POther1),b.bxgsid)
     and b.bdzzrq >= nvl(trim(pStartdate),'19000101')
     and b.bdzzrq <= nvl(trim(pEnddate),'99991231');

  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,1,6,v_tthjzs);
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,3,6,v_bdhjzs);
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,5,6,v_ryhjzs);
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,7,6,v_jhbfje);


  cell.statid := vstatid;
  cell.col    := 0; --?1???
  cell.r      := 10; --?11???
  --???????????????????????????????excel????????????????????
  for rec_bxgs in(
        select a.bxgsid,a.bxgsqc
         from tb_bxgsxx a, tb_bdxx b, tb_ttxx c
        where a.bxgsid = b.bxgsid
          and b.ttid = c.ttid
          and a.bxgsid = nvl(trim(POther1), a.bxgsid)
          --and b.bdzt = '3'
           and b.bdzzrq >= nvl(trim(pStartdate),'19000101')
           and b.bdzzrq <= nvl(trim(pEnddate), '99991231')
             and exists(select 'x' from tb_fdxx where khbdh=b.khbdh)
        group by a.bxgsid,a.bxgsqc
            ) loop
     for rec_tt in(
        select c.ttbh, c.ttid, c.ttmc
           from tb_bxgsxx a, tb_bdxx b, tb_ttxx c
          where a.bxgsid = rec_bxgs.bxgsid
            and a.bxgsid = b.bxgsid
            and b.ttid = c.ttid
            --and b.bdzt = '3'
            and b.bdzzrq >= nvl(trim(pStartdate),'19000101')
            and b.bdzzrq <= nvl(trim(pEnddate), '99991231')
              and exists(select 'x' from tb_fdxx where khbdh=b.khbdh)
          group by c.ttbh, c.ttid, c.ttmc
     ) loop
      for rec_bdxx in(
        select b.bdid,b.khbdh ,b.bdsxrq,b.bdzzrq,b.jffs
          from tb_bxgsxx  a,
               tb_bdxx    b,
               tb_ttxx    c
         where
           a.bxgsid = rec_bxgs.bxgsid
           and c.ttid = rec_tt.ttid
           and a.bxgsid = b.bxgsid
           and b.ttid = c.ttid
           --and b.bdzt = '3'
           and b.bdzzrq >= nvl(trim(pStartdate),'19000101')
           and b.bdzzrq <= nvl(trim(pEnddate), '99991231')
           and exists(select 'x' from tb_fdxx where khbdh=b.khbdh)
         group by b.bdid,b.khbdh ,b.bdsxrq,b.bdzzrq,b.jffs
       ) loop
          for rec_cpxx in(
                select j.cpmc ,count(distinct e.bbrkhid) as rs,nvl(sum(nvl(h.zrbf, 0)), 0) as bf
                   from tb_bxgsxx  a,
                        tb_bdxx    b,
                        tb_ttxx    c,
                        --tb_zttxx   d,
                        tb_fdxx e,
                       -- tb_bdcpxx f,
                        tb_cpzrdzb g,
                        tb_fdzrmx h,
                        tb_cpxx j
                  where
                    a.bxgsid = rec_bxgs.bxgsid
                    and c.ttid = rec_tt.ttid
                    and b.bdid = rec_bdxx.bdid
                    and a.bxgsid = b.bxgsid
                    and b.ttid = c.ttid
                  --  and b.bdid = f.bdid
                  --  and f.cpid = j.cpid
                    and b.khbdh = e.khbdh
                    and j.cpid = g.cpid
                    and g.zrid = h.zrid
                    and h.fdid = e.fdid
                    --and b.bdzt = '3'
                    and b.bdzzrq >= nvl(trim(pStartdate), '19000101')
                    and b.bdzzrq <= nvl(trim(pEnddate), '99991231')
                  group by j.cpmc
             )loop

              --??????
              cell.content := rec_bxgs.bxgsqc;
              if cell.content is not null then
              insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,0,cell.r,cell.content);
              end if;

              --????
              cell.content := rec_tt.ttbh;
              if cell.content is not null then
              insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,1,cell.r,cell.content);
              end if;

              --????
              cell.content := rec_tt.ttmc;
              if cell.content is not null then
              insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,2,cell.r,cell.content);
              end if;

              --?????
              select max(e.zttmc) into  cell.content from tb_zttxx e,tb_bdxx d  where e.zttid = d.zttid and d.bdid = rec_bdxx.bdid;
              if cell.content is not null then
              insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,3,cell.r,cell.content);
              end if;

              --???
              cell.content := rec_bdxx.khbdh;
              if cell.content is not null then
              insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,4,cell.r,cell.content);
              end if;

              --??????
              cell.content := rec_bdxx.BDSXRQ;
              if cell.content is not null then
              insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,5,cell.r,cell.content);
              end if;

              --??????
              cell.content := rec_bdxx.BDZZRQ;
              if cell.content is not null then
              insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,6,cell.r,cell.content);
              end if;

              --??
              cell.content := rec_cpxx.cpmc;
              if cell.content is not null then
              insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,7,cell.r,cell.content);
              end if;

              --????
              select max(aaa103) into cell.content from aa10 where aaa100 = 'JFFS' and aaa102 = rec_bdxx.jffs;
              if cell.content is not null then
              insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,8,cell.r,cell.content);
              end if;

              --????
              cell.content := rec_cpxx.rs;
              if cell.content is not null then
              insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,9,cell.r,cell.content);
              end if;

               --??????
              cell.content := rec_cpxx.bf;
              if cell.content is not null then
              insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,10,cell.r,cell.content);
              end if;

              cell.r :=  cell.r+1;

           end loop ;
               /*?????*/
               insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,8,cell.r,'????');
               select
                    count(distinct e.bbrkhid) as rs,
                    nvl(sum(nvl(h.zrbf, 0)), 0) as bf
                    into vv_rshj,vv_bfhj
               from tb_bxgsxx  a,
                    tb_bdxx    b,
                    tb_ttxx    c,
                    --tb_zttxx   d,
                    tb_fdxx    e,
                    --tb_bdcpxx  f,
                    tb_cpzrdzb g,
                    tb_fdzrmx  h,
                    tb_cpxx    j
              where a.bxgsid = rec_bxgs.bxgsid
                and c.ttid = rec_tt.ttid
                and b.bdid = rec_bdxx.bdid
                and a.bxgsid = b.bxgsid
                and b.ttid = c.ttid
                --and b.bdid = f.bdid
                --and f.cpid = j.cpid
                and b.khbdh = e.khbdh
                and j.cpid = g.cpid
                and g.zrid = h.zrid
              and h.fdid = e.fdid
                --and b.bdzt = '3'
                and b.bdzzrq >= nvl(trim(pStartdate), '19000101')
                and b.bdzzrq <= nvl(trim(pEnddate), '99991231');


               insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,9,cell.r,vv_rshj);
               insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,10,cell.r,vv_bfhj);

               cell.r :=  cell.r+1;
      end loop ;
          --???????      ????
          select count(distinct b.bdid) as bdhjzs,
                 count(distinct e.bbrkhid) as bdrshj,
                 nvl(sum(nvl(h.zrbf, 0)), 0) as ryhjzs
            into vv_bdhjzs, vv_ryhjzs,vv_bdrshj
            from tb_bxgsxx  a,
                    tb_bdxx    b,
                    tb_ttxx    c,
                    --tb_zttxx   d,
                    tb_fdxx    e,
                   -- tb_bdcpxx  f,
                    tb_cpzrdzb g,
                    tb_fdzrmx  h,
                    tb_cpxx    j
              where a.bxgsid = rec_bxgs.bxgsid
                and c.ttid = rec_tt.ttid
                --and b.bdid = rec_bdxx.bdid
                and a.bxgsid = b.bxgsid
                and b.ttid = c.ttid
               -- and b.bdid = f.bdid
              --  and f.cpid = j.cpid
                and b.khbdh = e.khbdh
                and j.cpid = g.cpid
                and g.zrid = h.zrid
                and h.fdid = e.fdid
                --and b.bdzt = '3'
                and b.bdzzrq >= nvl(trim(pStartdate), '19000101')
                and b.bdzzrq <= nvl(trim(pEnddate), '99991231');

           insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,1,cell.r,'???????');
           insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,2,cell.r,vv_bdhjzs);
           insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,8,cell.r,'????');
           insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,9,cell.r,vv_ryhjzs);
           insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,10,cell.r,vv_bdrshj);
           cell.r :=  cell.r+1;
    end loop;
  end loop;

  --???????????
  /*9.??*/
  PReturnCode := '0'; /* ??????????????vstatid????????? */
  PReturnMsg  := vstatid;
  DBMS_OUTPUT.PUT_LINE('[LDS debug] ' || 'PReturncode= ' || PReturnCode);
  --COMMIT; ???java?????????

EXCEPTION
  WHEN OTHERS THEN
    --rollback;???java?????????????0?????????????????
    PReturnCode := 'E'; /*  ??????  */
    DBMS_OUTPUT.PUT_LINE('[yhs debug] ' || 'PReturncode= ' || PReturnCode);
    PReturnMsg := ' rownum' || cell.r || 'Error:' || sqlerrm; --???????????
    DBMS_OUTPUT.PUT_LINE(PReturnMsg);
end SP_P1_30003;

/
