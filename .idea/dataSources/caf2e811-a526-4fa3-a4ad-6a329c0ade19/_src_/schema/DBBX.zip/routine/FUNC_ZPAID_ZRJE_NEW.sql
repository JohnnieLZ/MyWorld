CREATE function      FUNC_ZPAID_ZRJE_NEW(P_ZPAID number) return number is
--?????????
  Result number := 0;
ajjl_V varchar2(3):='';
begin
  select nvl(ZPAJL,'99') into ajjl_V from tb_zpaxx where zpaid=P_ZPAID;
  if ajjl_V='02' then   --???????
     select 0 into Result from dual;
  else           --????????
    select nvl(a.ZDZJE,0)-(
 select nvl(sum(case when t.hlbhfllsgzid is not null then h.FLZFJE else 0 end),0) + nvl(sum(case when t.zffylsgzid is null then h.zfje else 0 end),0) + nvl(a.sbzfzje,0) from tb_zpaxxdzb t,tb_fpxxfyxx h where t.xxid=h.xxid and t.zpaid=a.zpaid
 and (a.pfzrdm like 'AIOP%' or a.pfzrdm like 'IP%' or a.pfzrdm like 'OP%' or a.pfzrdm like 'OIP%' or a.pfzrdm like 'MAT%' or a.pfzrdm like 'DE%' or a.pfzrdm like 'PE%')
 ) into Result from tb_zpaxx a where a.zpaid=p_zpaid;

 select Result-FUNC_ZPAID_BLKCJE_NEW(p_zpaid) into Result from dual;
  end if;
  return(Result);
end FUNC_ZPAID_ZRJE_NEW;

/
