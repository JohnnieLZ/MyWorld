CREATE procedure SP_P1_CASEASSIGNFLOW(PIN_AJID IN varCHAR2,Pin_userid IN varCHAR2 ,PReturnCode OUT varchar2,
                              PReturnMsg    OUT varchar2) AS
  V_STEP_CODE  VARCHAR2(5):='00000';
  v_start_date number := 0;
  v_end_date   number := 0;
  v_no  number:=0;
  rec_ajxx tb_lpajxx%rowtype;
  v_001zd number:=0; --是否不确定诊断，缺省为0
  v_fpid number(16):=0;--出错发票号码
  --20141229 yhs 案件业务流程优化调整，初审复审都调用分流过程
  v_gndm varchar2(20):='';
  v_zjl number(6,2):=100; --未配置质检率的人员，缺省都按100%抽检
  --20141229 yhs
  begin
    PReturnCode:='E';
    PReturnMsg:='Error!';
    --业务处理块
    if (PIN_AJID is null or Pin_userid is null) then
      PReturnCode:='-1';
      PReturnMsg:='参数输入错误!';
      return;
    end if;
    --提交时数据检查
      select * into rec_ajxx from tb_lpajxx where ajid=to_number(trim(PIN_AJID));
      --added by yhs 20150407 借用rec_ajxx的WBPAZH储存团体编号，以便根据不同团体设置校验规则

   --医院为空的校验
     select nvl(max(fpid),0) into v_fpid from tb_lpfpxx where ajid=to_number(trim(PIN_AJID)) and yyid is  null;
     if v_fpid!=0 then
        select '发票id='||to_char(v_fpid)||' 发票号码为'||trim(FPHM) ||'的发票医院信息为空，不能提交！' into PReturnMsg  from tb_lpfpxx where fpid=v_fpid;
        PReturnCode:='-1';
         return;
     end if;

      --发票总金额不能<TCZFE+FJZFE+SBZFE
     select nvl(max(fpid),0) into v_fpid from tb_lpfpxx where ajid=to_number(trim(PIN_AJID)) and nvl(FPZE,0)<(nvl(TCZFE,0)+nvl(FJZFE,0)+nvl(sbZFE,0));
     if v_fpid!=0 then
        select '发票id='||to_char(v_fpid)||' 发票号码为'||trim(FPHM) ||'的发票发票总金额小于统筹支付额 +附加支付额+其他社保支付，不能提交！' into PReturnMsg  from tb_lpfpxx where fpid=v_fpid;
        PReturnCode:='-1';
         return;
     end if;
      --发票总金额必须等于细项账单金额之和


     /*流程调整，案件录入后到初审，不再调用后台过程，直接更新案件状态，由杜海龙调整java程序
    --校验通过后，最后更新案件状态和各类可生成标志
    update tb_lpajxx set AJZT='02',lrrid=Pin_userid,lrr=(select name from uap_user where userid=Pin_userid) where ajid=to_number(trim(PIN_AJID)) and AJZT='01';

     --如果录入完毕，则更新批次状态为已录入状态，录入日期
     update tb_lppcxx a set pcZT='02',lrrq=to_char(sysdate,'yyyymmdd') where pcid=(select lppcid from tb_lpajxx where ajid=to_number(trim(PIN_AJID))) and pcZT='01'
     and exists(select count(1) from tb_lpajxx b where b.lppcid=a.pcid group by b.lppcid having count(1)=a.ajs);
    */
    --更新案件复审人员信息
    --20141229 yhs 案件业务流程优化调整，初审复审都调用分流过程 begin 初审不送复审
      select /*nvl(count(1),1)*/1,0 into v_no, v_zjl  from dual; /*TB_YWYCJLPZ where userid=Pin_userid and zt='1' and YWLX=decode(rec_ajxx.ajzt,'02','P10408','P10409'); */--获取抽检比率
       if   v_no=0 then
          --PReturnCode:='-1';
         --PReturnMsg:='操作员'||Pin_userid||'没有配置初审、复审抽检比率，不能操作业务!';
         --return;
         null;
     end if ;
       -- 半流程业务逻辑处理
     --全流程业务逻辑处理 ,初审根据配置比率来决定是否送复审，不送复审的调用审核程序， 复审一定要生成子赔案，调用原来业务
         --初审业务根据抽检率决定是否送复审
         --获取当日先前送复审抽检的案件数,借用v_fpid储存当日总共检查的总案件数（不含当前案件）
      if rec_ajxx.ajzt='02' then
             select nvl(sum(case when nvl(fsr,'xx')!='system' then 1 else 0 end),0),count(1) into v_no ,v_fpid from tb_lpajxx a ,tb_ajqtxx b
                   where a.ajid=b.ajid and a.csrid=Pin_userid and csrq=to_char(sysdate,'yyyymmdd') ; --无需复审的案件，复审人统一设置为system,fsrid为空
             --num+算上本案作为该业务员总共处理案件数，num1为之前已质检的数，如果达到质检率则将该案送质检

             if ( v_no+1.00)/(v_fpid+1.00)*100<=v_zjl then --如果比率在抽检范围内，则要送复审
                 update tb_lpajxx set ajzt='21' , csrid=Pin_userid,csr=(select name from uap_user where userid=Pin_userid)
                   where ajid=to_number(trim(PIN_AJID));
                 update  tb_ajqtxx b set b.csrq=to_char(sysdate,'yyyymmdd')  where ajid=to_number(trim(PIN_AJID));
                    --20150126 16:00yhs 初审送完复审后，业务流程结束
                 PReturnCode:='0';
                 PReturnMsg:='案件录入处理成功!业务数据有问题，直接进入人工审核！';
                 return;
                 --20150126 16:00yhs  end
              else  --不复审的，直接设置为复审结束
                   update tb_lpajxx set ajzt='22', csrid=Pin_userid,csr=(select name from uap_user where userid=Pin_userid),fsr='system'
                   where ajid=to_number(trim(PIN_AJID));
                   update  tb_ajqtxx b set b.csrq=to_char(sysdate,'yyyymmdd')  where ajid=to_number(trim(PIN_AJID));
                   rec_ajxx.ajzt:='22';
                   rec_ajxx.fsr:='system';
                   goto FSYW;
                   --跳到复审送人工审核还是质检处理程序
              end if;
           end if ;
        <<FSYW>>

        --复审时案件流程分派处理

  --  受理、录入岗是否有选择人工悬挂代码，如有则不生成子赔案;虚拟赔案直接进入人工审核2状态.也不生成子赔案
      if rec_ajxx.sfxnaj='1' then
          update tb_lpajxx set AJZT='04',SFZDSCZPA='0',ajxgdm='CL12',AJXGLY='虚拟赔案，请审核' where ajid=to_number(trim(PIN_AJID)) and AJZT in('02','21','22');
          rec_ajxx.ajzt:='04';
      end if;
      if rec_ajxx.AJXGDM is not null  then
          update tb_lpajxx set AJZT='04',SFZDSCZPA='0' where ajid=to_number(trim(PIN_AJID)) and  AJZT in('02','21','22');
           rec_ajxx.ajzt:='04';
      end if;
      if   v_001zd=1 then
          update tb_lpajxx set AJZT='04',SFZDSCZPA='0',ajxgdm='CL11',AJXGLY='诊断错误!'  where ajid=to_number(trim(PIN_AJID)) and AJZT  in('02','21','22');
           rec_ajxx.ajzt:='04';

       end if ;
       if  rec_ajxx.ajzt='04' then
              PReturnCode:='0';
             PReturnMsg:='案件录入处理成功!业务数据有问题，直接进入人工审核！';
             --设置复审人信息
             update tb_lpajxx set  fsrid=Pin_userid,fsr=(select name from uap_user where userid=Pin_userid) where ajid=to_number(trim(PIN_AJID));
             update  tb_ajqtxx b set b.fsrq=to_char(sysdate,'yyyymmdd')  where ajid=to_number(trim(PIN_AJID));--更新全流程案件复审日期
             return;
       end if;

      --业务数据无问题的，生成子赔案
          SP_P1_CASECHECK(PIN_AJID ,'' ,PReturnCode, PReturnMsg);--全流程子赔案生成
         if PReturnCode!='0' and Pin_userid is null then --审核出错 返回具体错误码
             return;
         end if;





           --没任何悬挂子赔案的案件且案件、发票无悬挂的、或银行姓名、开户行、账号都完整的，根据配置比率送复审，能结案的根据配置比率送质检，设置人工审核1，其他人工审核2
        --select count(1),sum(case when a.xgdm is  null and not exists (select 'x' from tb_lpfpxx b,tb_lpajxx c where b.ajid=c.ajid and b.ajid=a.ajid and (c.ajxgdm is not null or b.xgdm is not null) and (c.sqrxm is null or c.lpkgfkhh is null or c.lpkgfyhzh is null) )  then 0 else 1 end)  into v_no, v_001zd from tb_zpaxx a where ajid=to_number(trim(PIN_AJID));
        --v1.4++ 案件分拣自动结案时，当事人在同一保险公司下如有之前受理的赔案未释放，则不能自动结案，必须送人工审核
        select count(1),sum(case when a.xgdm is  null and not exists (select 'x' from tb_lpfpxx b,tb_lpajxx c where b.ajid=c.ajid and b.ajid=a.ajid and ((c.ajxgdm is not null or b.xgdm is not null) or ( c.ajxgdm like '%CL73%' /*20150414 yhs 判断银行信息是否需要看悬挂代码就可 c.skfxm is null or c.lpkgfkhh is null or c.lpkgfyhzh is null */)) )  then 0 else 1 end)  into v_no, v_001zd
          from tb_zpaxx a where ajid=to_number(trim(PIN_AJID));
        if v_no>0 and v_001zd=0  then
             --未配置抽检比率的，都按全部流程必走处理
             select 1 ,nvl(max( zjl),100) into v_no,v_zjl from TB_YWYCJLPZ where userid=Pin_userid and zt='1' and YWLX='P10409'; --获取复审阶段抽检比率
             if   v_no=0 then
               PReturnCode:='-1';
               PReturnMsg:='操作员'||Pin_userid||'没有配置复审抽检比率，不能操作业务!';
               return;
             end if ;
             if  v_zjl>0.00 then
                if  rec_ajxx.fsr='system' then --初审人送质检
                   select case when  (f.Num1+1)/(f.num+1)*100<=v_zjl then 1 else 0 end into v_no from  (select count(1) as num ,nvl(sum(case when ZJJL is not null or ajzt='05' then 1 else 0 end),0) as num1
                   from tb_lpajxx a,tb_ajqtxx b where a.ajid=b.ajid(+)
                    and  a.csrid =Pin_userid
                      and  b.fsrq =to_number(to_char(sysdate,'yyyymmdd')) ) f;
                else  --复审人送质检
                    select case when  (f.Num1+1)/(f.num+1)*100<=v_zjl then 1 else 0 end into v_no from  (select count(1) as num ,nvl(sum(case when ZJJL is not null or ajzt='05' then 1 else 0 end),0) as num1
                   from tb_lpajxx a,tb_ajqtxx b where a.ajid=b.ajid(+)
                    and  a.fsrid =Pin_userid
                    and  b.fsrq =to_number(to_char(sysdate,'yyyymmdd')) ) f;
                end if;
               --num+算上本案作为该业务员总共处理案件数，num1为之前已质检的数，如果达到质检率则将该案送质检

               if v_no>0 then
                  update tb_lpajxx a set ajzt='04',ajjl='',shr='' where ajid=to_number(trim(PIN_AJID)) ;
                  PReturnMsg:='该赔案根据操作人质检比率，被送至质检。';

               else --不送质检的直接结案
                  --20150122 10:33 结案时批次已释放的，案件自动设置为释放状态
                  update tb_lpajxx a set jarq=to_char(sysdate,'yyyymmdd'),ajjl='01',shr='system' ,sfrq=to_char(sysdate,'yyyymmdd') ,ajzt='09'
                 where ajid=to_number(trim(PIN_AJID))
                 and  exists (select 'x' from tb_lppcxx b where b.pcid=a.lppcid and b.pczt='03') ;
                 if sql%rowcount=0 then
                    update tb_lpajxx a set ajzt='08',jarq=to_char(sysdate,'yyyymmdd'),ajjl='01',shr='system' where ajid=to_number(trim(PIN_AJID))
                    and  not exists (select 'x' from tb_lppcxx b where b.pcid=a.lppcid and b.pczt='03');
                  end if;
                  PReturnMsg:='该赔案由于子赔案没任何问题，直接结案。';

               end if;
                --更新复审日期
                update  tb_ajqtxx b set b.fsrq=to_char(sysdate,'yyyymmdd')  where ajid=to_number(trim(PIN_AJID));

            end if;

        else  --赔案或子赔案数据有疑问的，都送人工审核
         --20141110开始烦请协助安排将初审复核功能开放，初审复核通过后状态为人工审核1的案件请自动结案流转至质检环节中。后期需要记录自动结案案件被质检退回的案件比例
          -- update tb_lpajxx a set ajzt='04' where ajid=to_number(trim(PIN_AJID)) ;
              update tb_lpajxx a set ajzt='04' where ajid=to_number(trim(PIN_AJID));
              PReturnMsg:='该赔案由于子赔案有悬挂，被送至人工审核2。';
        end if;
        if rec_ajxx.fsr is null then       --直接是由复审员复审调用  ,更新案件复审人记录信息
             update tb_lpajxx set  fsrid=Pin_userid,fsr=(select name from uap_user where userid=Pin_userid) where ajid=to_number(trim(PIN_AJID));
             update  tb_ajqtxx b set b.fsrq=to_char(sysdate,'yyyymmdd')  where ajid=to_number(trim(PIN_AJID));--更新全流程案件复审日期
        end if;
     --20141229 yhs end

    PReturnCode:='0';
    PReturnMsg:='案件录入处理成功!';
    return;
    EXCEPTION
  WHEN OTHERS THEN
    PReturnCode := 'E';
    DBMS_OUTPUT.PUT_LINE('[yhs debug] ' || 'PReturncode= ' ||
                         PReturnCode);
    PReturnMsg := 'Error:' || sqlerrm;
    DBMS_OUTPUT.PUT_LINE(PReturnMsg);
  end   SP_P1_CASEASSIGNFLOW;
/
