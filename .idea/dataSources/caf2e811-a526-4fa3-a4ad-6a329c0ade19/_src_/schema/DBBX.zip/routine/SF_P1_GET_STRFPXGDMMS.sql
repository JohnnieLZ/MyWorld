CREATE function      SF_P1_GET_STRFPXGDMMS(pFpid in varchar2,p_aaa100 in varchar2) return varchar2 is
cursor cur_rec is /*select b.aaa102,trim(b.aaa103) as aaa103 from aa10 b where
b.aaa102 in(select trim(COLUMN_VALUE) from TABLE(sf_splitstr((select XGDM from tb_lpfpxx where fpid=pFpid),',')) H )
and b.aaa100=trim(p_aaa100)*/
   select b.aaa102, trim(b.aaa103) as aaa103
  from aa10 b,tb_lpfpxx c
 where ((c.xgdm like '%'||b.aaa102||'%' and c.xgdm not like '%02%') or (c.xgdm  like '%02%' and b.aaa102 in(select trim(COLUMN_VALUE) from TABLE(sf_splitstr((select XGDM from tb_lpfpxx where fpid=pFpid),',')) H )  ))  and c.fpid=to_number(pFpid)  --?????02????????FP02????
   and b.aaa100 = trim(p_aaa100);
v_FPXGDMMS varchar2(4096):='';


Result varchar2(4096):='' ;
 --v2.2++ begin
 v_kfckxzqhdm varchar2(10):='';
 v_kfcklx  varchar2(2):='';
v_zpaid number:=0;
BEGIN
   --?????????
    select max((select kfcklx from tb_bdxx where khbdh=b.khbdh)) as kfcklx,
     max((select decode (nvl(kfcklx,'1'),'1' ,(select b.xzqhdm from tb_yyxx b ,tb_lpfpxx a where b.yyid=a.yyid and a.fpid=Pfpid),'2' , cbdqh,'3',KFZDQH,'') as kfckxzqhdm from tb_bdxx where khbdh=b.khbdh)) as kfckxzqhdm into v_kfcklx,v_kfckxzqhdm
     from  tb_lpajxx b where  ajid=(select ajid from tb_lpfpxx where fpid=pFpid);
 /*
  select max(khid),max(csrq),max(xb) into rec_khxx.khid,rec_khxx.csrq,rec_khxx.xb from tb_khxx where khid =(selec bbrkhid from tb_lpajxx where ajid=(select ajid from tb_lpfpxx where fpid=pFpid));
  if rec_khxx.khid is null then
      select substr(max(a.bbrzjh),7,8),max(b.xb) into rec_khxx.csrq,rec_khxx.xb  from tb_lpajxx a,tb_ajqtxx b where a.ajid=b.ajid and a.ajid=(select ajid from tb_lpfpxx where fpid=pFpid);
  end if ;
  */
 if length(trim(pFpid))=0 then
    Result:='?';
  end if;

  for rec_xy in cur_rec loop
     if p_aaa100 ='FPXGDM' and rec_xy.aaa102 like 'SY00%'  then
          v_FPXGDMMS:=rec_xy.aaa103||'(';--??????
          for rec_dt in(select distinct d.xxdm,d.xxmc from  tb_fpxxfyxx d  where d.fpid=Pfpid and  exists(select 'x' from tb_lpajxx b,tb_khxx c,tb_lpfpxx a,tb_sbshgzpzxx e where b.ajid = a.ajid
                                                               and b.bbrkhid=c.khid and d.fpid=a.fpid and e.ZSDBM=d.XXDM and e.ZSDLB=d.xmlb
                                                               and e.status='1' and e.AAA102=substr(rec_xy.aaa102,1,5)
                                                               and ( (rec_xy.aaa102 in('SY001-1','SY001-2') and e.shys2=decode(rec_xy.aaa102,'SY001-1','1','2'))
                                                                  or (rec_xy.aaa102 not in('SY001-1','SY001-2')
                                                               and ( (e.shys1='02' and c.CSRQ< to_char(add_months(to_date(nvl(a.ryrq,jzrq),'yyyy-mm-dd'),-216),'yyyymmdd')) --?????0-18??/
                                                                                         and (nvl(e.XZQH,v_kfckxzqhdm)=nvl(v_kfckxzqhdm,'xxxx') or e.xzqh is null)
                                          or (e.shys1='03' and c.CSRQ<to_char(add_months(to_date(nvl(a.ryrq,jzrq),'yyyy-mm-dd'),-12),'yyyymmdd')) -- //??????0-1??
                                                                    or (e.shys1='04' and a.zdlx!='0') --????
                                                                    or (e.shys1='05' and a.zdlx!='1')--/????
                                                                    or (e.shys1='07' and d.zddm not in(select ZDDM from tb_bdtyshgzzddmpz h,tb_bdxx m,tb_fdzrmx n where h.bdid=m.bdid and m.khbdh=b.khbdh and n.fdid=b.fdid and n.zrid=h.zrid and h.YXZT='1' and h.JBLX='10'  ) ) -- //????
                                                                    ))))
                        ) loop
             v_FPXGDMMS:=substr( v_FPXGDMMS||rec_dt.xxmc||',',1,4096);
          end loop;
          if  v_FPXGDMMS like '%,' then
            v_FPXGDMMS:=substr(v_FPXGDMMS,1,length(trim(v_FPXGDMMS))-1);
          end if;
           v_FPXGDMMS:= v_FPXGDMMS||')';
           Result:=substr(Result||v_FPXGDMMS,1,4096);
     else
        Result:=Result||rec_xy.aaa103||',';
     end if;
  end loop;
  if  Result like '%,' then
    Result:=substr(Result,1,length(trim(Result))-1);
  end if;
  --????????????????????????????????????????????? begin
  --????????????????????????
     select max(b.zpaid) into v_zpaid from tb_zpaxxdzb a,tb_zpaxx b,tb_fpxxfyxx c where a.zpaid=b.zpaid and a.xxid=c.xxid and c.fpid=pFpid and (b.xgdm  like '%CL87%'
                    or b.xgdm like '%'||trim('CL88  ')||'%'
                    or b.xgdm like '%'||trim('CL89  ')||'%'
                    or b.xgdm like '%'||trim('CL90  ')||'%'
                    or b.xgdm like '%'||trim('SY008 ')||'%'
                    or b.xgdm like '%'||trim('SY009 ')||'%'
                    or b.xgdm like '%'||trim('CL92  ')||'%'
                    or b.xgdm like '%'||trim('CL93  ')||'%'
                    or b.xgdm like '%'||trim('CL94  ')||'%'
                    or b.xgdm like '%'||trim('CL95  ')||'%');
    if  v_zpaid is not null  and   v_zpaid>0 then
        v_FPXGDMMS:='???????:';
        for rec_zpaxgdm in(
           select distinct rec_xy.aaa102,rec_xy.aaa103
              from aa10 rec_xy where
              exists(select a.xgdm from tb_zpaxxdzb k,tb_zpaxx a,tb_fpxxfyxx d
               where  a.zpaid=k.zpaid and d.xxid=k.xxid and d.fpid=pFpid
                  and (((a.xgdm  like '%CL87%'
                    or a.xgdm like '%'||trim('CL88  ')||'%'
                    or a.xgdm like '%'||trim('CL89  ')||'%')
                    and  exists(select 'x' from TB_TYSHGZYJXX e where  e.ZSDBM=d.xxDM and e.ZSDLB=d.xmlb
                                                                   and e.status='1' and e.SHYS1=decode( rec_xy.aaa102,'CL87','11','CL88','12','CL89','13',rec_xy.aaa102))
                                                                   )
                    or ((a.xgdm like '%'||trim('CL90  ')||'%'
                        or a.xgdm like '%'||trim('CL92  ')||'%'
                        or a.xgdm like '%'||trim('CL93  ')||'%'
                        or a.xgdm like '%'||trim('CL94  ')||'%'
                        or a.xgdm like '%'||trim('CL95  ')||'%')
                          and  exists(select 'x' from TB_TYSHGZYJXX e where  e.ZSDBM=d.zdDM and e.ZSDLB='3'
                                and e.status='1'
                                and e.SHYS1=decode( rec_xy.aaa102,'CL90','13','CL92','1L','CL93','1N','CL94','02','CL95','03',rec_xy.aaa102))
                    )
                    or ((a.xgdm like '%'||trim('SY008 ')||'%'
                    or a.xgdm like '%'||trim('SY009 ')||'%')
                       and  exists(select 'x' from tb_sbshgzpzxx e
                                                             where  e.ZSDBM=d.XXDM and e.ZSDLB=d.xmlb
                                                                   and e.status='1' and e.AAA102=substr(rec_xy.aaa102,1,5)
                                                                   and ( ( e.AAA102='SY008' and d.ZDDM not in(select shys2 from tb_sbshgzpzxx h where nvl(h.xzqh,'xxx')=nvl(e.xzqh,'xxx') and h.aaa102=e.aaa102 and h.status='1' and h.zsdbm=e.zsdbm))
                                                                      or (e.AAA102='SY009' and e.shys1='09' and d.ZDDM not in(select ZDDM  as xxx from
                                                                     tb_bdtyshgzzddmpz  h,tb_fdxx y  where h.bdid=y.bdid and y.fdid=a.fdid  and h.zrid=a.zrid   and h.jblx=e.SHYS2 and h.YXZT='1'))
                                                                     ))
                    ))
                 )
              and rec_xy.aaa100='XTXGDM'
              and rec_xy.aaa102 in(trim('CL87  '),
              trim('CL88  '),
              trim('CL89  '),
              trim('CL90  '),
              trim('SY008 '),
              trim('SY009 '),
              trim('CL92  '),
              trim('CL93  '),
              trim('CL94  '),
              trim('CL95  ')
              )
              )   loop
              --??????????????SY009???????????????
             v_FPXGDMMS:=v_FPXGDMMS||rec_zpaxgdm.aaa103||'(';--??????
            if rec_zpaxgdm.aaa102 like 'SY00%' then
              for rec_dt in(select distinct d.xxdm,case when rec_zpaxgdm.aaa102='SY009' then (select max(c.aaa103)||'--'||d.xxmc from tb_sbshgzpzxx e,aa10 c where e.aaa102=rec_zpaxgdm.aaa102
                                     and e.zsdbm=d.xxdm  and e.shys2=c.aaa102
                                     and c.aaa100='JBLB' and e.status='1'  )  else  d.xxmc end as xxmc
                                    from  tb_fpxxfyxx d,tb_zpaxxdzb xx,tb_zpaxx a  where xx.zpaid=a.zpaid and d.fpid=Pfpid and d.xxid=xx.xxid and  exists(select 'x' from tb_sbshgzpzxx e
                                                             where  e.ZSDBM=d.XXDM and e.ZSDLB=d.xmlb
                                                                   and e.status='1' and e.AAA102=substr(rec_zpaxgdm.aaa102,1,5)
                                                                   and ( ( e.AAA102='SY008' and d.ZDDM not in(select shys2 from tb_sbshgzpzxx h where nvl(h.xzqh,'xxx')=nvl(e.xzqh,'xxx') and h.aaa102=e.aaa102 and h.status='1' and h.zsdbm=e.zsdbm))
                                                                      or (e.AAA102='SY009' and e.shys1='09' and d.ZDDM not in(select ZDDM  as xxx from
                                                                     tb_bdtyshgzzddmpz  h,tb_fdxx y  where h.bdid=y.bdid and y.fdid=a.fdid  and h.zrid=a.zrid   and h.jblx=e.SHYS2 and h.YXZT='1'))
                                                                     ))
                            ) loop
                 v_FPXGDMMS:=substr( v_FPXGDMMS||rec_dt.xxmc||',',1,4096);
              end loop;
         end if;
         --?????????
         if rec_zpaxgdm.aaa102 in('CL87', 'CL88','CL89') then
             for rec_dt in(select distinct d.xxdm,d.xxmc from  tb_fpxxfyxx d,tb_zpaxxdzb xx ,tb_zpaxx a   where xx.zpaid=a.zpaid and d.fpid=Pfpid and d.xxid=xx.xxid and  exists(select 'x' from TB_TYSHGZYJXX e where  e.ZSDBM=d.xxDM and e.ZSDLB=d.xmlb
                                                                   and e.status='1' and e.SHYS1=decode( rec_zpaxgdm.aaa102,'CL87','11','CL88','12','CL89','13',rec_zpaxgdm.aaa102))
                            ) loop
                 v_FPXGDMMS:=substr( v_FPXGDMMS||rec_dt.xxmc||',',1,4096);
              end loop;
         end if;
          --??????????
         if rec_zpaxgdm.aaa102 in('CL90', 'CL92','CL93','CL94','CL95') then
             for rec_dt in(select distinct d.xxdm,d.xxmc from  tb_fpxxfyxx d,tb_zpaxxdzb xx ,tb_zpaxx a   where xx.zpaid=a.zpaid and d.fpid=Pfpid and d.xxid=xx.xxid and  exists(select 'x' from TB_TYSHGZYJXX e where  e.ZSDBM=d.zdDM and e.ZSDLB='3'
                                                                   and e.status='1' and e.SHYS1=decode( rec_zpaxgdm.aaa102,'CL90','13','CL92','1L','CL93','1N','CL94','02','CL95','03',rec_zpaxgdm.aaa102))
                            ) loop
                 v_FPXGDMMS:=substr( v_FPXGDMMS||rec_dt.xxmc||',',1,4096);
              end loop;
         end if;
          if  v_FPXGDMMS like '%,' then
            v_FPXGDMMS:=substr(v_FPXGDMMS,1,length(trim(v_FPXGDMMS))-1);
          end if;
           v_FPXGDMMS:= v_FPXGDMMS||')';
           Result:=substr(Result||v_FPXGDMMS,1,4096);
        end loop;

    end if;
  --****end
  if  Result like '%,' then
    Result:=substr(Result,1,length(trim(Result))-1);
  end if;
--dbms_output.put_line(Result);
return(Result);
END SF_P1_GET_STRFPXGDMMS;

/
