CREATE PROCEDURE      "SP_P1_30029" (report_id   In t_report_def_info.REPORTID%TYPE,
                                        pStartdate  IN varchar2, -- ??????yyyymmdd
                                        pEnddate    IN varchar2, -- ??????yyyymmdd
                                        pStatman    IN t_report_gen_info.STATMAN%TYPE, --???
                                        ptype       in varchar2, /*0 ???? ,1 ?? 2 ?? 3 ?? */ --?????
                                        POther1     IN varchar2, --??id
                                        POther2     IN varchar2, --??id
                                        POther3     IN varchar2, --??id
                                        POther4     IN varchar2, --??ID
                                        POther5     IN varchar2, --????
                                        POther6     IN varchar2, --??ID
                                        POther7     IN varchar2, --????
                                        POther8     IN varchar2, --???
                                        PReturnCode OUT varchar2,
                                        PReturnMsg  OUT varchar2) AS

  V_STEP_CODE  CHAR(5); --?????????????????
  vreportid    t_report_def_info.REPORTID%TYPE; --??ID
  vxzqhdm      t_report_gen_info.STATORGID%TYPE; --????????????
  sLetter_Desc  VARCHAR2(1024);

  sKhbdh  number; --?????

  --sLetter_Desc1 VARCHAR2(1024);

  vstatid varchar(30); --?????????????????
  v_start_date number := 0; --????????
  v_end_date   number := 0; --????????

  type cellType is record(
    statid  varchar2(15),
    col     number,
    r       number,
    content varchar2(1024));

  cell      cellType; --?????????????
  vdwmc     varchar2(50); --????????????
  vusername t_report_gen_info.STATMAN%TYPE; --????????
  vnd       t_report_gen_info.STATYEAR%TYPE; --????
  rowno     number := 1; --??????
  v_count   number:=0;--?????????
 v_khbdh     varchar2(50):=''; --????????????
  --??????
  CURSOR c_Pasm(p_pah VARCHAR2) IS
    SELECT DISTINCT(A.CLAIM_LETTER_DESC)
    FROM TB_AL_CLOSE_EXPORT A
    WHERE A.WD_CLAIM_NO = p_pah order by length(trim(A.CLAIM_LETTER_DESC)) desc;

  --????????
v_drowstartcol number:=2;--???????
v_ttid number:=0;
BEGIN
  V_STEP_CODE := '00000';

  PReturnMsg  := 'OK';
  PReturnCode := 'E';
  vreportid   := substr(report_id, 1, 5);
  vusername   := pStatman;
   v_start_date := to_number(substr(pStartdate, 1, 8));
   v_end_date   := to_number(substr(pEnddate, 1, 8));

   --?????????
 select count(1) into v_count from tb_lpajxx where (ajzt!='11' and nvl(ajjl,'xx') not in('06','07'))
   and lppcid =(select pcid from tb_lppcxx where pch=TRIM(POther4));

 if v_count>0 then
     PReturnCode:= '-1'; /*  ??????  */
     PReturnMsg := '?????????????????????????????'; --???????????
    return;

 end if;

  --???????????????????????????

  DELETE FROM T_REPORT_DATA_INFO
   WHERE STATID IN (SELECT STATID FROM T_REPORT_GEN_INFO WHERE REPORTID = REPORT_ID);

  DELETE FROM T_REPORT_GEN_INFO
   WHERE STATID IN (SELECT STATID FROM T_REPORT_GEN_INFO WHERE REPORTID = REPORT_ID);

  --???,?T_RERORT_GEN_INFO????????????
  --?????????????????????????????????????????

  V_STEP_CODE := '00001';
  SELECT SEQ_STATID.NEXTVAL INTO VSTATID FROM DUAL;

  -- ??????????
  INSERT INTO T_REPORT_GEN_INFO(
    STATID, REPORTID,STATORGID,
    STATORGNAME,STATDATE,STATMAN,
    STATYEAR,BEGINDATE,ENDDATE,
    STAT_OTHER,STAT_TYPE)
  VALUES(
    VSTATID,VREPORTID,'',
     '',TO_CHAR(SYSDATE, 'YYYYMMDD'),VUSERNAME,
     VND,V_START_DATE,V_END_DATE,
     SUBSTR(PENDDATE, 1, 1),TRIM(PTYPE));

  --?????? ??excel???0?????1??,????0???

   V_STEP_CODE := '00002';
  --????
  INSERT INTO T_REPORT_DATA_INFO (STATID, SHEET, COL, R, CONTENT) VALUES (VSTATID,0,2,1,TO_CHAR(SYSDATE,'YYYYMMDD'));

  --?????
  INSERT INTO T_REPORT_DATA_INFO (STATID, SHEET, COL, R, CONTENT) VALUES (VSTATID,0,2,2,TRIM(TRIM(POther4)));

  --?????
  /*SELECT A.KHBDH INTO CELL.CONTENT FROM TB_LPPCXX A  WHERE A.PCH = TRIM(POther4);
  IF CELL.CONTENT IS NOT NULL THEN
    INSERT INTO T_REPORT_DATA_INFO (STATID, SHEET, COL, R, CONTENT) VALUES (VSTATID,0,1,4,CELL.CONTENT);
  END IF;*/

  --????
 -- INSERT INTO T_REPORT_DATA_INFO (STATID, SHEET, COL, R, CONTENT) VALUES (VSTATID,0,1,5,TRIM(POTHER7));

   INSERT INTO T_REPORT_DATA_INFO (STATID, SHEET, COL, R, CONTENT) select VSTATID,0,2,3,to_char(SJSFRQ) from tb_lppcxx where pch=TRIM(POther4);


  cell.statid := vstatid;
  cell.col    := 0; --?1???
 -- cell.r      := 10; --?11???
  cell.r      := 7; --?8???


  --???????????????????????????????excel????????????????????

  V_STEP_CODE := '00003';

  FOR REC_DATA IN (
    /*(ELECT
    A.AJID AS AJID,A.PAH AS PAH, A.WBPAFH AS WBPAFH,
    A.BBRXM AS BBRXM,SUM(B.FPZE) AS FPZE,SUM(B.ZFZE) AS ZFZE,
    SUM((B.TCZFE+B.FJZFE+B.SBZFE+B.DSFZFJE)) AS SBGF,
    A.AJPFJE AS PFJE
  FROM TB_LPAJXX A,TB_LPFPXX B, TB_LPPCXX C
  WHERE A.AJID=B.AJID
  --AND A.AJID='60257'
  --AND A.KHBDH = NVL(TRIM(POther3),A.KHBDH)
  --AND A.SFRQ = NVL(TRIM(POther7),A.SFRQ)
  AND C.PCH = NVL(TRIM(POther4),C.PCH)
  AND C.PCID = A.LPPCID
  AND A.AJZT = '11'
  GROUP BY A.AJID,A.PAH, A.WBPAFH,A.BBRXM,A.AJPFJE
*/

 select  nvl(g.wbbdh, f.khbdh1) as khbdh1,-- ?????,
            case when g.wbbdh is not null then
                  (select zttmc
                     from tb_nbbdwbbddzpzb
                    where wbbdh=g.wbbdh and khbdh=f.khbdh1)
                 else
                  (select ttmc
                     from tb_ttxx
                    where ttid = g.ttid)
               end as ttmc ,-- ???? ,
               f.wbpafh WBPAFH  ,  --???
               f.bbrxm  ,--?????
              f.bbrzjh ,-- ????
              f.jarq,-- ????
              f.pfje as PFJE,--??????
              f.jtpfje ,-- ????
                h.sjzje as FPZE, -- ????
                h.zfkcze zfje,--??
                h.flzfkcze ,-- ????,
               h.bhlfy ,-- ??,
               h.sbzfze as SBGF,-- ????,
               h.cde ,-- ???,
               h.dsfzfze ,-- ?????,
              decode(sign( nvl(h.sjzje,0)-nvl(h.sbzfze,0)-nvl(h.sjpfje,0)- nvl(h.zfkcze,0)- nvl(h.flzfkcze,0)-nvl(h.bhlfy,0)-nvl(h.dsfzfze,0)-nvl(h.cde,0)),1,nvl(h.sjzje,0)-nvl(h.sbzfze,0)-nvl(h.sjpfje,0)- nvl(h.zfkcze,0)- nvl(h.flzfkcze,0)-nvl(h.bhlfy,0)-nvl(h.dsfzfze,0)-nvl(h.cde,0),0) as grcdfy, --???? ,
              h.mpe -- as ???
          from (SELECT A.AJID AS AJID,
                       a.fdid,
                       A.PAH AS PAH,
                       A.WBPAFH AS WBPAFH,
                       A.BBRXM AS BBRXM,
                       a.bbrzjh,
                       a.sqrq,
                       a.jarq,
                       a.khbdh as khbdh1,
                       A.AJPFJE AS PFJE?
                      (select sum(nvl(sjpfje,0)) from tb_zpaxx where ajid=a.ajid and pfzrdm like 'HI%' and nvl(zpajl,'x')!='02') as jtpfje
                  FROM TB_LPAJXX  A
                 WHERE A.AJZT = '11' and lppcid in(select pcid from tb_lppcxx c where  C.PCH = NVL(TRIM(POther4),C.PCH)) and   seqlogid!=-1
                ) f,
               tb_fdxx  g,( select ajid,sum(nvl(data51,0)) as sjzje,
               sum(nvl(data52,0)) as sjpfje,
               sum(nvl(data53,0)) as zfkcze,
               sum(nvl(data55,0)) as flzfkcze,
               sum(nvl(data57,0)) as bhlfy,
               sum(nvl(data59,0)) as sbzfze,
               sum(nvl(data60,0)) as dsfzfze,
               sum(nvl(data61,0)) as mpe,
               sum(nvl(data69,0)) as cde from (
                select a.ajid,
             a.zpaid,
             to_char(trim(a.ZDZJE), '99999990.00') AS data51,--????
             to_char(nvl(a.SJPFJE, 0), '99999990.00') as data52, --??????
      case when a.zpajl!='02' then  to_char(trim((select sum(h.zfje)
                      from tb_zpaxxdzb n, tb_fpxxfyxx h
                     where n.zpaid = a.zpaid
                       and n.xxid = h.xxid
                       and n.ZFFYLSGZID is null
                       and nvl(h.zfje, 0) > 0)),
               '99999990.00') else '' end AS data53, --????????
       case when a.zpajl!='02' then    to_char(trim((select sum(nvl(h.FLZFJE, 0))
                      from tb_zpaxxdzb n, tb_fpxxfyxx h
                     where n.zpaid = a.zpaid
                       and n.xxid = h.xxid
                       and n.HLBHFLLSGZID is not null
                       and nvl(h.FLZFJE, 0) > 0)),
               '99999990.00') else '' end as data55, --??????
       a.BHLFY as data57,
       case
         when a.sbbdx = '1' then
          ''
         else
          to_char(a.SBZFZJE)
       end as data59,--??????
       a.QTDSFZFJE AS data60,--?????????
       to_char(trim(a.MPE), '99999990.00') AS data61,--???
       a.cdeje as data69,--???
       a.ZPAJL as data75
  from tb_lpfpxx b, tb_zpaxx a
 where b.fpid(+) = a.fpid
   and a.ajid in(select ajid from tb_lpajxx where  ajzt='11' and lppcid in(select pcid from tb_lppcxx c where  C.PCH = NVL(TRIM(POther4),C.PCH)) and   seqlogid!=-1)
   and nvl(a.JLSM1, '0') != 'X69'
   and (a.pfzrdm like 'AIOP%' or a.pfzrdm like 'IP%' or a.pfzrdm like 'OP%' or
        a.pfzrdm like 'OIP%' or a.pfzrdm like 'MAT%' or a.pfzrdm like 'DE%' or
        a.pfzrdm like 'PE%')
   and (a.fpid is not null or a.sfsdtj = '1') ) group by ajid ) h
         where f.fdid = g.fdid and f.ajid=h.ajid
          order by f.khbdh1,f.WBPAFH asc
  ) LOOP

  V_STEP_CODE := '00004';
  v_khbdh:=REC_DATA.KHBDH1;
  sLetter_Desc := '';
 /* FOR CC IN c_Pasm(REC_DATA.PAH) LOOP
     if nvl(instr(sLetter_Desc,CC.CLAIM_LETTER_DESC),0)> 0 or CC.CLAIM_LETTER_DESC is null then
         null;
      else
        sLetter_Desc := sLetter_Desc||CC.CLAIM_LETTER_DESC || ',';
      end if;
  END LOOP;
    sLetter_Desc:=substrb(substr(sLetter_Desc,1,length(sLetter_Desc)-1),1,1024);
    */
  --   sLetter_Desc:=replace(sLetter_Desc,',,',',');

  V_STEP_CODE := '00005';

  --??
 -- cell.content := A.WBPAFH;
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,0,cell.r,rowno);

 --???
  sKhbdh := 0;
 -- cell.content := A.WBPAFH;
 insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,2,cell.r,REC_DATA.KHBDH1);

 IF (sKhbdh = 0) THEN
    sKhbdh := TO_NUMBER(REC_DATA.KHBDH1);
  ELSE
      IF (sKhbdh > TO_NUMBER(REC_DATA.KHBDH1)) THEN
         sKhbdh := sKhbdh;
      ELSE
          sKhbdh := TO_NUMBER(REC_DATA.KHBDH1);
       END IF;
  END IF ;


  --????
  --cell.content := A.WBPAFH;
 insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,3,cell.r,REC_DATA.TTMC);

  --???
 -- cell.content := A.WBPAFH;
 -- if REC_DATA.WBPAFH is not null then
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,1,cell.r,REC_DATA.WBPAFH);
 -- end if;

  --??
  --cell.content := A.BBRXM;
--  if REC_DATA.BBRXM is not null then
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,4,cell.r,REC_DATA.BBRXM);
 -- end if;

  --????
  --cell.content := SJZE;
 -- if REC_DATA.FPZE is not null then
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,5,cell.r,REC_DATA.FPZE);
--  end if;

  --????
  --cell.content := ZFJE;
--  if REC_DATA.ZFZE is not null then
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,6,cell.r,REC_DATA.ZFjE);
--  end if;

 --??????
  --cell.content := ZFJE;
--  if REC_DATA.ZFZE is not null then
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,5+v_drowstartcol,cell.r,REC_DATA.flzfkcze);

  --????????
  --cell.content := SBGF;
 -- if REC_DATA.SBGF is not null then
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,6+v_drowstartcol,cell.r,REC_DATA.SBGF);
--  end if;
--???????
insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,7+v_drowstartcol,cell.r,REC_DATA.dsfzfze);


-- ???
insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,8+v_drowstartcol,cell.r,REC_DATA.cde);
--?????
insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,9+v_drowstartcol,cell.r,REC_DATA.bhlfy);
--??????
insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,10+v_drowstartcol,cell.r,REC_DATA.grcdfy);
--?????
insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,11+v_drowstartcol,cell.r,REC_DATA.jtpfje);
--????
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,12+v_drowstartcol,cell.r,REC_DATA.PFJE);
  --??
  cell.content := sLetter_Desc;
 -- if cell.content is not null then
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,13+v_drowstartcol,cell.r,cell.content);
 -- end if;
  cell.r :=  cell.r+1;
  rowno := rowno+1;

END LOOP;

--??????????????
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,9,cell.r+3,'????????????');

select ttid into v_ttid from tb_lppcxx where pch=trim(pOther4);


 --????

 if v_ttid!=1181 then
    --?????
   INSERT INTO T_REPORT_DATA_INFO (STATID, SHEET, COL, R, CONTENT) VALUES (VSTATID,0,2,4,v_khbdh);
    BEGIN
       SELECT A.ZTTMC INTO CELL.CONTENT  FROM TB_NBBDWBBDDZPZB A WHERE A.WBBDH = TO_CHAR(sKhbdh);
    EXCEPTION
    WHEN OTHERS THEN
      CELL.CONTENT := '';
    END;
  end if;
  if v_ttid=1181 then
      SELECT A.TTMC  INTO CELL.CONTENT FROM TB_TTXX A   WHERE A.TTID =1181;
  end if;
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,0,5,CELL.CONTENT);



--???????????
  /*9.??*/
  PReturnCode := '0'; /* ??????????????vstatid????????? */
  PReturnMsg  := vstatid;
  DBMS_OUTPUT.PUT_LINE('[LDS debug] ' || 'PReturncode= ' || PReturnCode);
  --COMMIT; ???java?????????

EXCEPTION
  WHEN OTHERS THEN
    --rollback;???java?????????????0?????????????????
    PReturnCode := 'E'; /*  ??????  */
    DBMS_OUTPUT.PUT_LINE('[yhs debug] ' || 'PReturncode= ' || PReturnCode);
    PReturnMsg := ' rownum' || cell.r || 'Error:' || sqlerrm; --???????????
    DBMS_OUTPUT.PUT_LINE(PReturnMsg);
END SP_P1_30029;

/
