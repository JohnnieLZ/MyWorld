CREATE PROCEDURE      "SP_P1_30025" (report_id   In t_report_def_info.REPORTID%TYPE,
                                        pStartdate  IN varchar2, -- ??????yyyymmdd
                                        pEnddate    IN varchar2, -- ??????yyyymmdd
                                        pStatman    IN t_report_gen_info.STATMAN%TYPE, --???
                                        ptype       in varchar2, /*0 ???? ,1 ?? 2 ?? 3 ?? */ --?????
                                        POther1     IN varchar2, --??id
                                        POther2     IN varchar2, --??id
                                        POther3     IN varchar2, --??id
                                        POther4     IN varchar2, --??ID
                                        POther5     IN varchar2, --????
                                        POther6     IN varchar2, --??ID
                                        POther7     IN varchar2, --??????
                                        POther8     IN varchar2, --??????
                                        PReturnCode OUT varchar2,
                                        PReturnMsg  OUT varchar2) AS
  V_STEP_CODE  CHAR(5); --?????????????????
  vreportid    t_report_def_info.REPORTID%TYPE; --??ID
  v_start_date number := 0; --????????
  v_end_date   number := 0; --????????
  vxzqhdm      t_report_gen_info.STATORGID%TYPE; --????????????

  vstatid varchar(30); --?????????????????
  type cellType is record(
    statid  varchar2(15),
    col     number,
    r       number,
    content varchar2(1024));

  cell      cellType; --?????????????
  vdwmc     varchar2(50); --????????????
  vusername t_report_gen_info.STATMAN%TYPE; --????????
  vnd       t_report_gen_info.STATYEAR%TYPE; --????
  rowno     number := 0; --??????

  tt_zycs number := 0;--????????
  tt_zyts number := 0;--????????
  tt_pjzyts number := 0;--??????????
  tt_zpfje number := 0;--?????????
  tt_mzypjpfje number := 0;--?????????????
  tt_mrpjpfje number := 0;--????????????

  gs_zycs number := 0;--??????????
  gs_zyts number := 0;--??????????
  gs_pjzyts number := 0;--????????????
  gs_zpfje number := 0;--???????????
  gs_mzypjpfje number := 0;--???????????????
  gs_mrpjpfje number := 0;--??????????????


begin
  V_STEP_CODE := '00000';
  PReturnMsg  := 'OK';
  PReturnCode := 'E';
  vreportid   := substr(report_id, 1, 5);
  vusername   := pStatman;
  vnd         := substr(pStartdate, 1, 4);

  v_start_date := to_number(substr(pStartdate, 1, 8));
  v_end_date   := to_number(substr(pEnddate, 1, 8));

  --???????????????????????????
  delete from t_report_data_info
   where statid in
         (select statid from T_REPORT_GEN_INFO where reportid = report_id);

  delete from T_REPORT_GEN_INFO
   where statid in
         (select statid from T_REPORT_GEN_INFO where reportid = report_id);

  V_STEP_CODE := '00001';
  --???,?T_RERORT_GEN_INFO?????????????
  --???????
  select seq_statid.nextval into vstatid from dual;

  -- ??????????
  insert into t_report_gen_info
    (STATID,
     REPORTID,
     STATORGID,
     STATORGNAME,
     STATDATE,
     STATMAN,
     STATYEAR,
     BEGINDATE,
     ENDDATE,
     STAT_OTHER,
     STAT_TYPE)
  values
    (vstatid,
     vreportid,
     '',
     '',
     to_char(sysdate, 'yyyymmdd'),
     vusername,
     vnd,
     v_start_date,
     v_end_date,
     substr(pEnddate, 1, 1),
     trim(ptype));

  /* --?????? ??excel???0?????1??,????0???*/

    --???
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid, 0,1, 2, 'CLFX05');


  --????
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,1,3,to_char(sysdate,'yyyymmdd'));

  --????
  select max(bxgsqc) into cell.content from tb_bxgsxx where bxgsid=trim(POther1);
  if cell.content is not null then
    insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,1,4,cell.content);
  end if;

  --????
  select max(ttmc) into cell.content from tb_ttxx where ttid = trim(POther2);
  if cell.content is not null then
    insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,1,5,cell.content);
  end if;

  --????
  select max(khbdh) into cell.content from tb_bdxx where bdid = trim(POther3);
  if cell.content is not null then
    insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,1,6,cell.content);
  end if;

  --??????
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,1,7, trim(pStartdate)||'--'||trim(pEnddate));

  --??????
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,1,8, trim(POther7)||'--'||trim(POther8));


  cell.statid := vstatid;
  cell.col    := 0; --?1???
  cell.r      := 11; --?15???
  --???????????????????????????????excel????????????????????

  --????
  for rec_bxgs in(
               select a.bxgsid,a.bxgsbh
               from tb_bxgsxx a,tb_ttxx b,tb_bdxx c,tb_lppcxx d,tb_lpajxx e,tb_zpaxx f,tb_zrxx g,TB_CPZRDZB h,TB_CPXX i,tb_fdxx j,tb_lpfpxx k
                where a.bxgsid = c.bxgsid
                  and b.ttid = c.ttid
                  and d.ttid = b.ttid
                  and d.bxgsid = c.bxgsid
                  and e.lppcid(+) = d.pcid
                  and f.ajid(+) = e.ajid
                  and g.zrid = f.zrid
                  and g.zrid = h.zrid
                  and h.cpid = i.cpid
                  and pfzrdm not like '%' || 'HI'|| '%'
                  and j.khbdh = c.khbdh
                  and k.fpid = f.fpid
                  and a.bxgsid = nvl(trim(POther1),a.bxgsid)
                  and b.ttid = nvl(trim(POther2),b.ttid)
                  and c.bdid = nvl(trim(POther3),c.bdid)
                  and c.bdsxrq >= nvl(trim(pStartdate),19900101)
                  and c.bdsxrq <= nvl(trim(pEnddate),99991231)
                  AND C.BDZZRQ >= NVL(TRIM(pEnddate),C.BDZZRQ)
                  and e.jarq >= nvl(trim(POther7),e.jarq)
                  and e.jarq <= nvl(trim(POther8),e.jarq)
                  and EXISTS(SELECT 'X' FROM TB_LPAJXX H WHERE H.AJID=F.AJID AND AJZT IN('08','09','10') and h.khbdh = c.khbdh )
                  and k.zdlx = '1'
                   and j.fdid=nvl(f.fdid,e.fdid)
              group by a.bxgsid,a.bxgsbh
              order by a.bxgsid,a.bxgsbh
  ) loop
    for rec_ttdata in(
        select b.ttid
               from tb_bxgsxx a,tb_ttxx b,tb_bdxx c,tb_lppcxx d,tb_lpajxx e,tb_zpaxx f,tb_zrxx g,TB_CPZRDZB h,TB_CPXX i,tb_fdxx j,tb_lpfpxx k
                where a.bxgsid = c.bxgsid
                  and b.ttid = c.ttid
                  and d.ttid = b.ttid
                  and d.bxgsid = c.bxgsid
                  and e.lppcid(+) = d.pcid
                  and f.ajid(+) = e.ajid
                  and g.zrid = f.zrid
                  and g.zrid = h.zrid
                  and h.cpid = i.cpid
                   and pfzrdm not like '%' ||'HI'|| '%'
                  and j.khbdh = c.khbdh
                  and k.fpid = f.fpid
                  and a.bxgsid = rec_bxgs.bxgsid
                  and b.ttid = nvl(trim(POther2),b.ttid)
                  and c.bdid = nvl(trim(POther3),c.bdid)
                  and c.bdsxrq >= nvl(trim(pStartdate),19900101)
                  and c.bdsxrq <= nvl(trim(pEnddate),99991231)
                  and c.bdZZrq <= nvl(trim(pEnddate),C.BDZZRQ)
                  and e.jarq >= nvl(trim(POther7),e.jarq)
                  and e.jarq <= nvl(trim(POther8),e.jarq)
                   and j.fdid=nvl(f.fdid,e.fdid)
                  and EXISTS(SELECT 'X' FROM TB_LPAJXX H WHERE H.AJID=F.AJID AND AJZT IN('08','09','10') and h.khbdh = c.khbdh )
                  and k.zdlx = '1'
              group by b.ttid
              order by b.ttid
    )loop
      for rec_data in(
          select t.bxgsbh,t.bxgsqc,t.ttbh,t.ttmc,t.khbdh,t.bdsxrq,t.bdzzrq,t.cph,t.cpmc,t.zycs,t.zyts,t.zpfe,
              decode(t.zycs,0,0,round(t.zyts/t.zycs,2)) as pjzyts,--??????
              decode(t.zycs,0,0,round(t.zpfe/t.zycs,2)) as mzypjffe,--?????????
              decode(t.zyts,0,0,round(t.zpfe/t.zyts,2)) as mrpjpfe--????????
           from (
             select a.bxgsbh,a.bxgsqc,b.ttbh,b.ttmc,c.khbdh,c.bdsxrq,c.bdzzrq,i.cph,i.cpmc,
                  count(distinct k.fpid) as zycs,--????
                  sum(nvl(to_date(k.cyrq,'yyyy-mm-dd')-to_date(k.ryrq,'yyyy-mm-dd'),0)) as zyts,--????
                  sum(nvl(f.SJPFJE,0)) as zpfe--?????
             from tb_bxgsxx a,tb_ttxx b,tb_bdxx c,tb_lppcxx d,tb_lpajxx e,tb_zpaxx f,tb_zrxx g,TB_CPZRDZB h,TB_CPXX i,tb_fdxx j,tb_lpfpxx k
                where a.bxgsid = c.bxgsid
                  and b.ttid = c.ttid
                  and d.ttid = b.ttid
                  and d.bxgsid = c.bxgsid
                  and e.lppcid(+) = d.pcid
                  and f.ajid(+) = e.ajid
                  and g.zrid = f.zrid
                  and g.zrid = h.zrid
                  and h.cpid = i.cpid
                  and j.khbdh = c.khbdh
                   and pfzrdm not like '%' ||'HI'|| '%'
                  and k.fpid = f.fpid
                  and a.bxgsid = rec_bxgs.bxgsid
                  and b.ttid = rec_ttdata.ttid
                  and c.bdid = nvl(trim(POther3),c.bdid)
                  and c.bdsxrq >= nvl(trim(pStartdate),19900101)
                  and c.bdsxrq <= nvl(trim(pEnddate),99991231)
                  and c.bdZZrq <= nvl(trim(pEnddate),C.BDZZRQ)
                  and e.jarq >= nvl(trim(POther7),e.jarq)
                  and e.jarq <= nvl(trim(POther8),e.jarq)
                   and j.fdid=nvl(f.fdid,e.fdid)
                  --and e.ajzt = '08'
                  and k.zdlx = '1'
                  and EXISTS(SELECT 'X' FROM TB_LPAJXX H WHERE H.AJID=F.AJID AND AJZT IN('08','09','10') and h.khbdh = c.khbdh )
              group by a.bxgsbh,a.bxgsqc,b.ttbh,b.ttmc,c.khbdh,c.bdsxrq,c.bdzzrq,i.cpmc,i.cph
              order by a.bxgsbh,b.ttbh,c.khbdh,i.cpmc)t
      )loop

         --??????
         insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 0, cell.r, rec_bxgs.bxgsbh);

         --??????
         insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 1, cell.r, rec_data.bxgsqc);

         --?????
         insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 2, cell.r, rec_data.ttbh);

         --??????
         insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 3, cell.r, rec_data.ttmc);

         --???
         insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 4, cell.r, rec_data.khbdh);

         --????
         insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 5, cell.r, rec_data.bdsxrq||'--'||rec_data.bdzzrq);

         --????
         insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 6, cell.r, rec_data.cph);

         --????
         insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 7, cell.r, rec_data.cpmc);

         --????
         insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 8, cell.r, rec_data.zycs);

         --????
         insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 9, cell.r, rec_data.zyts);

         --??????
         insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 10, cell.r, rec_data.pjzyts);

         --?????
         insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 11, cell.r, rec_data.zpfe);

         --?????????
         insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 12, cell.r, rec_data.mzypjffe);

         --????????
         insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 13, cell.r, rec_data.mrpjpfe);

         cell.r :=  cell.r+1;

       end loop;

       /*--?????
         select t.zycs,t.zyts,t.zpfe,
                decode(t.zycs,0,0,round(t.zyts/t.zycs,2)) as pjzyts,--??????
                decode(t.zycs,0,0,round(t.zpfe/t.zycs,2)) as mzypjffe,--?????????
                decode(t.zyts,0,0,round(t.zpfe/t.zyts,2)) as mrpjpfe--????????
               into tt_zycs,tt_zyts,tt_zpfje,tt_pjzyts,tt_mzypjpfje,tt_mrpjpfje
             from (
               select
                    count(k.fpid) as zycs,--????
                    sum(nvl(to_date(k.cyrq,'yyyy-mm-dd')-to_date(k.ryrq,'yyyy-mm-dd'),0)) as zyts,--????
                    sum(nvl(f.SJPFJE,0)) as zpfe--?????
               from tb_bxgsxx a,tb_ttxx b,tb_bdxx c,tb_lppcxx d,tb_lpajxx e,tb_zpaxx f,tb_zrxx g,TB_CPZRDZB h,TB_CPXX i,tb_fdxx j,tb_lpfpxx k
                  where a.bxgsid = c.bxgsid
                    and b.ttid = c.ttid
                    and d.ttid = b.ttid
                    and d.bxgsid = c.bxgsid
                    and e.lppcid(+) = d.pcid
                    and f.ajid(+) = e.ajid
                    and g.zrid = f.zrid
                    and g.zrid = h.zrid
                    and h.cpid = i.cpid
                     and pfzrdm not like '%' ||'HI'|| '%'
                    and j.khbdh = c.khbdh
                    and k.fpid = f.fpid
                    and a.bxgsid = rec_bxgs.bxgsid
                    and b.ttid = rec_ttdata.ttid
                    and c.bdsxrq >= nvl(trim(pStartdate),19900101)
                  and c.bdsxrq <= nvl(trim(pEnddate),99991231)
                  and c.bdZZrq <= nvl(trim(pEnddate),C.BDZZRQ)
                  and e.jarq >= nvl(trim(POther7),e.jarq)
                  and e.jarq <= nvl(trim(POther8),e.jarq)
                   and j.fdid=nvl(f.fdid,e.fdid)
                    and EXISTS(SELECT 'X' FROM TB_LPAJXX H WHERE H.AJID=F.AJID AND AJZT IN('08','09','10') and h.khbdh = c.khbdh )
                    and k.zdlx = '1')t;

                insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 0, cell.r,'????');
                insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 8, cell.r, tt_zycs);
                insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 9, cell.r, tt_zyts);
                insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 10, cell.r, tt_pjzyts);
                insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 11, cell.r, tt_zpfje);
                insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 12, cell.r, tt_mzypjpfje);
                insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 13, cell.r, tt_mrpjpfje);
       cell.r :=  cell.r+1;*/
       end loop;
      /* select t.zycs,t.zyts,t.zpfe,
                decode(t.zycs,0,0,round(t.zyts/t.zycs,2)) as pjzyts,--??????
                decode(t.zycs,0,0,round(t.zpfe/t.zycs,2)) as mzypjffe,--?????????
                decode(t.zyts,0,0,round(t.zpfe/t.zyts,2)) as mrpjpfe--????????
             into gs_zycs,gs_zyts,gs_zpfje,gs_pjzyts,gs_mzypjpfje,gs_mrpjpfje
             from (
               select a.bxgsid,
                    count(k.fpid) as zycs,--????
                    sum(nvl(to_date(k.cyrq,'yyyy-mm-dd')-to_date(k.ryrq,'yyyy-mm-dd'),0)) as zyts,--????
                    sum(nvl(f.SJPFJE,0)) as zpfe--?????
               from tb_bxgsxx a,tb_ttxx b,tb_bdxx c,tb_lppcxx d,tb_lpajxx e,tb_zpaxx f,tb_zrxx g,TB_CPZRDZB h,TB_CPXX i,tb_fdxx j,tb_lpfpxx k
                  where a.bxgsid = c.bxgsid
                    and b.ttid = c.ttid
                    and d.ttid = b.ttid
                    and d.bxgsid = c.bxgsid
                    and e.lppcid(+) = d.pcid
                    and f.ajid(+) = e.ajid
                    and g.zrid = f.zrid
                    and g.zrid = h.zrid
                    and h.cpid = i.cpid
                     and pfzrdm not like '%' ||'HI'|| '%'
                    and j.khbdh = c.khbdh
                    and k.fpid = f.fpid
                    and a.bxgsid = rec_bxgs.bxgsid
                      and b.ttid = nvl(trim(POther2),b.ttid)
                    and c.bdid = nvl(trim(POther3),c.bdid)
                    and c.bdsxrq >= nvl(trim(pStartdate),19900101)
                  and c.bdsxrq <= nvl(trim(pEnddate),99991231)
                  and c.bdZZrq >= nvl(trim(pEnddate),C.BDZZRQ)
                  and e.jarq >= nvl(trim(POther7),e.jarq)
                  and e.jarq <= nvl(trim(POther8),e.jarq)
                   and j.fdid=nvl(f.fdid,e.fdid)
                    and EXISTS(SELECT 'X' FROM TB_LPAJXX H WHERE H.AJID=F.AJID AND AJZT IN('08','09','10') and h.khbdh = c.khbdh )
                    and k.zdlx = '1'
                group by a.bxgsid
                order by a.bxgsid)t;
       --????????
        insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 0, cell.r, '??????');
        insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 8, cell.r, gs_zycs);
        insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 9, cell.r, gs_zyts);
        insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 10, cell.r, gs_pjzyts);
        insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 11, cell.r, gs_zpfje);
        insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 12, cell.r, gs_mzypjpfje);
        insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 13, cell.r, gs_mrpjpfje);

        cell.r :=  cell.r+1;*/


  end loop;


  --???????????
  /*9.??*/
  PReturnCode := '0'; /* ??????????????vstatid????????? */
  PReturnMsg  := vstatid;
  DBMS_OUTPUT.PUT_LINE('[LDS debug] ' || 'PReturncode= ' || PReturnCode);
  --COMMIT; ???java?????????

EXCEPTION
  WHEN OTHERS THEN
    --rollback;???java?????????????0?????????????????
    PReturnCode := 'E'; /*  ??????  */
    DBMS_OUTPUT.PUT_LINE('[yhs debug] ' || 'PReturncode= ' || PReturnCode);
    PReturnMsg := ' rownum' || cell.r || 'Error:' || sqlerrm; --???????????
    DBMS_OUTPUT.PUT_LINE(PReturnMsg);
end SP_P1_30025;

/
