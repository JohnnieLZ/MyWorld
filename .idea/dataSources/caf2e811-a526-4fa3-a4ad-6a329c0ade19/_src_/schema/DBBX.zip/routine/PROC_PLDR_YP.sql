CREATE PROCEDURE      "PROC_PLDR_YP" IS
	i_step  NUMBER(9);
	    CURSOR c_Pldr IS
	    SELECT XZQH FROM JYY_XZQH_0904;

BEGIN
	i_step := 0;
	FOR cc IN c_Pldr LOOP
		INSERT INTO tb_ypjbxx
		(YPID     ,
		YPBM     ,
		YPFLBM   ,
		JBYPBM   ,
		YPTYM    ,
		YPYWTYM  ,
		SPMC     ,
		YWSPMC   ,
		CPMC     ,
		JXBM     ,
		YPGZ     ,
		YPBZ     ,
		YPLB     ,
		YPLX     ,
		CPLB     ,
		SCGJZWM  ,
		SCGJYWM  ,
		SCQYBM   ,
		SCQYMC   ,
		SCQYYWM  ,
		CSDZ     ,
		CSDZYWM  ,
		PZWH     ,
		YPZWH    ,
		PZRQ     ,
		YXJZRQ   ,
		FBZQYMC  ,
		FBZQYDZ  ,
		FBZPZWH  ,
		FBZWHPZRQ,
		FBZWHJZRQ,
		YPBWM    ,
		YPSMSID  ,
		YYTJ     ,
		YLZJBZ   ,
		CJRQ     ,
		GXRQ     ,
		FYLB     ,
		XZQH     ,
		RSBYPID  ,
		DXFL     ,
		SEQLOGID ,
		PYSXBM)
		SELECT SEQ_YPID.NEXTVAL,
		A.YPBM     ,
		A.YPFLBM   ,
		A.JBYPBM   ,
		A.YPTYM    ,
		A.YPYWTYM  ,
		A.SPMC     ,
		A.YWSPMC   ,
		A.CPMC     ,
		A.JXBM     ,
		A.YPGZ     ,
		A.YPBZ     ,
		A.YPLB     ,
		A.YPLX     ,
		A.CPLB     ,
		A.SCGJZWM  ,
		A.SCGJYWM  ,
		A.SCQYBM   ,
		A.SCQYMC   ,
		A.SCQYYWM  ,
		A.CSDZ     ,
		A.CSDZYWM  ,
		A.PZWH     ,
		A.YPZWH    ,
		A.PZRQ     ,
		A.YXJZRQ   ,
		A.FBZQYMC  ,
		A.FBZQYDZ  ,
		A.FBZPZWH  ,
		A.FBZWHPZRQ,
		A.FBZWHJZRQ,
		A.YPBWM    ,
		A.YPSMSID  ,
		A.YYTJ     ,
		A.YLZJBZ   ,
		A.CJRQ     ,
		A.GXRQ     ,
		A.FYLB     ,
			cc.XZQH ,
		A.RSBYPID  ,
		A.DXFL     ,
		A.SEQLOGID ,
		A.PYSXBM
		FROM TB_YPJBXX A
		WHERE A.XZQH = '310000';
		COMMIT;
	END LOOP;


EXCEPTION
    WHEN OTHERS THEN
        --  ROLLBACK;
          Pkg_Error_Log.Pro_Error_In('PROC_PLDR_YP', i_step, SQLCODE, SQLERRM);
END PROC_PLDR_YP;

/
