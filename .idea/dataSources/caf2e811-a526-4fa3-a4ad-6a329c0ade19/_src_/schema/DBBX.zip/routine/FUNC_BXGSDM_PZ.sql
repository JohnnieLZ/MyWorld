CREATE FUNCTION      "FUNC_BXGSDM_PZ" (sZDXMMC IN VARCHAR2, sWFDM IN VARCHAR2, sBXGSID IN VARCHAR2, sBZW IN VARCHAR2, sYbbs IN VARCHAR2, sZDLX IN VARCHAR2) RETURN VARCHAR2 IS
	sBXGSXMBM VARCHAR(12) := '';
	sBXGSXMMC VARCHAR(300) := '';
  /**@version 1.0 update by zhangjunpeng ??????????????????000018?000019????  2015-6-9
    *
    */
BEGIN
	IF sBZW = '0' THEN
		IF sZDXMMC = 'ZRDM' THEN
      --FESCO???
        IF sYbbs = '1301' THEN
            BEGIN
              SELECT BXGSXMBM
              INTO sBXGSXMBM
              FROM TB_ZDDMBXGSDMDZB
              WHERE AAA100 = sZDXMMC
              AND AAA102 = sWFDM
              AND QTSM1 = sYbbs;
            EXCEPTION
                WHEN  NO_DATA_FOUND THEN
                  sBXGSXMBM := '';
               END;
       --?????
         ELSE
          IF SUBSTR(sWFDM,1,3) = 'OIP' THEN
                IF sZDLX = '1' THEN
                  BEGIN
                    SELECT BXGSXMBM
                    INTO sBXGSXMBM
                    FROM TB_ZDDMBXGSDMDZB
                    WHERE AAA100 = sZDXMMC
                    AND AAA102 = sWFDM
                    AND BXGSID = sBXGSID
                    AND NVL(QTSM2,'0') = NVL(sYbbs,'0')
                    AND NVL(QTSM3,'0') = NVL(sZDLX,'0')
                    AND YXZT='1'  and rownum=1;
                  EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                        sBXGSXMBM := '';
                    END;
                ELSE
                  BEGIN
                    SELECT BXGSXMBM
                    INTO sBXGSXMBM
                    FROM TB_ZDDMBXGSDMDZB
                    WHERE AAA100 = sZDXMMC
                    AND AAA102 = sWFDM
                    AND BXGSID = sBXGSID
                    --AND NVL(QTSM2,'0') = NVL(sYbbs,'0')
                    AND NVL(QTSM3,'0') = NVL(sZDLX,'0')
                    AND YXZT='1'  and rownum=1;
                  EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                        sBXGSXMBM := '';
                    END;
                END IF;

            ELSIF SUBSTR(sWFDM,1,2) IN ('OP','HI')   THEN
              BEGIN
                  SELECT BXGSXMBM
                  INTO sBXGSXMBM
                  FROM TB_ZDDMBXGSDMDZB
                  WHERE AAA100 = sZDXMMC
                  AND AAA102 = sWFDM
                  AND BXGSID = sBXGSID
                  AND YXZT='1'  and rownum=1;
                EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                      sBXGSXMBM := '';
                  END;
            ELSE
              BEGIN
                  SELECT BXGSXMBM
                  INTO sBXGSXMBM
                  FROM TB_ZDDMBXGSDMDZB
                  WHERE AAA100 = sZDXMMC
                  AND AAA102 = sWFDM
                  AND BXGSID = sBXGSID
                  AND NVL(QTSM2,'0') = NVL(sYbbs,'0')
                  --AND NVL(QTSM3,'0') = NVL(sZDLX,'0')
                  AND YXZT='1'  and rownum=1;
                EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                      sBXGSXMBM := '';
                  END;
            END IF;
        END IF;
        RETURN sBXGSXMBM;
        ----------------------------------------------------------------------------------------------------dhl
      ELSIF sZDXMMC = 'TB_YYXX' THEN
        BEGIN
        SELECT BXGSXMBM
        INTO sBXGSXMBM
        FROM TB_ZDDMBXGSDMDZB
        WHERE AAA100 = sZDXMMC
        AND AAA102 = sWFDM
        AND BXGSID = sBXGSID
        --AND NVL(QTSM2,'0') = NVL(sYbbs,'0')
        AND YXZT='1'
        AND ROWNUM=1;
      EXCEPTION
          WHEN NO_DATA_FOUND THEN
            sBXGSXMBM := '';
        END;
        ---?????????????????
        IF (sBXGSXMBM = '??') OR (sBXGSXMBM IS NULL) THEN
          IF SBXGSID='592' THEN
            BEGIN
              SELECT BXGSXMBM
            INTO SBXGSXMBM
            FROM( SELECT BXGSXMBM
              FROM TB_ZDDMBXGSDMDZB A
              WHERE A.BXGSID=SBXGSID
              AND A.AAA100='TB_YYXX'
            AND A.QTSM2 = (SELECT XZQHDM FROM TB_YYXX WHERE YYID=SWFDM)
            AND ((SUBSTR(A.QTSM1,1,2)=(SELECT DECODE(JB,'1','??','2','??','3','??') FROM TB_YYXX WHERE YYID = sWFDM)) OR(A.QTSM1=(SELECT JB FROM TB_YYXX WHERE YYID = sWFDM)) OR (A.QTSM1 IS NULL))
            ORDER BY BXGSXMBM)
            WHERE ROWNUM=1;
          EXCEPTION
              WHEN NO_DATA_FOUND THEN
                sBXGSXMBM := '';
            END;

            ----cxq???????????????????????????????????
            IF sBXGSXMBM IS NULL THEN
              SELECT BXGSXMBM
            INTO SBXGSXMBM
            FROM( SELECT BXGSXMBM
              FROM TB_ZDDMBXGSDMDZB A
              WHERE A.BXGSID=SBXGSID
              AND A.AAA100='TB_YYXX'
            AND A.QTSM2 = (SELECT XZQHDM FROM TB_YYXX WHERE YYID=SWFDM)
            AND SUBSTR(A.QTSM1,1,2)='??'
            ORDER BY BXGSXMBM)
            WHERE ROWNUM=1;

            END IF;
          ----?????0???1????????2?----
          ELSIF SBXGSID='613' THEN
            BEGIN
              SELECT BXGSXMBM
            INTO SBXGSXMBM
            FROM( SELECT BXGSXMBM
              FROM TB_ZDDMBXGSDMDZB A
              WHERE A.BXGSID=SBXGSID
              AND A.AAA100='TB_YYXX'
            AND A.QTSM2 = (SELECT XZQHDM FROM TB_YYXX WHERE YYID=SWFDM)
            AND ((SUBSTR(A.QTSM1,1,2)=(SELECT DECODE(JB,'1','??','2','??','3','??') FROM TB_YYXX WHERE YYID = sWFDM)) OR(A.QTSM1=(SELECT JB FROM TB_YYXX WHERE YYID = sWFDM)) OR(SUBSTR(A.QTSM1,1,2)='??'))
            ORDER BY BXGSXMBM)
            WHERE ROWNUM=1;
          EXCEPTION
              WHEN NO_DATA_FOUND THEN
                sBXGSXMBM := '';
            END;
          IF  sBXGSXMBM = '' THEN
            SELECT BXGSXMBM
            INTO SBXGSXMBM
            FROM(SELECT BXGSXMBM
              FROM TB_ZDDMBXGSDMDZB A
              WHERE A.BXGSID=SBXGSID
              AND A.AAA100='TB_YYXX'
            AND A.QTSM2 = (SELECT XZQHDM FROM TB_YYXX WHERE YYID=SWFDM)
            AND SUBSTR(A.QTSM1,1,2)='??'
            ORDER BY BXGSXMBM)
            WHERE ROWNUM=1;

          END IF;
          END IF;

        END IF;
        RETURN sBXGSXMBM;
        ----???1?5
      ELSIF sZDXMMC = 'YWSGYY' THEN
        BEGIN
        SELECT BXGSXMBM
        INTO sBXGSXMBM
        FROM TB_ZDDMBXGSDMDZB
        WHERE AAA100 = sZDXMMC
        AND AAA102 = sWFDM
        AND BXGSID = sBXGSID
        AND YXZT='1';
      EXCEPTION
          WHEN NO_DATA_FOUND THEN
              sBXGSXMBM := '';
        END;
        IF sBXGSXMBM NOT IN('1','5') AND sBXGSID= '592' THEN
          sBXGSXMBM := '';
        END IF;
      RETURN sBXGSXMBM;

      ELSIF sZDXMMC = 'YXJLX' THEN
        IF sBXGSID=945 THEN
   /*       IF sWFDM='21' THEN
            IF sYbbs IN('S3','S4','S5') THEN
              sBXGSXMBM:='000018';
            ELSE
              sBXGSXMBM:='000019';
            END IF;
          ELSE    -- -V1.0*/
            BEGIN
              SELECT BXGSXMBM
              INTO sBXGSXMBM
              FROM TB_ZDDMBXGSDMDZB
              WHERE AAA100 = sZDXMMC
              AND AAA102 = sWFDM
              AND BXGSID = sBXGSID
              AND YXZT='1';
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                  sBXGSXMBM := '';
            END;
         -- END IF;  -- -V1.0
          RETURN sBXGSXMBM;
        END IF;
      ----???????????????????????????????
      ELSIF  sZDXMMC='DXDM' AND sBXGSID='946' THEN
        IF sWFDM IN('01','02','03') THEN
          BEGIN
            SELECT BXGSXMBM
            INTO sBXGSXMBM
            FROM TB_ZDDMBXGSDMDZB
            WHERE AAA100 = sZDXMMC
            AND AAA102 = sWFDM
            AND BXGSID = sBXGSID
            AND YXZT='1'
            AND QTSM3 = sZDLX;
          EXCEPTION
              WHEN NO_DATA_FOUND THEN
                sBXGSXMBM := '';
          END;
        ELSE
           BEGIN
            SELECT BXGSXMBM
            INTO sBXGSXMBM
            FROM TB_ZDDMBXGSDMDZB
            WHERE AAA100 = sZDXMMC
            AND AAA102 = sWFDM
            AND BXGSID = sBXGSID
            AND NVL(QTSM2,'0') = NVL(sYbbs,'0')
            --AND NVL(QTSM3,'0') = NVL(sZDLX,'0')
            AND YXZT='1';
          EXCEPTION
              WHEN NO_DATA_FOUND THEN
                sBXGSXMBM := '';
            END;
        END IF;
      ELSE
        BEGIN
        SELECT BXGSXMBM
        INTO sBXGSXMBM
        FROM TB_ZDDMBXGSDMDZB
        WHERE AAA100 = sZDXMMC
        AND NVL(TRIM(AAA102),'X') =NVL(sWFDM,'X')
        AND BXGSID = sBXGSID
        AND YXZT='1' and rownum=1;
      EXCEPTION
          WHEN NO_DATA_FOUND THEN
              sBXGSXMBM := '';
        END;

    END IF;
    RETURN sBXGSXMBM;
  ELSE
     ----???????????????????????????????
    IF  sZDXMMC='DXDM' AND sBXGSID='946' THEN
      IF sWFDM IN('01','02','03') THEN
        BEGIN
          SELECT BXGSXMMC
          INTO sBXGSXMMC
          FROM TB_ZDDMBXGSDMDZB
          WHERE AAA100 = sZDXMMC
          AND AAA102 = sWFDM
          AND BXGSID = sBXGSID
          AND YXZT='1'
          AND QTSM3 = sZDLX;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
              sBXGSXMMC := '';
        END;
      ELSE
        BEGIN
          SELECT BXGSXMMC
          INTO sBXGSXMMC
          FROM TB_ZDDMBXGSDMDZB
          WHERE AAA100 = sZDXMMC
          AND AAA102 = sWFDM
          AND BXGSID = sBXGSID
          AND YXZT='1';
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
              sBXGSXMMC := '';
        END;
      END IF;
    ELSE
      BEGIN
        SELECT BXGSXMMC
        INTO sBXGSXMMC
        FROM TB_ZDDMBXGSDMDZB
        WHERE AAA100 = sZDXMMC
        AND AAA102 = sWFDM
        AND BXGSID = sBXGSID
        AND YXZT='1';
      EXCEPTION
          WHEN NO_DATA_FOUND THEN
            sBXGSXMMC := '';
        END;

    END IF;
    RETURN sBXGSXMMC;
  END IF;
EXCEPTION
  WHEN OTHERS THEN return 'EEEEEEEEEEEEEEEE';
END FUNC_BXGSDM_PZ;

/
