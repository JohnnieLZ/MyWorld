CREATE PROCEDURE      "SP_P1_30013" (report_id     In t_report_def_info.REPORTID%TYPE,
                                     pStartdate    IN varchar2,-- ??????yyyymmdd
                                     pEnddate      IN varchar2,-- ??????yyyymmdd
                                     pStatman      IN t_report_gen_info.STATMAN%TYPE,--???
                                     ptype         in varchar2, /*0 ???? ,1 ?? 2 ?? 3 ?? */--?????
                                     POther1   IN varchar2,--??id
                                     POther2   IN varchar2,--??id
                                     POther3   IN varchar2,--??id
                                     POther4   IN varchar2,--??ID
                                     POther5   IN varchar2,--????
                                     POther6   IN varchar2,--??ID
                                     POther7   IN varchar2,--??
                                     POther8   IN varchar2,--??
                                     PReturnCode   OUT varchar2,
                                     PReturnMsg    OUT varchar2) AS
  V_STEP_CODE  CHAR(5);--?????????????????
  vreportid    t_report_def_info.REPORTID%TYPE;--??ID
  v_start_date number := 0;--????????
  v_end_date   number := 0;--????????
  vxzqhdm   t_report_gen_info.STATORGID%TYPE; --????????????

  /*shuju*/
--??????????:
cursor cur_data is
select b.BXGSQC as col1,  -- ????
       case
         when a.zttmc is not null then
          a.zttmc
         else
          (select ttmc from tb_ttxx h where h.ttid = a.ttid)
       end as col2,   --????
       a.khbdh as col3,  --???
       a.pah as col4,   --???
       a.bbrxm as col5,  --????
       a.bbrzjh as col6,  --???????
       decode(a.zldbz, '0', '?', '1', '??', '??') as col7,   --?????
       (select xm from tb_khxx where khid = a.zbbrkhid) as col8,   --?????
       (select aac147 from tb_khxx where khid = a.zbbrkhid) as col9, --?????????
       (select aaa103
          from aa10
         where aaa100 = 'BYLALY'
           and aaa102 = a.AJJLSM1) || trim(a.AJJLSM) as col10,  --??????
       a.SHR as col11,    --???????
       to_char(a.jarq) as col12  --??????
  from TB_lpajxx a, TB_BXGSXX b, tb_bdxx c
 where a.bxgsid = b.bxgsid
   and a.khbdh = c.khbdh
   and a.bxgsid = nvl(trim(POther1), a.bxgsid)
   and a.khbdh = c.khbdh
   and c.bdid = nvl(trim(POther3), c.bdid)
   and c.ttid = nvl(trim(POther2), c.ttid)
   and a.jarq >= nvl(v_start_date,19000101)
   and a.jarq <= nvl(v_end_date,99991231)
   and a.ajjl = '06'
order by  a.bxgsid,a.ttid,a.khbdh,a.pah,a.jarq asc;

  vstatid varchar(30);--?????????????????

  type cellType is record(
    statid  varchar2(15),
    col     number,
    r       number,
    content varchar2(1024));
  cell      cellType; --?????????????
  vdwmc     varchar2(50);--????????????
  vusername t_report_gen_info.STATMAN%TYPE; --????????
  vnd       t_report_gen_info.STATYEAR%TYPE;--????
  rowno     number := 0;  --??????

begin
  V_STEP_CODE := '00000';
  PReturnMsg  := 'OK';
  PReturnCode := 'E';
  vreportid   := substr(report_id, 1, 5);
  vusername   := pStatman;
  vnd         := substr(pStartdate, 1, 4);

  v_start_date:=to_number(substr(pStartdate, 1, 8));
  v_end_date:=to_number(substr(pEnddate, 1, 8));


   --???????????????????????????
  delete from t_report_data_info
   where statid in
         (select statid from T_REPORT_GEN_INFO where reportid = report_id );

  delete from T_REPORT_GEN_INFO where statid in
         (select statid from T_REPORT_GEN_INFO where reportid = report_id );

   V_STEP_CODE := '00001';


  --???,?T_RERORT_GEN_INFO?????????????
  --???????
  select seq_statid.nextval into vstatid from dual;

    -- ??????????
    insert into t_report_gen_info
    (STATID, REPORTID, STATORGID, STATORGNAME, STATDATE, STATMAN, STATYEAR,BEGINDATE,ENDDATE,STAT_OTHER,STAT_TYPE)
  values
    (vstatid,
     vreportid,
     '',
     '',
     to_char(sysdate, 'yyyymmdd'),
     vusername,
     vnd,v_start_date,v_end_date,substr(pEnddate,1,1),trim(ptype));



 /* --?????? ??excel???0?????1??,????0???
?2?1? ????
?2?2? ????
?2?3? ???
?2?4? ????????
?2?5? ??
 */

  --???
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid, 0,1, 2, 'CLGL06');

   --????
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,1,3,to_char(sysdate,'yyyymmdd'));

 --????
  select max(bxgsqc) into cell.content from tb_bxgsxx where bxgsid=trim(POther1);
  if cell.content is not null then
    insert into t_report_data_info
      (statid, sheet, col, r, content)
    values (vstatid,0,1,4,cell.content);
  end if;
  --????
  select max(ttmc) into cell.content from tb_ttxx where ttid=trim(POther2);
  if cell.content is not null then
    insert into t_report_data_info
      (statid, sheet, col, r, content)
    values (vstatid,0,1,5,cell.content);
  end if;
  --???
  select max(khbdh) into cell.content from tb_bdxx where bdid=trim(POther3);
  if trim(POther3) is not null then
    insert into t_report_data_info
      (statid, sheet, col, r, content)
    values (vstatid,0,1,6, trim( cell.content));
  end if;
  --????????
  insert into t_report_data_info
      (statid, sheet, col, r, content)
    values (vstatid,0,1,7, trim(pStartdate)||'--'||trim(pEnddate));

  cell.statid := vstatid;
  cell.col    := 0; --?1???
  cell.r      := 10; --?9???
  --???????????????????????????????excel????????????????????
  for vrow in cur_data loop
    --????8??0?,??11???
   -- cell.content := vrow.col1;
        insert into t_report_data_info (statid, sheet, col, r, content)values(cell.statid, 0, 0 , cell.r, vrow.col1  );
        insert into t_report_data_info (statid, sheet, col, r, content)values(cell.statid, 0, 1 , cell.r, vrow.col2  );
        insert into t_report_data_info (statid, sheet, col, r, content)values(cell.statid, 0, 2 , cell.r, vrow.col3  );
        insert into t_report_data_info (statid, sheet, col, r, content)values(cell.statid, 0, 3 , cell.r, vrow.col4  );
        insert into t_report_data_info (statid, sheet, col, r, content)values(cell.statid, 0, 4 , cell.r, vrow.col5  );
        insert into t_report_data_info (statid, sheet, col, r, content)values(cell.statid, 0, 5 , cell.r, vrow.col6  );
        insert into t_report_data_info (statid, sheet, col, r, content)values(cell.statid, 0, 6 , cell.r, vrow.col7  );
        insert into t_report_data_info (statid, sheet, col, r, content)values(cell.statid, 0, 7 , cell.r, vrow.col8  );
        insert into t_report_data_info (statid, sheet, col, r, content)values(cell.statid, 0, 8 , cell.r, vrow.col9  );
        insert into t_report_data_info (statid, sheet, col, r, content)values(cell.statid, 0, 9, cell.r, vrow.col10 );
       -- insert into t_report_data_info (statid, sheet, col, r, content)values(cell.statid, 0, 10, cell.r, vrow.col11 );
        insert into t_report_data_info (statid, sheet, col, r, content)values(cell.statid, 0, 10, cell.r, vrow.col12 );
        cell.r   := cell.r + 1;     --??+1,???????1?
  end loop;

--???????????
 /* insert into t_report_data_info (statid, sheet, col, r, content)values(cell.statid, 0, 15, 23, '?????'||substr(to_char(sysdate, 'yyyymmdd'), 1, 4) || '?' ||
     substr(to_char(sysdate, 'yyyymmdd'), 5, 2) || '?' ||
     substr(to_char(sysdate, 'yyyymmdd'), 7, 2) || '?');*/
  /*9.??*/
  PReturnCode := '0'; /* ??????????????vstatid????????? */
  PReturnMsg  := vstatid;
  DBMS_OUTPUT.PUT_LINE('[yhs debug] ' || 'PReturncode= ' || PReturnCode);
  --COMMIT; ???java?????????
EXCEPTION
  WHEN OTHERS THEN
    --rollback;???java?????????????0?????????????????
    PReturnCode := 'E'; /*  ??????  */
    DBMS_OUTPUT.PUT_LINE('[yhs debug] ' || 'PReturncode= ' ||PReturnCode);
    PReturnMsg := ' rownum' || cell.r  || 'Error:' || sqlerrm; --???????????
    DBMS_OUTPUT.PUT_LINE(PReturnMsg);
end SP_P1_30013;

/
