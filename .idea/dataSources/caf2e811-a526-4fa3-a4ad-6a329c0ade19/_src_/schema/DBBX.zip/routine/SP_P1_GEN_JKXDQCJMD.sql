CREATE PROCEDURE      "SP_P1_GEN_JKXDQCJMD" AS
  V_STEP_CODE  CHAR(5);--?????????????????
  v_cjsj  varchar2(20):=to_char(sysdate,'yyyymmddhh24miss');
begin
  V_STEP_CODE := '00000';
  insert into TB_CJPT_SJSCZT_JKX(scsj,clbz) values(v_cjsj,'1');
  commit;
  insert into TB_CJPT_BX_REGULAR
	(
	  cjlx  ,--CHAR(1),
	  klx   ,--CHAR(2),
	  kh    ,--VARCHAR2(20),
	  xm    ,--VARCHAR2(50),
	  xb    ,--CHAR(1),
	  csrq  ,--CHAR(8),
	  zjh   ,--VARCHAR2(20),
	  fdsxr ,--CHAR(8),
	  scsj,zjlx  --CHAR(8)
	) select distinct '1' as cjlx,decode(b.ybbs ,'02','0', '03','1','9') as klx,b.YBKH as kh,b.xm,b.xb,to_char(b.csrq) as csrq,
	 b.aac147 as zjh,(select min(a.fdsxr) from tb_fdxx where khid=b.khid)  as fdsxr,to_char(sysdate,'yyyymmdd') as scsj,b.aac058 as zjlx
	    from tb_fdxx a,tb_khxx b  where  a.bbrkhid = b.khid
	    and nvl(a.XZTQBZ,'0')='0' and a.CJRQ<=to_char(sysdate,'yyyymmdd') and a.cjrq!=nvl(a.tcrq,19000101)
	     and not exists(
	    select 'x' from TB_CJPT_BX_REGULAR h where h.zjlx=b.aac058 and h.zjh=b.aac147 and cjlx='1');

 insert into TB_CJPT_BX_REGULAR
	(
	  cjlx  ,--CHAR(1),
	  klx   ,--CHAR(2),
	  kh    ,--VARCHAR2(20),
	  xm    ,--VARCHAR2(50),
	  xb    ,--CHAR(1),
	  csrq  ,--CHAR(8),
	  zjh   ,--VARCHAR2(20),
	  fdsxr ,--CHAR(8),
	  scsj,zjlx  --CHAR(8)
	) select '2' as cjlx,decode(b.ybbs ,'02','0', '03','1','9') as klx,b.YBKH as kh,b.xm,b.xb,to_char(b.csrq) as csrq,
	 b.aac147 as zjh,(select min(a.fdsxr) from tb_fdxx where khid=b.khid) as fdsxr,to_char(sysdate,'yyyymmdd') as scsj,b.aac058 as zjlx
	    from tb_fdxx a,tb_khxx b  where  a.bbrkhid = b.khid
	    and nvl(a.zZTQBZ,'0')='0' and a.tcRQ<=to_char(sysdate,'yyyymmdd') and a.tcrq!=a.cjrq and a.tcrq is not null
	     and not exists(
	    select 'x' from TB_CJPT_BX_REGULAR h where h.zjlx=b.aac058 and h.zjh=b.aac147 and cjlx='1');
	update  tb_fdxx set  XZTQBZ='1'  where  nvl(XZTQBZ,'0')='0' and CJRQ<=to_char(sysdate,'yyyymmdd');
	update  tb_fdxx set  zzTQBZ='1'  where  nvl(zzTQBZ,'0')='0' and tcRQ is not null and tcrq<=to_char(sysdate,'yyyymmdd');
	update TB_CJPT_SJSCZT_JKX set clbz='2' where scsj=v_cjsj;
  return;
  --COMMIT; ???java?????????
EXCEPTION
  WHEN OTHERS THEN
    --rollback;???java?????????????0?????????????????
    --PReturnCode := 'E'; /*  ??????  */
   -- DBMS_OUTPUT.PUT_LINE('[yhs debug] ' || 'PReturncode= ' ||PReturnCode);
   DBMS_OUTPUT.PUT_LINE('Error:' || sqlerrm); --???????????
  --  DBMS_OUTPUT.PUT_LINE(PReturnMsg);
end SP_P1_GEN_JKXDQCJMD;

/
