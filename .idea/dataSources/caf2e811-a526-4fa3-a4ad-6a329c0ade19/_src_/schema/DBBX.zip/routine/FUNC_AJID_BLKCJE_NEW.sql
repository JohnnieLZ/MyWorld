CREATE function      FUNC_AJID_BLKCJE_NEW(P_AJID number) return number is
  Result number := 0;
  CURSOR c_zpaid IS
  select zpaid from tb_zpaxx where ajid=P_AJID;
begin
   FOR cc IN c_zpaid LOOP
     Result := nvl(FUNC_ZPAID_BLKCJE_NEW(cc.zpaid),0)+Result;
   end loop;
  return(Result);
end FUNC_AJID_BLKCJE_NEW;

/
