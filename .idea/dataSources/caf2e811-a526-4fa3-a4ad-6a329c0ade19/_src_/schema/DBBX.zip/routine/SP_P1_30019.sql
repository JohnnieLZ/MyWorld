CREATE PROCEDURE      "SP_P1_30019" (report_id     In t_report_def_info.REPORTID%TYPE,
                                     pStartdate    IN varchar2,-- ??????yyyymmdd
                                     pEnddate      IN varchar2,-- ??????yyyymmdd
                                     pStatman      IN t_report_gen_info.STATMAN%TYPE,--???
                                     ptype         in varchar2, /*0 ???? ,1 ?? 2 ?? 3 ?? */--?????
                                     POther1   IN varchar2,--??id
                                     POther2   IN varchar2,--??id
                                     POther3   IN varchar2,--??id
                                     POther4   IN varchar2,--??ID
                                     POther5   IN varchar2,--????
                                     POther6   IN varchar2,--??ID
                                     POther7   IN varchar2,--??
                                     POther8   IN varchar2,--??
                                     PReturnCode   OUT varchar2,
                                     PReturnMsg    OUT varchar2) AS
  V_STEP_CODE  CHAR(5);--?????????????????
  vreportid    t_report_def_info.REPORTID%TYPE;--??ID
  v_start_date number := 0;--????????
  v_end_date   number := 0;--????????
  vxzqhdm   t_report_gen_info.STATORGID%TYPE; --????????????

   v_yhlx  varchar2(50) ;

  /*shuju*/
 cursor cur_data is
 --??
  select '??' as co1 ,a.slrid,a.slr as co2 ,count(distinct a.ajid) pas ,''as zpas
      from TB_LPAJXX a ,TB_LPPCXX b
      where to_char(b.SLRQ) >= nvl(v_start_date,19000101)
      and  to_char(b.SLRQ)  <=nvl(v_end_date,99991231)
      and a.lppcid = b.pcid
      group by a.slr,a.slrid
  union all
  --???
  select '??'as co1 ,a.lrrid, a.lrr as co2,count(distinct a.ajid) pas ,''as zpas
       from TB_LPAJXX a,TB_LPPCXX b
       where to_char(b.SLRQ  ) >= nvl(v_start_date,19000101)
       and  to_char(b.SLRQ  )  <=nvl(v_end_date,99991231)
       and a.lppcid = b.pcid
       group by a.lrr,a.lrrid
  union all
  --??? jarq
  select '??'as co1 ,a.shrid,a.shr as co2, count(distinct a.ajid) pas ,to_char(count(distinct c.ZPAID)) zpas
       from TB_LPAJXX a ,TB_ZPAXX c
       where a.ajid = c.ajid
       and to_char(a.jarq) >= nvl(v_start_date,19000101)
       and  to_char(a.jarq)  <=nvl(v_end_date,99991231)
       group by  a.shr,a.shrid
  union all
  --???
  select '??'as co1 ,a.zjrid, a.zjr as co2,count(distinct b.Aaz001) pas ,' 'as zpas
     from TB_LPAJXX a ,Ae02 b
     where b.cae249 = a.zjr
     and b.aac001 = a.zjrid
     --and b.aae016 = '1'
     and  b.AAE217 >= nvl(v_start_date,19000101)
     and b.AAE217 <= nvl(v_end_date,99991231)
     group by a.zjr,a.zjrid;

  vstatid varchar(30);--?????????????????

  type cellType is record(
    statid  varchar2(15),
    col     number,
    r       number,
    content varchar2(1024));
  cell      cellType; --?????????????
  vdwmc     varchar2(50);--????????????
  vusername t_report_gen_info.STATMAN%TYPE; --????????
  vnd       t_report_gen_info.STATYEAR%TYPE;--????
  rowno     number := 0;  --??????

begin
  V_STEP_CODE := '00000';
  PReturnMsg  := 'OK';
  PReturnCode := 'E';
  vreportid   := substr(report_id, 1, 5);
  vusername   := pStatman;
  vnd         := substr(pStartdate, 1, 4);

  v_start_date:=to_number(substr(pStartdate, 1, 8));
  v_end_date:=to_number(substr(pEnddate, 1, 8));


   --???????????????????????????
  delete from t_report_data_info
   where statid in
         (select statid from T_REPORT_GEN_INFO where reportid = report_id );

  delete from T_REPORT_GEN_INFO where statid in
         (select statid from T_REPORT_GEN_INFO where reportid = report_id );

   V_STEP_CODE := '00001';


  --???,?T_RERORT_GEN_INFO?????????????
  --???????
  select seq_statid.nextval into vstatid from dual;

    -- ??????????
    insert into t_report_gen_info
    (STATID, REPORTID, STATORGID, STATORGNAME, STATDATE, STATMAN, STATYEAR,BEGINDATE,ENDDATE,STAT_OTHER,STAT_TYPE)
  values
    (vstatid,
     vreportid,
     '',
     '',
     to_char(sysdate, 'yyyymmdd'),
     vusername,
     vnd,v_start_date,v_end_date,substr(pEnddate,1,1),trim(ptype));



 /* --?????? ??excel???0?????1??,????0???--*/
--???
  insert into t_report_data_info(statid,sheet,col,r,content) values(vstatid,0,1,2,'CLGL02');

--???
  insert into t_report_data_info
      (statid, sheet, col, r, content)
    values(vstatid,0,1,3, trim(pStartdate)||'--'||trim(pEnddate));


  cell.statid := vstatid;
  cell.col    := 0; --?1???
  cell.r      := 7; --?6???
  --???????????????????????????????excel????????????????????

  for vrow in cur_data loop
    --????6??0?,??4???
   -- cell.content := vrow.col1;
       if (vrow.co1 = v_yhlx ) then
         v_yhlx := '';
       end if ;
        v_yhlx := vrow.co1;
        insert into t_report_data_info (statid, sheet, col, r, content)values(cell.statid, 0, 0+0 , cell.r, vrow.co1  );
        insert into t_report_data_info (statid, sheet, col, r, content)values(cell.statid, 0, 0+1 , cell.r, vrow.co2  );
        insert into t_report_data_info (statid, sheet, col, r, content)values(cell.statid, 0, 0+2 , cell.r, vrow.pas  );
        insert into t_report_data_info (statid, sheet, col, r, content)values(cell.statid, 0, 0+3 , cell.r, vrow.zpas  );
        cell.r   := cell.r + 1;  --??+1,???????1?
  end loop;

--???????????
 /* insert into t_report_data_info (statid, sheet, col, r, content)values(cell.statid, 0, 15, 23, '?????'||substr(to_char(sysdate, 'yyyymmdd'), 1, 4) || '?' ||
     substr(to_char(sysdate, 'yyyymmdd'), 5, 2) || '?' ||
     substr(to_char(sysdate, 'yyyymmdd'), 7, 2) || '?');*/
  /*9.??*/
  PReturnCode := '0'; /* ??????????????vstatid????????? */
  PReturnMsg  := vstatid;
  DBMS_OUTPUT.PUT_LINE('[yhs debug] ' || 'PReturncode= ' || PReturnCode);
  --COMMIT; ???java?????????
EXCEPTION
  WHEN OTHERS THEN
    --rollback;???java?????????????0?????????????????
    PReturnCode := 'E'; /*  ??????  */
    DBMS_OUTPUT.PUT_LINE('[yhs debug] ' || 'PReturncode= ' ||PReturnCode);
    PReturnMsg := ' rownum' || cell.r  || 'Error:' || sqlerrm; --???????????
    DBMS_OUTPUT.PUT_LINE(PReturnMsg);
end SP_P1_30019;

/
