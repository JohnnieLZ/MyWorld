CREATE function      SF_P1_GET_STRMULTIZDDM(p_RGXGDM in varchar2,p_aaa100 in varchar2) return varchar2 is
cursor cur_rec is select b.aaa102,trim(b.aaa103) as aaa103 from aa10 b where /*p_RGXGDM like '%'|| trim(b.aaa102)||'%'*/
b.aaa102 in(select trim(COLUMN_VALUE) from TABLE(sf_splitstr(p_RGXGDM,',')) H )
and b.aaa100=trim(p_aaa100);
Result varchar2(4028):='' ;
BEGIN

 if length(trim(p_RGXGDM))=0 then
    Result:='?';

  end if;

  for rec in cur_rec loop
    /* if p_RGXGDM ='FPXGDM' and rec.aaa102 like 'SY00%'  then

     else*/
        Result:=Result||rec.aaa103||',';
/*     end if;*/

  end loop;
  Result:=substr(Result,1,length(trim(Result))-1);
--dbms_output.put_line(Result);
return(Result);
END SF_P1_GET_STRMULTIZDDM;

/
