CREATE procedure      SP_IMPORT_PSNFDZR_TMP(zpch IN varCHAR2 ,PReturnCode OUT varchar2,
                              PReturnMsg    OUT varchar2) as
n  number:=0;
m  number:=0;
cursor recs is select a.xm,a.zjlx,a.zjhm,a.zbbrxm,a.zbbrzjlx,a.zbbrzjhm from TB_IMPORT_PSNFDZR_TMP a where a.RUN_FLAG='1' and a.PCH=zpch group by a.xm,a.zjlx,a.zjhm,a.zbbrxm,a.zbbrzjlx,a.zbbrzjhm;
begin
    PReturnCode:='E';
    PReturnMsg:='Error!';
    --????????????????????????????????????????????????????????????????????????????
   -- ?????????????????????????????????????????????????????????????????????????????????????
    --????????????????????????????????????????????????????????????????????????
    --???????????????????????????????kkkkk


   ---------------------
   select nvl(count(1),0) into n from TB_IMPORT_PSNFDZR_TMP where RUN_FLAG='1' and PCH=zpch;
   --tmp?????????
   if(n>0) then
       for rec in recs loop
         --?????????????????????????????????TB_IMPORT_PSNFDZR?
         --?????????????????????????????????????? ?????????
        select nvl(count(1),0) into m from (select 1 as hs from TB_IMPORT_PSNFDZR_TMP a where a.xm=rec.xm and a.zjlx=rec.zjlx and a.zjhm=rec.zjhm and a.zbbrxm=rec.zbbrxm and a.zbbrzjlx=rec.zbbrzjlx and a.zbbrzjhm=rec.zbbrzjhm and a.RUN_FLAG='1' and a.PCH=zpch
         group by a.PCH,a.BDH,a.XH,a.XM,a.XB,a.CSRQ,a.ZJLX,a.ZJHM,a.YBBS,a.GX,a.ZBBRXM,a.ZBBRZJLX,a.ZBBRZJHM,a.ZY,a.ZYDM,a.CKR,a.KHH,a.KHHZH,a.PHONE,a.EMAIL,a.YJDZ,a.YZBM,
         a.DJ,a.SJSXR,a.SJZZR,a.SYRXM,a.YBBRGX,a.RUN_FLAG,a.DO_DATE,a.IMP_ERR_TYPE,a.IMP_ERR_DESC,a.OP_FLAG,a.SBSJDCRQ,a.BMBH,a.YBD,a.TTMC,a.ZTTMC,a.FDH,a.BBRXH,a.ZBBRXH,
         a.ZYLB,a.GZD,a.AGE,a.BXGSMC) group by hs;
         if(m>1) then
           PReturnCode:='2';
           PReturnMsg:='??????'||rec.xm||',????'||rec.zjhm||'??????????????';
           RETURN;
         else
           ---?????????-------------------------------------------
           --?????????????????????????????????????? ?????????
             insert into TB_IMPORT_PSNFDZR a (
             a.YWLSH,a.PCH,a.BDH,a.XH,a.XM,a.XB,a.CSRQ,a.ZJLX,a.ZJHM,a.YBBS,a.GX,a.ZBBRXM,a.ZBBRZJLX,a.ZBBRZJHM,a.ZY,a.ZYDM,a.CKR,a.KHH,a.KHHZH,a.PHONE,a.EMAIL,a.YJDZ,a.YZBM,a.DJ,a.SJSXR,a.SJZZR,a.SYRXM,a.YBBRGX,a.OPDATE,a.RUN_FLAG,a.DO_DATE,
             a.IMP_ERR_TYPE,a.IMP_ERR_DESC,a.OP_FLAG,a.SBSJDCRQ,a.BMBH,a.YBD,a.TTMC,a.ZTTMC,a.FDH,a.BBRXH,a.ZBBRXH,a.ZYLB,a.GZD,a.AGE,a.BXGSMC
             )
             select  max(b.ywlsh),max(b.pch),max(b.bdh),max(b.xh),max(b.xm),max(b.xb),max(b.csrq),max(b.zjlx),max(b.zjhm),max(b.ybbs),max(b.gx),max(b.zbbrxm),max(b.zbbrzjlx),max(b.zbbrzjhm),max(b.zy),max(b.zydm),max(b.ckr),max(b.khh),max(b.khhzh),max(b.phone),max(b.email),max(b.yjdz),max(b.yzbm),max(b.dj),max(b.sjsxr),max(b.sjzzr),max(b.syrxm),max(b.ybbrgx),max(b.opdate),'' as run_flag,max(b.do_date),
             max(b.imp_err_type),max(b.imp_err_desc),max(b.op_flag),max(b.sbsjdcrq),max(b.bmbh),max(b.ybd),max(b.ttmc),max(b.zttmc),max(b.fdh),max(b.bbrxh),max(b.zbbrxh),max(b.zylb),max(b.gzd),max(b.age),max(b.bxgsmc)
             from TB_IMPORT_PSNFDZR_TMP b
             where b.RUN_FLAG='1' and b.PCH=zpch and b.xm=rec.xm and b.zjlx=rec.zjlx and b.zjhm=rec.zjhm and b.zbbrxm=rec.zbbrxm and b.zbbrzjlx=rec.zbbrzjlx and b.zbbrzjhm=rec.zbbrzjhm
             and not exists(select 1 from TB_IMPORT_PSNFDZR c where b.RUN_FLAG='1' and b.PCH=zpch and c.xm=b.xm and c.zjlx=b.zjlx and c.zjhm=b.zjhm and c.zbbrxm=b.zbbrxm and c.zbbrzjlx=b.zbbrzjlx and c.zbbrzjhm=b.zbbrzjhm and c.pch=zpch and c.xm=rec.xm and c.zjlx=rec.zjlx and c.zjhm=rec.zjhm and c.zbbrxm=rec.zbbrxm and c.zbbrzjlx=rec.zbbrzjlx and c.zbbrzjhm=rec.zbbrzjhm);
           ----------------------------------------------------------------
              ---???????-----------------------------------------------
              --?????????????????????????????????????? ?????????
              select nvl(count(1),0) into n from TB_IMPORT_PSNFDZR_TMP a where a.RUN_FLAG='1' and a.PCH=zpch and a.xm=rec.xm and a.zjlx=rec.zjlx and a.zjhm=rec.zjhm and a.zbbrxm=rec.zbbrxm and a.zbbrzjlx=rec.zbbrzjlx and a.zbbrzjhm=rec.zbbrzjhm group by a.xm,a.zjlx,a.zjhm,a.zbbrxm,a.zbbrzjlx,a.zbbrzjhm;
              --?????????
              if (n=1) then
                  update TB_IMPORT_PSNFDZR a set (a.zr1dm,a.zr1be,a.zr1bf,a.zr1bz,a.zr2dm,a.zr2be,a.zr2bf,a.zr2bz,a.zr3dm,a.zr3be,a.zr3bf,a.zr3bz,a.zr4dm,a.zr4be,a.zr4bf,a.zr4bz)=(
                  select b.zr1dm,b.zr1be,b.zr1bf,b.zr1bz,b.zr2dm,b.zr2be,b.zr2bf,b.zr2bz,b.zr3dm,b.zr3be,b.zr3bf,b.zr3bz,b.zr4dm,b.zr4be,b.zr4bf,b.zr4bz from TB_IMPORT_PSNFDZR_TMP b
                  where b.RUN_FLAG='1' and b.PCH=zpch and b.xm=rec.xm and b.zjlx=rec.zjlx and b.zjhm=rec.zjhm and b.zbbrxm=rec.zbbrxm and b.zbbrzjlx=rec.zbbrzjlx and b.zbbrzjhm=rec.zbbrzjhm and a.xm=b.xm and a.zjlx=b.zjlx and a.zjhm=b.zjhm and a.zbbrxm=b.zbbrxm and a.zbbrzjlx=b.zbbrzjlx and a.zbbrzjhm=b.zbbrzjhm
                  ) where exists (select 1 from TB_IMPORT_PSNFDZR_TMP z where z.RUN_FLAG='1' and z.PCH=zpch and z.xm=rec.xm and z.zjlx=rec.zjlx and z.zjhm=rec.zjhm and z.zbbrxm=rec.zbbrxm and z.zbbrzjlx=rec.zbbrzjlx and z.zbbrzjhm=rec.zbbrzjhm and a.xm=z.xm and a.zjlx=z.zjlx and a.zjhm=z.zjhm and a.zbbrxm=z.zbbrxm and a.zbbrzjlx=z.zbbrzjlx and a.zbbrzjhm=z.zbbrzjhm);

              --?????2-4??????2?4
              elsif(n>1 and n<5) then
                  for zr in (select rownum as xh,zr1dm,zr1be,zr1bf,zr1bz from TB_IMPORT_PSNFDZR_TMP where RUN_FLAG='1' and PCH=zpch and xm=rec.xm and zjlx=rec.zjlx and zjhm=rec.zjhm and zbbrxm=rec.zbbrxm and zbbrzjlx=rec.zbbrzjlx and zbbrzjhm=rec.zbbrzjhm) loop
                    if(zr.xh=1) then
                      update TB_IMPORT_PSNFDZR a set (zr1dm,zr1be,zr1bf,zr1bz)=(select zr.zr1dm,zr.zr1be,zr.zr1bf,zr.zr1bz from dual)
                      where a.PCH=zpch and a.xm=rec.xm and a.zjlx=rec.zjlx and a.zjhm=rec.zjhm and a.zbbrxm=rec.zbbrxm and a.zbbrzjlx=rec.zbbrzjlx and a.zbbrzjhm=rec.zbbrzjhm;

                    elsif(zr.xh=2) then
                      update TB_IMPORT_PSNFDZR a set (zr2dm,zr2be,zr2bf,zr2bz)=(select zr.zr1dm,zr.zr1be,zr.zr1bf,zr.zr1bz from dual)
                      where a.PCH=zpch and a.xm=rec.xm and a.zjlx=rec.zjlx and a.zjhm=rec.zjhm and a.zbbrxm=rec.zbbrxm and a.zbbrzjlx=rec.zbbrzjlx and a.zbbrzjhm=rec.zbbrzjhm;

                    elsif(zr.xh=3) then
                       update TB_IMPORT_PSNFDZR a set (zr3dm,zr3be,zr3bf,zr3bz)=(select zr.zr1dm,zr.zr1be,zr.zr1bf,zr.zr1bz from dual)
                       where a.PCH=zpch and a.xm=rec.xm and a.zjlx=rec.zjlx and a.zjhm=rec.zjhm and a.zbbrxm=rec.zbbrxm and a.zbbrzjlx=rec.zbbrzjlx and a.zbbrzjhm=rec.zbbrzjhm;

                    elsif(zr.xh=4) then
                       update TB_IMPORT_PSNFDZR a set (zr4dm,zr4be,zr4bf,zr4bz)=(select zr.zr1dm,zr.zr1be,zr.zr1bf,zr.zr1bz from dual)
                       where a.PCH=zpch and a.xm=rec.xm and a.zjlx=rec.zjlx and a.zjhm=rec.zjhm and a.zbbrxm=rec.zbbrxm and a.zbbrzjlx=rec.zbbrzjlx and a.zbbrzjhm=rec.zbbrzjhm;
                    end if;
                  end loop;

              --????4??
              elsif(n>4) then
                   PReturnCode:='3';
                   PReturnMsg := '??'||rec.xm||',???'||rec.zjhm||'???????4?';
                   RETURN;
              end if;
         end if;
       end loop;
       update TB_IMPORT_PSNFDZR_TMP set RUN_FLAG='0' where RUN_FLAG='1' and pch=zpch;
       update TB_IMPORT_PSNFDZR a set a.xm='' where a.xm='kkkkk' and a.pch=zpch;
       update TB_IMPORT_PSNFDZR a set a.zjlx='' where a.zjlx='kkkkk' and a.pch=zpch;
       update TB_IMPORT_PSNFDZR a set a.zjhm='' where a.zjhm='kkkkk' and a.pch=zpch;
       update TB_IMPORT_PSNFDZR a set a.zbbrxm='' where a.zbbrxm='kkkkk' and a.pch=zpch;
       update TB_IMPORT_PSNFDZR a set a.zbbrzjlx='' where a.zbbrzjlx='kkkkk' and a.pch=zpch;
       update TB_IMPORT_PSNFDZR a set a.zbbrzjhm='' where a.zbbrzjhm='kkkkk' and a.pch=zpch;
   else
     PReturnCode:='1';
     PReturnMsg := 'tmp???????'||zpch||'??RUN_FLAG?1???';
     RETURN;
   end if;
    PReturnCode:='0';
    PReturnMsg:='????????!';
    EXCEPTION
  WHEN OTHERS THEN
    PReturnCode := 'E';
    DBMS_OUTPUT.PUT_LINE('[ddl debug] ' || 'PReturncode= ' ||
                         PReturnCode);
    PReturnMsg := 'Error:' || sqlerrm;
    DBMS_OUTPUT.PUT_LINE(PReturnMsg);
  end   SP_IMPORT_PSNFDZR_TMP;

/
