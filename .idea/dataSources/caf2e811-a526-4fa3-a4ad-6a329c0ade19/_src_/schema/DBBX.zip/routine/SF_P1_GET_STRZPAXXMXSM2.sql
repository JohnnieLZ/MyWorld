CREATE function      SF_P1_GET_STRZPAXXMXSM2(p_FPID in varchar2) return varchar2 is
cursor cur_rec is
select mc,sum(je) as zje from (
select trim(a.xxmc) as mc,a.flzfje as je from tb_fpxxfyxx a, tb_zpaxxdzb b where a.xxid=b.xxid and a.fpid=to_number(p_FPID) and a.flzfje>0 and b.HLBHFLLSGZID is not null
union all
select trim(a.xxmc) as mc,a.zdje as je from tb_fpxxfyxx a, tb_zpaxxdzb b where a.xxid=b.xxid and a.fpid=to_number(p_FPID) and a.zfje>0 and b.ZFFYLSGZID is  null
union all
select trim(a.xxmc) as mc,a.zdje as je from tb_fpxxfyxx a, tb_zpaxxdzb b where a.xxid=b.xxid and a.fpid=to_number(p_FPID) and a.bhlje>0)
group by mc;

Result varchar2(4096):='' ;
BEGIN

 if length(trim(p_FPID))=0 then
    Result:='?';

  end if;

  for rec in cur_rec loop
     Result:=Result||rec.mc||':'||trim(to_char(rec.zje,'9999990.00'))||'?,';
  end loop;
  dbms_output.put_line(Result);
  Result:=substr(Result,1,length(trim(Result))-1);

return(Result);
END SF_P1_GET_STRZPAXXMXSM2;

/
