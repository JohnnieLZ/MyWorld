CREATE PROCEDURE      "SP_P1_30002" (report_id   In t_report_def_info.REPORTID%TYPE,
                                        pStartdate  IN varchar2, -- ??????yyyymmdd
                                        pEnddate    IN varchar2, -- ??????yyyymmdd
                                        pStatman    IN t_report_gen_info.STATMAN%TYPE, --???
                                        ptype       in varchar2, /*0 ???? ,1 ?? 2 ?? 3 ?? */ --?????
                                        POther1     IN varchar2, --??id
                                        POther2     IN varchar2, --??id
                                        POther3     IN varchar2, --??id
                                        POther4     IN varchar2, --??ID
                                        POther5     IN varchar2, --????
                                        POther6     IN varchar2, --??ID
                                        POther7     IN varchar2, --??
                                        POther8     IN varchar2, --??
                                        PReturnCode OUT varchar2,
                                        PReturnMsg  OUT varchar2) AS
  V_STEP_CODE  CHAR(5); --?????????????????
  vreportid    t_report_def_info.REPORTID%TYPE; --??ID
  v_start_date number := 0; --????????
  v_end_date   number := 0; --????????
  vxzqhdm      t_report_gen_info.STATORGID%TYPE; --????????????

  vstatid varchar(30); --?????????????????
  type cellType is record(
    statid  varchar2(15),
    col     number,
    r       number,
    content varchar2(1024));

  cell      cellType; --?????????????
  vdwmc     varchar2(50); --????????????
  vusername t_report_gen_info.STATMAN%TYPE; --????????
  vnd       t_report_gen_info.STATYEAR%TYPE; --????
  rowno     number := 0; --??????


  v_tthjzs number :=0;--????
  v_bdhjzs number :=0;--????
  v_ryhjzs number :=0;--????
  v_bfhjzs number :=0;--??????
  V_pcmc varchar2(100);


begin
  V_STEP_CODE := '00000';
  PReturnMsg  := 'OK';
  PReturnCode := 'E';
  vreportid   := substr(report_id, 1, 5);
  vusername   := pStatman;
  vnd         := substr(pStartdate, 1, 4);

  v_start_date := to_number(substr(pStartdate, 1, 8));
  v_end_date   := to_number(substr(nvl(pEnddate,to_char(sysdate,'yyyymmdd')), 1, 8));

  --???????????????????????????
  delete from t_report_data_info
   where statid in
         (select statid from T_REPORT_GEN_INFO where reportid = report_id);

  delete from T_REPORT_GEN_INFO
   where statid in
         (select statid from T_REPORT_GEN_INFO where reportid = report_id);

  V_STEP_CODE := '00001';
  --???,?T_RERORT_GEN_INFO?????????????
  --???????
  select seq_statid.nextval into vstatid from dual;

  -- ??????????
  insert into t_report_gen_info
    (STATID,
     REPORTID,
     STATORGID,
     STATORGNAME,
     STATDATE,
     STATMAN,
     STATYEAR,
     BEGINDATE,
     ENDDATE,
     STAT_OTHER,
     STAT_TYPE)
  values
    (vstatid,
     vreportid,
     '',
     '',
     to_char(sysdate, 'yyyymmdd'),
     vusername,
     vnd,
     v_start_date,
     v_end_date,
     substr(v_end_date, 1, 1),
     trim(ptype));

  /* --?????? ??excel???0?????1??,????0???*/

  --???
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,1,2,'MB008');

  --????
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,1,3,to_char(sysdate,'yyyymmdd'));

  --????
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,1,8, trim(pStartdate)||'--'||trim(v_end_date));

  --????
  select max(ttmc) into cell.content from tb_ttxx where ttid = trim(POther2);
  if cell.content is not null then
    insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,1,4,cell.content);
  end if;

  --????
  select max(bxgsqc) into cell.content from tb_bxgsxx where bxgsid=trim(POther1);
  if cell.content is not null then
    insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,1,5,cell.content);
  end if;

  /*????*/
  select count(distinct a.ttmc) as tthjzs,
         count(distinct b.khbdh) as bdhjzs,
         count(distinct c.bbrkhid) as ryhjzs,
         nvl(sum(nvl(c.fdzbf, 0)), 0) as bf
    into v_tthjzs, v_bdhjzs, v_ryhjzs, v_bfhjzs
    from tb_ttxx    a,
         tb_bdxx    b,
         tb_fdxx    c/*,
         tb_bdcpxx  d,
         tb_cpxx e*/
         --tb_zttxx f
   where /*b.bdid = d.bdid
     --and f.ttid = a.ttid
     and d.cpid = e.cpid
     and*/ b.khbdh = c.khbdh
     and a.ttid = b.ttid
     and a.ttid=nvl(trim(POther2),a.ttid)
     and b.bdzzrq>=nvl(POther7,19000101)
     and b.bdzzrq<=nvl(POther8,99991231)
     and b.bdsxrq<=to_number(to_char(sysdate,'yyyymmdd'))
     and b.bdzzrq>=nvl(trim(pStartdate), '19000101')
     and b.bxgsid = nvl(trim(POther1),b.bxgsid);

 select  round(sum(  NVL(H.ZRBF,0)/to_number(to_date(c.bdzzrq,'yyyymmdd')-to_date(f.fdsxr,'yyyymmdd')+1) * (
               to_date( case when nvl(trim(v_end_date), '99991231')>=nvl(h.ZRJSRQ,f.fdzzr) then nvl(h.ZRJSRQ,f.fdzzr) else to_number(nvl(trim(v_end_date),'99991231')) end,'yyyy-mm-dd')-
                to_date(case when nvl(trim(pStartdate), '19000101')<=nvl(h.ZRKSRQ,f.fdsxr) then nvl(h.ZRKSRQ,f.fdsxr) else to_number(nvl(trim(pStartdate),  '19000101')) end,'yyyy-mm-dd')+1)),2) into v_bfhjzs  --????????
                 from TB_TTXX a,TB_BDXX c,TB_CPXX d,/*TB_BDCPXX e,*/TB_FDXX f,TB_FDZRMX H,TB_CPZRDZB M
                 where/* c.bdid = e.bdid AND */F.FDID=H.FDID AND M.CPID=D.CPID AND M.ZRID=H.ZRID
                 /*and d.cpid = e.cpid*/
                 and c.khbdh = f.khbdh
                 and c.bxgsid = nvl(trim(POther1),c.bxgsid)
                 and a.ttid=nvl(trim(POther2),a.ttid)
               and c.bdzzrq>=nvl(POther7,19000101)
               and c.bdzzrq<=nvl(POther8,99991231)
               and c.bdsxrq<=to_number(to_char(sysdate,'yyyymmdd'))
               and c.bdzzrq>=nvl(trim(pStartdate), '19000101')
                 and c.ttid = a.ttid;


  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,1,7,v_tthjzs);  --????
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,3,7,v_bdhjzs); --????
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,5,7,v_ryhjzs); --????
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,7,7,v_bfhjzs); --????


  cell.statid := vstatid;
  cell.col    := 0; --?1???
  cell.r      := 11; --?8???
  --???????????????????????????????excel????????????????????

  --???????
       for rec_ttxx in(select a.ttbh ,a.ttmc ,a.ttid,g.bxgsqc,g.bxgsid
            from TB_TTXX a,TB_BDXX c,/*TB_CPXX d,TB_BDCPXX e,*/TB_FDXX f,tb_bxgsxx g
            where /*d.cpid = e.cpid
            and e.bdid = c.bdid
            and*/ c.ttid = a.ttid
            and c.bxgsid = nvl(trim(POther1),c.bxgsid)
            and a.ttid=nvl(trim(POther2),a.ttid)
            and c.khbdh = f.khbdh
            and g.bxgsid = c.bxgsid
            and c.bdzzrq>=nvl(POther7,19000101)
           and c.bdzzrq<=nvl(POther8,99991231)
           and c.bdzzrq>=nvl(trim(pStartdate), '19000101')
           and c.bdsxrq<=to_number(to_char(sysdate,'yyyymmdd'))
            group by a.ttbh ,a.ttmc ,a.ttid,g.bxgsqc,g.bxgsid
            order by g.bxgsid
            ) loop
          for rec_bdxx in(select a.ttid as co2, c.khbdh as co4,c.bdsxrq as co5,
                      c.bdzzrq as co6,c.jffs as co9,c.bdid
              from TB_TTXX a,TB_BDXX c,/*TB_CPXX d,TB_BDCPXX e,*/TB_FDXX f,tb_bxgsxx g
              where/* c.bdid = e.bdid
              and d.cpid = e.cpid
              and*/ a.ttid = rec_ttxx.ttid
              and c.ttid = a.ttid
              and c.khbdh = f.khbdh
              and g.bxgsid = c.bxgsid
              and c.bxgsid =rec_ttxx.bxgsid /* nvl(trim(POther1),c.bxgsid)*/
                and c.bdzzrq>=nvl(POther7,19000101)
           and c.bdzzrq<=nvl(POther8,99991231)
           and c.bdzzrq>=nvl(trim(pStartdate), '19000101')
           and c.bdsxrq<=to_number(to_char(sysdate,'yyyymmdd'))
              group by a.ttid ,c.khbdh,c.bdsxrq,
                       c.bdzzrq,c.jffs,c.bdid
              ) loop
            for rec_cpxx in(
              select d.cpmc,d.cpid ,count(distinct f.BBRKHID)as bbrs ,
                  --(round(sum(nvl(H.ZRBf,0))/to_number(to_date(c.bdzzrq,'yyyymmdd')-to_date(f.fdsxr,'yyyymmdd')),2)*round(to_number(sysdate - to_date(f.fdsxr,'yyyymmdd')))) as bf  --????
              round(sum(  NVL(H.ZRBF,0)/to_number(to_date(c.bdzzrq,'yyyymmdd')-to_date(f.fdsxr,'yyyymmdd')+1) * (
               to_date( case when nvl(trim(v_end_date), '99991231')>=nvl(h.ZRJSRQ,f.fdzzr) then nvl(h.ZRJSRQ,f.fdzzr) else to_number(nvl(trim(v_end_date),'99991231')) end,'yyyy-mm-dd')-
                to_date(case when nvl(trim(pStartdate), '19000101')<=nvl(h.ZRKSRQ,f.fdsxr) then nvl(h.ZRKSRQ,f.fdsxr) else to_number(nvl(trim(pStartdate),  '19000101')) end,'yyyy-mm-dd')+1)),2) as bf  --????????
                 from TB_TTXX a,TB_BDXX c,TB_CPXX d,/*TB_BDCPXX e,*/TB_FDXX f,TB_FDZRMX H,TB_CPZRDZB M
                 where/* c.bdid = e.bdid AND */F.FDID=H.FDID AND M.CPID=D.CPID AND M.ZRID=H.ZRID
                 /*and d.cpid = e.cpid*/
                 and c.khbdh = f.khbdh
                 and c.khbdh=rec_bdxx.co4
                 and a.ttid = rec_ttxx.ttid
                 and c.bdid = rec_bdxx.bdid
                 and c.ttid = a.ttid
               /*  and c.bxgsid = nvl(trim(POther1),c.bxgsid)*/
                 and nvl(h.ZRJSRQ,f.fdzzr)>=nvl(POther7,19000101)
                 and nvl(h.ZRJSRQ,f.fdzzr)<=nvl(POther8,99991231)
                 and nvl(h.ZRJSRQ,f.fdzzr)>=nvl(trim(pStartdate), '19000101')
                 and nvl(h.ZRKSRQ,f.fdsxr)<=to_number(to_char(sysdate,'yyyymmdd'))
                 group by d.cpmc, d.cpid,f.fdsxr,c.bdzzrq
                  ) loop
                  V_pcmc := rec_cpxx.cpmc;

              --??????
                cell.content := rec_ttxx.bxgsqc;
                if cell.content is not null then
                insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,0,cell.r,cell.content);
                end if;

              --???
              cell.content := rec_ttxx.ttbh;
              if cell.content is not null then
              insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,1,cell.r,cell.content);
              end if;

              --????
              cell.content := rec_ttxx.ttmc;
              if cell.content is not null then
              insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,2,cell.r,cell.content);
              end if;

              --?????
              select max(e.zttmc) into  cell.content from tb_zttxx e,tb_bdxx d  where e.zttid = d.zttid and d.bdid = rec_bdxx.bdid;
              if cell.content is not null then
              insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,3,cell.r,cell.content);
              end if;

              --???
              cell.content := rec_bdxx.co4;
              if cell.content is not null then
              insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,4,cell.r,cell.content);
              end if;

              --??????
              cell.content := rec_bdxx.co5;
              if cell.content is not null then
              insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,5,cell.r,cell.content);
              end if;

              --??????
              cell.content := rec_bdxx.co6;
              if cell.content is not null then
              insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,6,cell.r,cell.content);
              end if;


              --??
              cell.content := rec_cpxx.cpmc;
              if cell.content is not null then
              insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,7,cell.r,cell.content);
              end if;

              --????
             select max(aaa103) into cell.content from aa10 where aaa100 = 'JFFS' and aaa102 = rec_bdxx.co9;
              if cell.content is not null then
              insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,8,cell.r,cell.content);
              end if;


              --?????
              cell.content := rec_cpxx.bbrs;
              if cell.content is not null then
              insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,9,cell.r,cell.content);
              end if;


              --??????
              cell.content := rec_cpxx.bf;
              if cell.content is not null then
              insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,10,cell.r,cell.content);
              end if;

              cell.r :=  cell.r+1;

           end loop ;

               /*??????*/
               insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,8,cell.r,'????');
                select count(distinct f.BBRKHID) into cell.content
                 from TB_TTXX a,TB_BDXX c,TB_CPXX d,/*TB_BDCPXX e,*/TB_FDXX f,TB_FDZRMX H,TB_CPZRDZB M
                 where /*c.bdid = e.bdid AND*/ F.FDID=H.FDID AND M.CPID=D.CPID AND M.ZRID=H.ZRID
                 /*and d.cpid = e.cpid*/
                 and c.khbdh = f.khbdh
                 and a.ttid = rec_ttxx.ttid
                 and c.bdid = rec_bdxx.bdid
                 and c.ttid = a.ttid
                 and c.bdzzrq>=nvl(POther7,19000101)
           and c.bdzzrq<=nvl(POther8,99991231)
           and c.bdzzrq>=nvl(trim(pStartdate), '19000101')
           and c.bdsxrq<=to_number(to_char(sysdate,'yyyymmdd'))
                 /*and c.bxgsid = nvl(trim(POther1),c.bxgsid)
                 and c.bxgsid = nvl(trim(POther1),c.bxgsid)*/;

               insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,9,cell.r,cell.content);
               select
                  --(round(sum(nvl(H.ZRBf,0))/to_number(to_date(c.bdzzrq,'yyyymmdd')-to_date(f.fdsxr,'yyyymmdd')),2)*round(to_number(sysdate - to_date(f.fdsxr,'yyyymmdd')))) as bf  --????
               round( sum(  NVL(H.ZRBF,0)/to_number(to_date(c.bdzzrq,'yyyymmdd')-to_date(f.fdsxr,'yyyymmdd')+1) * (
               to_date( case when nvl(trim(v_end_date), '99991231')>=nvl(h.ZRJSRQ,f.fdzzr) then nvl(h.ZRJSRQ,f.fdzzr) else to_number(nvl(trim(v_end_date),'99991231')) end,'yyyy-mm-dd')-
                to_date(case when nvl(trim(pStartdate), '19000101')<=nvl(h.ZRKSRQ,f.fdsxr) then nvl(h.ZRKSRQ,f.fdsxr) else to_number(nvl(trim(pStartdate),  '19000101')) end,'yyyy-mm-dd')+1)),2) as zrjgbf  --??????
                into cell.content from TB_TTXX a,TB_BDXX c,TB_CPXX d,/*TB_BDCPXX e,*/TB_FDXX f,TB_FDZRMX H,TB_CPZRDZB M
                 where /*c.bdid = e.bdid AND*/ F.FDID=H.FDID AND M.CPID=D.CPID AND M.ZRID=H.ZRID
                /* and d.cpid = e.cpid*/
                 and c.khbdh = f.khbdh
                 and a.ttid = rec_ttxx.ttid
                 and c.bdid = rec_bdxx.bdid
                 and c.ttid = a.ttid
                 and c.bxgsid = nvl(trim(POther1),c.bxgsid)
                 and nvl(h.ZRJSRQ,f.fdzzr)>=nvl(POther7,19000101)
                 and nvl(h.ZRJSRQ,f.fdzzr)<=nvl(POther8,99991231)
                 and nvl(h.ZRJSRQ,f.fdzzr)>=nvl(trim(pStartdate), '19000101')
                   and nvl(h.ZRKSRQ,f.fdsxr)<=to_number(to_char(sysdate,'yyyymmdd'))
                /* group by d.cpmc, d.cpid,f.fdsxr,c.bdzzrq*/;
                insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,10,cell.r,cell.content);
               cell.r :=  cell.r+1;
       end loop ;

           /*??????*/
           insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,3,cell.r,'??????');
           select count(distinct f.BBRKHID) into cell.content
                 from TB_TTXX a,TB_BDXX c,TB_CPXX d,/*TB_BDCPXX e,*/TB_FDXX f,TB_FDZRMX H,TB_CPZRDZB M
                 where /*c.bdid = e.bdid AND*/ F.FDID=H.FDID AND M.CPID=D.CPID AND M.ZRID=H.ZRID
                /* and d.cpid = e.cpid*/
                 and c.khbdh = f.khbdh
                 and a.ttid = rec_ttxx.ttid
                 and c.ttid = a.ttid
                 and c.bxgsid = rec_ttxx.bxgsid
                 and nvl(h.ZRJSRQ,f.fdzzr)>=nvl(POther7,19000101)
                 and nvl(h.ZRJSRQ,f.fdzzr)<=nvl(POther8,99991231)
                 and nvl(h.ZRJSRQ,f.fdzzr)>=nvl(trim(pStartdate), '19000101')
                  and nvl(h.ZRkSRQ,f.fdsxr)<=to_number(to_char(sysdate,'yyyymmdd'));

           insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,6,cell.r,cell.content);
           insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,8,cell.r,'????');

           select count(distinct f.BBRKHID) into cell.content
            from TB_TTXX a,TB_BDXX c,TB_CPXX d,/*TB_BDCPXX e,*/TB_FDXX f
            where/* d.cpid = e.cpid
            and e.bdid = c.bdid
            and*/ c.ttid = a.ttid
            and c.bxgsid = rec_ttxx.bxgsid/* nvl(trim(POther1),c.bxgsid)*/
            and a.ttid=rec_ttxx.ttid
            and nvl(f.fdzzr,c.bdzzrq)>=nvl(POther7,19000101)
                 and nvl(f.fdzzr,c.bdzzrq)<=nvl(POther8,99991231)
                 and nvl(f.fdzzr,c.bdzzrq)>=nvl(trim(pStartdate), '19000101')
                  and nvl(f.fdsxr,c.bdsxrq)<=to_number(to_char(sysdate,'yyyymmdd'))
            and c.khbdh = f.khbdh;

           insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,9,cell.r,cell.content);
           select
                  --(round(sum(nvl(H.ZRBf,0))/to_number(to_date(c.bdzzrq,'yyyymmdd')-to_date(f.fdsxr,'yyyymmdd')),2)*round(to_number(sysdate - to_date(f.fdsxr,'yyyymmdd')))) as bf  --????
              round(sum(  NVL(H.ZRBF,0)/to_number(to_date(c.bdzzrq,'yyyymmdd')-to_date(f.fdsxr,'yyyymmdd')+1) * (
               to_date( case when nvl(trim(v_end_date), '99991231')>=nvl(h.ZRJSRQ,f.fdzzr) then nvl(h.ZRJSRQ,f.fdzzr) else to_number(nvl(trim(v_end_date), '99991231')) end,'yyyy-mm-dd')-
                to_date(case when nvl(trim(pStartdate), '19900101')<=nvl(h.ZRKSRQ,f.fdsxr) then nvl(h.ZRKSRQ,f.fdsxr) else to_number(nvl(trim(pStartdate), '19900101')) end,'yyyy-mm-dd')+1)),2) as zrjgbf  --??????
                 into cell.content from TB_TTXX a,TB_BDXX c,TB_CPXX d,/*TB_BDCPXX e,*/TB_FDXX f,TB_FDZRMX H,TB_CPZRDZB M
                 where /*c.bdid = e.bdid AND*/ F.FDID=H.FDID AND M.CPID=D.CPID AND M.ZRID=H.ZRID
                 /*and d.cpid = e.cpid*/
                 and c.khbdh = f.khbdh
                 and a.ttid = rec_ttxx.ttid
                 and c.ttid = a.ttid
                 and c.bxgsid = rec_ttxx.bxgsid /*nvl(trim(POther1),c.bxgsid)*/
                  and nvl(h.ZRJSRQ,f.fdzzr)>=nvl(POther7,19000101)
                 and nvl(h.ZRJSRQ,f.fdzzr)<=nvl(POther8,99991231)
                 and nvl(h.ZRJSRQ,f.fdzzr)>=nvl(trim(pStartdate), '19000101')
                  and nvl(h.ZRkSRQ,f.fdsxr)<=to_number(to_char(sysdate,'yyyymmdd'))
             /*    group by d.cpmc, d.cpid,f.fdsxr,c.bdzzrq*/;
           insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,10,cell.r,cell.content);
           cell.r :=  cell.r+1;

    end loop;



  --???????????
  /*9.??*/
  PReturnCode := '0'; /* ??????????????vstatid????????? */
  PReturnMsg  := vstatid;
  DBMS_OUTPUT.PUT_LINE('[LDS debug] ' || 'PReturncode= ' || PReturnCode);
  --COMMIT; ???java?????????

EXCEPTION
  WHEN OTHERS THEN
    --rollback;???java?????????????0?????????????????
    PReturnCode := 'E'; /*  ??????  */
    DBMS_OUTPUT.PUT_LINE('[yhs debug] ' || 'PReturncode= ' || PReturnCode);
    PReturnMsg := ' rownum' || cell.r || 'Error:' || sqlerrm; --???????????
    DBMS_OUTPUT.PUT_LINE(PReturnMsg);
end SP_P1_30002;

/
