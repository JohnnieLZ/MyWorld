CREATE function      FUNC_XC_TFTG_YBNPFJE_AJID(P_AJID in number) return number is
  Result number;
begin
  -------???
   /* select
            nvl((select SUM(T.PFE) FROM TB_ZPALSGZDZB T ,TB_BDZRLSGZSZ N,TB_ZPAXX S WHERE T.LSGZID=N.LSGZID AND LSGZJB='1'
            AND N.FYLB NOT IN ('S','F') AND T.ZPAID=S.ZPAID AND S.AJID=P_AJID AND S.ZPAJL<>'02'
            and t.lsgzid not in (select f.lsgzid from TB_DBLSGZEJYYJDZ f,(select t.lsgzid from TB_ZPALSGZDZB T ,TB_BDZRLSGZSZ N,TB_ZPAXX S WHERE T.LSGZID=N.LSGZID AND LSGZJB='2'
            AND N.FYLB NOT IN ('S','F') AND T.ZPAID=S.ZPAID AND S.AJID=P_AJID AND S.ZPAJL<>'02') g where f.ejlsgzid=g.lsgzid)),0)
            +
            nvl((select SUM(T.PFE) FROM TB_ZPALSGZDZB T ,TB_BDZRLSGZSZ N,TB_ZPAXX S WHERE T.LSGZID=N.LSGZID AND LSGZJB='2'
            AND N.FYLB NOT IN ('S','F') AND T.ZPAID=S.ZPAID AND S.AJID=P_AJID AND S.ZPAJL<>'02'),0)
            into Result from dual;*/

   select nvl((select SUM(T.PFE) FROM TB_ZPALSGZDZB T ,TB_BDZRLSGZSZ N,TB_ZPAXX S WHERE T.LSGZID=N.LSGZID AND LSGZJB='1'
            AND N.FYLB NOT IN ('S','F') AND T.ZPAID=S.ZPAID AND S.AJID=P_AJID AND S.ZPAJL<>'02'
            and t.lsgzid not in (select f.lsgzid from TB_DBLSGZEJYYJDZ f,TB_BDZRLSGZSZ k,TB_ZPALSGZDZB h,TB_ZPAXX z,(select t.lsgzid FROM TB_ZPALSGZDZB T ,TB_ZPAXX S WHERE T.LSGZJB='2'
            AND T.ZPAID=S.ZPAID AND S.AJID=P_AJID AND S.ZPAJL<>'02') g where f.ejlsgzid=g.lsgzid and k.lsgzid=f.lsgzid and h.lsgzid=k.lsgzid and z.zpaid=h.zpaid and h.lsgzjb='1' and k.fylb not in ('S','F') and z.ajid=P_AJID)),0)
            +
            nvl((select sum(l.pfe) from TB_ZPALSGZDZB l,
             (select h.lsgzid,h.zpaid from TB_DBLSGZEJYYJDZ f,TB_BDZRLSGZSZ k,TB_ZPALSGZDZB h,TB_ZPAXX z,tb_bdzrejlsgzsz g where f.lsgzid=k.lsgzid and f.ejlsgzid=g.ejlsgzid
            and h.zpaid=z.zpaid and h.lsgzid=g.ejlsgzid and h.lsgzjb='2' and k.fylb not in ('S','F') and z.zpajl<>'02' and z.ajid=P_AJID group by h.lsgzid,h.zpaid) v
            where l.lsgzid=v.lsgzid and l.zpaid=v.zpaid),0) into Result from dual;
  return(Result);
end FUNC_XC_TFTG_YBNPFJE_AJID;

/
