CREATE PROCEDURE      "SP_P1_30031" (report_id   In t_report_def_info.REPORTID%TYPE,
                                        pStartdate  IN varchar2, -- ????/??????yyyymmdd
                                        pEnddate    IN varchar2, -- ????/??????yyyymmdd
                                        pStatman    IN t_report_gen_info.STATMAN%TYPE, --???
                                        ptype       in varchar2, /*0 ???? ,1 ?? 2 ?? 3 ?? */ --?????
                                        POther1     IN varchar2, --??id
                                        POther2     IN varchar2, --??id
                                        POther3     IN varchar2, --??id
                                        POther4     IN varchar2, --???
                                        POther5     IN varchar2, --????
                                        POther6     IN varchar2, --??ID
                                        POther7     IN varchar2, --??????/????
                                        POther8     IN varchar2, --??????/????
                                        PReturnCode OUT varchar2,
                                        PReturnMsg  OUT varchar2) AS

  V_STEP_CODE  CHAR(5); --?????????????????
  vreportid    t_report_def_info.REPORTID%TYPE; --??ID
  vxzqhdm      t_report_gen_info.STATORGID%TYPE; --????????????
  sLetter_Desc  VARCHAR2(1024);

  sKhbdh  number; --?????

  --sLetter_Desc1 VARCHAR2(1024);

  vstatid varchar(30); --?????????????????
  v_start_date number := 0; --????????
  v_end_date   number := 0; --????????

  type cellType is record(
    statid  varchar2(15),
    col     number,
    r       number,
    content varchar2(1024));

  cell      cellType; --?????????????
  vdwmc     varchar2(50); --????????????
  vusername t_report_gen_info.STATMAN%TYPE; --????????
  vnd       t_report_gen_info.STATYEAR%TYPE; --????
  rowno     number := 1; --??????
  v_count   number:=0;--?????????

	CURSOR c_Data IS
	SELECT DISTINCT B.PCH,A.PAH,NVL(C.WBBDH,C.KHBDH)AS KHBDH,(SELECT TTMC FROM TB_TTXX WHERE TTID=A.TTID)TTMC,
	A.BBRXM,(SELECT COUNT(1) FROM TB_LPFPXX WHERE AJID=A.AJID)FPSL,A.JARQ,B.SJRQ
	 FROM TB_LPAJXX A,TB_LPPCXX B,TB_FDXX C,TB_AJQTXX T,TB_BDXX S
	WHERE A.LPPCID=B.PCID
	AND A.FDID=C.FDID
	AND A.AJID=T.AJID
	AND T.SFTJ='1'
	AND A.AJZT='11'
	AND A.JARQ >= nvl(trim(pStartdate),19000101)
	AND A.JARQ <= nvl(trim(pEnddate),99991231)
	AND A.BXGSID=nvl(trim(POther1), A.BXGSID)
	AND A.TTID=nvl(trim(POther2), A.TTID)
	AND B.SJRQ >= nvl(trim(POther7),19000101)
	AND B.SJRQ <= nvl(trim(POther8),99991231)
	AND S.KHBDH=C.KHBDH
	AND S.BDID=nvl(trim(POther3), S.BDID)
	AND B.PCH=nvl(trim(POther4), B.PCH);
BEGIN
  V_STEP_CODE := '00000';

  PReturnMsg  := 'OK';
  PReturnCode := 'E';
  vreportid   := substr(report_id, 1, 5);
  vusername   := pStatman;
   v_start_date := to_number(substr(pStartdate, 1, 8));
   v_end_date   := to_number(substr(pEnddate, 1, 8));

  --???????????????????????????

  DELETE FROM T_REPORT_DATA_INFO
   WHERE STATID IN (SELECT STATID FROM T_REPORT_GEN_INFO WHERE REPORTID = REPORT_ID);

  DELETE FROM T_REPORT_GEN_INFO
   WHERE STATID IN (SELECT STATID FROM T_REPORT_GEN_INFO WHERE REPORTID = REPORT_ID);

  --???,?T_RERORT_GEN_INFO????????????
  --?????????????????????????????????????????

  V_STEP_CODE := '00001';
  SELECT SEQ_STATID.NEXTVAL INTO VSTATID FROM DUAL;

  -- ??????????
  INSERT INTO T_REPORT_GEN_INFO(
    STATID, REPORTID,STATORGID,
    STATORGNAME,STATDATE,STATMAN,
    STATYEAR,BEGINDATE,ENDDATE,
    STAT_OTHER,STAT_TYPE)
  VALUES(
    VSTATID,VREPORTID,'',
     '',TO_CHAR(SYSDATE, 'YYYYMMDD'),VUSERNAME,
     VND,V_START_DATE,V_END_DATE,
     SUBSTR(PENDDATE, 1, 1),TRIM(PTYPE));

  --?????? ??excel???0?????1??,????0???

   V_STEP_CODE := '00002';
  --??????
  INSERT INTO T_REPORT_DATA_INFO (STATID, SHEET, COL, R, CONTENT) SELECT VSTATID,0,3,1,BXGSQC FROM TB_BXGSXX WHERE BXGSID=POther1;

  --????
  INSERT INTO T_REPORT_DATA_INFO (STATID, SHEET, COL, R, CONTENT) SELECT VSTATID,0,3,2,TTMC FROM TB_TTXX WHERE TTID=POther2;

	--??????
  INSERT INTO T_REPORT_DATA_INFO (STATID, SHEET, COL, R, CONTENT) VALUES (VSTATID,0,3,3,pStartdate);

  --??????
  INSERT INTO T_REPORT_DATA_INFO (STATID, SHEET, COL, R, CONTENT) VALUES (VSTATID,0,3,4,pEnddate);

	--??????
  INSERT INTO T_REPORT_DATA_INFO (STATID, SHEET, COL, R, CONTENT) VALUES (VSTATID,0,3,5,POther7);

  --??????
  INSERT INTO T_REPORT_DATA_INFO (STATID, SHEET, COL, R, CONTENT) VALUES (VSTATID,0,3,6,POther8);


  cell.statid := vstatid;
  cell.col    := 0; --?1???
 -- cell.r      := 10; --?11???
  cell.r      := 9; --?8???


  --???????????????????????????????excel????????????????????

  V_STEP_CODE := '00003';

  FOR REC_DATA IN c_Data LOOP

  V_STEP_CODE := '00004';

  --??
 -- cell.content := A.WBPAFH;
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,0,cell.r,rowno);

 --???
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,1,cell.r,REC_DATA.PCH);

  --???
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,2,cell.r,REC_DATA.PAH);

  --???
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,3,cell.r,REC_DATA.KHBDH);


  --????
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,4,cell.r,REC_DATA.TTMC);


  --??
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,5,cell.r,REC_DATA.BBRXM);


  --????
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,6,cell.r,REC_DATA.FPSL);

  --????
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,7,cell.r,REC_DATA.JARQ);

  --????
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,8,cell.r,REC_DATA.SJRQ);
  cell.r :=  cell.r+1;
  rowno := rowno+1;

END LOOP;


--???????????
  /*9.??*/
  PReturnCode := '0'; /* ??????????????vstatid????????? */
  PReturnMsg  := vstatid;
  DBMS_OUTPUT.PUT_LINE('[LDS debug] ' || 'PReturncode= ' || PReturnCode);
  --COMMIT; ???java?????????

EXCEPTION
  WHEN OTHERS THEN
    --rollback;???java?????????????0?????????????????
    PReturnCode := 'E'; /*  ??????  */
    DBMS_OUTPUT.PUT_LINE('[yhs debug] ' || 'PReturncode= ' || PReturnCode);
    PReturnMsg := ' rownum' || cell.r || 'Error:' || sqlerrm; --???????????
    DBMS_OUTPUT.PUT_LINE(PReturnMsg);
END SP_P1_30031;

/
