CREATE PROCEDURE      PROC_ZXTFCLOSE_EXPORT(p_Jarqq NUMBER,  --?????
                                                 p_Jarqz NUMBER,  --?????
                                                 p_Sjrqq NUMBER,  --?????
                                                 p_Sjrqz NUMBER,  --?????
                                                 sPch VARCHAR2,  --??????
                                                 p_Czrid NUMBER,  --???id
                                                 p_Czrxm VARCHAR2, -- ?????
                                                 p_RtnCode OUT NUMBER,
                                                 p_RtnMsg OUT VARCHAR2) IS
	i_Count	NUMBER(9) := 0;
	i_step  NUMBER(9) := 0;
	s_Jbdm  VARCHAR2(100);
	s_Jbmc  VARCHAR2(400);
	CELL  VARCHAR2(100);
  /***
  -----  version_1.1.1 update by duhailong ##?????????????????????????????
  -----  version_1.1.2 update by duhailong ##?????????????????????????????
  -----  version_1.1.3 update by duhailong ##?????????????????????????????????
  -----  version_1.1.4 update by duhailong ##?????????????????????????????????
  ***/
	--??????
	CURSOR c_Jbdm(p_Bbrkhid NUMBER) IS
		SELECT  DISTINCT(B.JBDM) JBDM,B.BBRKHID
    FROM TB_XCTFTG_XX_CLOSE_EXPORT B
    WHERE B.pch = sPch
    AND B.BBRKHID = p_Bbrkhid;

  --????????????
	CURSOR c_Bbrkhid IS
		SELECT  DISTINCT(B.BBRKHID) BBRKHID,B.XM
    FROM TB_XCTFTG_HZ_CLOSE_EXPORT B
    WHERE B.pch = sPch;

  --???
  cursor YBNPFJE_ALLAJIDS is
    select YWLSH from TB_XCTFTG_XX_CLOSE_EXPORT
    where pch = sPch;
  --???
  cursor YBWPFJE_ALLAJIDS is
    select YWLSH from TB_XCTFTG_XX_CLOSE_EXPORT
    where pch = sPch;
  --

BEGIN
	--0.?????
    i_step := 0;
    i_Count := 0;
    s_jbdm := '';
    p_RtnCode := 0;
    p_RtnMsg := '????';

   	---???????????
   	i_step := 2;
   	INSERT INTO XC_AL_CLOSE_CZJL(PCH, SJRQ, KSSJ, JSSJ,YXZT,CZRID,CZRXM)
   	VALUES(sPch, TO_CHAR(SYSDATE,'YYYYMMDD'), SYSDATE, NULL,'0',p_Czrid,p_Czrxm);

   	--????????????????
   	i_step := 3;
   	INSERT INTO TB_XCTFTG_XX_CLOSE_EXPORT(
   		YWLSH,PCH,XH,BXGSID,TTID,TTMC,batchno,
      AJID,PAH,FPID,FPHM,XM,BBRKHID,SFZH,SQRQ,JARQ,SJRQ,
      JBDM,JBMC,RYRQ,CYRQ,ZJE	,YBBXJE,
      YBNPFJE,YBWPFJE,ZPFJE,
      YBNPFJE_NDLJ,YBWPFJE_NDLJ,NDZPF,EXPORTDATE	)
	  SELECT
	    FUNC_GENERATE_LSH('0113'),sPch,ROWNUM,'946','1461',C.TTMC,D.PCH,
	    A.AJID,A.PAH,B.FPID,B.FPHM,A.BBRXM,A.BBRKHID,A.BBRZJH,A.SQRQ,A.JARQ,D.SJRQ,
	    B.JBDM,(SELECT JBMC FROM TB_JBKXX WHERE JBDM = B.JBDM) AS JBMC ,B.RYRQ,B.CYRQ,
      NVL(b.FPZE,0),
      (case when b.ryrq is null then 0 else (select NVL(w.TCZFE,0) from TB_LPFPXX w where w.fpid=b.fpid and w.fpid not in(select distinct v.fpid from tb_zpaxx n,tb_zpaxxdzb m,tb_fpxxfyxx v where n.zpaid=m.zpaid and m.xxid=v.xxid and n.zpajl='02')) end
      +case when b.ryrq is null then 0 else (select NVL(w.FJZFE,0) from TB_LPFPXX w where w.fpid=b.fpid and w.fpid not in(select distinct v.fpid from tb_zpaxx n,tb_zpaxxdzb m,tb_fpxxfyxx v where n.zpaid=m.zpaid and m.xxid=v.xxid and n.zpajl='02')) end
      +case when b.ryrq is null then 0 else (select NVL(w.SBZFE,0) from TB_LPFPXX w where w.fpid=b.fpid and w.fpid not in(select distinct v.fpid from tb_zpaxx n,tb_zpaxxdzb m,tb_fpxxfyxx v where n.zpaid=m.zpaid and m.xxid=v.xxid and n.zpajl='02')) end
      +case when b.ryrq is null then 0 else (select NVL(w.DSFZFJE,0) from TB_LPFPXX w where w.fpid=b.fpid and w.fpid not in(select distinct v.fpid from tb_zpaxx n,tb_zpaxxdzb m,tb_fpxxfyxx v where n.zpaid=m.zpaid and m.xxid=v.xxid and n.zpajl='02')) end
      ) AS YBBXJE,
	    '','',NVL(A.AJPFJE,0),
	    '','','',SYSDATE
	  FROM TB_LPAJXX A ,TB_LPFPXX B,TB_TTXX C,TB_LPPCXX D
	  WHERE A.AJID = B.AJID
	  AND C.TTID = A.TTID
	  AND A.LPPCID = D.PCID
	  AND A.JARQ >= NVL(p_Jarqq,A.JARQ)
	  AND A.JARQ <= NVL(p_Jarqz,A.JARQ)
	  AND D.SJRQ >= NVL(p_Sjrqq,D.SJRQ)
	  AND D.SJRQ <= NVL(p_Sjrqz,D.SJRQ)
	  AND A.BXGSID = '946'
    AND C.TTID = '1461'
    AND AJZT = '09'
    AND ((A.AJJL NOT IN ('06','07'))
    OR (A.AJJL IS NULL));

  i_step := 4;
  ---?????????????-??-??????-???-???-???????*????
  ----MODIFY BY JYY ???????????????????
  ---UPDATE TB_XCTFTG_XX_CLOSE_EXPORT A
  ---SET A.YBNPFJE =
  ---(SELECT (NVL(C.FPZE,0) - NVL(C.ZFZE,0) - NVL(A.YBBXJE,0) - NVL(C.CDEJE,0)-NVL(C.FLZFZE,0))*0.9 AS YBNPFJE
  --- FROM TB_LPFPXX C
  --- WHERE A.FPID = C.FPID)
  --- WHERE A.PCH = sPch;
/***  ----------------------------------------------------------------------------------------- -v_1.1.1 star---------------------------
  UPDATE TB_XCTFTG_XX_CLOSE_EXPORT A
  SET A.YBNPFJE =(select SUM(T.PFE) FROM TB_ZPALSGZDZB T ,TB_BDZRLSGZSZ N,TB_ZPAXX S WHERE T.LSGZID=N.LSGZID AND LSGZJB='1'
            AND N.FYLB NOT IN ('S','F') AND T.ZPAID=S.ZPAID AND S.AJID=A.AJID AND S.ZPAJL<>'02')
   WHERE A.PCH = sPch; --and a.ryrq is not null and a.fpid not in (select distinct v.fpid from tb_zpaxx n,tb_zpaxxdzb m,tb_fpxxfyxx v where n.zpaid=m.zpaid and m.xxid=v.xxid and n.zpajl='02' and n.ajid=a.ajid);
      ------------------------------------------------------------------------------------------ -v_1.1.1 end---------------------------
***/
  ---------------------------------------------------------------------------------------------- +v_1.1.1 star--------------------------//YBNPFJE_ALLAJIDS????
  for YBNPFJE_AJID in YBNPFJE_ALLAJIDS loop
    update TB_XCTFTG_XX_CLOSE_EXPORT A
    set A.YBNPFJE = FUNC_XC_TFTG_YBNPFJE_AJID(A.AJID)
    where A.YWLSH=YBNPFJE_AJID.YWLSH;
  end loop;
  ---------------------------------------------------------------------------------------------- +v_1.1.1 end--------------------------
  i_step := 5;
  ---????????????????+?????*????
  ----MODIFY BY JYY ???????????????????
  --UPDATE TB_XCTFTG_XX_CLOSE_EXPORT A
  --SET A.YBWPFJE =
  --(SELECT (NVL(C.ZFZE,0) + (SELECT  SUM(DECODE(NVL(B.SBZFLB,0),'2',SUM(NVL(B.FLZFJE,0)),0)) AS FLZFJE
  --                   FROM TB_FPXXFYXX B
  --                   WHERE C.FPID = B.FPID
  --                   GROUP BY B.SBZFLB))* 0.7 AS YBWPFJE
  -- FROM  TB_LPFPXX C
  -- WHERE A.FPID = C.FPID)
  -- WHERE A.PCH = sPch;
  /***  ----------------------------------------------------------------------------------------- -v_1.1.2 star---------------------------
   UPDATE TB_XCTFTG_XX_CLOSE_EXPORT A
  SET A.YBWPFJE =(select SUM(NVL(T.PFE,0)) FROM TB_ZPALSGZDZB T ,TB_BDZRLSGZSZ N,TB_ZPAXX S WHERE T.LSGZID=N.LSGZID AND LSGZJB='1'
            AND N.FYLB IN ('S','F') AND T.ZPAID=S.ZPAID AND S.AJID=A.AJID AND S.ZPAJL<>'02')
   WHERE A.PCH = sPch; --and a.ryrq is not null and a.fpid not in (select distinct v.fpid from tb_zpaxx n,tb_zpaxxdzb m,tb_fpxxfyxx v where n.zpaid=m.zpaid and m.xxid=v.xxid and n.zpajl='02' and n.ajid=a.ajid);
        ------------------------------------------------------------------------------------------ -v_1.1.2 end---------------------------
***/
    ---------------------------------------------------------------------------------------------- +v_1.1.2 star--------------------------//YBWPFJE_ALLAJIDS????
  for YBWPFJE_AJID in YBWPFJE_ALLAJIDS loop
    update TB_XCTFTG_XX_CLOSE_EXPORT A
    set A.YBNPFJE = FUNC_XC_TFTG_YBWPFJE_AJID(A.AJID)
    where A.YWLSH=YBWPFJE_AJID.YWLSH;
  end loop;
    ---------------------------------------------------------------------------------------------- +v_1.1.2 end--------------------------
  i_step := 6;
  ---???????
  UPDATE TB_LPAJXX A
  SET A.AJZT = '11'
  WHERE
  EXISTS
  (SELECT 1 FROM TB_XCTFTG_XX_CLOSE_EXPORT B WHERE B.PCH = sPch AND B.AJID = A.AJID);

  i_step := 7;
  ------?????????????(????)---???????
  ---UPDATE TB_XCTFTG_XX_CLOSE_EXPORT A
  ---SET A.YBNPFJE_NDLJ =
  ---(SELECT (SUM(NVL(D.FPZE,0)) - SUM(NVL(D.ZFZE,0)) - SUM(NVL(D.TCZFE,0)+NVL(D.FJZFE,0)+NVL(D.SBZFE,0)) - SUM(NVL(D.DSFZFJE,0)) - 0 )*0.9
  --- FROM TB_LPAJXX C ,TB_LPFPXX D
  --- WHERE C.AJID = D.AJID
  --- AND SUBSTR(C.JARQ,1,4) = TO_CHAR(SYSDATE,'YYYY')
  --- AND C.AJZT = '11'
  --- AND A.BBRKHID = C.BBRKHID
  --- GROUP BY C.BBRKHID)
  --- WHERE A.PCH = sPch;

   UPDATE TB_XCTFTG_XX_CLOSE_EXPORT A
    SET A.YBNPFJE_NDLJ =(select SUM(NVL(T.PFE,0)) FROM TB_ZPALSGZDZB T ,TB_BDZRLSGZSZ N,TB_ZPAXX S,TB_LPAJXX M WHERE T.LSGZID=N.LSGZID AND LSGZJB='1'
            AND N.FYLB NOT IN ('S','F') AND S.ZPAID=T.ZPAID AND M.AJID=S.AJID
            AND M.BBRKHID=A.BBRKHID
            AND SUBSTR(M.JARQ,1,4) = TO_CHAR(SYSDATE,'YYYY')
            AND M.AJZT='11'
            AND S.ZPAJL<>'02'
            )
   WHERE A.PCH = sPch;


  i_step := 8;
  ---?????????????(????)---???????
  --UPDATE TB_XCTFTG_XX_CLOSE_EXPORT D
  --SET D.YBWPFJE_NDLJ =
  --(SELECT YBWPFJE_NDLJ FROM (SELECT SUM((
  --  (SELECT SUM(NVL(C.ZFZE,0)) FROM TB_LPFPXX C WHERE C.AJID=B.AJID)
  --  +(SELECT SUM((DECODE(NVL(A.SBZFLB,0),'2',SUM(NVL(A.FLZFJE,0)),0)))AS FLZFJE
 --    FROM TB_FPXXFYXX A
 --    WHERE A.FPID IN (SELECT FPID FROM TB_LPFPXX C1 WHERE C1.AJID=B.AJID)
 --    GROUP BY A.SBZFLB) )* 0.7)YBWPFJE_NDLJ,B.BBRKHID
 --FROM TB_LPAJXX B
 --WHERE SUBSTR(B.JARQ,1,4) = TO_CHAR(SYSDATE,'YYYY')
 --AND B.AJZT = '11'
 --GROUP BY B.BBRKHID)G
 --WHERE G.BBRKHID = D.BBRKHID)
 --WHERE D.PCH = sPch;
  UPDATE TB_XCTFTG_XX_CLOSE_EXPORT A
    SET A.YBWPFJE_NDLJ =(select SUM(NVL(T.PFE,0)) FROM TB_ZPALSGZDZB T ,TB_BDZRLSGZSZ N,TB_ZPAXX S,TB_LPAJXX M WHERE T.LSGZID=N.LSGZID AND LSGZJB='1'
            AND N.FYLB IN ('S','F') AND S.ZPAID=T.ZPAID AND M.AJID=S.AJID
            AND M.BBRKHID=A.BBRKHID
            AND SUBSTR(M.JARQ,1,4) = TO_CHAR(SYSDATE,'YYYY')
            AND M.AJZT='11'
            AND S.ZPAJL<>'02'
            )
   WHERE A.PCH = sPch;

  i_step := 9;
  ---???????(????)---???????
  UPDATE TB_XCTFTG_XX_CLOSE_EXPORT A
  SET NDZPF =
  /*(SELECT SUM(NVL(B.AJPFJE,0))
   FROM TB_LPAJXX B
   WHERE B.AJZT = '11'
   AND B.BBRKHID = A.BBRKHID)
   WHERE A.PCH = sPch;*/
   (SELECT SUM(NVL(B.AJPFJE,0)) FROM TB_LPAJXX B WHERE B.BBRKHID=A.BBRKHID
   AND SUBSTR(B.JARQ,1,4) = TO_CHAR(SYSDATE,'YYYY') AND B.AJZT='11'

   )
   WHERE A.PCH=sPch;

  i_step := 10;
  -----????????????????
  INSERT INTO TB_XCTFTG_HZ_CLOSE_EXPORT(
       YWLSH,PCH,XH,BXGSID,TTID,TTMC,
      XM,BBRKHID,SFZH,SQRQ,JARQ,SJRQ,
      JBDM,JBMC,RYRQ,CYRQ,ZJE  ,YBBXJE,
      YBNPFJE,YBWPFJE,ZPFJE,
      YBNPFJE_NDLJ,YBWPFJE_NDLJ,NDZPF,EXPORTDATE,AJID)
   SELECT
      FUNC_GENERATE_LSH('0133'),A.PCH,ROWNUM,A.BXGSID,A.TTID,A.TTMC,
      A.XM,A.BBRKHID,A.SFZH,A.SQRQ,A.JARQ,A.SJRQ,
      '','',B.RYRQ,B.CYRQ,B.ZJE,B.YBBXJE,
      C.YBNPFJE,C.YBWPFJE,C.ZPFJE,
      A.YBNPFJE_NDLJ,A.YBWPFJE_NDLJ,A.NDZPF,SYSDATE,A.AJID
   FROM (SELECT DISTINCT(BBRKHID),AJID,PCH,BXGSID,TTID,TTMC,
          XM,SFZH,SQRQ,JARQ,SJRQ,YBNPFJE_NDLJ,YBWPFJE_NDLJ,NDZPF
         FROM TB_XCTFTG_XX_CLOSE_EXPORT
         WHERE PCH =sPch)A,
        (SELECT PCH,BBRKHID,AJID,MIN(RYRQ)RYRQ,MAX(CYRQ) CYRQ ,SUM(ZJE) ZJE ,SUM(YBBXJE) YBBXJE
         FROM TB_XCTFTG_XX_CLOSE_EXPORT
         WHERE PCH = sPch
         GROUP BY PCH,BBRKHID,AJID)B,
         (select sum(e.YBNPFJE) AS YBNPFJE,SUM(e.YBWPFJE) AS YBWPFJE,SUM(e.ZPFJE) AS ZPFJE,e.pch,e.bbrkhid,e.ajid from (SELECT MAX(YBNPFJE) AS YBNPFJE,MAX(YBWPFJE) AS YBWPFJE,MAX(ZPFJE) AS ZPFJE,AJID,bbrkhid,pch FROM TB_XCTFTG_XX_CLOSE_EXPORT WHERE PCH=sPch GROUP BY AJID,bbrkhid,pch) e
          where e.pch=sPch
          group by e.pch,e.bbrkhid,e.ajid) C

   WHERE A.PCH=B.PCH and A.pch=C.pch and A.bbrkhid = C.bbrkhid and a.ajid=b.ajid and a.ajid=c.ajid
   AND A.BBRKHID=B.BBRKHID;

  i_step := 11;
  ---??????
  FOR xx in c_Bbrkhid LOOP
    s_Jbdm := '';
    s_Jbmc := '';
    FOR cc in c_Jbdm(xx.BBRKHID) LOOP
      s_Jbdm := cc.jbdm || ','|| s_Jbdm ;
      BEGIN
        SELECT JBMC INTO CELL FROM TB_JBKXX WHERE JBDM = cc.JBDM;
      EXCEPTION
      WHEN OTHERS THEN
        CELL := '';
      END ;
      s_Jbmc := CELL || ','|| s_Jbmc;
    END LOOP;
    UPDATE TB_XCTFTG_HZ_CLOSE_EXPORT A
    SET A.JBDM = SUBSTR(s_Jbdm,1,length(s_Jbdm)-1),
        A.JBMC = SUBSTR(s_Jbmc,1,length(s_Jbmc)-1)
    WHERE A.PCH = sPch
    AND A.BBRKHID = xx.BBRKHID;
  END LOOP;

  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
      p_RtnCode := SQLCODE;
      p_RtnMsg := SQLERRM;
      ROLLBACK;
      Pkg_Error_Log.Pro_Error_In('PROC_ZXTFCLOSE_EXPORT', i_step, p_RtnCode, p_RtnMsg);
END PROC_ZXTFCLOSE_EXPORT;

/
