CREATE PROCEDURE      "SP_CHECK_YY" (PIN_AJID IN VARCHAR2,PRETURNCODE OUT VARCHAR2, PRETURNMSG OUT VARCHAR2) AS
 nBdid 	 NUMBER(16) := 0;
 i_Count NUMBER(9) := 0;
 i_step  NUMBER(9) := 0;

 CURSOR c_Zpaxx(sAjid VARCHAR2) IS
 	SELECT T.ZPAID, T.FPID
 	FROM TB_ZPAXX T
 	WHERE T.AJID = sAjid
 	AND T.FPID IS NOT NULL;

 BEGIN
    PRETURNCODE:='E';
    PRETURNMSG:='ERROR!';

    ----???????????
    i_step := 1;
    IF TRIM(PIN_AJID) IS NULL THEN
		PRETURNCODE := 'E';
        PRETURNMSG := '??ID????';
        RETURN;
    END IF;

    ----????ID
    i_step := 2;
    BEGIN
     SELECT nvl(C.BDID,(select bdid from tb_fdxx where fdid=b.fdid))
        INTO nBdid
        FROM TB_LPPCXX C,TB_LPAJXX B
        WHERE  C.PCID=B.LPPCID
      AND B.AJID = PIN_AJID;
  EXCEPTION
    WHEN OTHERS THEN
          PRETURNCODE := 'E';
          PRETURNMSG := '??????ID';
          RETURN;
  END;

    FOR cc IN c_Zpaxx(PIN_AJID) LOOP
      i_step := 3;
      SELECT nvl(COUNT(1),0)
      INTO  i_Count
      FROM TB_BDTYSHGZYYPZ  a
      WHERE BDID = nBdid
      AND  exists(SELECT 'x'
            FROM TB_LPFPXX
            WHERE FPID=cc.FPID and yyid=a.yyid);

      IF i_Count = 0 THEN
        i_step := 4;
        UPDATE TB_ZPAXX
        SET XGDM =case when xgdm is not null then  XGDM || ',CL44' else 'CL44' end ,
          XGDMMS =case when XGDMMS is not null then XGDMMS || ',?????????'else '?????????' end
        WHERE ZPAID = cc.ZPAID;
    END IF;

  END LOOP;
    PRETURNCODE:='0';--????
    PRETURNMSG:='CHECK SUCCESS!';
    RETURN;
  EXCEPTION
  WHEN OTHERS THEN
    PRETURNCODE := 'E';
    DBMS_OUTPUT.PUT_LINE('[YHS DEBUG] ' || 'PRETURNCODE= ' ||
                         PRETURNCODE);
    PRETURNMSG := 'ERROR:' || SQLERRM;
    DBMS_OUTPUT.PUT_LINE(PRETURNMSG);
END SP_CHECK_YY;

/
