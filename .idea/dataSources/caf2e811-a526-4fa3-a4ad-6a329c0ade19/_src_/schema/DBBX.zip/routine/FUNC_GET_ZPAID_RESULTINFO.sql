CREATE function      FUNC_get_zpaid_resultInfo(flag in varchar2, P_ZPAID in number) return varchar2 is
   rett_var varchar2(1000) := '';
   P_zddm varchar2(15) := '';
begin
       select nvl(substr(zddm,0,instr((zddm),'.')-1),zddm) into P_zddm from tb_zpaxx where zpaid=P_ZPAID;
          if flag='1' then --?????1
            select CXJGMC into rett_var from TB_XH_CXJD1 where cxjgdm = P_zddm;
          else  --?????2
            select ILLZDNAME into rett_var from TMP_JBKXX_XH where jbdm=P_zddm;
          end if;
  return(rett_var);
end FUNC_get_zpaid_resultInfo;

/
