CREATE procedure SP_P1_RESETPARM Authid Current_User AS
  /*
 *@version 1.1  大病保险项目新建
 */
  V_DDLSQL varchar2(2048):='';
  PReturnCode varchar2(10):='E';
  PReturnMsg varchar2(255):='OK';

  begin

   V_DDLSQL:='Drop sequence SEQ_DAY_ZPALSH';
   execute immediate V_DDLSQL;
   
   V_DDLSQL:='create sequence SEQ_DAY_ZPALSH minvalue 1 maxvalue 99999 start with 1 increment by 1 cache 20';
   execute immediate V_DDLSQL;
   EXCEPTION
  WHEN OTHERS THEN
    PReturnCode := 'E';
    DBMS_OUTPUT.PUT_LINE('[yhs debug] ' || 'PReturncode= ' ||
                         PReturnCode);
    PReturnMsg := 'Error:' || sqlerrm;
    DBMS_OUTPUT.PUT_LINE(PReturnMsg);
  end   SP_P1_RESETPARM;

/
