CREATE procedure "SP_P1_AUTO_GENERATE_SZ"(PReturnCode OUT varchar2,
                                                     PReturnMsg  OUT varchar2) AS
  v_bxgsid  number := 572;
  v_pch     varchar2(30) := '';
  v_lppcid  number := 0;
  v_xh      varchar2(3) := '';
  v_no      number := 0;
  v_bxgsbh  varchar2(20) := '';
  v_ajid    number := 0;
  v_fpid    number := 0;
  v_bbrkhid number := 0;
  v_zfje    number := 0;
  rec_khxx  tb_khxx%rowtype;
  v_num     number := 0;
begin
  PReturnCode := 'E';
  PReturnMsg  := 'Error!';
  --业务处理块
  for recfund in (select BFD_MEMB_ID,
                         sum(BFD_SELF_MONEY + BFD_ZFU_MONEY) as zfje,
                         case
                           when BFD_SN is not null then
                            Extract(year from BFD_DEFRAY_DATE)
                           else
                            Extract(year from
                                    nvl(BFD_OUT_DATE, BFD_CLINIC_DATE))
                         end as ndgs
                    from tb_fund_defray t
                   where ajid is null
                     and fpid is null
                   group by BFD_MEMB_ID,
                            case
                              when BFD_SN is not null then
                               Extract(year from BFD_DEFRAY_DATE)
                              else
                               Extract(year from
                                       nvl(BFD_OUT_DATE, BFD_CLINIC_DATE))
                            end) loop
    --根据社保编号和参保类型判断该客户下是否已生成过赔案
    select count(1)
      into v_no
      from tb_khxx
     where bxgsid = v_bxgsid
       and ybkh = recfund.BFD_MEMB_ID;
    if v_no < 1 then
      insert into tb_error_log
        (BUSI_TYPE, ERROR_REASON, ERROR_TIME)
      values
        ('苏州自动生成案件',
         '医保卡号为：' || recfund.BFD_MEMB_ID ||'的客户不存在!',
         sysdate);
      continue;
     elsif v_no > 1 then
         insert into tb_error_log
        (BUSI_TYPE, ERROR_REASON, ERROR_TIME)
      values
        ('苏州自动生成案件',
         '医保卡号为：' || recfund.BFD_MEMB_ID ||'的客户存在重复！',
         sysdate);
      continue;
    end if;
    select khid
      into v_bbrkhid
      from tb_khxx
     where bxgsid = v_bxgsid
       and ybkh = recfund.BFD_MEMB_ID;
    select *
      into rec_khxx
      from tb_khxx
     where bxgsid = v_bxgsid
       and khid = v_bbrkhid;
    select count(1)
      into v_no
      from tb_lpajxx a, tb_lpfpxx b
     where a.ajid = b.ajid
       and bxgsid = v_bxgsid
       and a.bbrkhid = v_bbrkhid
       and b.fprq like recfund.ndgs || '%';
    select CAE187 into v_zfje from aa53 where CAE181 = 'SZDBZFJE';
    select count(1)
      into v_num
      from tb_lpajxx
     where bxgsid = v_bxgsid
       and lppcid = (select pcid from tb_lppcxx where pch = v_pch);
    if v_no > 0 or (v_no = 0 and recfund.zfje >= v_zfje) then
      if v_pch = '' or v_pch is null or v_num >= 999 then
        --生成批次
        select bxgsbh into v_bxgsbh from tb_bxgsxx where bxgsid = v_bxgsid;
        select trim(to_char(to_number(nvl(max(substr(pch, -3, 3)), '0')) + 1,
                            '099'))
          into v_xh
          from tb_lppcxx
         where bxgsid = v_bxgsid
           and pch like '%' || to_char(sysdate, 'yyyymmdd') || '%';
        v_pch := v_bxgsbh || to_char(sysdate, 'yyyymmdd') || v_xh;
        select seq_pcid.nextval into v_lppcid from dual;
        insert into tb_lppcxx
          (PCID,
           PCH,
           BXGSID,
           BXGSQC,
           TTID,
           TTMC,
           SJRQ,
           AJS,
           KHTJBH,
           KHJJR,
           SFZS,
           JHSFRQ,
           PCJBR,
           KHFSRQ,
           BDID,
           KHBDH,
           PCFKZS,
           SFYQBZ,
           BXGSLXR,
           PCZT,
           SJSFRQ,
           YQYY,
           YQBZ,
           SFRID,
           SFR,
           CJSJ,
           ZJXGR,
           ZJXGSJ,
           DYBZ,
           DYR,
           DYRQ,
           BDYRQ,
           BDYR,
           FPZS,
           SFJJPC,
           SJLY,
           LZYXMLMC,
           SEQLOGID,
           SLRQ,
           LRRQ)
        values
          (v_lppcid,
           v_pch,
           v_bxgsid,
           (select bxgsqc from tb_bxgsxx where bxgsid = v_bxgsid),
           (select ttid
              from tb_bdxx
             where bxgsid = v_bxgsid
               and rownum = 1),
           (select ttmc
              from tb_ttxx
             where ttid = (select ttid
                             from tb_bdxx
                            where bxgsid = v_bxgsid
                              and rownum = 1)),
           to_char(sysdate, 'yyyymmdd'),
           null,
           v_pch,
           'system',
           '0',
           null,
           'system',
           null,
           null,
           null,
           '2',
           '0',
           null,
           '02',
           null,
           null,
           null,
           null,
           null,
           sysdate,
           'system',
           sysdate,
           null,
           null,
           null,
           null,
           null,
           null,
           '0',
           '1',
           null,
           '-1',
           to_char(sysdate, 'yyyymmdd'),
           null);
      end if;
      --生成案件信息
      select seq_ajid.nextval into v_ajid from dual;
      insert into tb_lpajxx
        (AJID,
         LPPCID,
         PAH,
         BXGSID,
         TTID,
         BBRXM,
         BBRKHID,
         BBRZJH,
         ZLDBZ,
         ZBBRKHID,
         KHBDH,
         FDID,
         SQRZJLX,
         SQRZJHM,
         SQRXM,
         SQRSJ,
         SQRDZ,
         SQRYX,
         SQLX,
         SQRQ,
         AJZT,
         JBR,
         AJPFFS,
         SFXNAJ,
         SFZDSCZPA,
         SLRID,
         SLR,
         LPKGFKHH,
         LPKGFYHZH,
         SKFXM,
         FPS,
         SFBLC,
         YWSGDD,
         WBDRRQ,
         SEQLOGID)
      values
        (v_ajid,
         v_lppcid,
         (select v_pch ||
                 trim(to_char(to_number(nvl(max(substr(pah, -3, 3)), '0')) + 1,
                              '099'))
            from tb_lpajxx
           where bxgsid = v_bxgsid
             and pah like v_pch || '%'),
         v_bxgsid,
         (select ttid
            from tb_bdxx
           where bxgsid = v_bxgsid
             and rownum = 1),
         rec_khxx.xm,
         v_bbrkhid,
         rec_khxx.aac147,
         null,
         null,
         null,
         null,
         rec_khxx.aac058,
         rec_khxx.aac147,
         rec_khxx.xm,
         null,
         null,
         null,
         '5',
         to_char(sysdate, 'yyyymmdd'),
         '04',
         'system',
         '2',
         '0',
         '0',
         -1,
         'system',
         rec_khxx.khyh,
         rec_khxx.yhzh,
         rec_khxx.xm,
         null,
         '0',
         '苏州大病',
         (select min(to_char(BFD_DEFRAY_DATE, 'yyyymmdd'))
            from tb_fund_defray t
           where ajid is null
             and fpid is null
             and BFD_MEMB_ID = recfund.BFD_MEMB_ID
             and (case when BFD_SN is not null then
                  Extract(year from BFD_DEFRAY_DATE) else
                  Extract(year from nvl(BFD_OUT_DATE, BFD_CLINIC_DATE)) end) =
                 recfund.ndgs),
         -1);
      --生成发票信息
      for rec_fpxx in (select BFD_LID,
                              BFD_SN,
                              BFD_ARCH_NO,
                              BFD_MEMB_ID,
                              BFD_HOSP_IN_NO,
                              nvl(BFD_SN, BFD_ARCH_NO) YBJYLSH,
                              BFD_HOSP_NAME JZYY,
                              BFD_HOSP_ID YYDM,
                              BFD_OFFICE JZKS,
                              BFD_ILL_ID JBDM,
                              case
                                when t.bfd_sn is not null then
                                 to_char(BFD_DEFRAY_DATE, 'yyyymmdd')
                                else
                                 to_char(nvl(BFD_CLINIC_DATE, BFD_OUT_DATE),
                                         'yyyymmdd')
                              end as FPRQ,
                              to_char(BFD_CLINIC_DATE, 'yyyymmdd') JZRQ,
                              to_char(BFD_IN_DATE, 'yyyymmdd') RYRQ,
                              to_char(BFD_OUT_DATE, 'yyyymmdd') CYRQ,
                              BFD_INVOICEMONEY FPZE,
                              BFD_SELF_MONEY ZFZE,
                              BFD_HOSP_IN_NO ZYH,
                              BFD_ILL_DESC ZDSM,
                              BFD_ZFU_MONEY ZFYJE,
                              BFD_MONEY TCZFE
                         from tb_fund_defray t
                        where ajid is null
                          and fpid is null
                          and BFD_MEMB_ID = recfund.BFD_MEMB_ID
                          and (case when BFD_SN is not null then
                               Extract(year from BFD_DEFRAY_DATE) else
                               Extract(year from
                                       nvl(BFD_OUT_DATE, BFD_CLINIC_DATE)) end) =
                              recfund.ndgs) loop
        select seq_fpid.nextval into v_fpid from dual;
        insert into tb_lpfpxx
          (FPID,
           AJID,
           YBJYLSH,
           FPHM,
           BBRKHID,
           BBRXM,
           ZDLX,
           JZYY,
           YYID,
           JZKS,
           JBDM,
           FPRQ,
           JZRQ,
           RYRQ,
           CYRQ,
           FPZE,
           ZFZE,
           FLZFZE,
           TCZFE,
           SFSYYBK,
           SFYWYL,
           SFYSS,
           SFICU,
           JZLSH,
           ZYH,
           ZDSM,
           JZLX,
           YBJSLX,
           SJLX,
           ZFYJE,
           FPXM,
           ZYTS,
           SEQLOGID)
        values
          (v_fpid,
           v_ajid,
           rec_fpxx.YBJYLSH,
           null,
           v_bbrkhid,
           rec_khxx.xm,
           case when rec_fpxx.RYRQ is not null then '1' else '0' end,
           rec_fpxx.JZYY,
           (select max(yyid)
              from tb_yyxx
             where xzqhdm = '320500'
               and yydm = rec_fpxx.YYDM),
           rec_fpxx.JZKS,
           rec_fpxx.JBDM,
           rec_fpxx.FPRQ,
           rec_fpxx.JZRQ,
           rec_fpxx.RYRQ,
           rec_fpxx.CYRQ,
           rec_fpxx.FPZE,
           rec_fpxx.ZFZE,
           null,
           rec_fpxx.TCZFE,
           '0',
           '0',
           '0',
           '0',
           null,
           rec_fpxx.ZYH,
           rec_fpxx.ZDSM,
           null,
           null,
           null,
           rec_fpxx.ZFYJE,
           rec_khxx.xm,
           (to_date(rec_fpxx.CYRQ, 'yyyymmdd') -
           to_date(rec_fpxx.RYRQ, 'yyyymmdd')) + 1,
           -1);

        --有交易号时生成发票细项
        if rec_fpxx.bfd_sn is not null then
          for rec_fpxxfyxx in (select BRD_ITEM_ID XXDM,
                                      BRD_HOSP_ITEM_NAME XXMC,
                                      BRD_ITEM_TYPE XMLB,
                                      BRD_HOSP_UNIT MXXMDW,
                                      BRD_HOSP_PRICE MXXMDJ,
                                      BRD_HOSP_AMOUNT MXXMSL,
                                      NVL(CASE BRD_ITEM_TYPE
                                            WHEN '1' THEN
                                             (SELECT NVL(TO_CHAR(HM_SELF_RATE,
                                                                 'FM0.00'),
                                                         0)
                                                FROM TB_MEDICAL
                                               WHERE HM_MED_ID = T.BRD_ITEM_ID
                                                 AND hm_status = '0')
                                            WHEN '2' THEN
                                             (SELECT NVL(TO_CHAR(HC_ITEM_RATE,
                                                                 'FM0.00'),
                                                         0)
                                                FROM TB_CHARGE
                                               WHERE HC_ITEM_ID =
                                                     T.BRD_ITEM_ID
                                                 and hc_status = '0')
                                          END,
                                          to_char(0, 'FM0.00')) SJZFBL
                                 from tb_recipe_detail t
                                where t.BRD_SN = rec_fpxx.BFD_SN
                                  and t.brd_memb_id = rec_fpxx.BFD_MEMB_ID
                               union all
                               select BHC_ITEM_ID XXDM,
                                      BHC_HOSP_ITEM_NAME XXMC,
                                      BHC_ITEM_TYPE XMLB,
                                      BHC_HOSP_UNIT MXXMDW,
                                      BHC_HOSP_PRICE MXXMDJ,
                                      BHC_HOSP_AMOUNT MXXMSL,
                                      NVL(CASE a.bhc_item_type
                                            WHEN '1' THEN
                                             (SELECT NVL(TO_CHAR(HM_SELF_RATE,
                                                                 'FM0.00'),
                                                         0)
                                                FROM TB_MEDICAL
                                               WHERE HM_MED_ID = a.bhc_item_id
                                                 AND hm_status = '0')
                                            WHEN '2' THEN
                                             (SELECT NVL(TO_CHAR(HC_ITEM_RATE,
                                                                 'FM0.00'),
                                                         0)
                                                FROM TB_CHARGE
                                               WHERE HC_ITEM_ID =
                                                     a.bhc_item_id
                                                 and hc_status = '0')
                                          END,
                                          to_char(0, 'FM0.00')) SJZFBL
                                 from tb_hosp_charge a
                                where a.BHC_MEMB_ID = rec_fpxx.BFD_MEMB_ID
                                  and A.BHC_HOSP_IN_NO =
                                      rec_fpxx.BFD_HOSP_IN_NO) loop
            insert into tb_fpxxfyxx
              (XXID,
               FPID,
               DXDM,
               DXMC,
               XXDM,
               XXMC,
               ZDJE,
               MXXMDW,
               MXXMDJ,
               MXXMSL,
               SJZFBL)
            values
              (seq_xxid.nextval,
               v_fpid,
               '08',
               '西药费',
               nvl(rec_fpxxfyxx.xxdm, '未知'),
               nvl(rec_fpxxfyxx.xxmc, '未知'),
               nvl(rec_fpxxfyxx.mxxmdj, 0) * nvl(rec_fpxxfyxx.mxxmsl, 0),
               rec_fpxxfyxx.mxxmdw,
               rec_fpxxfyxx.mxxmdj,
               rec_fpxxfyxx.mxxmsl,
               rec_fpxxfyxx.sjzfbl*100);--设置自付比例为百分比类型
          end loop;
        end if;

        --将ajid，fpid回写到支出明细表
        update tb_fund_defray
           set ajid = v_ajid, fpid = v_fpid
         where BFD_LID = rec_fpxx.BFD_LID;
        commit;
      end loop;
    end if;
  end loop;

  PReturnCode := '0';
  PReturnMsg  := '自动生成案件成功！';
  return;
EXCEPTION
  WHEN OTHERS THEN
    PReturnCode := 'E';
    DBMS_OUTPUT.PUT_LINE('[yhs debug] ' || 'PReturncode= ' || PReturnCode);
    PReturnMsg := 'Error:' || sqlerrm;
    DBMS_OUTPUT.PUT_LINE(PReturnMsg);
    ROLLBACK;
    insert into tb_error_log
      (BUSI_TYPE, ERROR_REASON, ERROR_TIME)
    values
      ('苏州自动生成案件', PReturnMsg, sysdate);
end SP_P1_AUTO_GENERATE_SZ;

/
