CREATE PROCEDURE "SP_P1_30035"(REPORT_ID   IN T_REPORT_DEF_INFO.REPORTID%TYPE,
                                          PSTARTDATE  IN VARCHAR2, -- 结案时间/查询开始时间YYYYMMDD
                                          PENDDATE    IN VARCHAR2, -- 结案时间/查询结束时间YYYYMMDD
                                          PSTATMAN    IN T_REPORT_GEN_INFO.STATMAN%TYPE, --统计员
                                          PTYPE       IN VARCHAR2, /*0 任意时段 ,1 月报 2 季报 3 年报 */ --报表样式，
                                          POTHER1     IN VARCHAR2, --保险ID
                                          POTHER2     IN VARCHAR2, --团体ID
                                          POTHER3     IN VARCHAR2, --保单ID
                                          POTHER4     IN VARCHAR2, --批次号
                                          POTHER5     IN VARCHAR2, --责任分类
                                          POTHER6     IN VARCHAR2, --责任ID
                                          POTHER7     IN VARCHAR2, --其他开始时间/收件时间
                                          POTHER8     IN VARCHAR2, --其他结束时间/收件时间
                                          POTHER9     IN VARCHAR2, --客户保单号
                                          PRETURNCODE OUT VARCHAR2,
                                          PRETURNMSG  OUT VARCHAR2) AS

  V_STEP_CODE  CHAR(5); --执行步骤，可用来制定执行到哪部报错
  VREPORTID    T_REPORT_DEF_INFO.REPORTID%TYPE; --报表ID
  VXZQHDM      T_REPORT_GEN_INFO.STATORGID%TYPE; --报表统计机构代码，暂不用
  UAP_USER_ROW UAP_USER%ROWTYPE;

  VSTATID VARCHAR(30); --报表生成流水号，一次调用生成一个号

  TYPE CELLTYPE IS RECORD(
    STATID  VARCHAR2(15),
    COL     NUMBER,
    R       NUMBER,
    CONTENT VARCHAR2(1024));

  CELL      CELLTYPE; --定义ＥＸＣＥＬ中单元格数据
  VDWMC     VARCHAR2(50); --报表单位名称，系统暂不用
  VUSERNAME T_REPORT_GEN_INFO.STATMAN%TYPE; --记载报表用户名字
  VND       T_REPORT_GEN_INFO.STATYEAR%TYPE; --报表年度
  ROWNO     NUMBER := 1; --临时技术变量
  V_COUNT   NUMBER := 0; --判断存在的计数变量

  MONTH_START_DATE      NUMBER;
  MONTH_END_DATE        NUMBER;
  YEAR_START_DATE       NUMBER;
  YEAR_END_DATE         NUMBER;
  LAST_MONTH_START_DATE NUMBER;
  LAST_MONTH_END_DATE   NUMBER;
  LAST_YEAR_START_DATE  NUMBER;
  LAST_YEAR_END_DATE    NUMBER;
  MONTH_RATIO           VARCHAR2(100);
  YEAR_RATIO            VARCHAR2(100);
  TEMP_DATA             VARCHAR2(100);

  TYPE A_TYPE IS TABLE OF VARCHAR2(100);
  ARR            A_TYPE := A_TYPE(); -- 定义并初始化一个数组变量
  ARR_LAJS       A_TYPE := A_TYPE(); --立案件数数组(1当月,2当年,3去年当月,4去年)
  ARR_JAJS       A_TYPE := A_TYPE(); --结案件数数组(1当月,2当年,3去年当月,4去年)
  ARR_BAJE       A_TYPE := A_TYPE(); --报案金额数组(1当月,2当年,3去年当月,4去年)
  ARR_PFJE       A_TYPE := A_TYPE(); --赔付金额数组(1当月,2当年,3去年当月,4去年)
  ARR_PJJATS     A_TYPE := A_TYPE(); --平均结案天数数组(1当月,2当年,3去年当月,4去年)
  ARR_DGAJZDPFJE A_TYPE := A_TYPE(); --单个案件最大赔付金额数组(1当月,2当年,3去年当月,4去年)
  ARR_CBDQ       A_TYPE := A_TYPE(); --承保地区数组

BEGIN
  ARR_LAJS.EXTEND(4); -- 数组扩展到4个元素
  ARR_JAJS.EXTEND(4); -- 数组扩展到4个元素
  ARR_BAJE.EXTEND(4); -- 数组扩展到4个元素
  ARR_PFJE.EXTEND(4); -- 数组扩展到4个元素
  ARR_PJJATS.EXTEND(4); -- 数组扩展到4个元素
  ARR_DGAJZDPFJE.EXTEND(4); -- 数组扩展到4个元素
  ARR_CBDQ.EXTEND(17);
  ARR_CBDQ(1) := 'D12,D13,D14'; --浦东新区
  ARR_CBDQ(2) := 'D01'; --宝山区
  ARR_CBDQ(3) := 'D06'; --黄浦区
  ARR_CBDQ(4) := 'D05'; --虹口区
  ARR_CBDQ(5) := 'D17,D18'; --松江区
  ARR_CBDQ(6) := 'D15'; --普陀区
  ARR_CBDQ(7) := 'D07'; --嘉定区
  ARR_CBDQ(8) := 'D11'; --闵行区
  ARR_CBDQ(9) := 'D16'; --青浦区
  ARR_CBDQ(10) := 'D21'; --杨浦区
  ARR_CBDQ(11) := 'D08,D09'; --金山区
  ARR_CBDQ(12) := 'D04'; --奉贤区
  ARR_CBDQ(13) := 'D02'; --长宁区
  ARR_CBDQ(14) := 'D00'; --闸北区TODO
  ARR_CBDQ(15) := 'D10'; --静安区
  ARR_CBDQ(16) := 'D19,D20'; --徐汇区
  ARR_CBDQ(17) := 'D03'; --崇明县

  V_STEP_CODE := '00000';

  PRETURNMSG  := 'OK';
  PRETURNCODE := 'E';
  VREPORTID   := SUBSTR(REPORT_ID, 1, 5);
  VUSERNAME   := PSTATMAN;

  --本期原来已生成过的数据先删除，只保留最近一次生成的数据

  DELETE FROM T_REPORT_DATA_INFO
   WHERE STATID IN
         (SELECT STATID FROM T_REPORT_GEN_INFO WHERE REPORTID = REPORT_ID);

  DELETE FROM T_REPORT_GEN_INFO
   WHERE STATID IN
         (SELECT STATID FROM T_REPORT_GEN_INFO WHERE REPORTID = REPORT_ID);

  --第一步,向T_RERORT_GEN_INFO表中插入此次统计属性信息
  --当存在正常赔付的案子，状态非回传成功时，不能处理批次退件，（撤案，不予立案的除外）

  V_STEP_CODE := '00001';
  SELECT SEQ_STATID.NEXTVAL INTO VSTATID FROM DUAL;

  -- 生成报表调度产生信息
  INSERT INTO T_REPORT_GEN_INFO
    (STATID,
     REPORTID,
     STATORGID,
     STATORGNAME,
     STATDATE,
     STATMAN,
     STATYEAR,
     BEGINDATE,
     ENDDATE,
     STAT_OTHER,
     STAT_TYPE)
  VALUES
    (VSTATID,
     VREPORTID,
     '',
     '',
     TO_CHAR(SYSDATE, 'YYYYMMDD'),
     VUSERNAME,
     VND,
     MONTH_START_DATE,
     MONTH_END_DATE,
     SUBSTR(PENDDATE, 1, 1),
     TRIM(PTYPE));

  --生成表头数据 记住EXCEL是从第0开始表示第1行的,列也是从0开始的

  V_STEP_CODE := '00002';
  SELECT * INTO UAP_USER_ROW FROM UAP_USER WHERE USERID = PSTATMAN;
  --填报单位
  INSERT INTO T_REPORT_DATA_INFO
    (STATID, SHEET, COL, R, CONTENT)
  VALUES
    (VSTATID, 0, 2, 1, UAP_USER_ROW.EXT4);

  --填报日期
  INSERT INTO T_REPORT_DATA_INFO
    (STATID, SHEET, COL, R, CONTENT)
  VALUES
    (VSTATID, 0, 13, 1, TO_CHAR(SYSDATE, 'YYYYMMDD'));

  CELL.STATID := VSTATID;
  CELL.COL    := 0; --第1列开始
  -- CELL.R      := 10; --第11行开始
  CELL.R := 9; --第8行开始

  SELECT TO_CHAR(TRUNC(TO_DATE(PSTARTDATE, 'YYYYMMDD'), 'MM'), 'YYYYMMDD')
    INTO MONTH_START_DATE
    FROM DUAL;
  SELECT TO_CHAR(LAST_DAY(TO_DATE(PSTARTDATE, 'YYYYMMDD')), 'YYYYMMDD')
    INTO MONTH_END_DATE
    FROM DUAL;
  SELECT TO_CHAR(TRUNC(TO_DATE(PSTARTDATE, 'YYYYMMDD'), 'YYYY'), 'YYYYMMDD')
    INTO YEAR_START_DATE
    FROM DUAL;
  SELECT TO_CHAR(ADD_MONTHS(TRUNC(TO_DATE(PSTARTDATE, 'YYYYMMDD'), 'YYYY'),
                            12) - 1,
                 'YYYYMMDD')
    INTO YEAR_END_DATE
    FROM DUAL;

  SELECT TO_CHAR(TRUNC(ADD_MONTHS(TO_DATE(PSTARTDATE, 'YYYYMMDD'), -12),
                       'MM'),
                 'YYYYMMDD')
    INTO LAST_MONTH_START_DATE
    FROM DUAL;
  SELECT TO_CHAR(LAST_DAY(ADD_MONTHS(TO_DATE(PSTARTDATE, 'YYYYMMDD'), -12)),
                 'YYYYMMDD')
    INTO LAST_MONTH_END_DATE
    FROM DUAL;
  SELECT TO_CHAR(TRUNC(ADD_MONTHS(TO_DATE(PSTARTDATE, 'YYYYMMDD'), -12),
                       'YYYY'),
                 'YYYYMMDD')
    INTO LAST_YEAR_START_DATE
    FROM DUAL;
  SELECT TO_CHAR(ADD_MONTHS(TRUNC(ADD_MONTHS(TO_DATE(PSTARTDATE, 'YYYYMMDD'),
                                             -12),
                                  'YYYY'),
                            12) - 1,
                 'YYYYMMDD')
    INTO LAST_YEAR_END_DATE
    FROM DUAL;

  ARR.EXTEND(8); -- 数组扩展到8个元素
  ARR(1) := MONTH_START_DATE;
  ARR(2) := MONTH_END_DATE;
  --ARR(3) := 0; --当月立案件数
  ARR(3) := YEAR_START_DATE;
  ARR(4) := MONTH_END_DATE;
  --ARR(6) := 0; --当年立案件数
  ARR(5) := LAST_MONTH_START_DATE;
  ARR(6) := LAST_MONTH_END_DATE;
  --ARR(9) := 0; --上一年同月立案件数
  ARR(7) := LAST_YEAR_START_DATE;
  ARR(8) := LAST_MONTH_END_DATE;
  --ARR(12) := 0; --上一年立案件数

  V_STEP_CODE := '00003';
  -- 遍历每个承保地区
  FOR QUXIAN_I IN 1 .. ARR_CBDQ.COUNT LOOP

    -- 遍历 当月，当年累计，去年当月，去年累计
    ROWNO := 1;
    FOR I IN 1 .. ARR.COUNT LOOP
      IF MOD(I + 1, 2) = 0 THEN
        BEGIN

          --立案件数（件）
          WITH CODES(CODE) AS(
            SELECT REGEXP_SUBSTR(ARR_CBDQ(QUXIAN_I), '[^,]+', 1, LEVEL) AS CODE
              FROM DUAL
            CONNECT BY LEVEL <= REGEXP_COUNT(ARR_CBDQ(QUXIAN_I), '[^,]+'))
              SELECT COUNT(DISTINCT(ZPA.ZPAH))
                INTO ARR_LAJS(ROWNO)
                FROM TB_LPAJXX   A,
                     TB_ZPAXX    ZPA
               WHERE A.AJID = ZPA.AJID
                 AND ZPA.ZPAJL != '02'
                 AND A.WBDRRQ >= ARR(I)
                 AND A.WBDRRQ <= ARR(I + 1)
                 AND ZPA.MPTS = NVL(POTHER9, ZPA.MPTS)
                 AND A.BXGSID = (SELECT ZONE2 FROM UAP_ORGAN_NODE WHERE GROUPID IN (SELECT GROUPID FROM UAP_GROUP_USER WHERE USERID = PSTATMAN))
                 AND A.YWSGYY IN (SELECT CODE FROM CODES);

          --结案件数（件）
          WITH CODES(CODE) AS(
            SELECT REGEXP_SUBSTR(ARR_CBDQ(QUXIAN_I), '[^,]+', 1, LEVEL) AS CODE
              FROM DUAL
            CONNECT BY LEVEL <= REGEXP_COUNT(ARR_CBDQ(QUXIAN_I), '[^,]+'))
              SELECT COUNT(DISTINCT(ZPA.ZPAH))
                INTO ARR_JAJS(ROWNO)
                FROM TB_LPAJXX   A,
                     TB_ZPAXX    ZPA
               WHERE A.AJID = ZPA.AJID
                 AND ZPA.ZPAJL != '02'
                 AND A.JARQ >= ARR(I)
                 AND A.JARQ <= ARR(I + 1)
                 AND A.AJZT IN ('08', '11')
                 AND ZPA.MPTS = NVL(POTHER9, ZPA.MPTS)
                 AND A.BXGSID = (SELECT ZONE2 FROM UAP_ORGAN_NODE WHERE GROUPID IN (SELECT GROUPID FROM UAP_GROUP_USER WHERE USERID = PSTATMAN))
                 AND A.YWSGYY IN (SELECT CODE FROM CODES);


          --报案金额（万元）
          WITH CODES(CODE) AS(
            SELECT REGEXP_SUBSTR(ARR_CBDQ(QUXIAN_I), '[^,]+', 1, LEVEL) AS CODE
              FROM DUAL
            CONNECT BY LEVEL <= REGEXP_COUNT(ARR_CBDQ(QUXIAN_I), '[^,]+'))
              SELECT ROUND(NVL(SUM(FP.FPZE), 0) / 10000, 2)
                INTO ARR_BAJE(ROWNO)
                FROM TB_LPAJXX A, TB_LPFPXX FP,TB_ZPAXX ZPA,TB_ZPAXXDZB DZB
               WHERE A.AJID = FP.AJID
                 AND A.AJID = ZPA.AJID
                 AND FP.FPID = DZB.XXID
                 AND ZPA.ZPAID = DZB.ZPAID
                 AND ZPA.ZPAJL != '02'
                 AND A.WBDRRQ >= ARR(I)
                 AND A.WBDRRQ <= ARR(I + 1)
                 AND ZPA.MPTS = NVL(POTHER9, ZPA.MPTS)
                 AND A.BXGSID = (SELECT ZONE2 FROM UAP_ORGAN_NODE WHERE GROUPID IN (SELECT GROUPID FROM UAP_GROUP_USER WHERE USERID = PSTATMAN))
                 AND A.YWSGYY IN (SELECT CODE FROM CODES);


          --赔付金额（万元）
          WITH CODES(CODE) AS(
            SELECT REGEXP_SUBSTR(ARR_CBDQ(QUXIAN_I), '[^,]+', 1, LEVEL) AS CODE
              FROM DUAL
            CONNECT BY LEVEL <= REGEXP_COUNT(ARR_CBDQ(QUXIAN_I), '[^,]+'))
              SELECT ROUND(NVL(SUM(ZPA.SJPFJE), 0) / 10000, 2)
                INTO ARR_PFJE(ROWNO)
                FROM TB_LPAJXX A,TB_ZPAXX ZPA
               WHERE A.AJID= ZPA.AJID
                 AND A.JARQ >= ARR(I)
                 AND A.JARQ <= ARR(I + 1)
                 AND A.AJZT IN ('08', '11')
                 AND ZPA.MPTS = NVL(POTHER9, ZPA.MPTS)
                 AND A.BXGSID = (SELECT ZONE2 FROM UAP_ORGAN_NODE WHERE GROUPID IN (SELECT GROUPID FROM UAP_GROUP_USER WHERE USERID = PSTATMAN))
                 AND A.YWSGYY IN (SELECT CODE FROM CODES);


          --平均结案天数（天）
          WITH CODES(CODE) AS(
            SELECT REGEXP_SUBSTR(ARR_CBDQ(QUXIAN_I), '[^,]+', 1, LEVEL) AS CODE
              FROM DUAL
            CONNECT BY LEVEL <= REGEXP_COUNT(ARR_CBDQ(QUXIAN_I), '[^,]+'))
              SELECT ROUND(NVL(SUM(TO_DATE(A.JARQ, 'YYYYMMDD') -
                                   TO_DATE(A.WBDRRQ, 'YYYYMMDD') + 1),
                               0) /
                           DECODE(ARR_JAJS(ROWNO),
                                  0,
                                  1,
                                  ARR_JAJS(ROWNO)),
                           1)
                INTO ARR_PJJATS(ROWNO)
                FROM TB_LPAJXX A
               WHERE A.JARQ >= ARR(I)
                 AND A.JARQ <= ARR(I + 1)
                 AND A.AJZT IN ('08', '11')
                 AND EXISTS(SELECT '1' FROM TB_ZPAXX WHERE AJID = A.AJID AND MPTS = NVL(POTHER9,MPTS))
                 AND A.BXGSID = (SELECT ZONE2 FROM UAP_ORGAN_NODE WHERE GROUPID IN (SELECT GROUPID FROM UAP_GROUP_USER WHERE USERID = PSTATMAN))
                 AND A.YWSGYY IN (SELECT CODE FROM CODES);


          --单个案件最大赔付金额（元）
          WITH CODES(CODE) AS(
            SELECT REGEXP_SUBSTR(ARR_CBDQ(QUXIAN_I), '[^,]+', 1, LEVEL) AS CODE
              FROM DUAL
            CONNECT BY LEVEL <= REGEXP_COUNT(ARR_CBDQ(QUXIAN_I), '[^,]+'))
              SELECT NVL(MAX(ZPA.SJPFJE), 0)
                INTO ARR_DGAJZDPFJE(ROWNO)
                FROM TB_LPAJXX A,TB_ZPAXX ZPA,TB_LPFPXX FP,TB_ZPAXXDZB DZB
               WHERE A.AJID = ZPA.AJID
                 AND A.AJID = FP.AJID
                 AND DZB.ZPAID = ZPA.ZPAID
                 AND DZB.XXID = FP.FPID
                 AND ZPA.ZPAJL != '02'
                 AND A.JARQ >= ARR(I)
                 AND A.JARQ <= ARR(I + 1)
                 AND A.AJZT IN ('08', '11')
                 AND ZPA.MPTS = NVL(POTHER9,ZPA.MPTS)
                 AND A.BXGSID = (SELECT ZONE2 FROM UAP_ORGAN_NODE WHERE GROUPID IN (SELECT GROUPID FROM UAP_GROUP_USER WHERE USERID = PSTATMAN))
                 AND A.YWSGYY IN (SELECT CODE FROM CODES);


          ROWNO := ROWNO + 1;
        END;
      END IF;
    END LOOP;

    V_STEP_CODE := '00004';
    --立案件数（件）当月
    INSERT INTO T_REPORT_DATA_INFO
      (STATID, SHEET, COL, R, CONTENT)
    VALUES
      (VSTATID, 0, 2, QUXIAN_I + 3, ARR_LAJS(1));
    --立案件数（件）同比增长
    SELECT DECODE(ARR_LAJS(3),
                  0,
                  (ARR_LAJS(1) / 1) * 100 || '%',
                  (ROUND(ARR_LAJS(1) / ARR_LAJS(3), 3) - 1) * 100 || '%')
      INTO MONTH_RATIO
      FROM DUAL;
    INSERT INTO T_REPORT_DATA_INFO
      (STATID, SHEET, COL, R, CONTENT)
    VALUES
      (VSTATID, 0, 3, QUXIAN_I + 3, MONTH_RATIO);
    --立案件数（件）本年累计
    INSERT INTO T_REPORT_DATA_INFO
      (STATID, SHEET, COL, R, CONTENT)
    VALUES
      (VSTATID, 0, 4, QUXIAN_I + 3, ARR_LAJS(2));
    --立案件数（件）同比增长
    SELECT DECODE(ARR_LAJS(4),
                  0,
                  (ARR_LAJS(2) / 1) * 100 || '%',
                  (ROUND(ARR_LAJS(2) / ARR_LAJS(4), 3) - 1) * 100 || '%')
      INTO YEAR_RATIO
      FROM DUAL;
    INSERT INTO T_REPORT_DATA_INFO
      (STATID, SHEET, COL, R, CONTENT)
    VALUES
      (VSTATID, 0, 5, QUXIAN_I + 3, YEAR_RATIO);

    --结案件数(件）当月
    INSERT INTO T_REPORT_DATA_INFO
      (STATID, SHEET, COL, R, CONTENT)
    VALUES
      (VSTATID, 0, 6, QUXIAN_I + 3, ARR_JAJS(1));
    --结案件数(件）同比增长
    SELECT DECODE(ARR_JAJS(3),
                  0,
                  (ARR_JAJS(1) / 1) * 100 || '%',
                  (ROUND(ARR_JAJS(1) / ARR_JAJS(3), 3) - 1) * 100 || '%')
      INTO MONTH_RATIO
      FROM DUAL;
    INSERT INTO T_REPORT_DATA_INFO
      (STATID, SHEET, COL, R, CONTENT)
    VALUES
      (VSTATID, 0, 7, QUXIAN_I + 3, MONTH_RATIO);
    --结案件数(件）本年累计
    INSERT INTO T_REPORT_DATA_INFO
      (STATID, SHEET, COL, R, CONTENT)
    VALUES
      (VSTATID, 0, 8, QUXIAN_I + 3, ARR_JAJS(2));
    --结案件数(件）同比增长
    SELECT DECODE(ARR_JAJS(4),
                  0,
                  (ARR_JAJS(2) / 1) * 100 || '%',
                  (ROUND(ARR_JAJS(2) / ARR_JAJS(4), 3) - 1) * 100 || '%')
      INTO YEAR_RATIO
      FROM DUAL;
    INSERT INTO T_REPORT_DATA_INFO
      (STATID, SHEET, COL, R, CONTENT)
    VALUES
      (VSTATID, 0, 9, QUXIAN_I + 3, YEAR_RATIO);

    --报案金额（万元）当月
    INSERT INTO T_REPORT_DATA_INFO
      (STATID, SHEET, COL, R, CONTENT)
    VALUES
      (VSTATID, 0, 10, QUXIAN_I + 3, ARR_BAJE(1));
    --报案金额（万元）同比增长
    SELECT DECODE(ARR_BAJE(3),
                  0,
                  (ARR_BAJE(1) / 1) * 100 || '%',
                  (ROUND(ARR_BAJE(1) / ARR_BAJE(3), 3) - 1) * 100 || '%')
      INTO MONTH_RATIO
      FROM DUAL;
    INSERT INTO T_REPORT_DATA_INFO
      (STATID, SHEET, COL, R, CONTENT)
    VALUES
      (VSTATID, 0, 11, QUXIAN_I + 3, MONTH_RATIO);
    --报案金额（万元）本年累计
    INSERT INTO T_REPORT_DATA_INFO
      (STATID, SHEET, COL, R, CONTENT)
    VALUES
      (VSTATID, 0, 12, QUXIAN_I + 3, ARR_BAJE(2));
    --报案金额（万元）同比增长
    SELECT DECODE(ARR_BAJE(4),
                  0,
                  (ARR_BAJE(2) / 1) * 100 || '%',
                  (ROUND(ARR_BAJE(2) / ARR_BAJE(4), 3) - 1) * 100 || '%')
      INTO YEAR_RATIO
      FROM DUAL;
    INSERT INTO T_REPORT_DATA_INFO
      (STATID, SHEET, COL, R, CONTENT)
    VALUES
      (VSTATID, 0, 13, QUXIAN_I + 3, YEAR_RATIO);

    --赔付金额（万元）当月
    INSERT INTO T_REPORT_DATA_INFO
      (STATID, SHEET, COL, R, CONTENT)
    VALUES
      (VSTATID, 0, 14, QUXIAN_I + 3, ARR_PFJE(1));
    --赔付金额（万元）同比增长
    SELECT DECODE(ARR_PFJE(3),
                  0,
                  (ARR_PFJE(1) / 1) * 100 || '%',
                  (ROUND(ARR_PFJE(1) / ARR_PFJE(3), 3) - 1) * 100 || '%')
      INTO MONTH_RATIO
      FROM DUAL;
    INSERT INTO T_REPORT_DATA_INFO
      (STATID, SHEET, COL, R, CONTENT)
    VALUES
      (VSTATID, 0, 15, QUXIAN_I + 3, MONTH_RATIO);
    --赔付金额（万元）本年累计
    INSERT INTO T_REPORT_DATA_INFO
      (STATID, SHEET, COL, R, CONTENT)
    VALUES
      (VSTATID, 0, 16, QUXIAN_I + 3, ARR_PFJE(2));
    --赔付金额（万元）同比增长
    SELECT DECODE(ARR_PFJE(4),
                  0,
                  (ARR_PFJE(2) / 1) * 100 || '%',
                  (ROUND(ARR_PFJE(2) / ARR_PFJE(4), 3) - 1) * 100 || '%')
      INTO YEAR_RATIO
      FROM DUAL;
    INSERT INTO T_REPORT_DATA_INFO
      (STATID, SHEET, COL, R, CONTENT)
    VALUES
      (VSTATID, 0, 17, QUXIAN_I + 3, YEAR_RATIO);

    --平均结案天数（天）当月
    INSERT INTO T_REPORT_DATA_INFO
      (STATID, SHEET, COL, R, CONTENT)
    VALUES
      (VSTATID, 0, 18, QUXIAN_I + 3, ARR_PJJATS(1));
    --平均结案天数（天）同比增长
    SELECT DECODE(ARR_PJJATS(3),
                  0,
                  (ARR_PJJATS(1) / 1) * 100 || '%',
                  (ROUND(ARR_PJJATS(1) / ARR_PJJATS(3), 3) - 1) * 100 || '%')
      INTO MONTH_RATIO
      FROM DUAL;
    INSERT INTO T_REPORT_DATA_INFO
      (STATID, SHEET, COL, R, CONTENT)
    VALUES
      (VSTATID, 0, 19, QUXIAN_I + 3, MONTH_RATIO);
    --平均结案天数（天）本年累计
    INSERT INTO T_REPORT_DATA_INFO
      (STATID, SHEET, COL, R, CONTENT)
    VALUES
      (VSTATID, 0, 20, QUXIAN_I + 3, ARR_PJJATS(2));
    --平均结案天数（天）同比增长
    SELECT DECODE(ARR_PJJATS(4),
                  0,
                  (ARR_PJJATS(2) / 1) * 100 || '%',
                  (ROUND(ARR_PJJATS(2) / ARR_PJJATS(4), 3) - 1) * 100 || '%')
      INTO YEAR_RATIO
      FROM DUAL;
    INSERT INTO T_REPORT_DATA_INFO
      (STATID, SHEET, COL, R, CONTENT)
    VALUES
      (VSTATID, 0, 21, QUXIAN_I + 3, YEAR_RATIO);

    --单个案件最大赔付金额（元）当月
    INSERT INTO T_REPORT_DATA_INFO
      (STATID, SHEET, COL, R, CONTENT)
    VALUES
      (VSTATID, 0, 22, QUXIAN_I + 3, ARR_DGAJZDPFJE(1));
    --单个案件最大赔付金额（元）累计
    INSERT INTO T_REPORT_DATA_INFO
      (STATID, SHEET, COL, R, CONTENT)
    VALUES
      (VSTATID, 0, 23, QUXIAN_I + 3, ARR_DGAJZDPFJE(2));
  END LOOP;

  V_STEP_CODE := '00005';
  -- 小计，合计
  ROWNO := 1;
  FOR II IN 1 .. 4 LOOP

    --当月
    SELECT SUM(TO_NUMBER(CONTENT))
      INTO TEMP_DATA
      FROM T_REPORT_DATA_INFO
     WHERE STATID = VSTATID
       AND SHEET = 0
       AND R >= 4
       AND R <= 20
       AND COL = ROWNO + 1;
    INSERT INTO T_REPORT_DATA_INFO
      (STATID, SHEET, COL, R, CONTENT)
    VALUES
      (VSTATID, 0, ROWNO + 1, 21, TEMP_DATA);
    INSERT INTO T_REPORT_DATA_INFO
      (STATID, SHEET, COL, R, CONTENT)
    VALUES
      (VSTATID, 0, ROWNO + 1, 22, TEMP_DATA);
    --同比增长
    SELECT SUM(TO_NUMBER(REPLACE(CONTENT, '%', '')))
      INTO TEMP_DATA
      FROM T_REPORT_DATA_INFO
     WHERE STATID = VSTATID
       AND SHEET = 0
       AND R >= 4
       AND R <= 20
       AND COL = ROWNO + 2;
    INSERT INTO T_REPORT_DATA_INFO
      (STATID, SHEET, COL, R, CONTENT)
    VALUES
      (VSTATID, 0, ROWNO + 2, 21, TEMP_DATA || '%');
    INSERT INTO T_REPORT_DATA_INFO
      (STATID, SHEET, COL, R, CONTENT)
    VALUES
      (VSTATID, 0, ROWNO + 2, 22, TEMP_DATA || '%');
    --本年累计
    SELECT SUM(TO_NUMBER(CONTENT))
      INTO TEMP_DATA
      FROM T_REPORT_DATA_INFO
     WHERE STATID = VSTATID
       AND SHEET = 0
       AND R >= 4
       AND R <= 20
       AND COL = ROWNO + 3;
    INSERT INTO T_REPORT_DATA_INFO
      (STATID, SHEET, COL, R, CONTENT)
    VALUES
      (VSTATID, 0, ROWNO + 3, 21, TEMP_DATA);
    INSERT INTO T_REPORT_DATA_INFO
      (STATID, SHEET, COL, R, CONTENT)
    VALUES
      (VSTATID, 0, ROWNO + 3, 22, TEMP_DATA);
    --年度同比增长
    SELECT SUM(TO_NUMBER(REPLACE(CONTENT, '%', '')))
      INTO TEMP_DATA
      FROM T_REPORT_DATA_INFO
     WHERE STATID = VSTATID
       AND SHEET = 0
       AND R >= 4
       AND R <= 20
       AND COL = ROWNO + 4;
    INSERT INTO T_REPORT_DATA_INFO
      (STATID, SHEET, COL, R, CONTENT)
    VALUES
      (VSTATID, 0, ROWNO + 4, 21, TEMP_DATA || '%');
    INSERT INTO T_REPORT_DATA_INFO
      (STATID, SHEET, COL, R, CONTENT)
    VALUES
      (VSTATID, 0, ROWNO + 4, 22, TEMP_DATA || '%');
    ROWNO := ROWNO + 4;
  END LOOP;

  --平均结案天数（天）当月
  SELECT NVL(ROUND(AVG(TO_NUMBER(CONTENT)), 1), 0)
    INTO TEMP_DATA
    FROM T_REPORT_DATA_INFO
   WHERE STATID = VSTATID
     AND SHEET = 0
     AND R >= 4
     AND R <= 20
     AND COL = 18
     AND CONTENT != '0';
  INSERT INTO T_REPORT_DATA_INFO
    (STATID, SHEET, COL, R, CONTENT)
  VALUES
    (VSTATID, 0, 18, 21, TEMP_DATA);
  INSERT INTO T_REPORT_DATA_INFO
    (STATID, SHEET, COL, R, CONTENT)
  VALUES
    (VSTATID, 0, 18, 22, TEMP_DATA);
  --平均结案天数（天）同比增长
  SELECT NVL(ROUND(AVG(TO_NUMBER(REPLACE(CONTENT, '%', ''))), 1), 0)
    INTO TEMP_DATA
    FROM T_REPORT_DATA_INFO
   WHERE STATID = VSTATID
     AND SHEET = 0
     AND R >= 4
     AND R <= 20
     AND COL = 19
     AND CONTENT != '0%';
  INSERT INTO T_REPORT_DATA_INFO
    (STATID, SHEET, COL, R, CONTENT)
  VALUES
    (VSTATID, 0, 19, 21, TEMP_DATA || '%');
  INSERT INTO T_REPORT_DATA_INFO
    (STATID, SHEET, COL, R, CONTENT)
  VALUES
    (VSTATID, 0, 19, 22, TEMP_DATA || '%');
  --平均结案天数（天）本年累计
  SELECT NVL(ROUND(AVG(TO_NUMBER(CONTENT)), 1), 0)
    INTO TEMP_DATA
    FROM T_REPORT_DATA_INFO
   WHERE STATID = VSTATID
     AND SHEET = 0
     AND R >= 4
     AND R <= 20
     AND COL = 20
     AND CONTENT != '0';
  INSERT INTO T_REPORT_DATA_INFO
    (STATID, SHEET, COL, R, CONTENT)
  VALUES
    (VSTATID, 0, 20, 21, TEMP_DATA);
  INSERT INTO T_REPORT_DATA_INFO
    (STATID, SHEET, COL, R, CONTENT)
  VALUES
    (VSTATID, 0, 20, 22, TEMP_DATA);
  --平均结案天数（天）同比增长
  SELECT NVL(ROUND(AVG(TO_NUMBER(REPLACE(CONTENT, '%', ''))), 1), 0)
    INTO TEMP_DATA
    FROM T_REPORT_DATA_INFO
   WHERE STATID = VSTATID
     AND SHEET = 0
     AND R >= 4
     AND R <= 20
     AND COL = 21
     AND CONTENT != '0%';
  INSERT INTO T_REPORT_DATA_INFO
    (STATID, SHEET, COL, R, CONTENT)
  VALUES
    (VSTATID, 0, 21, 21, TEMP_DATA || '%');
  INSERT INTO T_REPORT_DATA_INFO
    (STATID, SHEET, COL, R, CONTENT)
  VALUES
    (VSTATID, 0, 21, 22, TEMP_DATA || '%');

  --单个案件最大赔付金额（元）当月
  SELECT SUM(TO_NUMBER(CONTENT))
    INTO TEMP_DATA
    FROM T_REPORT_DATA_INFO
   WHERE STATID = VSTATID
     AND SHEET = 0
     AND R >= 4
     AND R <= 20
     AND COL = 22;
  INSERT INTO T_REPORT_DATA_INFO
    (STATID, SHEET, COL, R, CONTENT)
  VALUES
    (VSTATID, 0, 22, 21, TEMP_DATA);
  INSERT INTO T_REPORT_DATA_INFO
    (STATID, SHEET, COL, R, CONTENT)
  VALUES
    (VSTATID, 0, 22, 22, TEMP_DATA);

  --单个案件最大赔付金额（元）累计
  SELECT SUM(TO_NUMBER(CONTENT))
    INTO TEMP_DATA
    FROM T_REPORT_DATA_INFO
   WHERE STATID = VSTATID
     AND SHEET = 0
     AND R >= 4
     AND R <= 20
     AND COL = 23;
  INSERT INTO T_REPORT_DATA_INFO
    (STATID, SHEET, COL, R, CONTENT)
  VALUES
    (VSTATID, 0, 23, 21, TEMP_DATA);
  INSERT INTO T_REPORT_DATA_INFO
    (STATID, SHEET, COL, R, CONTENT)
  VALUES
    (VSTATID, 0, 23, 22, TEMP_DATA);

  V_STEP_CODE := '00006';
  --制表人
  INSERT INTO T_REPORT_DATA_INFO
    (STATID, SHEET, COL, R, CONTENT)
  VALUES
    (VSTATID, 0, 2, 24, UAP_USER_ROW.NAME);

  --联系方式
  INSERT INTO T_REPORT_DATA_INFO
    (STATID, SHEET, COL, R, CONTENT)
  VALUES
    (VSTATID, 0, 9, 24, UAP_USER_ROW.TELEPHONE);

  --制表单位
  INSERT INTO T_REPORT_DATA_INFO
    (STATID, SHEET, COL, R, CONTENT)
  VALUES
    (VSTATID, 0, 16, 24, UAP_USER_ROW.EXT4);

  --报表注脚，本报表无注脚
  /*9.返回*/
  PRETURNCODE := '0'; /* 生成报表成功，返回生成流水号VSTATID给前台获取报表数据 */
  PRETURNMSG  := VSTATID;
  DBMS_OUTPUT.PUT_LINE('[LDS DEBUG] ' || 'PRETURNCODE= ' || PRETURNCODE);
  --COMMIT; 由于给JAVA调用，无须提交事务

EXCEPTION
  WHEN OTHERS THEN
    --ROLLBACK;由于给JAVA调用，无须提交事务，返回非0值后，前台会获取错误信息，回滚事务
    PRETURNCODE := 'E'; /*  生成报表出错  */
    DBMS_OUTPUT.PUT_LINE('PRETURNCODE= ' || PRETURNCODE);
    PRETURNMSG := 'V_STEP_CODE' || V_STEP_CODE || ' ROWNUM' || CELL.R ||
                  'ERROR:' || SQLERRM; --记录生成到哪行数据错误
    DBMS_OUTPUT.PUT_LINE(PRETURNMSG);
END SP_P1_30035;

/
