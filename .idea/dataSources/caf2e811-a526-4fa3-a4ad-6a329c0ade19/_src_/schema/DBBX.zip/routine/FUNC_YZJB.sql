CREATE function      func_yzjb(a in varchar2)

    return varchar2 as

    str varchar2(100);

    begin
    str := a;
    IF a='血透' OR a='腹透' OR a='肾移植抗排异'
    THEN str:='重症尿毒症';
    ELSIF a= '化疗' OR a='放疗' OR a='同位素治疗' OR a='介入治疗' OR a='中医药治疗'
    THEN str:='恶性肿瘤';
    END IF;
    return str;

     end;

/
