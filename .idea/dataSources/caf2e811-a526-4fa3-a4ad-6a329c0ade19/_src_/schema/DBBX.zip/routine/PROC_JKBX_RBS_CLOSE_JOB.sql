CREATE PROCEDURE      "PROC_JKBX_RBS_CLOSE_JOB" IS
	i_step  NUMBER(9);
	p_RtnCode NUMBER;
	p_RtnMsg VARCHAR2(512);
BEGIN
	i_step := 1;
	---??????????
	PROC_RBSCLOSE_EXPORT(p_RtnCode,p_RtnMsg);

EXCEPTION
	WHEN OTHERS THEN
        p_RtnCode := SQLCODE;
        p_RtnMsg := SQLERRM;
        ROLLBACK;
        Pkg_Error_Log.Pro_Error_In('PROC_JKBX_RBS_CLOSE_JOB', i_step, p_RtnCode, p_RtnMsg);
END PROC_JKBX_RBS_CLOSE_JOB;

/
