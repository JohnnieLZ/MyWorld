CREATE procedure SP_P1_CASECHECK(PIN_AJID IN varCHAR2,Pin_userid IN varCHAR2 ,PReturnCode OUT varchar2,
                              PReturnMsg    OUT varchar2) AS
  /*
 *@version 1.1  大病保险项目新建
 *@version 1.2  理算出错时的异常处理
 *@version 1.5  红冲结算单号处理
 *@version 2.0	同一次申请中，按照账单类型以及发票的结算日期的找生效年度内的保单进行生成结算单。
 案件重新审核时，如果存在结算单并且强制生成子赔案标志不为1时，才执行业务处理逻辑，否则直接退出；
          红冲和普通案件重新审核结算单号沿用原来的规则保持一致、结算单号沿用原来的规则增加了个保单的判断。
          如果一张发票结算期对应有两个有效的保单，不能生成结算信息，系统给出提示。
  *@version 3.0 其它地区医保大病审核理算逻辑实现
 */
  V_STEP_CODE  VARCHAR2(5):='00000';
  v_start_date number := 0;
  v_end_date   number := 0;
  v_no  number:=0;
  rec_ajxx tb_lpajxx%rowtype;
  v_001zd number:=0; --是否不确定诊断，缺省为0
  --根据申请类型缺省为S1
  cursor cur_lx is select aaa102,aaa103 from aa10 a,tb_lpajxx b where b.ajid=to_number(trim(PIN_AJID)) and a.aaa100='SQLX' and  b.SQLX like '%'||a.aaa102||'%';

  --医疗类子赔案游标 同一诊断代码、同一医院、同一就诊日期\同一账单类型 生成1子赔案
  cursor cur_ylzpa is  select /*v2.0++ begin*/k.bdid as mpts,k.bdsxrq,k.bdzzrq, /*v2.0++ end*/ min(a.fpid) as fpid,a.ZDLX,min(a.YYID) as yyid,min(nvl(ryrq,jzrq)) as jzrq,'0' sfywyl,'' as SFYSS,'' as xgdm, sum(nvl(a.fpze,0)) as zdje, --     NUMBER(16,2)  Y                账单总金额
sum(nvl(a.tczfe,0)+ nvl(a.fjzfe,0)+nvl(a.SBZFE,0) ) as SBZFJE,-- 社保支付总金额
sum(nvl(ZFZE,0)   ) as zfje,--      NUMBER(16,2)  Y                自费金额
sum(nvl(a.flzfze ,0)) as FLZFJE, --  NUMBER(16,2)  Y                分类自负金额
'' as QTDSFZFJE,--  其他第三方支付金额
sum(nvl(a.bhlfy,0)) as BHLFY  --   NUMBER(16,2)  Y                不合理费用
 from TB_LPFPXX a/*,TB_FPXXFYXX b*//*v2.0++*/,tb_bdxx k where k.bxgsid=733 and a.fprq>=k.bdsxrq and a.fprq<=k.bdzzrq and k.BDZT='1' and /*a.fpid=b.fpid and*/ a.ajid=to_number(trim(PIN_AJID))
   /* and not exists(select 'x' from tb_zpaxxdzb where xxid=b.xxid)*/
     group by  /*v2.0++ begin*/k.bdid,k.bdsxrq,k.bdzzrq,/*v2.0++ end*/ a.ZDLX having sum(nvl(a.fpze,0))>0
     order by a.ZDLX asc;
   v_zrlxdm varchar2(6):='xxxxxx';
   v_xtxgdm varchar2(60):=''; --系统悬挂代码
   v_zpaid number(16):=-1;
   v_fphm varchar2(500):=''; --医疗子赔案用到的所有发票号
   v_zpah varchar2(30):='';--子赔案号
   v_zrid number(16):=0; -- 赔付的责任Id
   v_zddm varchar2(20):='';
   rec_zrxx tb_zrxx%rowtype;
   v_fdid number(16):=0; -- 子陪案对应的分单Id
   v_zjl number(5,2):=0.00;--初审人所在审核组质检率
   v_fdksrq  number(8):=0;--生育责任分单开始日期
   v_fdjsrq  number(8):=0;--生育责任分单结束日期
   v_syyjms varchar2(200) :='';
   type  rec_zpaxx is table of tb_zpaxx%rowtype index by binary_integer;--v1.5++
   arr_zpaxx rec_zpaxx;--v1.5++
    v_zpas number:=0;

  begin
    PReturnCode:='E';
    PReturnMsg:='Error!';
    --业务处理块
    if (PIN_AJID is null ) then
      PReturnCode:='-1';
      PReturnMsg:='参数输入错误!';
      return;
    end if;
 --现金支付-分类自负-自费=自负/自负一，系统计算自负1 20151231 ;20160104 14:00
      /*update tb_lpfpxx a set ZFYJE=decode(sign(nvl(xjzfe,0)-(nvl(ZFzE,0)+nvl(FLZFZE,0))),1,nvl(xjzfe,0)-(nvl(ZFzE,0)+nvl(FLZFZE,0)),null) where ajid=to_number(trim(PIN_AJID)) and exists(select 'x' from tb_yyxx where yyid=a.yyid and XZQHDM  not like '11%') and (nvl(xjzfe,0)>0 or abs(ZFYJE -(nvl(xjzfe,0) +nvl(ZFzE,0)+nvl(FLZFZE,0)))>0.05)
      and exists(select 'x' from tb_lpajxx where ajid=a.ajid and bxgsid=733);*/
    --@version 1.7.2 去掉发票号码中的空格
      update tb_lpfpxx a set a.fphm=replace(a.fphm,' ','') where ajid=to_number(trim(PIN_AJID)) and instr(fphm,' ')>0;

    select * into rec_ajxx from tb_lpajxx where ajid=to_number(trim(PIN_AJID));
  if rec_ajxx.bxgsid=733 then --v3.0++ begin 上海人寿案件走原来的处理逻辑
    select syyjms/*v2.0++begin*/,(select count(1) from tb_zpaxx where ajid=a.ajid) /*v2.0++begin*/ into v_syyjms,v_no from tb_lpajxx a where ajid=to_number(trim(PIN_AJID));
   /*v2.0++begin*/
    if nvl(rec_ajxx.BXCSSCZPABZ,'0')!='1' and v_no>0 then
       PReturnCode:='0';
       PReturnMsg:='案件已有结算单信息，无需生成!';
       return;
    end if;
    --  如果一张发票结算期对应有两个有效的保单，不能生成结算信息，系统给出提示。
    select  count(1),min(a.fprq) into v_no,v_fdid from tb_lpfpxx a where a.ajid=to_number(trim(PIN_AJID))
           and exists (select count(1) from tb_bdxx b where b.bxgsid=733 and a.fprq>= b.bdsxrq and a.fprq<=b.bdzzrq and b.bdzt='1' having count(1)>1 );
   if v_no>0 then
   	   PReturnCode:='-99';
       PReturnMsg:='存在结算日期为'||to_char(v_fdid)||'的发票，对应有两个及以上的有效的保单，请只保留一个有效保单后再操作!';
       return;
  end if;
    /*v2.0++end*/
   /*v2.0++begin*/
    if nvl(rec_ajxx.BXCSSCZPABZ,'0')!='1' and v_no>0 then
       PReturnCode:='0';
       PReturnMsg:='案件已有结算单信息，无需生成!';
       return;
    end if;

   /*v2.0++end*/
     --受理员录入了案件悬挂代码的，系统自动审核时直接将案件转到人工审核2 ，后续处理不用。
     if (rec_ajxx.ajxgdm is not null and trim(Pin_userid) is null) then
       PReturnCode:='0';
       PReturnMsg:='受理员录入了案件悬挂代码的，系统自动审核时直接将案件转到人工审核2!';
       update tb_lpajxx a set ajzt='04' where a.ajid=to_number(trim(PIN_AJID));
       return;
      end if;
       --医疗类理赔申请，如无发票信息录入，将该案件挂起，代码为CL29，后续也不需要自动生成赔案，进入人工审核2
    select count(1) into v_no from tb_lpajxx a where  ajid=to_number(trim(PIN_AJID))  ;
    if v_no=0 then
       PReturnCode:='0';
       PReturnMsg:='医疗类理赔案件却没有提供任何发票，不能生成赔案，请修改!';
       update tb_lpajxx set ajzt='04', AJXGDM=replace(AJXGDM,'CL12','')||'CL12',AJXGLY=replace(AJXGLY,'无发票信息录入','')||'无发票信息录入'
         where ajid=to_number(trim(PIN_AJID));
       return;
    end if;
    --结算日期为空校验
      select count(1),min(fphm) into v_no,v_fphm from tb_lpfpxx a where  ajid=to_number(trim(PIN_AJID)) and (fprq is null )  ;
    if v_no>0 then
       PReturnCode:='-1';
       PReturnMsg:='存在发票号为:'||v_fphm||'的发票无结算日期，请核查修改!';
       return;
    end if;
        --就诊方式为空校验
      select count(1),min(fphm) into v_no,v_fphm from tb_lpfpxx a where  ajid=to_number(trim(PIN_AJID)) and (zdlx is null or zdlx not in('0','1') )  ;
    if v_no>0 then
       PReturnCode:='-1';
       PReturnMsg:='存在发票号为:'||v_fphm||'的发票就诊方式错误，请核查修改!';
       return;
    end if;
        --就诊方式为空校验
      select count(1),min(fphm) into v_no,v_fphm from tb_lpfpxx a where  ajid=to_number(trim(PIN_AJID)) and nvl(a.bhlfy,0)>0 and (yyid is null or exists(select 'x' from tb_yyxx b where b.yyid=a.yyid and b.jb not in('1','2','3')) )  ;
    if v_no>0 then
       PReturnCode:='-1';
       PReturnMsg:='存在发票号为:'||v_fphm||'的发票医院等级错误，请核查修改!';
       return;
    end if;
    /*v1.5 记录原来的子赔案结算单号*/
    for rec_zpa in(select zpaid,zpah,/*(select zdlx from tb_lpfpxx where fpid=a.fpid)*/pfzrdm as zddm/*v2.0++*/,a.mpts /*v2.0++*/ from tb_zpaxx a where ajid=to_number(trim(PIN_AJID)) ) loop
        v_zpas:=v_zpas+1;
        arr_zpaxx(v_zpas).zpah:=rec_zpa.zpah;
        arr_zpaxx(v_zpas).zddm:=rec_zpa.zddm;
        arr_zpaxx(v_zpas).mpts:=rec_zpa.mpts; --v2.0++
    end loop;
    /*v1.5++ end */
    delete from TB_ZPAXXDZB where zpaid in(select zpaid as xxx from tb_zpaxx where ajid=to_number(trim(PIN_AJID)) and nvl(SFSDTJ,'0')='0') ;

    delete from TB_ZPALSGZDZB a where a.ZPAID in(select zpaid as xxx from tb_zpaxx where ajid=to_number(trim(PIN_AJID)) and nvl(SFSDTJ,'0')='0');

    delete from tb_zpaxx where ajid=to_number(trim(PIN_AJID)) and nvl(SFSDTJ,'0')='0';

   --清除删除不干净的 TB_ZPALSGZDZB里的垃圾数据
    delete from tb_zpalsgzdzb c where not exists(select 'x' from tb_zpaxx a where a.zpaid=c.zpaid);

    --大病险子赔案生成
    for recylzpa in cur_ylzpa loop
                v_fphm:='';
                v_zrlxdm:='';
                v_xtxgdm:='';
                   --生成子赔案信息表，初步统计下总金额，后面理算好后在更新
                  select seq_ZPAID.nextval into v_zpaid from dual;
                  insert into tb_zpaxx(
                            ZPAID     ,--NUMBER(16)                     子赔案ID
                            ZPAH, --JSD+YYYYMMDD+5位流水号              子赔案号
                            AJID      ,--NUMBER(16)                     案件ID
                            JBID      ,--NUMBER(16)                     疾病ID
                            ZDDM      ,--VARCHAR2(10)  Y                诊断代码
                            ZRID      ,--NUMBER(16)                     责任ID
                            PFZRDM    ,--VARCHAR2(4)   Y                赔付责任代码
                            ZDZJE     ,--NUMBER(16,2)  Y                账单总金额
                            SBZFZJE   ,--NUMBER(16,2)  Y                社保支付总金额
                            ZFJE      ,--NUMBER(16,2)  Y                自费金额
                            FLZFJE    ,--NUMBER(16,2)  Y                分类自负金额
                            QTDSFZFJE ,--NUMBER(16,2)  Y                其他第三方支付金额
                            BHLFY     ,--NUMBER(16,2)  Y                不合理费用
                            XGDM      ,--VARCHAR2(100) Y                悬挂代码
                            ZT ,fpid ,fdid       --VARCHAR2(1)   Y                状态
                            ,mpts --v2.0++ 结算单所属保单ID
                            ) select v_zpaid as ZPAID,
                                   'JSD'||to_char(sysdate,'yyyymmdd')||Ltrim(rtrim(to_char(SEQ_DAY_ZPALSH.nextval,'09999'))) as zpah,
                                   to_number(trim(PIN_AJID)) ,
                                  '' as jbid,
                                  '' as zddm, '' as zrid,
                                   recylzpa.zdlx as   PFZRDM,
                                     recylzpa.zdje,
                                     recylzpa.SBZFJE,
                                         recylzpa.ZFJE,
                                           recylzpa.FLZFJE,
                                           recylzpa.QTDSFZFJE  ,
                                           recylzpa.BHLFY,
                                           recylzpa.xgdm as XGDM,
                                         '0' as zt ,  recylzpa.fpid,'' as fdid/*v2.0++*/,recylzpa.mpts /*v2.0++ end*/
                                   from dual;

                  -- v1.4.5++ end
                   --生成子赔案与发票对照表
                   insert into tb_zpaxxdzb(
                   XXDZID  ,--NUMBER(16)                   细项对照ID
                    ZPAID  ,--NUMBER(16)                   子赔案ID
                    XXID   ,--NUMBER(16)                   细项ID
                    XXJFLY ,--VARCHAR2(4) Y                细项拒付理由
                    AJID )--NUMBER(16)                   案件ID
                    select seq_XXDZID.nextval as XXDZID, v_zpaid as ZPAID,
                    a.fpid,'' as XXJFLY, a.ajid as AJID
                    from   TB_LPFPXX a where a.ajid=to_number(trim(PIN_AJID))
                     and a.zdlx=recylzpa.zdlx /*v2.0++ begin*/ and a.fprq>=recylzpa.bdsxrq and a.fprq<=recylzpa.bdzzrq
                     and not exists(select 'x' from tb_zpaxxdzb where xxid=a.fpid) /*v2.0++ end*/;
                     --更新子赔案用到的所有发票号码,根据细项找不同发票号码，去掉后面个‘，’;
                      v_fphm:='';
                     for rec in(select distinct a.fphm from TB_LPFPXX a,tb_zpaxxdzb b,tb_zpaxx c,tb_fpxxfyxx d where a.fpid=d.fpid and b.xxid=d.xxid and b.zpaid=c.zpaid and c.zpaid=v_zpaid
                      /* and (a.yyid,a.zdlx,nvl(a.ryrq,a.jzrq),c.zddm) in(
                      select yyid ,zdlx,nvl(ryrq,jzrq),case when instr(jbdm,c.zddm)>0 then c.zddm else jbdm end from TB_LPFPXX g where g.fpid=c.fpid)
                       group by a.fphm*/
                       ) loop
                         v_fphm:=substr(v_fphm||rec.fphm||',',1,500);
                     end loop;
                    -- update tb_zpaxx set SYFPH=substr(v_fphm,1,length(trim(v_fphm))-1 ),xgdm=case when v_xtxgdm is null then '' else v_xtxgdm||',' end ||(select max(a.xgdm) from TB_LPFPXX a,tb_zpaxxdzb b,tb_fpxxfyxx d where a.fpid=d.fpid and b.xxid=d.xxid and b.zpaid=v_zpaid) where zpaid=v_zpaid;--20150306 生成子赔案时，发票有悬挂代码的，带到子赔案中
                      --去掉悬挂代码后面多余的逗号（，）；20151029
                     update tb_zpaxx set SYFPH=substr(v_fphm,1,length(trim(v_fphm))-1 ),xgdm=case when trim(recylzpa.xgdm) is null then v_xtxgdm else case when v_xtxgdm is null then trim(recylzpa.xgdm) else  v_xtxgdm|| ','||  trim(recylzpa.xgdm) end end  where zpaid=v_zpaid;
           end loop;
      --子赔案理算
    for rec in(select zpaid,xgdm ,zrid,pfzrdm from tb_zpaxx where ajid=to_number(trim(PIN_AJID)) and nvl(zpajl,'01')!='02'  order by zpaid asc)  loop

            SP_P1_COMPUTESUBCASE(rec.zpaid,Pin_userid ,'1', PReturnCode ,PReturnMsg);
            --/*v1.2++ begin */
            if PReturnCode!='0' then
               PReturnCode := '-2';
               PReturnMsg:=substrb('案件理算失败!错误码为'||PReturnCode||' 错误描述:'||PReturnMsg,1,200);
               return;
            end if;
            --/*v1.2++ end */
            --理算后有悬挂的将状态设为处理中 案件结论都设为正常赔付
            update tb_zpaxx a set a.zpajl= '01',  a.ZT=case when trim(a.xgdm) is null then '1' else '0' end where a.ajid=to_number(trim(PIN_AJID)) and a.zpaid=rec.zpaid ;

    end loop;

    if trim(Pin_userid) is not null then --有必须重新生成子赔案标识的，生成好后去掉该标志
       update tb_lpajxx a set a.BXCSSCZPABZ='0',SCZPASJ=sysdate where a.ajid=to_number(trim(PIN_AJID));
    end if;

    --v1.5++ 处理红冲案件结算单号
   --v2.0--  if trim(v_syyjms) = '红冲' then
        for rec_newzpa in (select * from tb_zpaxx where ajid=to_number(trim(PIN_AJID))) loop
            for v_count in 1..v_zpas loop
               if rec_newzpa.pfzrdm=arr_zpaxx(v_count).zddm /*v2.0++ begin*/ and rec_newzpa.mpts=arr_zpaxx(v_count).mpts /*v2.0++ begin*/ then
                    update tb_zpaxx z set z.zpah =arr_zpaxx(v_count).zpah where z.zpaid=rec_newzpa.zpaid;
                 exit;
               end if;
             end loop;
        end loop;
    --v2.0--  end if;
     --v1.5++end
  /*v3.0++ begin */
   else  -- 非上海大病案件走新的处理逻辑
       SP_P1_OTHERCASECHECK(PIN_AJID ,Pin_userid ,PReturnCode ,PReturnMsg );
       if  PReturnCode!='0' then --报出错误异常，返回
           return;
       end if;
   end if;
   /*v3.0++ end */
    PReturnCode:='0';
    PReturnMsg:='案件审核处理成功!';

    EXCEPTION
  WHEN OTHERS THEN
    PReturnCode := 'E';
    DBMS_OUTPUT.PUT_LINE('[yhs debug] ' || 'PReturncode= ' ||
                         PReturnCode);
   PReturnMsg := 'Error:' || sqlerrm;
    DBMS_OUTPUT.PUT_LINE(PReturnMsg);
  end   SP_P1_CASECHECK;
/
