CREATE PROCEDURE      "PROC_UNLOCK" (pPch IN VARCHAR2, p_RtnCode OUT NUMBER, p_RtnMsg OUT VARCHAR2) IS
	i_Count  NUMBER(9);
    i_step   NUMBER(9);

BEGIN
	--0.?????
	i_step := 0;
	i_Count := 0;
  p_RtnCode := 0;
  p_RtnMsg := '????';

    --???????????????????????
    i_step := 1;
    SELECT COUNT(1)
    INTO i_Count
    FROM TB_LOCK_INFO
    WHERE PCH = pPch;
    --AND ZT = '00';

    IF i_Count = 0 THEN
    	p_RtnCode := 1;
      	p_RtnMsg := '????????';
      	RETURN;
    END IF;

    --?????
    i_step := 2;
	UPDATE TB_LOCK_INFO A
	SET
		A.PLAN_UNLOCK_DATE = (SELECT TO_DATE(TO_CHAR(MAX(AL_LOCK_DATE),'YYYYMMDD'),'YYYYMMDD')+1 FROM TB_LOCK_INFO),
		A.ZT = '20',
		A.CWYY = ''
	WHERE A.ZT IN('10','12')
	AND A.WD_LOCK_DATE < (SELECT TO_DATE(TO_CHAR(MAX(AL_LOCK_DATE),'YYYYMMDD'),'YYYYMMDD') FROM TB_LOCK_INFO)
    AND NOT EXISTS (SELECT 1
                    FROM TB_LOCK_INFO C
                    WHERE C.PCH = pPch
                    AND C.ZT IN ('10','12')
                    AND C.WD_LOCK_DATE = (SELECT TO_DATE(TO_CHAR(MAX(AL_LOCK_DATE),'YYYYMMDD'),'YYYYMMDD') FROM TB_LOCK_INFO)
                    AND C.SUB_POLICY_REF=A.SUB_POLICY_REF
                    AND C.POLICY_REF = A.POLICY_REF);

    --????????????
    i_step := 3;
	UPDATE TB_FDXX A
  	SET
    	A.SDBZ = '0',
    	A.SDRQ=''
  	WHERE EXISTS (SELECT 1
                  FROM TB_LOCK_INFO B
                  WHERE A.FDH = B.SUB_POLICY_REF
                  AND A.WBBDH = B.POLICY_REF
                  AND B.ZT = '20'
                  AND to_char(B.PLAN_UNLOCK_DATE,'yyyymmdd') = (SELECT TO_CHAR(MAX(AL_LOCK_DATE),'YYYYMMDD') FROM TB_LOCK_INFO))
  	AND NOT EXISTS (SELECT 1
                    FROM TB_LOCK_INFO C
                    WHERE C.PCH = pPch
                    AND A.FDH = c.SUB_POLICY_REF
                    AND A.WBBDH = C.POLICY_REF
                    AND C.ZT IN ('10','12')
                    AND to_char(C.WD_LOCK_DATE,'yyyymmdd') = (SELECT TO_CHAR(MAX(AL_LOCK_DATE),'YYYYMMDD') FROM TB_LOCK_INFO));

	--?????????????
    i_step := 4;
    UPDATE TB_LOCK_INFO A
    SET
    	A.UNLOCK_DATE = (SELECT TO_DATE(TO_CHAR(MAX(AL_LOCK_DATE),'YYYYMMDD'),'YYYYMMDD') FROM TB_LOCK_INFO),
    	A.ZT = '30'
    WHERE EXISTS (SELECT 1
                  FROM TB_LOCK_INFO B
                  WHERE A.SUB_POLICY_REF = B.SUB_POLICY_REF
                  AND A.POLICY_REF = B.POLICY_REF
                  AND B.ZT = '20'
                  AND to_char(B.PLAN_UNLOCK_DATE,'yyyymmdd') = (SELECT TO_CHAR(MAX(AL_LOCK_DATE),'YYYYMMDD') FROM TB_LOCK_INFO))
  	AND NOT EXISTS (SELECT 1
                    FROM TB_LOCK_INFO C
                    WHERE C.PCH = pPch
                    AND A.SUB_POLICY_REF = c.SUB_POLICY_REF
                    AND A.POLICY_REF = C.POLICY_REF
                    AND C.ZT IN ('10','12')
                    AND to_char(C.WD_LOCK_DATE,'yyyymmdd') = (SELECT TO_CHAR(MAX(AL_LOCK_DATE),'YYYYMMDD') FROM TB_LOCK_INFO));

    --?????????30?31??????????
    i_step := 5;
	INSERT INTO TB_LOCK_INFO_HZ(
		PCH, SUB_POLICY_REF, INSURED_NAME,
		INSURED_IDTYPE, INSURED_IDNO, INSURED_GENDER,
		INSURED_BIRTH, AL_LOCK_DATE, UNLOCK_DATE, POLICY_REF)
	SELECT
		 PCH, SUB_POLICY_REF, INSURED_NAME,
		 INSURED_IDTYPE, INSURED_IDNO, INSURED_GENDER,
		 INSURED_BIRTH, AL_LOCK_DATE, UNLOCK_DATE, POLICY_REF
	FROM TB_LOCK_INFO
	WHERE ZT IN ('30','31')
	AND PCH = pPch;
	--COMMIT;
EXCEPTION
WHEN OTHERS THEN
      p_RtnCode := SQLCODE;
      p_RtnMsg := SQLERRM;
      --ROLLBACK;
      Pkg_Error_Log.pro_error_in_pldr('Proc_UnLock', i_step, p_RtnCode, p_RtnMsg);
END Proc_UnLock;

/
