CREATE PROCEDURE      "SP_P1_30023" (report_id   In t_report_def_info.REPORTID%TYPE,
                                        pStartdate  IN varchar2, -- ??????yyyymmdd
                                        pEnddate    IN varchar2, -- ??????yyyymmdd
                                        pStatman    IN t_report_gen_info.STATMAN%TYPE, --???
                                        ptype       in varchar2, /*0 ???? ,1 ?? 2 ?? 3 ?? */ --?????
                                        POther1     IN varchar2, --??id
                                        POther2     IN varchar2, --??id
                                        POther3     IN varchar2, --??id
                                        POther4     IN varchar2, --????
                                        POther5     IN varchar2, --????
                                        POther6     IN varchar2, --??ID
                                        POther7     IN varchar2, --??????yyyymmdd
                                        POther8     IN varchar2, --??????yyyymmdd
                                        PReturnCode OUT varchar2,
                                        PReturnMsg  OUT varchar2) AS
  V_STEP_CODE  CHAR(5); --?????????????????
  vreportid    t_report_def_info.REPORTID%TYPE; --??ID
  v_start_date number := 0; --????????
  v_end_date   number := 0; --????????
  vxzqhdm      t_report_gen_info.STATORGID%TYPE; --????????????

  vstatid varchar(30); --?????????????????
  type cellType is record(
    statid  varchar2(15),
    col     number,
    r       number,
    content varchar2(1024));

  cell      cellType; --?????????????
  vdwmc     varchar2(50); --????????????
  vusername t_report_gen_info.STATMAN%TYPE; --????????
  vnd       t_report_gen_info.STATYEAR%TYPE; --????
  rowno     number := 0; --??????

  v_pas number :=0;--???
  v_pfjezj number :=0;--??????
  v_zjpfje number :=0;--??????
  v_zbfb varchar2(10);--????

  vv_pfjezj number :=0;
  vv_zjpfje number :=0;

begin
  V_STEP_CODE := '00000';
  PReturnMsg  := 'OK';
  PReturnCode := 'E';
  vreportid   := substr(report_id, 1, 5);
  vusername   := pStatman;
  vnd         := substr(pStartdate, 1, 4);

  v_start_date := to_number(substr(pStartdate, 1, 8));
  v_end_date   := to_number(substr(pEnddate, 1, 8));

  --???????????????????????????
  delete from t_report_data_info
   where statid in
         (select statid from T_REPORT_GEN_INFO where reportid = report_id);

  delete from T_REPORT_GEN_INFO
   where statid in
         (select statid from T_REPORT_GEN_INFO where reportid = report_id);

  V_STEP_CODE := '00001';
  --???,?T_RERORT_GEN_INFO?????????????
  --???????
  select seq_statid.nextval into vstatid from dual;

  -- ??????????
  insert into t_report_gen_info
    (STATID,
     REPORTID,
     STATORGID,
     STATORGNAME,
     STATDATE,
     STATMAN,
     STATYEAR,
     BEGINDATE,
     ENDDATE,
     STAT_OTHER,
     STAT_TYPE)
  values
    (vstatid,
     vreportid,
     '',
     '',
     to_char(sysdate, 'yyyymmdd'),
     vusername,
     vnd,
     v_start_date,
     v_end_date,
     substr(pEnddate, 1, 1),
     trim(ptype));

  /* --?????? ??excel???0?????1??,????0???*/
  --???
  insert into t_report_data_info(statid,sheet,col,r,content) values(vstatid,0,1,2,'CLFX04');

  --????
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,1,3,to_char(sysdate,'yyyymmdd'));

  --????
  select max(bxgsqc) into cell.content from tb_bxgsxx where bxgsid = trim(POther1);
  if cell.content is not null then
    insert into t_report_data_info(statid,sheet,col,r,content) values(vstatid,0,1,5,cell.content);
  end if;

  --????
  select max(ttmc) into cell.content from tb_ttxx where ttid = trim(POther2);
  if cell.content is not null then
    insert into t_report_data_info(statid,sheet,col,r,content) values (vstatid,0,1,6,cell.content);
  end if;

  --???
  select max(khbdh) into cell.content from tb_bdxx where bdid = trim(POther3);
  if cell.content is not null then
    insert into t_report_data_info(statid,sheet,col,r,content) values (vstatid,0,1,7,cell.content);
  end if;

  --????????
  insert into t_report_data_info(statid,sheet,col,r,content) values (vstatid,0,1,8,trim(pStartdate) ||'-'|| trim(pEnddate));

  --????????
  insert into t_report_data_info(statid,sheet,col,r,content) values (vstatid,0,1,9,trim(POther7) ||'-'|| trim(POther8));


  cell.statid := vstatid;
  cell.col    := 0; --?1???
  cell.r      := 12; --?13???
  --???????????????????????????????excel????????????????????

  --?????????
  for rec_bxgs in(
    select a.bxgsid
    from tb_bxgsxx a,tb_ttxx b,tb_bdxx c,tb_cpxx d,tb_yyxx e,tb_zpaxx f,tb_cpzrdzb g,tb_lpfpxx h,/*tb_bdcpxx i,*/tb_lpajxx k,tb_lppcxx j,tb_fdxx m
    where a.bxgsid = j.bxgsid
      and f.ajid = k.ajid
      and h.ajid = f.ajid
      and m.khbdh = c.khbdh
      and m.ttid = b.ttid
       and j.khbdh = c.khbdh
      and a.bxgsid = c.bxgsid
      and b.ttid = c.ttid
      /*and d.cpid = i.cpid
      and c.bdid = i.bdid*/
      and e.yyid = h.yyid
      and h.fpid = f.fpid
      and f.zrid = g.zrid
      and d.cpid = g.cpid
      and k.lppcid = j.pcid
      and k.bxgsid =a.bxgsid
      and k.ttid = c.ttid
      and f.sjpfje <> 0
      and a.bxgsid = nvl(trim(POther1),a.bxgsid)
      and b.ttid = nvl(trim(POther2),b.ttid)
      and c.bdid = nvl(trim(POther3),c.bdid)
      and d.cpid = nvl(trim(POther4),d.cpid)
      and c.bdsxrq >=nvl(trim(pStartdate), 19000101)
      and c.bdzzrq >= nvl(trim(pEnddate), c.bdzzrq)
      and c.bdsxrq <=nvl(trim(pEnddate), 99991231)
      and k.jarq >= nvl(trim(POther7),19000101)
      and k.jarq <= nvl(trim(POther8),99991231)
    group by a.bxgsid
    order by a.bxgsid
    )loop

    --???????
    for rec_tt in(
      select b.ttid
      from tb_bxgsxx a,tb_ttxx b,tb_bdxx c,tb_cpxx d,tb_yyxx e,tb_zpaxx f,tb_cpzrdzb g,tb_lpfpxx h,/*tb_bdcpxx i,*/tb_lpajxx k,tb_lppcxx j,tb_fdxx m
      where a.bxgsid = j.bxgsid
      and f.ajid = k.ajid
      and h.ajid = f.ajid
      and m.khbdh = c.khbdh
      and m.ttid = b.ttid
       and j.khbdh = c.khbdh
      and a.bxgsid = c.bxgsid
      and b.ttid = c.ttid
      /*and d.cpid = i.cpid
      and c.bdid = i.bdid*/
      and e.yyid = h.yyid
      and h.fpid = f.fpid
      and f.zrid = g.zrid
      and d.cpid = g.cpid
      and k.lppcid = j.pcid
      and k.bxgsid =a.bxgsid
      and k.ttid = c.ttid
      and f.sjpfje <> 0
      and a.bxgsid = rec_bxgs.bxgsid
      and b.ttid = nvl(trim(POther2),b.ttid)
      and c.bdid = nvl(trim(POther3),c.bdid)
      and d.cpid = nvl(trim(POther4),d.cpid)
      and c.bdsxrq >=nvl(trim(pStartdate), 19000101)
      and c.bdzzrq >= nvl(trim(pEnddate), c.bdzzrq)
      and c.bdsxrq <=nvl(trim(pEnddate), 99991231)
      and k.jarq >= nvl(trim(POther7),19000101)
      and k.jarq <= nvl(trim(POther8),99991231)
    group by b.ttid
    order by b.ttid
    )loop

    --???????
    for rec_bd in(
      select c.bdid
      from tb_bxgsxx a,tb_ttxx b,tb_bdxx c,tb_cpxx d,tb_yyxx e,tb_zpaxx f,tb_cpzrdzb g,tb_lpfpxx h,/*tb_bdcpxx i,*/tb_lpajxx k,tb_lppcxx j,tb_fdxx m
      where a.bxgsid = j.bxgsid
      and f.ajid = k.ajid
      and h.ajid = f.ajid
      and m.khbdh = c.khbdh
      and m.ttid = b.ttid
       and j.khbdh = c.khbdh
      and a.bxgsid = c.bxgsid
      and b.ttid = c.ttid
      /*and d.cpid = i.cpid
      and c.bdid = i.bdid*/
      and e.yyid = h.yyid
      and h.fpid = f.fpid
      and f.zrid = g.zrid
      and d.cpid = g.cpid
      and k.lppcid = j.pcid
      and k.bxgsid =a.bxgsid
      and k.ttid = c.ttid
      and f.sjpfje <> 0
      and a.bxgsid = rec_bxgs.bxgsid
      and b.ttid = rec_tt.ttid
      and c.bdid = nvl(trim(POther3),c.bdid)
      and d.cpid = nvl(trim(POther4),d.cpid)
      and c.bdsxrq >=nvl(trim(pStartdate), 19000101)
      and c.bdzzrq >= nvl(trim(pEnddate), c.bdzzrq)
      and c.bdsxrq <=nvl(trim(pEnddate), 99991231)
      and k.jarq >= nvl(trim(POther7),19000101)
      and k.jarq <= nvl(trim(POther8),99991231)
    group by c.bdid
    order by c.bdid
    )loop

    --???????
    for rec_cp in(
      select d.cpid ,sum (nvl(f.sjpfje,0)) as zjpfje
            from tb_zpaxx f,tb_cpzrdzb g,tb_cpxx d,tb_bdxx c,/*tb_bdcpxx i,*/tb_ttxx b,tb_bxgsxx a,tb_lpajxx k,tb_lpfpxx h,tb_lppcxx j,tb_fdxx m
            where a.bxgsid = j.bxgsid
            and f.ajid = k.ajid
            and h.ajid = k.ajid
            and m.khbdh = c.khbdh
            and m.ttid = b.ttid
             and j.khbdh = c.khbdh
            and a.bxgsid = c.bxgsid
            and b.ttid = c.ttid
            /*and d.cpid = i.cpid
            and c.bdid = i.bdid
            and i.cpid = d.cpid*/
            and d.cpid = g.cpid
            and g.zrid = f.zrid
            and k.lppcid = j.pcid
            and k.bxgsid =a.bxgsid
            and k.ttid = c.ttid
            and a.bxgsid = rec_bxgs.bxgsid
            and b.ttid = rec_tt.ttid
            and c.bdid = rec_bd.bdid
            and d.cpid = nvl(trim(POther4),d.cpid)
            and c.bdsxrq >=nvl(trim(pStartdate), 19000101)
            and c.bdzzrq >= nvl(trim(pEnddate), c.bdzzrq)
            and c.bdsxrq <=nvl(trim(pEnddate), 99991231)
            and k.jarq >= nvl(trim(POther7),19000101)
            and k.jarq <= nvl(trim(POther8),99991231)
            and f.sjpfje <> 0
            and h.fpid = f.fpid
            and EXISTS(SELECT 'X' FROM TB_LPAJXX H WHERE H.AJID=F.AJID AND AJZT IN('08','09','10'))
            group by d.cpid
            order by d.cpid
        )loop
       vv_zjpfje:= rec_cp.zjpfje ;
    --????
    for rec_data in(
     select t.bxgsdm,t.bxgsmc,t.tbtth,t.ttmc,t.bdh,t.bdqj,t.cph,t.cpmc,t.yydm,t.yymc,t.pas,t.pfjezj from
      (select a.bxgsbh as bxgsdm,a.bxgsqc as bxgsmc,b.ttbh as tbtth,b.ttmc as ttmc,c.khbdh as bdh,c.bdsxrq || '-' || c.bdzzrq as bdqj,d.cph as cph,d.cpmc as cpmc,e.yydm as yydm,e.yymc as yymc,
           sum(nvl(f.sjpfje,0)) as pfjezj,count(distinct nvl( f.zpaid,0)) as pas
           from tb_bxgsxx a,tb_ttxx b,tb_bdxx c,tb_cpxx d,tb_yyxx e,tb_zpaxx f,tb_cpzrdzb g,tb_lpfpxx h,/*tb_bdcpxx i,*/tb_lpajxx k,tb_lppcxx j,tb_fdxx m
            where a.bxgsid = j.bxgsid
            and f.ajid = k.ajid
            and h.ajid = f.ajid
            and m.khbdh = c.khbdh
            and m.ttid = b.ttid
             and j.khbdh = c.khbdh
            and a.bxgsid = c.bxgsid
            and b.ttid = c.ttid
            /*and d.cpid = i.cpid
            and c.bdid = i.bdid*/
            and e.yyid = h.yyid
            and h.fpid = f.fpid
            and f.zrid = g.zrid
            and d.cpid = g.cpid
            and k.lppcid = j.pcid
            and k.bxgsid =a.bxgsid
            and k.ttid = c.ttid
            AND NVL(F.FDID,K.FDID)=M.FDID
            and f.sjpfje <> 0
            and a.bxgsid = rec_bxgs.bxgsid
            and b.ttid = rec_tt.ttid
            and c.bdid = rec_bd.bdid
            and d.cpid = rec_cp.cpid
            and c.bdsxrq >=nvl(trim(pStartdate), 19000101)
            and c.bdzzrq >= nvl(trim(pEnddate), c.bdzzrq)
            and c.bdsxrq <=nvl(trim(pEnddate), 99991231)
            and k.jarq >= nvl(trim(POther7),19000101)
            and k.jarq <= nvl(trim(POther8),99991231)
            and EXISTS(SELECT 'X' FROM TB_LPAJXX H WHERE H.AJID=F.AJID AND AJZT IN('08','09','10'))
            group by a.bxgsbh,a.bxgsqc,b.ttbh,b.ttmc,c.khbdh,c.bdsxrq || '-' || c.bdzzrq,d.cph,d.cpmc,e.yydm,e.yymc
            order by a.bxgsbh,a.bxgsqc,b.ttbh,b.ttmc,c.khbdh,c.bdsxrq || '-' || c.bdzzrq,d.cph,d.cpmc,e.yydm,e.yymc
            )t where rownum <16 order by t.tbtth,t.pfjezj desc
            )loop

       vv_pfjezj:= rec_data.pfjezj ;
      --??????
      insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 0, cell.r, rec_data.bxgsdm);
      --??????
      insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 1, cell.r, rec_data.bxgsmc);
       --?????
     select max(e.zttbh) into  cell.content from tb_zttxx e,tb_bdxx d  where e.zttid = d.zttid and d.bdid = rec_bd.bdid;
     if cell.content is not null then
        insert into t_report_data_info (statid, sheet, col, r, content) values (cell.statid,0,2,cell.r,cell.content);
     else
        insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 2, cell.r, rec_data.tbtth);
     end if;
      --??????
     select max(e.zttmc) into  cell.content from tb_zttxx e,tb_bdxx d  where e.zttid = d.zttid and d.bdid = rec_bd.bdid;
     if cell.content is not null then
        insert into t_report_data_info (statid, sheet, col, r, content) values (cell.statid,0,3,cell.r,cell.content);
     else
     insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 3, cell.r, rec_data.ttmc);
     end if;
      --???
      insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 4, cell.r, rec_data.bdh);
      --????
      insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 5, cell.r, rec_data.bdqj);
      --????
      insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 6, cell.r, rec_data.cph);
      --????
      insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 7, cell.r, rec_data.cpmc);
      --????
    --  insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 8, cell.r, rec_data.yydm);
      --????
      insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 8, cell.r, rec_data.yymc);
      --???
      insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 9, cell.r, rec_data.pas);
      --??????
      insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 10, cell.r, rec_data.pfjezj);
      --????
      insert into t_report_data_info(statid, sheet, col, r, content)select cell.statid,0,11,cell.r,
      case when vv_zjpfje>0 then to_char(round(nvl(vv_pfjezj,0)/vv_zjpfje*100,2)) else '' end from dual;
      cell.r := cell.r+1;
    end loop;
    /*--????
    select
           sum (nvl(f.sjpfje,0)) as zjpfje into v_zjpfje
           from tb_bxgsxx a,tb_ttxx b,tb_bdxx c,tb_cpxx d,tb_yyxx e,tb_zpaxx f,tb_cpzrdzb g,tb_lpfpxx h,\*tb_bdcpxx i,*\tb_lpajxx k,tb_lppcxx j,tb_fdxx m
            where a.bxgsid = j.bxgsid
            and f.ajid = k.ajid
            and h.ajid = f.ajid
            and m.khbdh = c.khbdh
            and m.ttid = b.ttid
             and j.khbdh = c.khbdh
            and a.bxgsid = c.bxgsid
            and b.ttid = c.ttid
            \*and d.cpid = i.cpid
            and c.bdid = i.bdid*\
            and e.yyid = h.yyid
            and h.fpid = f.fpid
            and f.zrid = g.zrid
            and d.cpid = g.cpid
            and k.lppcid = j.pcid
            and k.bxgsid =a.bxgsid
            and k.ttid = c.ttid
            AND NVL(F.FDID,K.FDID)=M.FDID
            and f.sjpfje <> 0
            and a.bxgsid = rec_bxgs.bxgsid
            and b.ttid = rec_tt.ttid
            and c.bdid = rec_bd.bdid
            and d.cpid = rec_cp.cpid
             and c.bdsxrq >=nvl(trim(pStartdate), 19000101)
            and c.bdzzrq >= nvl(trim(pEnddate), c.bdzzrq)
            and c.bdsxrq <=nvl(trim(pEnddate), 99991231)
            and k.jarq >= nvl(trim(POther7),19000101)
            and k.jarq <= nvl(trim(POther8),99991231)
            and EXISTS(SELECT 'X' FROM TB_LPAJXX H WHERE H.AJID=F.AJID AND AJZT IN('08','09','10'));

      insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 6, cell.r, '?????');
     --??????
     insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 12, cell.r, v_zjpfje);
     cell.r := cell.r+1;*/
   end loop;
    --????
   /* select t.pas,t.pfjezj,t.zjpfje--,decode(zjpfje,null,'0.00',0,'0.00',to_char(round(t.pfjezj*100/t.zjpfje,2),'FM90.00'))||'%' as zbfb
      into v_pas,v_pfjezj,v_zjpfje--,v_zbfb
      from(select
           sum(nvl(f.sjpfje,0)) as pfjezj,count(nvl(f.zpaid,0)) as pas,
           sum (nvl(f.sjpfje,0)) as zjpfje
           from tb_bxgsxx a,tb_ttxx b,tb_bdxx c,tb_cpxx d,tb_yyxx e,tb_zpaxx f,tb_cpzrdzb g,tb_lpfpxx h,\*tb_bdcpxx i,*\tb_lpajxx k,tb_lppcxx j,tb_fdxx m
            where a.bxgsid = j.bxgsid
            and f.ajid = k.ajid
            and h.ajid = f.ajid
            and m.khbdh = c.khbdh
            and m.ttid = b.ttid
             and j.khbdh = c.khbdh
            and a.bxgsid = c.bxgsid
            and b.ttid = c.ttid
            \*and d.cpid = i.cpid
            and c.bdid = i.bdid*\
            and e.yyid = h.yyid
            and h.fpid = f.fpid
            and f.zrid = g.zrid
            and d.cpid = g.cpid
            and k.lppcid = j.pcid
            and k.bxgsid =a.bxgsid
            and k.ttid = c.ttid
            AND NVL(F.FDID,K.FDID)=M.FDID
            and f.sjpfje <> 0
           -- and a.bxgsid = rec_bxgs.bxgsid
            --and b.ttid = rec_tt.ttid
            and c.bdid = rec_bd.bdid
            --and d.cpid = rec_cp.cpid
             and c.bdsxrq >=nvl(trim(pStartdate), 19000101)
         and c.bdzzrq >= nvl(trim(pEnddate), c.bdzzrq)         and c.bdsxrq <=nvl(trim(pEnddate), 99991231)
             and k.jarq >= nvl(trim(POther7),19000101)
            and k.jarq <= nvl(trim(POther8),99991231)
            and EXISTS(SELECT 'X' FROM TB_LPAJXX H WHERE H.AJID=F.AJID AND AJZT IN('08','09','10'))
            )t;
      if (v_pas <> 0 ) then
      insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 4, cell.r, '?????');
      --???
      insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 10, cell.r, v_pas);
      --??????
      insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 11, cell.r, v_pfjezj);
      --??????
      insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 12, cell.r, v_zjpfje);
      --????
      --insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 11, cell.r, v_zbfb);
      cell.r := cell.r+1;
      end if;*/
    end loop;
    --????
    /*select t.pas,t.pfjezj,t.zjpfje--,decode(zjpfje,null,'0.00',0,'0.00',to_char(round(t.pfjezj*100/t.zjpfje,2),'FM90.00'))||'%' as zbfb
      into v_pas,v_pfjezj,v_zjpfje--,v_zbfb
      from(select
           sum(nvl(f.sjpfje,0)) as pfjezj,count(nvl(f.zpaid,0)) as pas,
           sum (nvl(f.sjpfje,0)) as zjpfje
           from tb_bxgsxx a,tb_ttxx b,tb_bdxx c,tb_cpxx d,tb_yyxx e,tb_zpaxx f,tb_cpzrdzb g,tb_lpfpxx h,\*tb_bdcpxx i,*\tb_lpajxx k,tb_lppcxx j,tb_fdxx m
            where a.bxgsid = j.bxgsid
            and f.ajid = k.ajid
            and h.ajid = f.ajid
            and m.khbdh = c.khbdh
            and m.ttid = b.ttid
             and j.khbdh = c.khbdh
            and a.bxgsid = c.bxgsid
            and b.ttid = c.ttid
            \*and d.cpid = i.cpid
            and c.bdid = i.bdid*\
            and e.yyid = h.yyid
            and h.fpid = f.fpid
            and f.zrid = g.zrid
            and d.cpid = g.cpid
            and k.lppcid = j.pcid
            and k.bxgsid =a.bxgsid
            and k.ttid = c.ttid
            AND NVL(F.FDID,K.FDID)=M.FDID
            and f.sjpfje <> 0
            and a.bxgsid = rec_bxgs.bxgsid
            and b.ttid = rec_tt.ttid
           -- and c.bdid = rec_bd.bdid
            --and d.cpid = rec_cp.cpid
             and c.bdsxrq >=nvl(trim(pStartdate), 19000101)
             and c.bdzzrq >= nvl(trim(pEnddate), c.bdzzrq)
             and c.bdsxrq <=nvl(trim(pEnddate), 99991231)
             and k.jarq >= nvl(trim(POther7),19000101)
            and k.jarq <= nvl(trim(POther8),99991231)
            and EXISTS(SELECT 'X' FROM TB_LPAJXX H WHERE H.AJID=F.AJID AND AJZT IN('08','09','10'))
            )t;
      if (v_pas <> 0) then
      insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 2, cell.r, '?????');
      --???
      insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 10, cell.r, v_pas);
      --??????
      insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 11, cell.r, v_pfjezj);
      --??????
      insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 12, cell.r, v_zjpfje);
      --????
      --insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 11, cell.r, v_zbfb);
      cell.r := cell.r+1;
      end if ;*/
    end loop;

    --??????
    /*select t.pas,t.pfjezj,t.zjpfje--,decode(zjpfje,null,'0.00',0,'0.00',to_char(round(t.pfjezj*100/t.zjpfje,2),'FM90.00'))||'%' as zbfb
      into v_pas,v_pfjezj,v_zjpfje--,v_zbfb
      from(select
           sum(nvl(f.sjpfje,0)) as pfjezj,count(nvl(f.zpaid,0)) as pas,
           sum (nvl(f.sjpfje,0)) as zjpfje
           from tb_bxgsxx a,tb_ttxx b,tb_bdxx c,tb_cpxx d,tb_yyxx e,tb_zpaxx f,tb_cpzrdzb g,tb_lpfpxx h,\*tb_bdcpxx i,*\tb_lpajxx k,tb_lppcxx j,tb_fdxx m
            where a.bxgsid = j.bxgsid
            and f.ajid = k.ajid
            and h.ajid = f.ajid
            and m.khbdh = c.khbdh
            and m.ttid = b.ttid
             and j.khbdh = c.khbdh
            and a.bxgsid = c.bxgsid
            and b.ttid = c.ttid
            \*and d.cpid = i.cpid
            and c.bdid = i.bdid*\
            and e.yyid = h.yyid
            and h.fpid = f.fpid
            and f.zrid = g.zrid
            and d.cpid = g.cpid
            and k.lppcid = j.pcid
            and k.bxgsid =a.bxgsid
            and k.ttid = c.ttid
            AND NVL(F.FDID,K.FDID)=M.FDID
            and f.sjpfje <> 0
            and a.bxgsid = rec_bxgs.bxgsid
            --and b.ttid = rec_tt.ttid
            --and c.bdid = rec_bd.bdid
            --and d.cpid = rec_cp.cpid
             and c.bdsxrq >=nvl(trim(pStartdate), 19000101)
             and c.bdzzrq >= nvl(trim(pEnddate), c.bdzzrq)
             and c.bdsxrq <=nvl(trim(pEnddate), 99991231)
             and k.jarq >= nvl(trim(POther7),19000101)
            and k.jarq <= nvl(trim(POther8),99991231)
            and EXISTS(SELECT 'X' FROM TB_LPAJXX H WHERE H.AJID=F.AJID AND AJZT IN('08','09','10'))
            )t;
      insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 0, cell.r, '???????');
      if (v_pas <> 0 ) then
      --???
      insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 10, cell.r, v_pas);
      --??????
      insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 11, cell.r, v_pfjezj);
      --??????
      insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 12, cell.r, v_zjpfje);
      --????
      --insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 11, cell.r, v_zbfb);
      cell.r := cell.r +1;
      end if;*/
    end loop;

    --???????????
  /*9.??*/
  PReturnCode := '0'; /* ??????????????vstatid????????? */
  PReturnMsg  := vstatid;
  DBMS_OUTPUT.PUT_LINE('[LDS debug] ' || 'PReturncode= ' || PReturnCode);
  --COMMIT; ???java?????????

EXCEPTION
  WHEN OTHERS THEN
    --rollback;???java?????????????0?????????????????
    PReturnCode := 'E'; /*  ??????  */
    DBMS_OUTPUT.PUT_LINE('[yhs debug] ' || 'PReturncode= ' || PReturnCode);
    PReturnMsg := ' rownum' || cell.r || 'Error:' || sqlerrm; --???????????
    DBMS_OUTPUT.PUT_LINE(PReturnMsg);
end SP_P1_30023;

/
