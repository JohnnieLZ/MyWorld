CREATE procedure SP_CHECK_ZPABE(PIN_ZPAID IN varCHAR2,Pin_userid IN varCHAR2 ,PReturnCode OUT varchar2,
                              PReturnMsg    OUT varchar2) AS
      v_no number:=0; --计数变量
      v_error_flag number:=0; --是否有触发悬挂
      v_ajxgdm varchar2(512):='';
      v_sumpfje number(16,2):=0; --之前已累计的赔付
      v_zrbe number(16,2):=0;
      rec_fdzrmx TB_fdzrmx%rowtype;
      rec_zpaxx TB_zpaxx%rowtype;
      rec_ajxx TB_lpajxx%rowtype;
      v_tempstr varchar2(500):='';--临时字符串变量
      v_pos number:=0; --记录字符串查找当前位置
       v_fphm varchar2(30):='';
       v_fpzs number:=0;--发票张数计数器
       v_pppfje  number(16,2):=0.00;--v1.5++ 公共保额应赔付金额
       rec_zrxx TB_zrxx%rowtype;--v1.5++ 公共保额应赔付责任
       rec_fdxx TB_fdxx%rowtype;--v2.0++ 分单公共账户余额信息
 begin
    PReturnCode:='E';
    PReturnMsg:='Error!';  
   /*  检查子赔案对应责任保额是否已经赔满
   （1）如果已满，并且是系统理算，则子赔案设置CL23、保额已经赔满 悬挂代码和描述，
    （2）如果有部分剩余保额，系统定义结论为“部分赔付”，选择结论说明为“X56”，实际赔付金额为剩余保额，全部金额超保额的定义
    为“拒付”，选择结论说明为“X56”，赔付金额0；
    （3）如果是人工理算，系统提示：保额已经赔满；*/
    select * into rec_zpaxx from tb_zpaxx where zpaid=to_number(trim(PIN_ZPAID));
    select * into rec_fdzrmx from tb_fdzrmx where zrid=rec_zpaxx.zrid and fdid=(select fdid from tb_lpajxx where ajid=rec_zpaxx.ajid) and rownum<2;
    select * into rec_ajxx from TB_lpajxx where ajid=rec_zpaxx.ajid; --v1.3--
    select ajid,bbrkhid,khbdh,ttid,zttid,(select ttbh from tb_ttxx where ttid=a.ttid) as GLAJH,(select nvl(ggbe,0)  from tb_bdxx where  khbdh=rec_ajxx.khbdh) 
        into rec_ajxx.ajid,rec_ajxx.bbrkhid, rec_ajxx.khbdh,rec_ajxx.ttid,rec_ajxx.zttid,rec_ajxx.GLAJH,rec_ajxx.ajpfje
    from TB_lpajxx a where ajid=rec_zpaxx.ajid; --v1.3++
    if nvl(rec_fdzrmx.zrbe ,0)=0 or rec_fdzrmx.BELX='2'  then
           select nvl(yx,0)*nvl(rec_fdzrmx.yxbs,0) into rec_fdzrmx.ZRBE from tb_khxx where khid=rec_ajxx.bbrkhid;
           if  rec_fdzrmx.ZRBE <nvl(rec_fdzrmx.zdbe,0) and rec_fdzrmx.BELX='2' then
                  rec_fdzrmx.ZRBE :=rec_fdzrmx.zdbe;
                end if;
                if   rec_fdzrmx.zgbe is not null and  rec_fdzrmx.ZRBE>rec_fdzrmx.zgbe and rec_fdzrmx.BELX='2' then
                    rec_fdzrmx.ZRBE :=rec_fdzrmx.zgbe;
                end if;       
    end if;
    --取下子赔案赔付责任的责任分类代码，以便识别是否是公共保额类责任
    select zrfldm into rec_zrxx.zrfldm from tb_zrxx where zrid=rec_zpaxx.zrid;
    if rec_fdzrmx.BELX in('0','2') /*v1.5++ begin*/ and rec_zrxx.zrfldm not like 'PP%' /*v1.5++ end*/ then --按元 或月薪计算的直接统计赔付额校验   
        --select nvl(sum(nvl(a.SJPFJE,0)),0) into  v_sumpfje from tb_zpaxx a,tb_lpajxx b where a.ajid=b.ajid and a.zpaid!=to_number(trim(PIN_ZPAID))  --v1.1--
        select nvl(sum(nvl(a.SJPFJE,0)),0) into  v_sumpfje from tb_zpaxx a,tb_lpajxx b where a.ajid=b.ajid and a.zpaid<to_number(trim(PIN_ZPAID)) --v1.1++
           and nvl(a.zpajl,'01')!='02' and a.zrid=rec_zpaxx.zrid and b.bbrkhid=rec_ajxx.bbrkhid and b.khbdh=rec_ajxx.khbdh;           
        if  v_sumpfje>= rec_fdzrmx.zrbe then
            update tb_zpaxx a set a.xgdm= case when trim(a.xgdm) is null then 'CL23' else a.xgdm||',CL23' end,a.sjpfje=0 where a.zpaid=rec_zpaxx.zpaid
            and not exists(select 'x' from tb_zpaxx b where b.zpaid=a.zpaid and xgdm like '%CL23%');
        end if ;
        if   v_sumpfje<rec_fdzrmx.zrbe and (v_sumpfje+nvl(rec_zpaxx.sjpfje,0))> rec_fdzrmx.zrbe  then
            update tb_zpaxx a set a.xgdm=case when exists(select 'x' from tb_zpaxx b where b.zpaid=a.zpaid and xgdm like '%CL23%') then a.xgdm else a.xgdm||decode(a.xgdm,'','CL23',',CL23') end,
              a.sjpfje=rec_fdzrmx.zrbe-v_sumpfje,JLSM1='X56'
             where a.zpaid=rec_zpaxx.zpaid;           
        end if ;
        /*v1.5++begin */
        select nvl(count(1),0) into v_no  from tb_lpajxx a ,tb_zpaxx b,tb_zrxx c where a.ajid=b.ajid and b.zpaid=rec_zpaxx.zpaid and b.zrid=c.zrid /* and a.sqlx like '%S7%' */
         and b.xgdm like '%CL23%'  and b.fpid is not null and exists(  select 'x' from tb_zrxx e,tb_fdzrmx f where e.zrid=f.zrid and f.fdid=b.fdid and e.ZRFLDM like 'PP%');
         if v_no>0 then
              select e.* into rec_zrxx from tb_zrxx e,tb_fdzrmx f where e.zrid=f.zrid and f.fdid=rec_zpaxx.fdid and e.ZRfldM like 'PP%' and rownum<2;
              /*v2.5++begin 取个人公共责任的保额及之前已用过的累计赔付额*/
              select f.zrbe into rec_zrxx.bedw from tb_zrxx e,tb_fdzrmx f where e.zrid=f.zrid and f.fdid=rec_zpaxx.fdid and e.ZRfldM like 'PP%' and rownum<2; /*v2.5++*/
              select nvl(sum(nvl(a.SJPFJE,0)),0) into  v_sumpfje from tb_zpaxx a,tb_lpajxx b where a.ajid=b.ajid and a.zpaid<to_number(trim(PIN_ZPAID)) 
                and nvl(a.zpajl,'01')!='02' and a.zrid=rec_zrxx.zrid and b.bbrkhid=rec_ajxx.bbrkhid and b.khbdh=rec_ajxx.khbdh;             
              /*v2.5++end*/
              select rec_zpaxx.sjpfje-nvl(b.sjpfje,0),JLSM1 into v_pppfje, rec_zpaxx.JLSM1 from tb_zpaxx b where b.zpaid=rec_zpaxx.zpaid ;
              if nvl( rec_zpaxx.JLSM1,'xxxxxx')  like  '%X56%' then 
                   /*v2.1++ begin 新增赔案后，后面公共保额责任的子赔案再需要保额控制，将zpaid切换到新生成的子赔案*/
                     select seq_ZPAID.nextval as zpaid into v_pos from dual;                      
                   /*v2.1++ end*/    
                      insert into tb_zpaxx( ZPAID     ,--NUMBER(16)                      子赔案ID  
                  AJID      ,--NUMBER(16)                      案件ID    
                  ZPAH      ,--VARCHAR2(30)   Y                子赔案编号 
                  JBID      ,--NUMBER(16)     Y                疾病ID    
                  ZDDM      ,--VARCHAR2(20)   Y                诊断代码  
                  ZRID      ,--NUMBER(16)                      责任ID    
                  PFZRDM    ,--VARCHAR2(10)   Y                赔付责任代码 
                  ZDZJE     ,--NUMBER(16,2)   Y                账单总金额 
                  SBZFZJE   ,--NUMBER(16,2)   Y                社保支付总金额 
                  ZFJE      ,--NUMBER(16,2)   Y                自费金额  
                  FLZFJE    ,--NUMBER(16,2)   Y                分类自负金额 
                  QTDSFZFJE ,--NUMBER(16,2)   Y                其他第三方支付金额 
                  BHLFY     ,--NUMBER(16,2)   Y                不合理费用 
                  BXZRWJE   ,--NUMBER(16,2)   Y                保险责任外金额 
                  XLLSPFJE  ,--NUMBER(16,2)   Y                系统理算赔付金额 
                  RGTZJE    ,--NUMBER(16,2)   Y                人工调整金额 
                  SJPFJE    ,--NUMBER(16,2)   Y                实际赔付金额 
                  MPE       ,--NUMBER(16,2)   Y                免赔额    
                  XGDM      ,--VARCHAR2(100)  Y                悬挂代码  
                  XGDMMS    ,--VARCHAR2(1024) Y                悬挂代码描述 
                  ZT        ,--VARCHAR2(1)    Y                状态      
                  ZPAJL     ,--VARCHAR2(2)    Y                子赔案结论 
                  JLSM1     ,--VARCHAR2(10)   Y                结论说明1 
                  JLSM2     ,--VARCHAR2(500)  Y                结论说明2 
                  SHYYJ     ,--VARCHAR2(200)  Y                审核员意见 
                  SJGFTS    ,--NUMBER         Y                实际可理算天数 
                  SSXM      ,--VARCHAR2(30)   Y                手术项目  
                  SSPFBL    ,--NUMBER(5,2)    Y                手术赔付比例 
                  MPTS      ,--NUMBER         Y                免赔天数  
                  SFSDTJ    ,--VARCHAR2(1)             '0'     是否手动添加 
                  LSSJ      ,--DATE           Y                理算时间  
                  SYFPH     ,--VARCHAR2(500)  Y                所有发票号 
                  FPID      ,--NUMBER(16)     Y                发票ID    
                  SEQLOGID  ,--NUMBER         Y                          
                  FDID      ,--NUMBER(16)     Y                责任对应分单 
                  SBBDX     ,--VARCHAR2(1)    Y                社保比大小情况 
                  CDEJE  )    --NUMBER(16,2)   Y                超大额金额  
                  select   /*v2.1--seq_ZPAID.nextval*//*v2.1++begin*/v_pos /*v2.1++end*/ as zpaid     ,--NUMBER(16)                      子赔案ID  
                  b.ajid as ajid      ,--NUMBER(16)                      案件ID    
                  (select pah from tb_lpajxx where ajid=b.ajid)||ltrim(rtrim(to_char(nvl((select count(1) from tb_zpaxx where ajid=b.ajid),0)+1,'099'))) as ZPAH      ,--VARCHAR2(30)   Y                子赔案编号 
                  b.jbid as JBID ,--NUMBER(16)     Y                疾病ID    
                  b.ZDDM      ,--VARCHAR2(20)   Y                诊断代码  
                  rec_zrxx.ZRID      ,--NUMBER(16)               责任ID    
                  rec_zrxx.zrbm PFZRDM    ,--VARCHAR2(10)   Y    赔付责任代码  
                  b.ZDZJE     ,--NUMBER(16,2)   Y                账单总金额 
                  b.SBZFZJE   ,--NUMBER(16,2)   Y                社保支付总金额 
                  b.ZFJE      ,--NUMBER(16,2)   Y                自费金额   ,
                  b.FLZFJE    ,--NUMBER(16,2)   Y                分类自负金额 
                  b.QTDSFZFJE ,--NUMBER(16,2)   Y                其他第三方支付金额 
                  b.BHLFY     ,--NUMBER(16,2)   Y                不合理费用 
                  b.BXZRWJE   ,--NUMBER(16,2)   Y                保险责任外金额 
                  b.XLLSPFJE  ,--NUMBER(16,2)   Y                系统理算赔付金额 
                  null as RGTZJE    ,--NUMBER(16,2)   Y                人工调整金额 
                  /*v2.5--v_pppfje*//*v2.5++begin 和个人责任允许的公共保额比对*/                   
                  decode(sign(v_pppfje-(rec_zrxx.bedw-v_sumpfje)),1,case when rec_zrxx.bedw-v_sumpfje<=0 then 0 else rec_zrxx.bedw-v_sumpfje end,v_pppfje)
                  /*v2.5++end*/ as SJPFJE    ,--NUMBER(16,2)   Y                实际赔付金额 
                  '' MPE       ,--NUMBER(16,2)   Y                免赔额    
                  'CL9A' as XGDM      ,--VARCHAR2(100)  Y                悬挂代码  
                  '申请类型有公共保额，请人工调整公共保额赔付金额' XGDMMS    ,--VARCHAR2(1024) Y                悬挂代码描述 
                  '1' ZT        ,--VARCHAR2(1)    Y                状态      
                  '01' ZPAJL     ,--VARCHAR2(2)    Y                子赔案结论 
                  '' JLSM1     ,--VARCHAR2(10)   Y                结论说明1 
                  '' JLSM2     ,--VARCHAR2(500)  Y                结论说明2 
                  '' SHYYJ     ,--VARCHAR2(200)  Y                审核员意见 
                  SJGFTS    ,--NUMBER         Y                实际可理算天数 
                  b.SSXM      ,--VARCHAR2(30)   Y                手术项目  
                  b.SSPFBL    ,--NUMBER(5,2)    Y                手术赔付比例 
                  b.MPTS      ,--NUMBER         Y                免赔天数  
                  b.SFSDTJ    ,--VARCHAR2(1)             '0'     是否手动添加 
                  b.LSSJ      ,--DATE           Y                理算时间  
                  b.SYFPH     ,--VARCHAR2(500)  Y                所有发票号 
                  b.FPID      ,--NUMBER(16)     Y                发票ID    
                  -b.zpaid as SEQLOGID  ,--NUMBER         Y                          
                  b.FDID      ,--NUMBER(16)     Y                责任对应分单 
                  b.SBBDX     ,--VARCHAR2(1)    Y                社保比大小情况 
                  b.CDEJE     --NUMBER(16,2)   Y                超大额金额
                   from tb_zpaxx b 
                      where b.zpaid =rec_zpaxx.zpaid and not exists(select 'x' from tb_zpaxx c where c.ajid=b.ajid and /*c.pfzrdm like 'PP%'*/c.zrid=rec_zrxx.zrid and nvl(sjpfje,0)>0);                     
                      /*v2.1++ begin 新增赔案后，后面公共保额责任的子赔案再需要保额控制，将zpaid切换到新生成的子赔案*/
                   rec_zpaxx.zpaid:= v_pos ;                     
                   /*v2.1++ end*/
             else --全部赔到公共保额的，直接修改原来子赔案的赔付责任
                    update tb_zpaxx b set b.zrid=rec_zrxx.zrid,PFZRDM=rec_zrxx.zrbm,xgdm=case when instr(b.xgdm,'CL9A')>0 then b.xgdm
                                                                     else DECODE(b.xgdm,null,'CL9A','','CL9A',b.xgdm||',CL9A') end ,
                                                                     XGDMMS='申请类型有公共保额，请人工调整公共保额赔付金额' ,/*v2.5--sjpfje=b.xllspfje-nvl(b.rgtzje,0),*/zpajl='01'
                                                                     /*v2.5++begin 和个人公共保额责任的保额比对，不能超过总保额*/ 
                                                                     ,sjpfje=decode(sign(b.xllspfje-nvl(b.rgtzje,0)-(rec_zrxx.bedw-v_sumpfje)),1,case when (rec_zrxx.bedw-v_sumpfje)<=0 then 0 else rec_zrxx.bedw-v_sumpfje end,b.xllspfje-nvl(b.rgtzje,0))
                    where b.zpaid =rec_zpaxx.zpaid and not exists(select 'x' from tb_zpaxx c where c.ajid=b.ajid and /*c.pfzrdm like 'PP%'*/c.zrid=rec_zrxx.zrid and nvl(sjpfje,0)>0);             
                    --去掉原来CL23悬挂
                 update tb_zpaxx b set b.xgdm=replace(replace(replace(b.xgdm, ',CL23', ''), 'CL23,', ''),'CL23', '')  where b.zpaid =rec_zpaxx.zpaid ;
            end if;
         end if;         
        /*v1.5++end */
        if v_sumpfje>= rec_fdzrmx.zrbe and trim(Pin_userid) is not null then
            if rec_zpaxx.zpajl!='02' then
              PReturnCode:='-23';
              PReturnMsg:='客户id'||rec_ajxx.bbrkhid||'保额已赔满，不能赔付!如该子赔案赔付，则累计赔付额将达到:'||to_char(v_sumpfje);
              return;
             end if;
        else
              update tb_zpaxx a set a.xgdm=replace(replace(a.xgdm,'CL23,',''),'CL23','')
              where a.zpaid=rec_zpaxx.zpaid and xgdm like '%CL23%';       
        end if;
    end if;
    if rec_fdzrmx.BELX in('1') /*v1.5++ begin*/ and rec_zrxx.zrfldm not like 'PP%' /*v1.5++ end*/then --按元/天计算的，去津贴类理算规则设置那取到最高赔付额，再比较  
        select nvl(max(zgbe),0) into rec_fdzrmx.zrbe from TB_BDZRFYLLSGZPZ where bdid in(select bdid from tb_bdxx where khbdh=rec_ajxx.khbdh) and zrid=rec_zpaxx.zrid and yxzt='1' and rownum<2; 
     --  select sum(nvl(a.SJPFJE,0)) into  v_sumpfje from tb_zpaxx a,tb_lpajxx b where a.ajid=b.ajid and a.zpaid!=to_number(trim(PIN_ZPAID)) --v1.1--
     select sum(nvl(a.SJPFJE,0)) into  v_sumpfje from tb_zpaxx a,tb_lpajxx b where a.ajid=b.ajid and a.zpaid<to_number(trim(PIN_ZPAID)) --v1.1++
           and nvl(a.zpajl,'01')!='02' and a.zrid=rec_zpaxx.zrid and b.bbrkhid=rec_ajxx.bbrkhid and b.khbdh=rec_ajxx.khbdh;    
               
        if  v_sumpfje>= rec_fdzrmx.zrbe then
            update tb_zpaxx a set a.xgdm= case when trim(a.xgdm) is null then 'CL23' else a.xgdm||',CL23' end,a.sjpfje=0 where a.zpaid=rec_zpaxx.zpaid
            and not exists(select 'x' from tb_zpaxx b where b.zpaid=a.zpaid and xgdm like '%CL23%');
        end if ;
        if   v_sumpfje<rec_fdzrmx.zrbe and (v_sumpfje+nvl(rec_zpaxx.sjpfje,0))> rec_fdzrmx.zrbe  then
            update tb_zpaxx a set a.xgdm=case when exists(select 'x' from tb_zpaxx b where b.zpaid=a.zpaid and xgdm like '%CL23%') then a.xgdm else a.xgdm||decode(a.xgdm,'','CL23',',CL23') end,
              a.sjpfje=rec_fdzrmx.zrbe-v_sumpfje,JLSM1='X56'
             where a.zpaid=rec_zpaxx.zpaid;           
        end if ;
        if v_sumpfje>= rec_fdzrmx.zrbe and trim(Pin_userid) is not null then
            if rec_zpaxx.zpajl!='02' then
              PReturnCode:='-23';
              PReturnMsg:='客户id'||rec_ajxx.bbrkhid||'保额已赔满，不能赔付!';
              return;
             else
                null;
            end if;
         else
              update tb_zpaxx a set a.xgdm=replace(replace(a.xgdm,'CL23,',''),'CL23','')
              where a.zpaid=rec_zpaxx.zpaid and xgdm like '%CL23%';    
        end if;
    end if;
    --公共保额类责任验证

   if  rec_zrxx.zrfldm like 'PP%'  then   --v1.3++
          select sum(nvl(a.SJPFJE,0)) into  v_sumpfje from tb_zpaxx a,tb_lpajxx b where a.ajid=b.ajid and a.zpaid<to_number(trim(PIN_ZPAID)) 
           and nvl(a.zpajl,'01')!='02' and a.zrid=/*v2.1--rec_ajxx.zrid*//*v2.1++*/rec_zrxx.zrid/*v2.1++*/ and  b.khbdh=rec_ajxx.khbdh;    
         --取公共保额
         select nvl(ggbe,0) into rec_fdzrmx.zrbe from tb_bdxx where  khbdh=rec_ajxx.khbdh   ;
        if  v_sumpfje>= rec_fdzrmx.zrbe then
            update tb_zpaxx a set a.xgdm= case when trim(a.xgdm) is null then 'CL23' else a.xgdm||',CL23' end,a.sjpfje=0 where a.zpaid=rec_zpaxx.zpaid
            and not exists(select 'x' from tb_zpaxx b where b.zpaid=a.zpaid and xgdm like '%CL23%');
        end if ;
        if   v_sumpfje<rec_fdzrmx.zrbe and (v_sumpfje+nvl(rec_zpaxx.sjpfje,0))> rec_fdzrmx.zrbe  then
            update tb_zpaxx a set a.xgdm=case when exists(select 'x' from tb_zpaxx b where b.zpaid=a.zpaid and xgdm like '%CL23%') then a.xgdm else a.xgdm||decode(a.xgdm,'','CL23',',CL23') end,
              a.sjpfje=rec_fdzrmx.zrbe-v_sumpfje,JLSM1='X56'
             where a.zpaid=rec_zpaxx.zpaid;           
        end if ;
        if v_sumpfje>= rec_fdzrmx.zrbe and trim(Pin_userid) is not null then         
            PReturnCode:='-23';
            PReturnMsg:='客户id'||rec_ajxx.bbrkhid||'公共保额已赔满，不能赔付!';
            return;
        end if;
    end if;
    -- if  rec_zpaxx.pfzrdm like 'PP%' then   --v1.3 --
    /*if  (rec_ajxx.GLAJH='TPYRS' and rec_ajxx.ajpfje>0) then   --v1.3++
          select sum(nvl(a.SJPFJE,0)) into  v_sumpfje from tb_zpaxx a,tb_lpajxx b where a.ajid=b.ajid and a.zpaid<to_number(trim(PIN_ZPAID)) 
           and nvl(a.zpajl,'01')!='02' and  b.khbdh=rec_ajxx.khbdh;    
         --取公共保额
         select nvl(ggbe,0) into rec_fdzrmx.zrbe from tb_bdxx where  khbdh=rec_ajxx.khbdh   ;
        if  v_sumpfje>= rec_fdzrmx.zrbe then
            update tb_zpaxx a set a.xgdm= case when trim(a.xgdm) is null then 'CL96' else a.xgdm||',CL96' end,a.sjpfje=0 where a.zpaid=rec_zpaxx.zpaid
            and not exists(select 'x' from tb_zpaxx b where b.zpaid=a.zpaid and xgdm like '%CL96%');
        end if ;
        if   v_sumpfje<rec_fdzrmx.zrbe and (v_sumpfje+nvl(rec_zpaxx.sjpfje,0))> rec_fdzrmx.zrbe  then
            update tb_zpaxx a set a.xgdm=case when exists(select 'x' from tb_zpaxx b where b.zpaid=a.zpaid and xgdm like '%CL96%') then a.xgdm else a.xgdm||decode(a.xgdm,'','CL96',',CL96') end,
              a.sjpfje=rec_fdzrmx.zrbe-v_sumpfje,JLSM1='X56'
             where a.zpaid=rec_zpaxx.zpaid;           
        end if ;
        if v_sumpfje>= rec_fdzrmx.zrbe and trim(Pin_userid) is not null then         
            PReturnCode:='-23';
            PReturnMsg:='客户id'||rec_ajxx.bbrkhid||'公共保额已赔满，不能赔付!';
            return;
        end if;
    end if;*/
    --v2.0++ begin
     select * into rec_fdxx from TB_fdxx where fdid=nvl(rec_zpaxx.fdid,rec_ajxx.fdid); --v1.3--
     if rec_fdxx.FDZHYE is not null and rec_fdxx.FDZHYE>0 then
         select nvl(sum(nvl(sjpfje,0)),0) into v_sumpfje from TB_ZPAXX b,tb_lpajxx c where b.ajid=c.ajid 
                                  and c.BBRKHID=rec_ajxx.BBRKHID and c.KHBDH =rec_ajxx.khbdh
                                  and b.fdid=rec_zpaxx.fdid 
                                  and nvl(b.zpajl,'01')!='02'  and b.zpaid<rec_zpaxx.zpaid;
         
         if  v_sumpfje>= rec_fdxx.fdzhye then
            update tb_zpaxx a set a.xgdm= case when trim(a.xgdm) is null then 'CL23' else a.xgdm||',CL23' end,a.sjpfje=0 where a.zpaid=rec_zpaxx.zpaid
            and not exists(select 'x' from tb_zpaxx b where b.zpaid=a.zpaid and xgdm like '%CL23%');
        end if ;
        if   v_sumpfje<rec_fdxx.fdzhye and (v_sumpfje+nvl(rec_zpaxx.sjpfje,0))> rec_fdxx.fdzhye  then
            update tb_zpaxx a set a.xgdm=case when exists(select 'x' from tb_zpaxx b where b.zpaid=a.zpaid and xgdm like '%CL23%') then a.xgdm else a.xgdm||decode(a.xgdm,'','CL23',',CL23') end,
              a.sjpfje=rec_fdxx.fdzhye-v_sumpfje,JLSM1='X56'
             where a.zpaid=rec_zpaxx.zpaid;           
        end if ;
        if v_sumpfje>= rec_fdxx.fdzhye and trim(Pin_userid) is not null then
            if rec_zpaxx.zpajl!='02' then
              PReturnCode:='-23';
              PReturnMsg:='客户id'||rec_ajxx.bbrkhid||'分单账户余额已赔满，不能赔付!';
              return;
             else
                null;
            end if;
         else
              update tb_zpaxx a set a.xgdm=replace(replace(a.xgdm,'CL23,',''),'CL23','')
              where a.zpaid=rec_zpaxx.zpaid and xgdm like '%CL23%';    
        end if;                         
      end if;                          
    --v2.0++ end
   --检查该被保险人的历史赔案或同一案件中是否出现过与该子赔案相同的发票,根据子赔案对应的发票号找begin--（检查规则 同一医院、同诊断、同就诊日期、同金额）；
   v_no:=0;
   v_tempstr:=rec_zpaxx.syfph;
   v_pos:=1;
   v_fpzs:=0;
   if v_tempstr is not null  then
   
        if  instr(v_tempstr,',')=0 then
            v_fphm:=v_tempstr;
             select count(1) into v_no from tb_lpfpxx a,tb_lpajxx b where  a.ajid=b.ajid 
                   and  a.fphm=v_fphm and b.bbrkhid=rec_ajxx.bbrkhid /*and exists(
                   --select 'x' from tb_zpaxx c where c.ajid=b.ajid and c.fpid=a.fpid and nvl(c.zpajl,'01')!='02'); v.1.1--                
                   select 'x' from tb_zpaxx c,tb_fpxxfyxx d,tb_zpaxxdzb e where c.zpaid=e.zpaid and d.xxid=e.xxid and c.ajid=b.ajid and d.fpid=a.fpid and nvl(c.zpajl,'01')!='02')*/;  --  v.1.1++
                if v_no>1 then
                    update tb_zpaxx a set a.xgdm= case when trim(a.xgdm) is null then 'CL24' else a.xgdm||',CL24' end where a.zpaid=rec_zpaxx.zpaid
                        and not exists(select 'x' from tb_zpaxx b where b.zpaid=a.zpaid and xgdm like '%CL24%');                        
                end if;
        else
            loop
               if instr(v_tempstr,',',1,v_fpzs+1)>0 then
                  v_fphm:=substr(v_tempstr,v_pos,instr(v_tempstr,',',1,v_fpzs+1)-v_pos);
                else
                  v_fphm:=substr(v_tempstr,v_pos,lengthb(v_tempstr)-v_pos+1);
               end if;
             --  select substr(v_tempstr,v_pos+1,case when  instr(v_tempstr,',',v_pos+1,1)>0 then instr(v_tempstr,',',v_pos+1,1)-1 else lengthb(v_tempstr)-v_pos end) into v_fphm from dual;               
               select count(1) into v_no from tb_lpfpxx a,tb_lpajxx b where  a.ajid=b.ajid 
                   and  a.fphm=v_fphm and b.bbrkhid=rec_ajxx.bbrkhid /*and exists(
                  -- select 'x' from tb_zpaxx c where c.ajid=b.ajid and c.fpid=a.fpid and nvl(c.zpajl,'01')!='02');     
                  select 'x' from tb_zpaxx c,tb_fpxxfyxx d,tb_zpaxxdzb e where c.zpaid=e.zpaid and d.xxid=e.xxid and c.ajid=b.ajid and d.fpid=a.fpid and nvl(c.zpajl,'01')!='02')*/;  --  v.1.1++              
                if    v_no>1 then
                    update tb_zpaxx a set a.xgdm= case when trim(a.xgdm) is null then 'CL24' else a.xgdm||',CL24' end where a.zpaid=rec_zpaxx.zpaid
                        and not exists(select 'x' from tb_zpaxx b where b.zpaid=a.zpaid and xgdm like '%CL24%');
                        exit;
                end if;
                if instr(v_tempstr,',',1,v_fpzs+1)=0 then
                    exit;
                end if ;
                v_pos:=instr(v_tempstr,',',1,v_fpzs+1)+1;
                v_fpzs:=v_fpzs+1;                
             end loop;
        end if;
   end if;
    --检查该被保险人的历史赔案或同一案件中是否出现过与该子赔案相同的发票,根据子赔案对应的发票号找 end
    --?  自动理算的悬挂情况 判断子赔案对应账单类型是否为“住院”，是的子赔案设置CL25、原因：住院案件请审核的悬挂；
    if trim(Pin_userid) is null then 
        select count(1) into v_no from  tb_lpfpxx a where fpid=rec_zpaxx.fpid and a.zdlx='1';
       if v_no>0 then
          update tb_zpaxx a set a.xgdm= case when trim(a.xgdm) is null then 'CL25' else a.xgdm||',CL25' end where a.zpaid=rec_zpaxx.zpaid
            and not exists(select 'x' from tb_zpaxx b where b.zpaid=a.zpaid and xgdm like '%CL25%');
       end if;
       --判断子赔案赔付责任是否含有以下子赔案分类之一：死亡、伤残、重大疾病,涉及责任类型TERM\ADD\PCA\CI，存在的子赔案设置CL26、原因：存在非医疗险申请的悬挂
        if  rec_zpaxx.PFZRDM  like 'PCA%'  or rec_zpaxx.PFZRDM  like 'ADD%' or rec_zpaxx.PFZRDM like 'CI%' or rec_zpaxx.pfzrdm like 'TERM%' then          
             update tb_zpaxx a set a.xgdm= case when trim(a.xgdm) is null then 'CL26' else a.xgdm||',CL26' end where a.zpaid=rec_zpaxx.zpaid
            and not exists(select 'x' from tb_zpaxx b where b.zpaid=a.zpaid and xgdm like '%CL26%');
        end if;
        --判断子赔案赔付责任类型是否为MAT，是的子赔案设置CL27、原因：生育案件的悬挂
        if  rec_zpaxx.PFZRDM  like 'MAT%'  then          
             update tb_zpaxx a set a.xgdm= case when trim(a.xgdm) is null then 'CL27' else a.xgdm||',CL27' end where a.zpaid=rec_zpaxx.zpaid
            and not exists(select 'x' from tb_zpaxx b where b.zpaid=a.zpaid and xgdm like '%CL27%');
        end if;
        
    end if;   
          
    PReturnCode:='0';--校验完毕
    PReturnMsg:='check success!';  
    return;
  EXCEPTION
  WHEN OTHERS THEN
    PReturnCode := 'E';
    DBMS_OUTPUT.PUT_LINE('[yhs debug] ' || 'PReturncode= ' ||
                         PReturnCode);
    PReturnMsg := 'Error:' || sqlerrm;
    DBMS_OUTPUT.PUT_LINE(PReturnMsg);                               
end SP_CHECK_ZPABE;
/
