CREATE PROCEDURE      "SP_P1_30026" (report_id   In t_report_def_info.REPORTID%TYPE,
                                        pStartdate  IN varchar2, -- ??????yyyymmdd
                                        pEnddate    IN varchar2, -- ??????yyyymmdd
                                        pStatman    IN t_report_gen_info.STATMAN%TYPE, --???
                                        ptype       in varchar2, /*0 ???? ,1 ?? 2 ?? 3 ?? */ --?????
                                        POther1     IN varchar2, --??id
                                        POther2     IN varchar2, --??id
                                        POther3     IN varchar2, --??id
                                        POther4     IN varchar2, --??ID
                                        POther5     IN varchar2, --????
                                        POther6     IN varchar2, --??ID
                                        POther7     IN varchar2, --??
                                        POther8     IN varchar2, --??
                                        PReturnCode OUT varchar2,
                                        PReturnMsg  OUT varchar2) AS
  V_STEP_CODE  CHAR(5); --?????????????????
  vreportid    t_report_def_info.REPORTID%TYPE; --??ID
  v_start_date number := 0; --????????
  v_end_date   number := 0; --????????
  vxzqhdm      t_report_gen_info.STATORGID%TYPE; --????????????

  vstatid varchar(30); --?????????????????
  type cellType is record(
    statid  varchar2(15),
    col     number,
    r       number,
    content varchar2(1024));

  cell      cellType; --?????????????
  vdwmc     varchar2(50); --????????????
  vusername t_report_gen_info.STATMAN%TYPE; --????????
  vnd       t_report_gen_info.STATYEAR%TYPE; --????
  rowno     number := 0; --??????

  tt_khbdh varchar2(20);

  tt_tbrs number := 0;
  tt_cxrs number := 0;
  tt_cxl varchar2(10) := 0;


  gs_tbrs number := 0;
  gs_cxrs number := 0;
  gs_cxl varchar2(10) := 0;


begin
  V_STEP_CODE := '00000';
  PReturnMsg  := 'OK';
  PReturnCode := 'E';
  vreportid   := substr(report_id, 1, 5);
  vusername   := pStatman;
  vnd         := substr(pStartdate, 1, 4);

  v_start_date := to_number(substr(pStartdate, 1, 8));
  v_end_date   := to_number(substr(pEnddate, 1, 8));

  --???????????????????????????
  delete from t_report_data_info
   where statid in
         (select statid from T_REPORT_GEN_INFO where reportid = report_id);

  delete from T_REPORT_GEN_INFO
   where statid in
         (select statid from T_REPORT_GEN_INFO where reportid = report_id);

  V_STEP_CODE := '00001';
  --???,?T_RERORT_GEN_INFO?????????????
  --???????
  select seq_statid.nextval into vstatid from dual;

  -- ??????????
  insert into t_report_gen_info
    (STATID,
     REPORTID,
     STATORGID,
     STATORGNAME,
     STATDATE,
     STATMAN,
     STATYEAR,
     BEGINDATE,
     ENDDATE,
     STAT_OTHER,
     STAT_TYPE)
  values
    (vstatid,
     vreportid,
     '',
     '',
     to_char(sysdate, 'yyyymmdd'),
     vusername,
     vnd,
     v_start_date,
     v_end_date,
     substr(pEnddate, 1, 1),
     trim(ptype));

  /* --?????? ??excel???0?????1??,????0???*/

   --???
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid, 0,1, 2, 'CLFX06');

  --????
  insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,1,3,to_char(sysdate,'yyyymmdd'));

  --????
  select max(bxgsqc) into cell.content from tb_bxgsxx where bxgsid=trim(POther1);
  if cell.content is not null then
    insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,1,4,cell.content);
  end if;

  --????
  select max(ttmc) into cell.content from tb_ttxx where ttid = trim(POther2);
  if cell.content is not null then
    insert into t_report_data_info (statid, sheet, col, r, content) values (vstatid,0,1,5,cell.content);
  end if;

  --????
  select max(khbdh) into cell.content from tb_bdxx where bdid=trim(POther3);
  if trim(POther3) is not null then
    insert into t_report_data_info
      (statid, sheet, col, r, content)
    values (vstatid,0,1,6, trim( cell.content));
  end if;

  --????????
     insert into t_report_data_info(statid, sheet, col, r, content)values (vstatid,0,1,7, trim(pStartdate)||'--'||trim(pEnddate));

  cell.statid := vstatid;
  cell.col    := 0; --?1???
  cell.r      := 10; --?13???
  --???????????????????????????????excel????????????????????

  --????
  for rec_bxgs in(
       select a.bxgsid,a.bxgsbh
        from tb_bxgsxx a,tb_ttxx b,tb_bdxx c,tb_fdxx d,/*tb_bdcpxx e,*/tb_cpxx f,tb_lpajxx g,tb_zpaxx k,Tb_Cpzrdzb m
           where a.bxgsid = c.bxgsid
             and b.ttid = c.ttid
             and c.bdid = c.bdid
             and c.khbdh = d.khbdh
             /*and c.bdid = e.bdid
             and e.cpid = f.cpid*/  and f.cpid = m.cpid
             and a.bxgsid = nvl(trim(POther1),a.bxgsid)
             and b.ttid = nvl(trim(POther2),b.ttid)
             and c.bdid = nvl(trim(POther3),c.bdid)
            -- and d.zbbrkhid is not null
             and c.bxgsid = g.bxgsid
             and g.ajid = k.ajid
             and k.zrid = m.zrid
             AND C.BDSXRQ >= nvl(trim(pStartdate),C.BDSXRQ)
             AND C.BDSXRQ <= NVL(TRIM(pEnddate),C.BDSXRQ)
             AND C.BDZZRQ >= NVL(TRIM(pEnddate),C.BDZZRQ)
             /*and m.cpid = e.cpid*/
           group by a.bxgsid,a.bxgsbh
           order by a.bxgsid,a.bxgsbh
  ) loop

  for rec_ttdata in(
        select b.ttid
        from tb_bxgsxx a,tb_ttxx b,tb_bdxx c,tb_fdxx d,/*tb_bdcpxx e,*/tb_cpxx f,tb_lpajxx g,tb_zpaxx k,Tb_Cpzrdzb m
           where a.bxgsid = c.bxgsid
             and b.ttid = c.ttid
             and c.bdid = c.bdid
             and c.khbdh = d.khbdh
             /*and c.bdid = e.bdid
             and e.cpid = f.cpid*/  and f.cpid = m.cpid
             and a.bxgsid = rec_bxgs.bxgsid
             and b.ttid = nvl(trim(POther2),b.ttid)
             and c.bdid = nvl(trim(POther3),c.bdid)
             --and d.zbbrkhid is not null
             and c.bxgsid = g.bxgsid
             and g.ajid = k.ajid
             and k.zrid = m.zrid
             AND C.BDSXRQ >= nvl(trim(pStartdate),C.BDSXRQ)
             AND C.BDSXRQ <= NVL(TRIM(pEnddate),C.BDSXRQ)
             AND C.BDZZRQ >= NVL(TRIM(pEnddate),C.BDZZRQ)
            /* and m.cpid = e.cpid*/
           group by b.ttid
           order by b.ttid
    )loop

    for rec_bddata in(
        select c.bdid
        from tb_bxgsxx a,tb_ttxx b,tb_bdxx c,tb_fdxx d,/*tb_bdcpxx e,*/tb_cpxx f,tb_lpajxx g,tb_zpaxx k,Tb_Cpzrdzb m
           where a.bxgsid = c.bxgsid
             and b.ttid = c.ttid
             and c.bdid = c.bdid
             and c.khbdh = d.khbdh
             /*and c.bdid = e.bdid
             and e.cpid = f.cpid*/  and f.cpid = m.cpid
             and a.bxgsid = rec_bxgs.bxgsid
             and b.ttid = rec_ttdata.ttid
             and c.bdid = nvl(trim(POther3),c.bdid)
             --and d.zbbrkhid is not null
             and c.bxgsid = g.bxgsid
             and g.ajid = k.ajid
             and k.zrid = m.zrid
             AND C.BDSXRQ >= nvl(trim(pStartdate),C.BDSXRQ)
             AND C.BDSXRQ <= NVL(TRIM(pEnddate),C.BDSXRQ)
             AND C.BDZZRQ >= NVL(TRIM(pEnddate),C.BDZZRQ)
             /*and m.cpid = e.cpid*/
           group by c.bdid
           order by c.bdid
    )loop
      for rec_data in(
          select x.*,y.tbrs ,(round(X.CXRS*100/Y.TBRS,2)||'%')as cxl FROM ( select a.bxgsqc,b.ttbh,b.ttmc,c.khbdh,c.Bdsxrq,c.Bdzzrq,f.cph,f.cpmc,
      count(distinct g.bbrkhid) as cxrs
           from tb_bxgsxx a,tb_ttxx b,tb_bdxx c,tb_fdxx d,/*tb_bdcpxx e,*/tb_cpxx f,tb_lpajxx g,tb_zpaxx k,Tb_Cpzrdzb m,tb_fdzrmx e
           where a.bxgsid = c.bxgsid
             and b.ttid = c.ttid
             and c.bdid = c.bdid
             and c.khbdh = d.khbdh
             /*and c.bdid = e.bdid
             and e.cpid = f.cpid*/  and f.cpid = m.cpid
            and a.bxgsid = rec_bxgs.bxgsid
             and c.bdid = rec_bddata.bdid
             and b.ttid = rec_ttdata.ttid
             and c.bxgsid = g.bxgsid
             and g.ajid = k.ajid
             and k.zrid = m.zrid
             --and f.cpid = '33'
             and e.fdid = d.fdid
             and e.zrid = m.zrid
             AND C.BDSXRQ >= nvl(trim(pStartdate),C.BDSXRQ)
             AND C.BDSXRQ <= NVL(TRIM(pEnddate),C.BDSXRQ)
             AND C.BDZZRQ >= NVL(TRIM(pEnddate),C.BDZZRQ)
             /*and m.cpid = e.cpid*/
           group by a.bxgsqc,b.ttbh,b.ttmc,c.khbdh,c.Bdsxrq,c.Bdzzrq,f.cph,f.cpmc
           order by a.bxgsqc,b.ttmc,c.khbdh,f.cpmc)X,


           ( select c.khbdh||f.cpmc as key1,
             count(distinct d.bbrkhid) as tbrs

           from tb_bxgsxx a,tb_ttxx b,tb_bdxx c,tb_fdxx d,tb_cpxx f,Tb_Cpzrdzb m,tb_fdzrmx e
           where a.bxgsid = c.bxgsid
             and b.ttid = c.ttid
             and c.bdid = c.bdid
             and c.khbdh = d.khbdh
             /*and c.bdid = e.bdid
             and e.cpid = f.cpid*/  and f.cpid = m.cpid
             --and a.bxgsid = rec_bxgs.bxgsid
             and a.bxgsid = rec_bxgs.bxgsid
             and c.bdid = rec_bddata.bdid
             and b.ttid = rec_ttdata.ttid
            --and f.cpid = '33'
             and e.fdid = d.fdid
             and e.zrid = m.zrid
             AND C.BDSXRQ >= nvl(trim(pStartdate),C.BDSXRQ)
             AND C.BDSXRQ <= NVL(TRIM(pEnddate),C.BDSXRQ)
             AND C.BDZZRQ >= NVL(TRIM(pEnddate),C.BDZZRQ)
             /*and m.cpid = e.cpid*/
           group by c.khbdh||f.cpmc)Y where X.KHBDH||X.CPMC = Y.KEY1 (+)
      )loop
         --??????
         insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 0, cell.r, rec_bxgs.bxgsbh);

         --??????
         insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 1, cell.r, rec_data.bxgsqc);

         --?????
         insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 2, cell.r, rec_data.ttbh);

         --??????
         insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0,3, cell.r, rec_data.ttmc);

         --?????
         insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 4, cell.r, rec_data.khbdh);

         --?????
         insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 5, cell.r, rec_data.bdsxrq);

         --?????
         insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 6, cell.r, rec_data.bdzzrq);

         --???
         insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 7, cell.r, rec_data.cph);

         --???
         insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 8, cell.r, rec_data.cpmc);

         --????
         insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 9, cell.r, rec_data.tbrs);

         --????
         insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 10, cell.r, rec_data.cxrs);

         --???
         insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 11, cell.r, rec_data.cxl);

         cell.r :=  cell.r+1;

       end loop;
       /*--?????
         select x.CXRS,y.tbrs ,(round(X.CXRS*100/Y.TBRS,2)||'%')as cxl  INTO tt_cxrs,tt_tbrs,tt_cxl FROM ( select C.KHBDH,
          count(distinct g.bbrkhid) as cxrs
           from tb_bxgsxx a,tb_ttxx b,tb_bdxx c,tb_fdxx d,\*tb_bdcpxx e,*\tb_cpxx f,tb_lpajxx g,tb_zpaxx k,Tb_Cpzrdzb m,tb_fdzrmx e
           where a.bxgsid = c.bxgsid
             and b.ttid = c.ttid
             and c.bdid = c.bdid
             and c.khbdh = d.khbdh
             \*and c.bdid = e.bdid
             and e.cpid = f.cpid*\  and f.cpid = m.cpid
            --and a.bxgsid = rec_bxgs.bxgsid
             and c.bdid = rec_bddata.bdid
             --and b.ttid = rec_ttdata.ttid
             and c.bxgsid = g.bxgsid
             and g.ajid = k.ajid
             and k.zrid = m.zrid
             --and f.cpid = '33'
             and e.fdid = d.fdid
             and e.zrid = m.zrid
             AND C.BDSXRQ >= nvl(trim(pStartdate),C.BDSXRQ)
             AND C.BDSXRQ <= NVL(TRIM(pEnddate),C.BDSXRQ)
             AND C.BDZZRQ >= NVL(TRIM(pEnddate),C.BDZZRQ)
             \*and m.cpid = e.cpid*\
           group by  C.KHBDH
           order by  C.KHBDH )X,


           ( select c.khbdh  as key1,
             count(distinct d.bbrkhid) as tbrs
           from tb_bxgsxx a,tb_ttxx b,tb_bdxx c,tb_fdxx d,tb_cpxx f,Tb_Cpzrdzb m,tb_fdzrmx e
           where a.bxgsid = c.bxgsid
             and b.ttid = c.ttid
             and c.bdid = c.bdid
             and c.khbdh = d.khbdh
             \*and c.bdid = e.bdid
             and e.cpid = f.cpid*\  and f.cpid = m.cpid
             --and a.bxgsid = rec_bxgs.bxgsid
            -- and a.bxgsid = rec_bxgs.bxgsid
             and c.bdid = rec_bddata.bdid
             --and b.ttid = rec_ttdata.ttid
             and e.fdid = d.fdid
             and e.zrid = m.zrid
             AND C.BDSXRQ >= nvl(trim(pStartdate),C.BDSXRQ)
             AND C.BDSXRQ <= NVL(TRIM(pEnddate),C.BDSXRQ)
             AND C.BDZZRQ >= NVL(TRIM(pEnddate),C.BDZZRQ)
             \*and m.cpid = e.cpid*\
           group by c.khbdh)Y where X.KHBDH (+) = Y.KEY1 ;

            insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 3, cell.r, '????');

            insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 9, cell.r, tt_tbrs);
            insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 10, cell.r, tt_cxrs);
            insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 11, cell.r, tt_cxl);
            cell.r :=  cell.r+1;*/
       end loop;
           --??????
       /*  select x.CXRS,y.tbrs ,(round(X.CXRS*100/Y.TBRS,2)||'%')as cxl  INTO tt_cxrs,tt_tbrs,tt_cxl FROM ( select c.ttid,
      count(distinct g.bbrkhid) as cxrs
           from tb_bxgsxx a,tb_ttxx b,tb_bdxx c,tb_fdxx d,\*tb_bdcpxx e,*\tb_cpxx f,tb_lpajxx g,tb_zpaxx k,Tb_Cpzrdzb m,tb_fdzrmx e
           where a.bxgsid = c.bxgsid
             and b.ttid = c.ttid
             and c.bdid = c.bdid
             and c.khbdh = d.khbdh
             \*and c.bdid = e.bdid
             and e.cpid = f.cpid*\  and f.cpid = m.cpid
             and a.bxgsid = rec_bxgs.bxgsid
             --and c.bdid = rec_bddata.bdid
             and b.ttid = rec_ttdata.ttid
             and c.bxgsid = g.bxgsid
             and g.ajid = k.ajid
             and k.zrid = m.zrid
             --and f.cpid = '33'
             and e.fdid = d.fdid
             and e.zrid = m.zrid
             AND C.BDSXRQ >= nvl(trim(pStartdate),C.BDSXRQ)
             AND C.BDSXRQ <= NVL(TRIM(pEnddate),C.BDSXRQ)
             AND C.BDZZRQ >= NVL(TRIM(pEnddate),C.BDZZRQ)
             \*and m.cpid = e.cpid*\
           group by  c.ttid
           order by  c.ttid)X,


           ( select c.ttid as key1,
             count(distinct d.bbrkhid) as tbrs

           from tb_bxgsxx a,tb_ttxx b,tb_bdxx c,tb_fdxx d,tb_cpxx f,Tb_Cpzrdzb m,tb_fdzrmx e
           where a.bxgsid = c.bxgsid
             and b.ttid = c.ttid
             and c.bdid = c.bdid
             and c.khbdh = d.khbdh
             \*and c.bdid = e.bdid
             and e.cpid = f.cpid*\  and f.cpid = m.cpid
             --and a.bxgsid = rec_bxgs.bxgsid
             and a.bxgsid = rec_bxgs.bxgsid
             and b.ttid = rec_ttdata.ttid
             --and b.ttid = rec_ttdata.ttid
             and e.fdid = d.fdid
             and e.zrid = m.zrid
             AND C.BDSXRQ >= nvl(trim(pStartdate),C.BDSXRQ)
             AND C.BDSXRQ <= NVL(TRIM(pEnddate),C.BDSXRQ)
             AND C.BDZZRQ >= NVL(TRIM(pEnddate),C.BDZZRQ)
             \*and m.cpid = e.cpid*\
           group by C.TTID)Y where X.TTID(+) = Y.KEY1 ;

             insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 1, cell.r, '????');
             insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 9, cell.r, gs_tbrs);
              insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 10, cell.r, gs_cxrs);
              insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 11, cell.r, gs_cxl);
              cell.r :=  cell.r+1;*/
       end loop;


      /*select x.CXRS,y.tbrs ,(round(X.CXRS*100/Y.TBRS,2)||'%')as cxl  INTO tt_cxrs,tt_tbrs,tt_cxl FROM ( select c.bxgsid,
      count(distinct g.bbrkhid) as cxrs
           from tb_bxgsxx a,tb_ttxx b,tb_bdxx c,tb_fdxx d,\*tb_bdcpxx e,*\tb_cpxx f,tb_lpajxx g,tb_zpaxx k,Tb_Cpzrdzb m,tb_fdzrmx e
           where a.bxgsid = c.bxgsid
             and b.ttid = c.ttid
             and c.bdid = c.bdid
             and c.khbdh = d.khbdh
             \*and c.bdid = e.bdid
             and e.cpid = f.cpid*\  and f.cpid = m.cpid
            and a.bxgsid = rec_bxgs.bxgsid
             --and c.bdid = rec_bddata.bdid
             --and b.ttid = rec_ttdata.ttid
             and c.bxgsid = g.bxgsid
             and g.ajid = k.ajid
             and k.zrid = m.zrid
             --and f.cpid = '33'
             and e.fdid = d.fdid
             and e.zrid = m.zrid
             AND C.BDSXRQ >= nvl(trim(pStartdate),C.BDSXRQ)
             AND C.BDSXRQ <= NVL(TRIM(pEnddate),C.BDSXRQ)
             AND C.BDZZRQ >= NVL(TRIM(pEnddate),C.BDZZRQ)
             \*and m.cpid = e.cpid*\
           group by  c.bxgsid
           order by  c.bxgsid)X,


           ( select c.bxgsid as key1,
             count(distinct d.bbrkhid) as tbrs

           from tb_bxgsxx a,tb_ttxx b,tb_bdxx c,tb_fdxx d,tb_cpxx f,Tb_Cpzrdzb m,tb_fdzrmx e
           where a.bxgsid = c.bxgsid
             and b.ttid = c.ttid
             and c.bdid = c.bdid
             and c.khbdh = d.khbdh
             \*and c.bdid = e.bdid
             and e.cpid = f.cpid*\  and f.cpid = m.cpid
             --and a.bxgsid = rec_bxgs.bxgsid
              and a.bxgsid = rec_bxgs.bxgsid
             --and c.bdid = rec_bddata.bdid
             --and b.ttid = rec_ttdata.ttid
             and e.fdid = d.fdid
             and e.zrid = m.zrid
             AND C.BDSXRQ >= nvl(trim(pStartdate),C.BDSXRQ)
             AND C.BDSXRQ <= NVL(TRIM(pEnddate),C.BDSXRQ)
             AND C.BDZZRQ >= NVL(TRIM(pEnddate),C.BDZZRQ)
             \*and m.cpid = e.cpid*\
           group by c.bxgsid)Y where X.bxgsid (+) = Y.KEY1 ;

        insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 0, cell.r, '??????');
        insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 9, cell.r, gs_tbrs);
            insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 10, cell.r, gs_cxrs);
            insert into t_report_data_info(statid, sheet, col, r, content)values(cell.statid, 0, 11, cell.r, gs_cxl);

        cell.r :=  cell.r+1;*/


  end loop;


  --???????????
  /*9.??*/
  PReturnCode := '0'; /* ??????????????vstatid????????? */
  PReturnMsg  := vstatid;
  DBMS_OUTPUT.PUT_LINE('[LDS debug] ' || 'PReturncode= ' || PReturnCode);
  --COMMIT; ???java?????????

EXCEPTION
  WHEN OTHERS THEN
    --rollback;???java?????????????0?????????????????
    PReturnCode := 'E'; /*  ??????  */
    DBMS_OUTPUT.PUT_LINE('[yhs debug] ' || 'PReturncode= ' || PReturnCode);
    PReturnMsg := ' rownum' || cell.r || 'Error:' || sqlerrm; --???????????
    DBMS_OUTPUT.PUT_LINE(PReturnMsg);
end SP_P1_30026;

/
