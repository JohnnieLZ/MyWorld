CREATE procedure      SP_IMPORT_BQXX_CITIC(PReturnCode OUT varchar2,
                              PReturnMsg    OUT varchar2) AS
  /*****@version 1.1 update by zhangjunpeng??????????????????  2015-5-8
       *@version 1.2 update by zhangjupeng ????????????????? 2015-6-4
       *@version 1.3 update by zhangjunpeng ?????????????????? 2015-6-5
       *version 1.5  insert  by zhongyaode ????????? 2015-11-17
       ***/
  V_STEP_CODE  VARCHAR2(5):='00000';
  v_start_date number := 0;
  v_end_date   number := 0;
  v_no  number:=0;
  rec_ajxx tb_lpajxx%rowtype;
  v_001zd number:=0; --???????????0

   v_zrlxdm varchar2(6):='xxxxxx';
   v_xtxgdm varchar2(60):=''; --??????
   v_zpaid number(16):=-1;
   v_fphm varchar2(400):=''; --?????????????
   v_zpah varchar2(30):='';--????
   v_zrid number(16):=0; -- ?????Id
   v_zddm varchar2(20):='';
   rec_zrxx tb_zrxx%rowtype;
    v_fdid number(16):=0; -- ????????Id
    v_pch number(16):=0;
    v_ttid number(16):=0;
    v_fftt varchar2(60):='';
    v_fdxx tb_fdxx%rowtype;--????????????
    v_fdzrmx tb_fdzrmx%rowtype;--?????????????????
  --????????????
  cursor cur_bwxx is
    select * from TB_XC_PRESERVATION_IMPORT_BASE   where nvl(FLAG,'N')='N' order by POLICY_NO,MAKEDATE asc,BQBWID asc;
  begin
    PReturnCode:='E';
    PReturnMsg:='Error!';
    --?????
    --????
    for rec_bd in cur_bwxx loop
        select nvl(count(1),0) into v_no from TB_XC_PRESERVATION_IMPORT_BASE a where nvl(FLAG,'N')='N'
         and not exists(select 'x' from TB_bdxx where khbdh=rec_bd.POLICY_NO);
         if (v_no>0 ) then
            PReturnCode:='-1';
            PReturnMsg:='??????'||rec_bd.POLICY_NO||'??????????????!';
            return;
        end if;

     /*  select nvl(count(1),0) into v_no from TB_XC_PRESERVATION_IMPORT_BASE a where nvl(FLAG,'N')='N'
         and not exists(select 'x' from TB_bdxx b,tb_bddjzrxx c,TB_XC_PRESERVATION_IMPORT_ROWS d  where khbdh=rec_bd.POLICY_NO and b.bdid=c.bdid and c.djbh=d.CONTPLANCODE
         and d.bqbwid=a.bqbwid);
         if (v_no >0 ) then
          PReturnCode:='-2';
          PReturnMsg:='??????'||rec_bd.POLICY_NO||'??????????????????????????!';
          return;
        end if;*/

     select nvl(count(1),0) into v_no from TB_XC_PRESERVATION_IMPORT_ROWS a where nvl(FLAG,'N')='N'
       and a.RELATION is not null and a.BQBWID=rec_bd.BQBWID
       and not exists(select 'x' from TB_XC_PRESERVATION_IMPORT_ROWS c  where c.INSUREDNO=a.MAININSUNO);
     if (v_no >0 ) then
      PReturnCode:='-2';
      PReturnMsg:='??????'||rec_bd.POLICY_NO||'?,??????????????????????!';
      return;
    end if;
    --??????????
      select nvl(max(ttid),0) into v_ttid from tb_ttxx f
      where exists(select 'x' from TB_XC_PRESERVATION_IMPORT_ROWS a where   a.BQBWID=rec_bd.BQBWID
        and a.grpname=f.ttmc);
     if (v_ttid =0 ) then
      PReturnCode:='-2';
      PReturnMsg:='??????'||rec_bd.POLICY_NO||'?,??????????????????!';
      return;
    end if;
    --??????+???????????????????E
     update TB_XC_PRESERVATION_IMPORT_ROWS a set a.flag='E',ERROR_DESC='E001:?????????????????' where
     a.flag is null and a.BQBWID=rec_bd.BQBWID and not exists(select 'x' from  tb_zddmbxgsdmdzb b where aaa100='ZRDM' and bxgsid=946
        and b.yxzt='1' and b.qtsm2=rec_bd.POLICY_NO||'@'||trim(a.CONTPLANCODE));
   --??????
    update tb_bdxx a set (ttid,bdxz,bdlx,tbzrs,ttmc,dlrbh)=(select v_ttid, GRPCONTCATEGORY,GRPCONTTYPE ,POLICYHOLDERNUM,GRPNAME,appntno from TB_XC_PRESERVATION_IMPORT_ROWS b where b.BQMXID=(select min(BQMXID) from TB_XC_PRESERVATION_IMPORT_ROWS where /*b.  -- -V1.1*/BQBWID=rec_bd.BQBWID) )  where khbdh=rec_bd.POLICY_NO;
   --????????
     insert into tb_bddjxx(
            DJID  ,--   NUMBER(16)                     ??id
            BDID    ,-- NUMBER(16)                     ??ID
            DJBH    ,-- VARCHAR2(20)  Y                ????
            DJMC    ,-- VARCHAR2(50)  Y                ????
            SLRQ    ,-- NUMBER(8)     Y                ????
            ZZRQ    ,-- NUMBER(8)     Y                ????
            BZ      ,-- VARCHAR2(100) Y                ??
            CJR     ,-- VARCHAR2(30)  Y                ???
            XGR     ,-- VARCHAR2(30)  Y                ???
            SEQLOGID)-- NUMBER        Y
            select  seq_djid.nextval as djid ,h.bdid,h.CONTPLANCODE djbh,h.CONTPLANCODE djmc,
            to_char(sysdate,'yyyymmdd')      ,'','??????','system','',-1 as seqlogid
       from (select    f.bdid,a.CONTPLANCODE from   tb_bdxx f,TB_XC_PRESERVATION_IMPORT_ROWS a where a.BQBWID=rec_bd.BQBWID  and nvl(a.flag,'N')!='N'
            and  f.khbdh =rec_bd.POLICY_NO group by    f.bdid, a.CONTPLANCODE ) h
             where not exists(select 'x' from  tb_bddjxx
            where bdid=h.bdid and djbh=h.CONTPLANCODE) and h.CONTPLANCODE is not null;

   --????????
    insert into tb_bdfwxx(
          BDFWID   ,--NUMBER(16)                     ??id
          BDID     ,--NUMBER(16)                     ??ID
          FWRYDM   ,--VARCHAR2(20)  Y                ??????
          FWRYMC   ,--VARCHAR2(50)  Y                ??????
          SLRQ     ,--NUMBER(8)     Y                ????
          ZZRQ     ,--NUMBER(8)     Y                ????
          BZ       ,--VARCHAR2(100) Y                ??
          CJR      ,--VARCHAR2(30)  Y                ???
          XGR      ,--VARCHAR2(30)  Y                ???
          SEQLOGID)-- NUMBER        Y
            select  seq_BDFWID.nextval as BDFWID ,h.bdid,h.MANAGECOM FWRYDM,h.MANAGECOMNAME FWRYMC,
            to_char(sysdate,'yyyymmdd') slrq    ,'' as zzrq,'??????' as bz,'system' as cjr,'',-1 as seqlogid
       from (select    f.bdid,A.MANAGECOM,A.MANAGECOMNAME from   tb_bdxx f,TB_XC_PRESERVATION_IMPORT_ROWS a where a.BQBWID=rec_bd.BQBWID
            and  F.KHBDH =REC_BD.POLICY_NO GROUP BY    F.BDID,A.MANAGECOM,A.MANAGECOMNAME) H
             WHERE NOT EXISTS(SELECT 'X' FROM  TB_BDFWXX
            WHERE BDID=H.BDID AND FWRYDM=H.MANAGECOM) AND H.MANAGECOM IS NOT NULL;

    select to_number(to_char(sysdate,'yyyymmddhh24miss')) into v_pch from dual;
    --???????????
    select max(ttbh) into v_fftt from tb_ttxx where ttmc=(select distinct GRPNAME from tb_xc_preservation_import_rows where BQBWID=REC_BD.BQBWID);
    update TB_KHXX t set (KHBH, XM, SCZT, XB, CSRQ, SWRQ, ZZBZ,
          ZYDJ, ZYDM, GH, KHYH, ZHMC, YHZH ,BANKCODE,BANKSELFCODE,KHHSZS, KHHSZSHI, FWTT,
          FWTTMC, FWZTTBH, BMBH, BMMC, YBBS, YBKH, YBD, GZDJZD, HYZK,
          EMAIL, SJH, YX, XGBZ, BBRTBYD, GZDXZQH, YBDXZQH, JZDXZQH, SFMZZYGYED)=(select a.INSUREDNO,
         substrb(NAME,1,50) as  XM, '0' as sczt,decode( a.GENDER,'?','1','?','2','9') as xb,
  case when a.RELATION is not null and a.RELATION!= '??'
     then
     case when length(trim(a.IDNO))=18  then to_number(substr(a.IDNO,7,8))
          when length(trim(a.IDNO))=15  then to_number(substr(a.IDNO,7,8))
      else null end
   else
       case when length(trim(a.IDNO))=18  then to_number(substr(a.IDNO,7,8))
            when length(trim(a.IDNO))=15 then to_number(substr(a.IDNO,7,8))
            when length(trim(a.IDNO))=8  then to_number(substr(a.IDNO,0,8))
       else null end

         end as csrq
         ,
           '' as swrq, decode('',null,'0','','0','1') as ZZBZ,
          '' ZYDJ, '' ZYDM,
          substrb(a.WORKNO,1,20) as  GH,
          a.BANKNAME as KHYH,   substrb(NAME,1,50) as ZHMC, a.BANKACCNO as YHZH,a.BANKCODE,a.BANKSELFCODE,  '' as KHHSZS,'' as KHHSZSHI,
          (select ttbh from tb_ttxx where ttmc=a.GRPNAME)   as FWTT ,
          a.GRPNAME as FWTTMC, '' as FWZTTBH, '' as BMBH,'' as BMMC,
         decode( a.SSFLAG,'1','02','01') as YBBS,'' as YBKH,
         a.REMARKSSD as  YBD,a.REMARKGZDW as GZDJZD, '' as HYZK,
          '' as EMAIL,''  as SJH,'' as  YX, '' as XGBZ, '' as BBRTBYD,(select aab301 from aa26 where aaa146= a.REMARKGZDW) GZDXZQH,(select aab301 from aa26 where aaa146= a.REMARKSSD ) as YBDXZQH,'' JZDXZQH, '0' as SFMZZYGYED
          FROM TB_XC_PRESERVATION_IMPORT_ROWS a where a.BQbwID=rec_bd.BQbwID and a.IDNO=t.aac147 and FUNC_GETCODEBYBXGSDM(946,'ZJLX',a.IDTYPE ,'','')=t.aac058 and a.INSUREDNO=t.khbh and nvl(FLAG,'N')='N' and rownum<2)  --????????  1.4
         where exists(  select 'x' FROM TB_XC_PRESERVATION_IMPORT_ROWS a where a.BQbwID=rec_bd.BQbwID /*and  a.IDNO=t.aac147 and FUNC_GETCODEBYBXGSDM(946,'ZJLX',a.IDTYPE,'','')=t.aac058*/ and a.INSUREDNO=t.khbh and nvl(a.FLAG,'N')='N'--1.4
         ) and t.fwtt=v_fftt;
     v_no:=SQL%rowcount;
    dbms_output.put_line('????????'||     to_char(v_no));
    --??????,?????????????
    INSERT INTO TB_KHXX(
              KHID, KHBH, XM, AAC058, AAC147, SCZT, XB, CSRQ, SWRQ, ZZBZ,
          ZYDJ, ZYDM, GH, KHYH, ZHMC, YHZH,BANKCODE,BANKSELFCODE, KHHSZS, KHHSZSHI, FWTT,
          FWTTMC, FWZTTBH, BMBH, BMMC, YBBS, YBKH, YBD, GZDJZD, HYZK,
          EMAIL, SJH, YX, XGBZ, BBRTBYD, GZDXZQH, YBDXZQH, JZDXZQH, SFMZZYGYED)
        SELECT
          seq_khid.nextval as khid,a.INSUREDNO as khbh,  substrb(NAME,1,50) as  XM,FUNC_GETCODEBYBXGSDM(946,'ZJLX',a.IDTYPE,'','') as aac058,  a.IDNO, '0' as sczt,
          decode( a.GENDER,'?','1','?','2','9') as xb,
         -- case when length(trim(a.IDNO))=18 then   to_number(substr(a.IDNO,7,8)) else null end as csrq,
         -- ???????????????????1?????18??2?????15?3????????
         -- ??????????1?????18??2?????15?3??????8?????????????
        case when nvl(a.RELATION,'XX')<> '??'
     then
     case when length(trim(a.IDNO))=18  then to_number(substr(a.IDNO,7,8))
          when length(trim(a.IDNO))=15  then to_number('19'||substr(a.IDNO,7,6))
      else null end
   else
       case when length(trim(a.IDNO))=18  then to_number(substr(a.IDNO,7,8))
            when length(trim(a.IDNO))=15 then to_number('19'||substr(a.IDNO,7,6))
            when length(trim(a.IDNO))=8  then to_number(trim(a.IDNO))
       else null end

         end as csrq ,
           '' as swrq, decode('',null,'0','','0','1') as ZZBZ,
          '' ZYDJ, '' ZYDM,
          substrb(a.WORKNO,1,20) as  GH,
          a.BANKNAME as KHYH,   substrb(NAME,1,50) as ZHMC, a.BANKACCNO as YHZH,
          a.BANKCODE,a.BANKSELFCODE,  '' as KHHSZS,'' as KHHSZSHI, (select ttbh from tb_ttxx where ttmc=a.GRPNAME)  as FWTT ,
          a.GRPNAME as FWTTMC, '' as FWZTTBH, '' as BMBH,'' as BMMC,
           decode( a.SSFLAG,'1','02','01') as YBBS,'' as YBKH,
        a.REMARKSSD  as  YBD,a.REMARKGZDW as GZDJZD, '' as HYZK,
          '' as EMAIL,''  as SJH,'' as  YX, '' as XGBZ, '' as BBRTBYD,'' GZDXZQH,(select aab301 from aa26 where aaa146= a.REMARKSSD ) as YBDXZQH,
          (select aab301 from aa26 where aaa146= a.REMARKGZDW ) JZDXZQH, '0' as SFMZZYGYED
          FROM  (
 select
   bqbwid,
   GRPCONTNO           ,
   MANAGECOM           ,
   MANAGECOMNAME       ,
   APPNTNO             ,
   GRPCONTNO_1         ,
   GRPCONTCATEGORY     ,
   GRPCONTTYPE         ,
   POLICYHOLDERNUM     ,
   GRPNAME             ,
   MANAGECOM_1         ,
   INSUREDNO           ,
   NAME                ,
   GENDER              ,
   AGE                 ,
   IDTYPE              ,
   IDNO                ,
   CONTNO              ,
   WORKNO              ,
   CONTRACTSTATUS      ,
   REMARKSSD           ,
   REMARKGZDW          ,
   SSFLAG              ,
   BANKCODE            ,
   BANKSELFCODE        ,
   BANKNAME            ,
   RELATION            ,
   BANKACCNO  ,flag
  from TB_XC_PRESERVATION_IMPORT_ROWS group by  bqbwid,
   GRPCONTNO           ,
   MANAGECOM           ,
   MANAGECOMNAME       ,
   APPNTNO             ,
   GRPCONTNO_1         ,
   GRPCONTCATEGORY     ,
   GRPCONTTYPE         ,
   POLICYHOLDERNUM     ,
   GRPNAME             ,
   MANAGECOM_1         ,
   INSUREDNO           ,
   NAME                ,
   GENDER              ,
   AGE                 ,
   IDTYPE              ,
   IDNO                ,
   CONTNO              ,
   WORKNO              ,
   CONTRACTSTATUS      ,
   REMARKSSD           ,
   REMARKGZDW          ,
   SSFLAG              ,
   BANKCODE            ,
   BANKSELFCODE        ,
   BANKNAME            ,
   RELATION            ,
   BANKACCNO,flag  ) a
           WHERE   nvl(FLAG,'N')='N' and a.BQbwID=rec_bd.BQbwID
           and not exists(select 'x' from TB_KHXX b where b.aac147=a.IDNO and b.aac058=/*IDTYPE -- -V1.2*/ FUNC_GETCODEBYBXGSDM(946,'ZJLX',a.IDTYPE,'','')/**-- +V1.2**/ and b.khbh=a.INSUREDNO);
           v_no:=SQL%rowcount;
  --  dbms_output.put_line('????????'||     to_char(v_no));
    --??????
-- select count(1) into v_no from tb_fdxx where khbdh in(select bdh from TB_IMPORT_PSNFDZR a WHERE a.RUN_FLAG is null);
    --???????????????????
    for rec_fdzrmx in(select * from TB_XC_PRESERVATION_IMPORT_ROWS a where BQBWID=rec_bd.BQBWID order by a.INSUREDNO,a.CVALIDATE asc) loop
       select nvl(max(fdid),0) into  v_fdid from tb_fdxx a,tb_khxx b where a.khbdh=rec_bd.POLICY_NO and a.bbrkhid=b.khid
         and b.aac147=rec_fdzrmx.IDNO  and b.khbh=rec_fdzrmx.INSUREDNO;
       select * into  v_fdxx from tb_fdxx  a,tb_khxx b where a.khbdh=rec_bd.POLICY_NOand and a.bbrkhid=b.khid and b.aac147=rec_fdzrmx.IDNO  and b.khbh=rec_fdzrmx.INSUREDNO;--???????fdsxr?fdzzr?????????
        if v_fdid!=0 then
            --insert 2015-11-18?????????????????????? ?????????????????????????????
       if v_fdxx.fdsxr>rec_fdzrmx.cvalidate and v_fdxx.zztqbz>rec_fdzrmx.policyenddate or v_fdxx.fdsxr<rec_fdzrmx.cvalidate and v_fdxx.zztqbz<rec_fdzrmx.policyenddate then
              select  seq_Fdid.nextval into  v_fdid from dual;
          INSERT INTO TB_FDXX   (
            FDID, TTID, KHBDH, TBDH, FDH,
          FDSXR, FDZZR, FDZT, FDZBF, BBRKHID,
          BBRNL, ZYLB, ZYDM, ZTTID, DJ,
          GZDXZQH, BBRDZID, BBRDZXX,
          ZLDBZ, ZBBRGX, ZBBRKHID, ZBBRFDH,
          FDZS1, FDZS2, DJID,
          YBDXZQH, JZDQH,Cjrq,Bdid,WBBDH,seqlogid)
        SELECT
          v_fdid as fdid,v_ttid TTID, rec_bd.POLICY_NO as KHBDH, '' as TBDH,
         rec_fdzrmx.CONTNO as fdh,
        replace( rec_fdzrmx.cvalidate,'-','') as FDSXR,
        --replace(  rec_fdzrmx.POLICYENDDATE,'-','') as FDZZR,                              -- -V1.3
        to_char(to_date(replace(rec_fdzrmx.policyenddate,'-',''),'yyyyMMdd')-1,'yyyyMMdd')  as FDZZR, -- +V1.3
          '1' as fdzt,
          '' fdzbf,
          b.khid as BbrKhid,
          rec_fdzrmx.age as BBRNL ,
           '' ZYLB, '' as ZYDM,
         '' as ZTTID,
          rec_fdzrmx.CONTPLANCODE as  DJ,
          b.gzdxzqh as GZDXZQH,
         '' as  DZID ,
        '' as jtdz,
         case when rec_fdzrmx.RELATION is not null and rec_fdzrmx.RELATION!= '??'  then '1' else '0' end as ZLDBZ,
           --FUNC_GETCODEBYBXGSDM(946,'ZBBRGX',rec_fdzrmx.RELATION,'','' ) as ZBBRGX, --???????????????????????
        --FUNC_GETCODEBYBXGSDM(946,'ZBBRGX',decode(rec_fdzrmx.RELATION,'??','??',rec_fdzrmx.RELATION),'','' ) as ZBBRGX,  --??????????rows????????????????FUNC_GETCODEBYBXGSDM??????????????????????????????????????????????FUNC_GETCODEBYBXGSDM?

        FUNC_GETCODEBYBXGSDM(946,'ZBBRGX',(SELECT J.BXGSXMBM FROM TB_ZDDMBXGSDMDZB J WHERE J.BXGSID=946 AND J.AAA100='ZBBRGX' AND J.BXGSXMMC=(decode(rec_fdzrmx.RELATION,'??','??',rec_fdzrmx.RELATION))),'','' ) as ZBBRGX,
         case when rec_fdzrmx.RELATION is not null and rec_fdzrmx.RELATION!= '??'  then (select to_char(max(khid)) from tb_khxx  where xm=rec_fdzrmx.MAININSUNAME and khbh=rec_fdzrmx.MAININSUNO) else '' end as ZBBRKHID ,
         '' Zbbrfdh ,
        '' FDZS1, '' FDZS2,
        (SELECT DJID FROM TB_BDDJXX WHERE BDID in(select bdid from tb_bdxx where khbdh= rec_bd.POLICY_NO) AND DJbh =  rec_fdzrmx.CONTPLANCODE ) as djid,
        b.ybdxzqh YBDXZQH,'' JZDXZQH,
          to_number(to_char(SYSDATE,'yyyymmdd')) as Cjrq,
         (select bdid from tb_bdxx where khbdh= rec_bd.POLICY_NO)  as BDID,
        rec_bd.POLICY_NO as  wbbdh,
        rec_bd.BQBWID as seqlogid
        FROM  tb_khxx b
          where  b.aac147=rec_fdzrmx.IDNO and b.xm=rec_fdzrmx.NAME and b.khbh=rec_fdzrmx.INSUREDNO and rec_fdzrmx.contractstatus<>'?????' and  rownum<2;
          --update+insert 2015-11-18??????????????????????????????????????????
          elsif rec_fdzrmx.cvalidate<v_fdxx.fdsxr and rec_fdzrmx.policyenddate<v_fdxx.fdzzr or rec_fdzrmx.cvalidate<v_fdxx.fdsxr and rec_fdzrmx.policyenddate>v_fdxx.fdzzr then
             select  seq_Fdid.nextval into  v_fdid from dual;
             --????????????????????????????????????
             update tb_fdxx f set f.FDZZR=  /*replace( rec_fdzrmx.POLICYENDDATE,'-','')  -- -V1.3*/ to_char(to_date(replace(rec_fdzrmx. cvalidate,'-',''),'yyyyMMdd')-1,'yyyyMMdd')   where fdid=v_fdid;
          INSERT INTO TB_FDXX(
            FDID, TTID, KHBDH, TBDH, FDH,
          FDSXR, FDZZR, FDZT, FDZBF, BBRKHID,
          BBRNL, ZYLB, ZYDM, ZTTID, DJ,
          GZDXZQH, BBRDZID, BBRDZXX,
          ZLDBZ, ZBBRGX, ZBBRKHID, ZBBRFDH,
          FDZS1, FDZS2, DJID,
          YBDXZQH, JZDQH,Cjrq,Bdid,WBBDH,seqlogid)
        SELECT
          v_fdid as fdid,v_ttid TTID, rec_bd.POLICY_NO as KHBDH, '' as TBDH,
         rec_fdzrmx.CONTNO as fdh,
        replace( rec_fdzrmx.CVALIDATE,'-','') as FDSXR,
        --replace(  rec_fdzrmx.POLICYENDDATE,'-','') as FDZZR,                              -- -V1.3
        to_char(to_date(replace(rec_fdzrmx.policyenddate,'-',''),'yyyyMMdd')-1,'yyyyMMdd')  as FDZZR, -- +V1.3
          '1' as fdzt,
          '' fdzbf,
          b.khid as BbrKhid,
          rec_fdzrmx.age as BBRNL ,
           '' ZYLB, '' as ZYDM,
         '' as ZTTID,
          rec_fdzrmx.CONTPLANCODE as  DJ,
          b.gzdxzqh as GZDXZQH,
         '' as  DZID ,
        '' as jtdz,
         case when rec_fdzrmx.RELATION is not null and rec_fdzrmx.RELATION!= '??'  then '1' else '0' end as ZLDBZ,
           --FUNC_GETCODEBYBXGSDM(946,'ZBBRGX',rec_fdzrmx.RELATION,'','' ) as ZBBRGX, --???????????????????????
        --FUNC_GETCODEBYBXGSDM(946,'ZBBRGX',decode(rec_fdzrmx.RELATION,'??','??',rec_fdzrmx.RELATION),'','' ) as ZBBRGX,  --??????????rows????????????????FUNC_GETCODEBYBXGSDM??????????????????????????????????????????????FUNC_GETCODEBYBXGSDM?
        FUNC_GETCODEBYBXGSDM(946,'ZBBRGX',(SELECT J.BXGSXMBM FROM TB_ZDDMBXGSDMDZB J WHERE J.BXGSID=946 AND J.AAA100='ZBBRGX' AND J.BXGSXMMC=(decode(rec_fdzrmx.RELATION,'??','??',rec_fdzrmx.RELATION))),'','' ) as ZBBRGX,
         case when rec_fdzrmx.RELATION is not null and rec_fdzrmx.RELATION!= '??'  then (select to_char(max(khid)) from tb_khxx  where xm=rec_fdzrmx.MAININSUNAME and khbh=rec_fdzrmx.MAININSUNO) else '' end as ZBBRKHID ,
         '' Zbbrfdh ,
        '' FDZS1, '' FDZS2,
        (SELECT DJID FROM TB_BDDJXX WHERE BDID in(select bdid from tb_bdxx where khbdh= rec_bd.POLICY_NO) AND DJbh =  rec_fdzrmx.CONTPLANCODE ) as djid,
        b.ybdxzqh YBDXZQH,'' JZDXZQH,
          to_number(to_char(SYSDATE,'yyyymmdd')) as Cjrq,
         (select bdid from tb_bdxx where khbdh= rec_bd.POLICY_NO)  as BDID,
        rec_bd.POLICY_NO as  wbbdh,
        rec_bd.BQBWID as seqlogid
        FROM  tb_khxx b
          where  b.aac147=rec_fdzrmx.IDNO and b.xm=rec_fdzrmx.NAME and b.khbh=rec_fdzrmx.INSUREDNO and rec_fdzrmx.contractstatus<>'?????' and  rownum<2;
          --update 2015-11-18
      elsif rec_fdzrmx.cvalidate<v_fdxx.fdsxr and rec_fdzrmx.policyenddate>v_fdxx.fdzzr or rec_fdzrmx.cvalidate<v_fdxx.fdsxr and rec_fdzrmx.policyenddate<v_fdxx.fdzzr then
              update tb_fdxx f set f.fdsxr=  replace(  rec_fdzrmx.CVALIDATE,'-',''),f.FDZZR=  /*replace( rec_fdzrmx.POLICYENDDATE,'-','')  -- -V1.3*/ to_char(to_date(replace(rec_fdzrmx.POLICYENDDATE,'-',''),'yyyyMMdd')-1,'yyyyMMdd')   where fdid=v_fdid;
       else
         select  seq_Fdid.nextval into  v_fdid from dual;
          INSERT INTO TB_FDXX(
            FDID, TTID, KHBDH, TBDH, FDH,
          FDSXR, FDZZR, FDZT, FDZBF, BBRKHID,
          BBRNL, ZYLB, ZYDM, ZTTID, DJ,
          GZDXZQH, BBRDZID, BBRDZXX,
          ZLDBZ, ZBBRGX, ZBBRKHID, ZBBRFDH,
          FDZS1, FDZS2, DJID,
          YBDXZQH, JZDQH,Cjrq,Bdid,WBBDH,seqlogid)
        SELECT
          v_fdid as fdid,v_ttid TTID, rec_bd.POLICY_NO as KHBDH, '' as TBDH,
         rec_fdzrmx.CONTNO as fdh,
        replace( rec_fdzrmx.CVALIDATE,'-','') as FDSXR,
        --replace(  rec_fdzrmx.POLICYENDDATE,'-','') as FDZZR,                              -- -V1.3
        to_char(to_date(replace(rec_fdzrmx.POLICYENDDATE,'-',''),'yyyyMMdd')-1,'yyyyMMdd')  as FDZZR, -- +V1.3
          '1' as fdzt,
          '' fdzbf,
          b.khid as BbrKhid,
          rec_fdzrmx.age as BBRNL ,
           '' ZYLB, '' as ZYDM,
         '' as ZTTID,
          rec_fdzrmx.CONTPLANCODE as  DJ,
          b.gzdxzqh as GZDXZQH,
         '' as  DZID ,
        '' as jtdz,
         case when rec_fdzrmx.RELATION is not null and rec_fdzrmx.RELATION!= '??'  then '1' else '0' end as ZLDBZ,
           --FUNC_GETCODEBYBXGSDM(946,'ZBBRGX',rec_fdzrmx.RELATION,'','' ) as ZBBRGX, --???????????????????????
        --FUNC_GETCODEBYBXGSDM(946,'ZBBRGX',decode(rec_fdzrmx.RELATION,'??','??',rec_fdzrmx.RELATION),'','' ) as ZBBRGX,  --??????????rows????????????????FUNC_GETCODEBYBXGSDM??????????????????????????????????????????????FUNC_GETCODEBYBXGSDM?

        FUNC_GETCODEBYBXGSDM(946,'ZBBRGX',(SELECT J.BXGSXMBM FROM TB_ZDDMBXGSDMDZB J WHERE J.BXGSID=946 AND J.AAA100='ZBBRGX' AND J.BXGSXMMC=(decode(rec_fdzrmx.RELATION,'??','??',rec_fdzrmx.RELATION))),'','' ) as ZBBRGX,
         case when rec_fdzrmx.RELATION is not null and rec_fdzrmx.RELATION!= '??'  then (select to_char(max(khid)) from tb_khxx  where xm=rec_fdzrmx.MAININSUNAME and khbh=rec_fdzrmx.MAININSUNO) else '' end as ZBBRKHID ,
         '' Zbbrfdh ,
        '' FDZS1, '' FDZS2,
        (SELECT DJID FROM TB_BDDJXX WHERE BDID in(select bdid from tb_bdxx where khbdh= rec_bd.POLICY_NO) AND DJbh =  rec_fdzrmx.CONTPLANCODE ) as djid,
        b.ybdxzqh YBDXZQH,'' JZDXZQH,
          to_number(to_char(SYSDATE,'yyyymmdd')) as Cjrq,
         (select bdid from tb_bdxx where khbdh= rec_bd.POLICY_NO)  as BDID,
        rec_bd.POLICY_NO as  wbbdh,
        rec_bd.BQBWID as seqlogid
        FROM  tb_khxx b
          where  b.aac147=rec_fdzrmx.IDNO and b.xm=rec_fdzrmx.NAME and b.khbh=rec_fdzrmx.INSUREDNO and rec_fdzrmx.contractstatus<>'?????' and  rownum<2;  --1.5
         end if;
         /*update tb_fdxx f set f.fdsxr=  replace(  rec_fdzrmx.CVALIDATE,'-',''),f.FDZZR=  \*replace( rec_fdzrmx.POLICYENDDATE,'-','')  -- -V1.3*\ to_char(to_date(replace(rec_fdzrmx.POLICYENDDATE,'-',''),'yyyyMMdd')-1,'yyyyMMdd')   where fdid=v_fdid;*/--????????????????????

     -- ??????????
       --??????
       select * into  v_fdzrmx from tb_fdzrmx  a,tb_zrxx b where a.zrid=b.zrid and b.zrbm=rec_fdzrmx.DUTYCODE and fdid=v_fdid;
        INSERT INTO TB_FDZRMX(
          FDZRID, FDID, ZRXH, ZRID,
          BELX, BEDW, GMFSHYS, ZRBE,
          ZRBF, ZRBZBF, ZRFJF, ZRLJPFE, ZRLJMPE,
          ZRKSRQ, ZRJSRQ, YXBS, ZDBE, ZGBE,SEQLOGID,Polno)
        SELECT
          TO_NUMBER(SEQ_FDZRID.NEXTVAL), v_fdid as fdid, rownum, b.ZRID,
          B.BELX, B.BEDW, DECODE(rec_fdzrmx.AMNT, '', '', TRUNC(rec_fdzrmx.AMNT/B.BEDW) ) as GMFSHYS,
          --rec_fdzrmx.AMNT,????????????
          --CASE WHEN B.ZRBM='PP00001' THEN (select h.BEDW from tb_zrxx h where h.zrbm='PP00001' ) ELSE to_number(rec_fdzrmx.AMNT) END, --ELSE rec_fdzrmx.AMNT END,
          CASE WHEN B.ZRBM='PP00001' THEN (select be from TB_BDDJZRXX where zrdm='PP00001' and bdid=(select bdid from tb_bdxx where khbdh= rec_bd.POLICY_NO) and rownum=1)  else to_number(rec_fdzrmx.AMNT) end,
        --rec_fdzrmx.PREM,???????????????
          CASE WHEN B.ZRBM like'OIP0%' THEN rec_fdzrmx.PREM ELSE NULL END,

           NULL, NULL, NULL, NULL,
            replace( rec_fdzrmx.CVALIDATE,'-','') as zrksrq,
        replace(  rec_fdzrmx.POLICYENDDATE,'-','') as zrjsrq,
           null YXBS, null ZDBE, null ZGBE,rec_fdzrmx.BQMXID as seqlogid,rec_fdzrmx.polno
        FROM  TB_ZRXX B,tb_fdxx e
        WHERE  e.fdid=v_fdid
       -- and b.zrbm=rec_fdzrmx.DUTYCODE
        --and b.zrbm=nvl(case when rec_fdzrmx.relation='??' then FUNC_GETCODEBYBXGSDM(946,'ZRDM',rec_fdzrmx.DUTYCODE,rec_fdzrmx.relation,'') else  FUNC_GETCODEBYBXGSDM(946,'ZRDM',rec_fdzrmx.DUTYCODE,'','') end ,'OP00002')
        and b.zrbm= FUNC_GETCODEBYBXGSDM(946,'ZRDM',rec_fdzrmx.DUTYCODE,rec_bd.POLICY_NO||'@'||trim(rec_fdzrmx.CONTPLANCODE),'')
        and not exists(select 'x' from TB_FDZRMX where fdid=e.fdid and zrid=b.zrid and nvl(ZRKSRQ,e.fdsxr)= replace( rec_fdzrmx.CVALIDATE,'-','')
         and  nvl(ZRJSRQ,e.fdzzr)= replace( rec_fdzrmx.POLICYENDDATE,'-',''));
         v_no:=SQL%rowcount;
      --   dbms_output.put_line('??????????'|| to_char(v_no));
         if  v_no=0 then  --?????????????
           --insert 2015-11-18?????????????????????? ?????????????????????????????
           if v_fdzrmx.zrksrq>rec_fdzrmx.cvalidate and v_fdzrmx.zrjsrq>rec_fdzrmx.policyenddate or v_fdzrmx.zrksrq<rec_fdzrmx.cvalidate and v_fdzrmx.zrjsrq<rec_fdzrmx.policyenddate then
       -- and b.zrbm=rec_fdzrmx.DUTYCODE
        --and b.zrbm=nvl(case when rec_fdzrmx.relation='??' then FUNC_GETCODEBYBXGSDM(946,'ZRDM',rec_fdzrmx.DUTYCODE,rec_fdzrmx.relation,'') else  FUNC_GETCODEBYBXGSDM(946,'ZRDM',rec_fdzrmx.DUTYCODE,'','') end ,'OP00002')
        and b.zrbm= FUNC_GETCODEBYBXGSDM(946,'ZRDM',rec_fdzrmx.DUTYCODE,rec_bd.POLICY_NO||'@'||trim(rec_fdzrmx.CONTPLANCODE),'')
        and not exists(select 'x' from TB_FDZRMX where fdid=e.fdid and zrid=b.zrid and nvl(ZRKSRQ,e.fdsxr)= replace( rec_fdzrmx.CVALIDATE,'-','')
         and  nvl(ZRJSRQ,e.fdzzr)= replace( rec_fdzrmx.POLICYENDDATE,'-',''));
                INSERT INTO TB_FDZRMX(
          FDZRID, FDID, ZRXH, ZRID,
          BELX, BEDW, GMFSHYS, ZRBE,
          ZRBF, ZRBZBF, ZRFJF, ZRLJPFE, ZRLJMPE,
          ZRKSRQ, ZRJSRQ, YXBS, ZDBE, ZGBE,SEQLOGID,Polno)
        SELECT
          TO_NUMBER(SEQ_FDZRID.NEXTVAL), v_fdid as fdid, rownum, b.ZRID,
          B.BELX, B.BEDW, DECODE(rec_fdzrmx.AMNT, '', '', TRUNC(rec_fdzrmx.AMNT/B.BEDW) ) as GMFSHYS,
          --rec_fdzrmx.AMNT,????????????
          --CASE WHEN B.ZRBM='PP00001' THEN (select h.BEDW from tb_zrxx h where h.zrbm='PP00001' ) ELSE to_number(rec_fdzrmx.AMNT) END, --ELSE rec_fdzrmx.AMNT END,
          CASE WHEN B.ZRBM='PP00001' THEN (select be from TB_BDDJZRXX where zrdm='PP00001' and bdid=(select bdid from tb_bdxx where khbdh= rec_bd.POLICY_NO) and rownum=1)  else to_number(rec_fdzrmx.AMNT) end,
        --rec_fdzrmx.PREM,???????????????
          CASE WHEN B.ZRBM like'OIP0%' THEN rec_fdzrmx.PREM ELSE NULL END,

           NULL, NULL, NULL, NULL,
            replace( rec_fdzrmx.CVALIDATE,'-','') as zrksrq,
            replace(  rec_fdzrmx.POLICYENDDATE,'-','') as zrjsrq,
           null YXBS, null ZDBE, null ZGBE,rec_fdzrmx.BQMXID as seqlogid,rec_fdzrmx.polno
        FROM  TB_ZRXX B,tb_fdxx e
        WHERE e.fdid=v_fdid
       -- and b.zrbm=rec_fdzrmx.DUTYCODE
        --and b.zrbm=nvl(case when rec_fdzrmx.relation='??' then FUNC_GETCODEBYBXGSDM(946,'ZRDM',rec_fdzrmx.DUTYCODE,rec_fdzrmx.relation,'') else  FUNC_GETCODEBYBXGSDM(946,'ZRDM',rec_fdzrmx.DUTYCODE,'','') end ,'OP00002')
        and b.zrbm= FUNC_GETCODEBYBXGSDM(946,'ZRDM',rec_fdzrmx.DUTYCODE,rec_bd.POLICY_NO||'@'||trim(rec_fdzrmx.CONTPLANCODE),'')
        and not exists(select 'x' from TB_FDZRMX where fdid=e.fdid and zrid=b.zrid and nvl(ZRKSRQ,e.fdsxr)= replace( rec_fdzrmx.CVALIDATE,'-','')
         and  nvl(ZRJSRQ,e.fdzzr)= replace( rec_fdzrmx.POLICYENDDATE,'-',''));
         v_no:=SQL%rowcount;
         elsif rec_fdzrmx.cvalidate<v_fdzrmx.zrksrq and rec_fdzrmx.policyenddate>v_fdzrmx.zrjsrq or rec_fdzrmx.cvalidate<v_fdzrmx.zrksrq and rec_fdzrmx.policyenddate<v_fdzrmx.zrjsrq then
          --update 2015-11-18
         update   TB_FDZRMX a set (
            GMFSHYS,ZRBE,ZRBF,ZRKSRQ,ZRJSRQ)=(select  DECODE(rec_fdzrmx.AMNT, '', '', TRUNC(rec_fdzrmx.AMNT/B.BEDW) ) as GMFSHYS,
            rec_fdzrmx.AMNT, -- ????????????[  ?????????]
           -- (select h.BEDW from tb_zrxx h where h.zrbm=rec_fdzrmx.DUTYCODE) as ZRBE,[???]
            rec_fdzrmx.PREM ,--???????????????[  ?????????]
            replace( rec_fdzrmx.CVALIDATE,'-','') as ZRKSRQ,
            replace( rec_fdzrmx.Policyenddate,'-','') as ZRJSRQ
            --case when (select h.zrbm from tb_zrxx h,TB_FDZRMX a where a.zrid=h.zrid)='OIP00005' then rec_fdzrmx.PREM else null end as ZRBF [???]
            from tb_zrxx B where b.zrbm=rec_fdzrmx.DUTYCODE)
              where fdid=v_fdid and a.zrid in(select b.zrid from TB_ZRXX B where b.zrbm=/*rec_fdzrmx.DUTYCODE*/case when rec_fdzrmx.relation='??' then FUNC_GETCODEBYBXGSDM(946,'ZRDM',rec_fdzrmx.DUTYCODE,rec_fdzrmx.relation,'') else  FUNC_GETCODEBYBXGSDM(946,'ZRDM',rec_fdzrmx.DUTYCODE,'','') end);
           v_no:=SQL%rowcount;
           --update+insert
           --???????
            elsif  rec_fdzrmx.cvalidate<v_fdzrmx.zrksrq and rec_fdzrmx.policyenddate<v_fdzrmx.zrjsrq or rec_fdzrmx.cvalidate<v_fdzrmx.zrksrq and rec_fdzrmx.policyenddate>v_fdzrmx.zrjsrq then
             update   TB_FDZRMX a set (
            GMFSHYS,ZRBE,ZRBF,ZRKSRQ,ZRJSRQ)=(select  DECODE(rec_fdzrmx.AMNT, '', '', TRUNC(rec_fdzrmx.AMNT/B.BEDW) ) as GMFSHYS,
            rec_fdzrmx.AMNT, -- ????????????[  ?????????]
           -- (select h.BEDW from tb_zrxx h where h.zrbm=rec_fdzrmx.DUTYCODE) as ZRBE,[???]
            rec_fdzrmx.PREM ,--???????????????[  ?????????]
            replace( v_fdzrmx.zrksrq,'-','') as ZRKSRQ,
           to_char(to_date(replace(rec_fdzrmx.CVALIDATE,'-',''),'yyyyMMdd')-1,'yyyyMMdd') as ZRJSRQ
            --case when (select h.zrbm from tb_zrxx h,TB_FDZRMX a where a.zrid=h.zrid)='OIP00005' then rec_fdzrmx.PREM else null end as ZRBF [???]
            from tb_zrxx B where b.zrbm=rec_fdzrmx.DUTYCODE)
              where fdid=v_fdid and a.zrid in(select b.zrid from TB_ZRXX B where b.zrbm=/*rec_fdzrmx.DUTYCODE*/case when rec_fdzrmx.relation='??' then FUNC_GETCODEBYBXGSDM(946,'ZRDM',rec_fdzrmx.DUTYCODE,rec_fdzrmx.relation,'') else  FUNC_GETCODEBYBXGSDM(946,'ZRDM',rec_fdzrmx.DUTYCODE,'','') end);
           v_no:=SQL%rowcount;
           --?insert??
             INSERT INTO TB_FDZRMX(
          FDZRID, FDID, ZRXH, ZRID,
          BELX, BEDW, GMFSHYS, ZRBE,
          ZRBF, ZRBZBF, ZRFJF, ZRLJPFE, ZRLJMPE,
          ZRKSRQ, ZRJSRQ, YXBS, ZDBE, ZGBE,SEQLOGID,Polno)
        SELECT
          TO_NUMBER(SEQ_FDZRID.NEXTVAL), v_fdid as fdid, rownum, b.ZRID,
          B.BELX, B.BEDW, DECODE(rec_fdzrmx.AMNT, '', '', TRUNC(rec_fdzrmx.AMNT/B.BEDW) ) as GMFSHYS,
          --rec_fdzrmx.AMNT,????????????
          --CASE WHEN B.ZRBM='PP00001' THEN (select h.BEDW from tb_zrxx h where h.zrbm='PP00001' ) ELSE to_number(rec_fdzrmx.AMNT) END, --ELSE rec_fdzrmx.AMNT END,
          CASE WHEN B.ZRBM='PP00001' THEN (select be from TB_BDDJZRXX where zrdm='PP00001' and bdid=(select bdid from tb_bdxx where khbdh= rec_bd.POLICY_NO) and rownum=1)  else to_number(rec_fdzrmx.AMNT) end,
        --rec_fdzrmx.PREM,???????????????
          CASE WHEN B.ZRBM like'OIP0%' THEN rec_fdzrmx.PREM ELSE NULL END,

           NULL, NULL, NULL, NULL,
            replace( rec_fdzrmx.CVALIDATE,'-','') as zrksrq,
        replace(  rec_fdzrmx.POLICYENDDATE,'-','') as zrjsrq,
           null YXBS, null ZDBE, null ZGBE,rec_fdzrmx.BQMXID as seqlogid,rec_fdzrmx.polno
        FROM  TB_ZRXX B,tb_fdxx e
        WHERE e.fdid=v_fdid
       -- and b.zrbm=rec_fdzrmx.DUTYCODE
        --and b.zrbm=nvl(case when rec_fdzrmx.relation='??' then FUNC_GETCODEBYBXGSDM(946,'ZRDM',rec_fdzrmx.DUTYCODE,rec_fdzrmx.relation,'') else  FUNC_GETCODEBYBXGSDM(946,'ZRDM',rec_fdzrmx.DUTYCODE,'','') end ,'OP00002')
        and b.zrbm= FUNC_GETCODEBYBXGSDM(946,'ZRDM',rec_fdzrmx.DUTYCODE,rec_bd.POLICY_NO||'@'||trim(rec_fdzrmx.CONTPLANCODE),'')
        and not exists(select 'x' from TB_FDZRMX where fdid=e.fdid and zrid=b.zrid and nvl(ZRKSRQ,e.fdsxr)= replace( rec_fdzrmx.CVALIDATE,'-','')
         and  nvl(ZRJSRQ,e.fdzzr)= replace( rec_fdzrmx.POLICYENDDATE,'-',''));
         v_no:=SQL%rowcount;
           /* update   TB_FDZRMX a set (
            GMFSHYS,ZRBE,ZRBF)=(select  DECODE(rec_fdzrmx.AMNT, '', '', TRUNC(rec_fdzrmx.AMNT/B.BEDW) ) as GMFSHYS,
            rec_fdzrmx.AMNT, -- ????????????[  ?????????]
           -- (select h.BEDW from tb_zrxx h where h.zrbm=rec_fdzrmx.DUTYCODE) as ZRBE,[???]
            rec_fdzrmx.PREM --???????????????[  ?????????]
            --case when (select h.zrbm from tb_zrxx h,TB_FDZRMX a where a.zrid=h.zrid)='OIP00005' then rec_fdzrmx.PREM else null end as ZRBF [???]
            from tb_zrxx B where b.zrbm=rec_fdzrmx.DUTYCODE)
              where fdid=v_fdid and a.zrid in(select b.zrid from TB_ZRXX B where b.zrbm=\*rec_fdzrmx.DUTYCODE*\case when rec_fdzrmx.relation='??' then FUNC_GETCODEBYBXGSDM(946,'ZRDM',rec_fdzrmx.DUTYCODE,rec_fdzrmx.relation,'') else  FUNC_GETCODEBYBXGSDM(946,'ZRDM',rec_fdzrmx.DUTYCODE,'','') end);
           v_no:=SQL%rowcount;  */

            update TB_XC_PRESERVATION_IMPORT_ROWS a set flag='U' where BQMXID=rec_fdzrmx.BQMXID; --????
        else
            update TB_XC_PRESERVATION_IMPORT_ROWS a set flag='Y' where BQMXID=rec_fdzrmx.BQMXID;   --????
         end if;
       end loop;
         --???????

         update TB_XC_PRESERVATION_IMPORT_BASE a set flag='Y',a.update_time = sysdate where BQBWID=rec_bd.BQBWID;   --??????????
            v_no:=SQL%rowcount;
         dbms_output.put_line('??'||rec_bd.POLICY_NO ||'???????????'|| to_char(v_no));
           --?????????
         update   TB_FDXX t set t.fdzbf=(select nvl(sum(nvl(zrbf,0)),0) from tb_fdzrmx h where h.fdid=t.fdid) where t.khbdh =rec_bd.POLICY_NO  and cjrq=to_char(sysdate,'yyyymmdd');
             --???????
         update   TB_bDXX t set t.bf=(select nvl(sum(nvl(fdzbf,0)),0) from tb_fdxx h where h.khbdh=t.khbdh) where t.khbdh =rec_bd.POLICY_NO ;
         --????????????? TB_KHXX.bgsj
         update TB_KHXX a set bgsj=(select max(fdsxr) from tb_fdxx where bbrkhid=a.khid ),czsj=sysdate where khid in(select bbrkhid from  TB_FDXX t
           where  t.khbdh =rec_bd.POLICY_NO  and t.cjrq=to_char(sysdate,'yyyymmdd'));
            v_no:=SQL%rowcount;
         dbms_output.put_line('??'||rec_bd.POLICY_NO ||'?????????'|| to_char(v_no));
      end loop;
      --?????????????

    PReturnCode:='0';
    PReturnMsg:='????????!';
    EXCEPTION
  WHEN OTHERS THEN
    PReturnCode := 'E';
    DBMS_OUTPUT.PUT_LINE('[yhs debug] ' || 'PReturncode= ' ||
                         PReturnCode);
    PReturnMsg := 'Error:' || sqlerrm;
    DBMS_OUTPUT.PUT_LINE(PReturnMsg);
  end   SP_IMPORT_BQXX_CITIC;

/
