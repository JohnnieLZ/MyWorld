CREATE PROCEDURE      "SP_P1_SJDR_FPTCCDEXXFT" (pInLsid    In varchar2,
                                     PReturnCode   OUT varchar2,
                                     PReturnMsg    OUT varchar2) AS
  V_STEP_CODE  CHAR(5);--?????????????????

  rowno     number := 0;  --??????
  rec_fpxx  TB_LPFPXX%rowtype; --?????????

  v_sumzfje number:=0; --??????????
  v_sumflzfje number:=0;--????????????
  v_tempje number:=0;--??????
  v_tczfwc number:=0;--???????
  v_fjzfwc number:=0;--???????
  v_sbzfwc number:=0;--???????
  v_cdewc number:=0;--?????
begin
  V_STEP_CODE := '00000';
  PReturnMsg  := 'OK';
  PReturnCode := 'E';
  select * into rec_fpxx from TB_LPFPXX where fpid=to_number(trim(pInLsid));
  if nvl(rec_fpxx.fpze,0)<=0 then
      PReturnMsg  := '?????????????';
      PReturnCode := '0';
      return;
  end if;
  if (nvl(rec_fpxx.tczfe,0)+ nvl(rec_fpxx.fjzfe,0)+ nvl(rec_fpxx.sbzfe,0))>0 then
			  select nvl(sum(nvl(zfje,0)),0), nvl(sum(nvl(flzfje,0)),0) into v_sumzfje,v_sumflzfje from TB_FPXXFYXX where fpid=rec_fpxx.fpid ;
			  --???????
			  for rec in(select * from TB_FPXXFYXX where fpid=rec_fpxx.fpid ) loop
          if (rec_fpxx.fpze-v_sumzfje-v_sumflzfje)>0 then --yhs 20150417 ????0??????
			     if nvl(rec_fpxx.tczfe,0)>0 then --????????0?????????
			        v_tempje:= round(round((nvl(rec.zdje,0)-nvl(rec.zfje,0)-nvl(rec.flzfje,0))/(rec_fpxx.fpze-v_sumzfje-v_sumflzfje),5)*nvl(rec_fpxx.tczfe,0),2);
			        --????????????????
			        select case when v_tempje>rec.zdje then rec.zdje else v_tempje end into v_tempje from dual;
			        update  TB_FPXXFYXX set tczfe=v_tempje where xxid=rec.xxid;
			     end if;
			     if nvl(rec_fpxx.fjzfe,0)>0 then --????????0?????????
			        v_tempje:= round(round((nvl(rec.zdje,0)-nvl(rec.zfje,0)-nvl(rec.flzfje,0))/(rec_fpxx.fpze-v_sumzfje-v_sumflzfje),5)*nvl(rec_fpxx.fjzfe,0),2);
               --????????????????
              select case when v_tempje>rec.zdje then rec.zdje else v_tempje end into v_tempje from dual;
              update  TB_FPXXFYXX set fjzfe=v_tempje where xxid=rec.xxid;
           end if;
           if nvl(rec_fpxx.sbzfe,0)>0 then --??????????0?????????
              v_tempje:= round(round((nvl(rec.zdje,0)-nvl(rec.zfje,0)-nvl(rec.flzfje,0))/(rec_fpxx.fpze-v_sumzfje-v_sumflzfje),5)*nvl(rec_fpxx.sbzfe,0),2);
               --????????????????
              select case when v_tempje>rec.zdje then rec.zdje else v_tempje end into v_tempje from dual;
              update  TB_FPXXFYXX set sbzfe=v_tempje where xxid=rec.xxid;
           end if;
           --???????
           if nvl(rec_fpxx.cdeje,0)>0 then
              v_tempje:= round(round((nvl(rec.zdje,0)-nvl(rec.zfje,0)-nvl(rec.flzfje,0))/(rec_fpxx.fpze-v_sumzfje-v_sumflzfje),5)*nvl(rec_fpxx.cdeje,0),2);
               --????????????????
              select case when v_tempje>rec.zdje then rec.zdje else v_tempje end into v_tempje from dual;
              update  TB_FPXXFYXX set CDEJE=v_tempje where xxid=rec.xxid;
           end if;
          end if;
        end loop;
        --???????????
        select nvl(rec_fpxx.tczfe,0)-nvl(sum(nvl(tczfe,0)),0),nvl(rec_fpxx.fjzfe,0)-nvl(sum(nvl(fjzfe,0)),0),nvl(rec_fpxx.sbzfe,0)-nvl(sum(nvl(sbzfe,0)),0), nvl(rec_fpxx.cdeje, 0) - nvl(sum(nvl(cdeje, 0)), 0)
            into v_tczfwc,v_fjzfwc,v_sbzfwc,v_cdewc from TB_FPXXFYXX where fpid=rec_fpxx.fpid ;
        if  v_tczfwc!=0 then --?????????????
            update TB_FPXXFYXX a set tczfe=tczfe+v_tczfwc where fpid=rec_fpxx.fpid and nvl(tczfe,0)>0 and (nvl(zfje,0)+nvl(flzfje,0)+nvl(tczfe,0)+nvl(fjzfe,0)+nvl(sbzfe,0)+nvl(cdeje, 0)+v_tczfwc)<=nvl(zdje,0) and rownum<2;
        end if;
         if  v_fjzfwc!=0 then --?????????????
            update TB_FPXXFYXX set fjzfe=fjzfe+v_fjzfwc where fpid=rec_fpxx.fpid and nvl(fjzfe,0)>0 and (nvl(zfje,0)+nvl(flzfje,0)+nvl(tczfe,0)+nvl(fjzfe,0)+nvl(sbzfe,0)+nvl(cdeje, 0)+v_fjzfwc)<=nvl(zdje,0) and rownum<2;
        end if;
        if  v_sbzfwc!=0 then --?????????????
            update TB_FPXXFYXX set sbzfe=sbzfe+v_sbzfwc where fpid=rec_fpxx.fpid and nvl(sbzfe,0)>0 and (nvl(zfje,0)+nvl(flzfje,0)+nvl(tczfe,0)+nvl(fjzfe,0)+nvl(sbzfe,0)+nvl(cdeje, 0)+v_sbzfwc)<=nvl(zdje,0)  and rownum<2;
        end if;

        if  v_cdewc!=0 then --??????????
           update TB_FPXXFYXX set cdeje=cdeje+v_cdewc where fpid=rec_fpxx.fpid and nvl(cdeje,0)>0 and  (nvl(zfje,0)+nvl(flzfje,0)+nvl(tczfe,0)+nvl(fjzfe,0)+nvl(sbzfe,0)+nvl(cdeje, 0)+v_cdewc)<=nvl(zdje,0) and rownum<2;
        end if;
        --????????????????????
        update TB_FPXXFYXX set SBZFJE=nvl(tczfe,0)+nvl(fjzfe,0)+nvl(sbzfe,0) where fpid=rec_fpxx.fpid ;
   end if;



  PReturnCode := '0'; /* ??????????????vstatid????????? */
  PReturnMsg  := '';
  DBMS_OUTPUT.PUT_LINE('[yhs debug] ' || 'PReturncode= ' || PReturnCode);
  --COMMIT; ???java?????????
EXCEPTION
  WHEN OTHERS THEN
    --rollback;???java?????????????0?????????????????
    PReturnCode := 'E'; /*  ??????  */
    DBMS_OUTPUT.PUT_LINE('[yhs debug] ' || 'PReturncode= ' ||PReturnCode);
    PReturnMsg :=  'Error:' || sqlerrm; --???????????
    DBMS_OUTPUT.PUT_LINE(PReturnMsg);
end SP_P1_SJDR_FPTCCDEXXFT;

/
