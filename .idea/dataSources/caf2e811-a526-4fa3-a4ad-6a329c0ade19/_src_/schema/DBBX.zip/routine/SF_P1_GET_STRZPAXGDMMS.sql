CREATE function SF_P1_GET_STRZPAXGDMMS(pFpid in varchar2,p_aaa100 in varchar2) return varchar2 is
cursor cur_rec is 
 select g.aaa102,case when exists(select 'x' from aa10 where aaa100='XTXGDM' and aaa102=g.aaa102) then (select aaa103 from aa10 where aaa100='XTXGDM' and aaa102=g.aaa102)
	                                         else ( select aaa103 from aa10 where aaa100='FPXGDM' and aaa102=g.aaa102) end as aaa103,
        (select max(aaa100)  from aa10 where aaa102=g.aaa102 and aaa100 in('XTXGDM','FPXGDM')) as aaa100 ,
        (select fpid from tb_zpaxx where zpaid=pFpid) as fpid                                     
    from (select COLUMN_VALUE as aaa102 from TABLE(sf_splitstr((select XGDM from tb_zpaxx where zpaid=pFpid),',')) h ) g /* order by aaa100*/ ;   
v_FPXGDMMS varchar2(4096):='';
--

Result varchar2(4096):='' ;
 --v2.2++ begin
 v_kfckxzqhdm varchar2(10):='';
 v_kfcklx  varchar2(2):='';
 v_ifgetfpxgms  varchar2(1):='0';
 v_fpid number:=-1;
 rec_ajxx tb_zpaxx%rowtype;
 
BEGIN
   --获取扣费参考地区划
   /* select  (select kfcklx from tb_bdxx where khbdh=b.khbdh) as kfcklx,
     (select decode (nvl(kfcklx,'1'),'1' ,(select b.xzqhdm from tb_yyxx b ,tb_lpfpxx a where b.yyid=a.yyid and a.fpid=(select fpid from tb_zpaxx where zpaid=Pfpid)),'2' , cbdqh,'3',KFZDQH,'') as kfckxzqhdm from tb_bdxx where khbdh=b.khbdh) as kfckxzqhdm into v_kfcklx,v_kfckxzqhdm 
     from  tb_lpajxx b where  ajid=(select ajid from tb_zpaxx where zpaid=pFpid);
*/
 if length(trim(pFpid))=0 then
    Result:='无';
  end if;
 
  for rec_xy in cur_rec loop
     if rec_xy.aaa100 ='XTXGDM' and (rec_xy.aaa102 like 'SY00%' or rec_xy.aaa102 in('CL92', 'CL93','CL94','CL95','CL87', 'CL88','CL89','CL90')) then 
          v_FPXGDMMS:=rec_xy.aaa103||'(';--去掉具体内容
          if rec_xy.aaa102 like 'SY00%' then 
              /*for rec_dt in(select distinct d.xxdm,d.xxmc from  tb_fpxxfyxx d,tb_zpaxxdzb xx,tb_zpaxx a   where xx.zpaid=a.zpaid and a.zpaid=Pfpid and d.xxid=xx.xxid and  exists(select 'x' from tb_sbshgzpzxx e 
                                                             where  e.ZSDBM=d.XXDM and e.ZSDLB=d.xmlb
                                                                   and e.status='1' and e.AAA102=substr(rec_xy.aaa102,1,5)
                                                                   and ( ( e.AAA102='SY008' and d.ZDDM not in(select shys2 from tb_sbshgzpzxx h where nvl(h.xzqh,'xxx')=nvl(e.xzqh,'xxx') and h.aaa102=e.aaa102 and h.status='1' and h.zsdbm=e.zsdbm)) 
                                                                      or (e.AAA102='SY009' and e.shys1='09' and d.ZDDM not in(select ZDDM  as xxx from
                                                                     tb_bdtyshgzzddmpz  h,tb_fdxx y  where h.bdid=y.bdid and y.fdid=a.fdid  and h.zrid=a.zrid   and h.jblx=e.SHYS2 and h.YXZT='1'))
                                                                     or (rec_xy.aaa102 not in('SY009','SY008'))) )
                            ) loop
                 v_FPXGDMMS:=substr( v_FPXGDMMS||rec_dt.xxmc||',',1,4096);          
              end loop;*/
              null;
         end if;
         --看费用悬挂描述获取
         if rec_xy.aaa102 in('CL87', 'CL88','CL89') then 
             for rec_dt in(select distinct d.xxdm,d.xxmc from  tb_fpxxfyxx d,tb_zpaxxdzb xx ,tb_zpaxx a   where xx.zpaid=a.zpaid and a.zpaid=Pfpid and d.xxid=xx.xxid and  exists(select 'x' from TB_TYSHGZYJXX e where  e.ZSDBM=d.xxDM and e.ZSDLB=d.xmlb
                                                                   and e.status='1' and e.SHYS1=decode( rec_xy.aaa102,'CL87','11','CL88','12','CL89','13',rec_xy.aaa102))
                            ) loop
                 v_FPXGDMMS:=substr( v_FPXGDMMS||rec_dt.xxmc||',',1,4096);          
              end loop;
         end if;
          --看诊断类悬挂描述获取
         if rec_xy.aaa102 in('CL90', 'CL92','CL93','CL94','CL95') then 
             for rec_dt in(select distinct d.xxdm,d.xxmc from  tb_fpxxfyxx d,tb_zpaxxdzb xx ,tb_zpaxx a   where xx.zpaid=a.zpaid and a.zpaid=Pfpid and d.xxid=xx.xxid and  exists(select 'x' from TB_TYSHGZYJXX e where  e.ZSDBM=d.zdDM and e.ZSDLB='3'
                                                                   and e.status='1' and e.SHYS1=decode( rec_xy.aaa102,'CL90','13','CL92','1L','CL93','1N','CL94','02','CL95','03',rec_xy.aaa102))
                            ) loop
                 v_FPXGDMMS:=substr( v_FPXGDMMS||rec_dt.xxmc||',',1,4096);          
              end loop;
         end if;
          if  v_FPXGDMMS like '%,' then 
            v_FPXGDMMS:=substr(v_FPXGDMMS,1,length(trim(v_FPXGDMMS))-1);
          end if;
           v_FPXGDMMS:= v_FPXGDMMS||')';
           Result:=Result||v_FPXGDMMS;
     else       
        if rec_xy.aaa100='FPXGDM' and  rec_xy.aaa102 like 'SY0%' then --如果该悬挂代码是发票悬挂，且悬挂代码是因为医保审核规则引起，需要列出具体细项
           /* v_FPXGDMMS:=rec_xy.aaa103||'(';
            for rec_dt in( select distinct d.xxdm,d.xxmc from  tb_zpaxx a,tb_fpxxfyxx d,tb_zpaxxdzb k                                                  
            where a.zpaid=pFpid and a.zpaid=k.zpaid and k.xxid=d.xxid and   exists(select 'x' from tb_lpajxx b,tb_khxx c,tb_sbshgzpzxx e where b.ajid = a.ajid
                                                               and b.bbrkhid=c.khid and e.ZSDBM=d.XXDM and e.ZSDLB=d.xmlb
                                                               and e.status='1' and e.AAA102=substr(rec_xy.aaa102,1,5)
                                                               and ((e.SHYS1='01' and e.SHYS2!= c.xb ) 
                                                                    or (e.shys1='02' and rec_xy.aaa102='SY002') --儿童年龄在0-18周岁/
                                                                    or (e.shys1='03' and rec_xy.aaa102='SY003') -- //新生儿年龄在0-1周岁
                                                                    or (e.shys1='04' and rec_xy.aaa102='SY004') --门诊限用
                                                                    or (e.shys1='05' and rec_xy.aaa102='SY005')--/住院限用
                                                                    or (e.shys1='07' and d.zddm not in(select ZDDM from tb_bdtyshgzzddmpz h,tb_bdxx m,tb_fdzrmx n where h.bdid=m.bdid and m.khbdh=b.khbdh and n.fdid=b.fdid and n.zrid=h.zrid and h.YXZT='1' and h.JBLX='10'  ) ) -- //生育限用
                                                                    ))
                          ) loop
                    v_FPXGDMMS:=v_FPXGDMMS||rec_dt.xxmc||',';      
            end loop;*/
            if  v_FPXGDMMS like '%,' then 
                 v_FPXGDMMS:=substr(v_FPXGDMMS,1,length(trim(v_FPXGDMMS))-1);
            end if;
            v_FPXGDMMS:=v_FPXGDMMS||')';
             Result:=Result||v_FPXGDMMS||',';
        else 
            if rec_xy.aaa100='CL91' then --重症监护天数超过30天悬挂的。要求显示累计赔付重症天数
               select * into rec_ajxx from tb_zpaxx where zpaid=pFpid;
               select sum(nvl(c.sjgfts,0)),sum(case when nvl(d.ICUZYTS,0)>nvl(c.sjgfts,0) then c.sjgfts else  d.ICUZYTS end ) into  rec_ajxx.sjgfts,rec_ajxx.mpts  from tb_zpaxx c,tb_lpfpxx d,tb_fdxx e
                                   where e.fdid = c.fdid 
                                                                  and c.fpid=d.fpid 
                                                                  and c.pfzrdm like 'HI%' and e.fdid=rec_ajxx.fdid
                                                                  and c.ajid<=rec_ajxx.ajid
                                                                  and nvl(c.zpajl,'01')!='02';
               Result:=Result||rec_xy.aaa103||('累计(含本次)赔付重症津贴天数为'||to_char(rec_ajxx.mpts)||'天)');                                                                  
           else
             Result:=Result||rec_xy.aaa103||',';
           end if;
        end if; 
     end if;     
  end loop;
  --如果存在来自发票悬挂代码，需要到取发票悬挂代码的描述
 
  if  Result like '%,' then 
    Result:=substr(Result,1,length(trim(Result))-1);
  end if;
 
--dbms_output.put_line(Result);
return(Result);
END SF_P1_GET_STRZPAXGDMMS;
/
