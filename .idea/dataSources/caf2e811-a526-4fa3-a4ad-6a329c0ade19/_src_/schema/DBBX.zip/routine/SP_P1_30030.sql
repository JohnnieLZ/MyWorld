CREATE PROCEDURE      "SP_P1_30030" (REPORT_ID   IN T_REPORT_DEF_INFO.REPORTID%TYPE,
                                        PSTARTDATE  IN VARCHAR2, -- ??????yyyymmdd
                                        PENDDATE    IN VARCHAR2, -- ??????yyyymmdd
                                        PSTATMAN    IN T_REPORT_GEN_INFO.STATMAN%TYPE, --???
                                        PTYPE       IN VARCHAR2, /*0 ???? ,1 ?? 2 ?? 3 ?? */ --?????
                                        POTHER1     IN VARCHAR2, --??id
                                        POTHER2     IN VARCHAR2, --??id
                                        POTHER3     IN VARCHAR2, --??id
                                        POTHER4     IN VARCHAR2, --??ID
                                        POTHER5     IN VARCHAR2, --????
                                        POTHER6     IN VARCHAR2, --??ID
                                        POTHER7     IN VARCHAR2, --????????
                                        POTHER8     IN VARCHAR2, --????????
                                        PRETURNCODE OUT VARCHAR2,
                                        PRETURNMSG  OUT VARCHAR2) AS
  V_STEP_CODE  CHAR(5); --?????????????????
  VREPORTID    T_REPORT_DEF_INFO.REPORTID%TYPE; --??ID
  V_START_DATE NUMBER := 0; --????????
  V_END_DATE   NUMBER := 0; --????????
  VXZQHDM      T_REPORT_GEN_INFO.STATORGID%TYPE; --????????????

  VSTATID VARCHAR(30); --?????????????????
  TYPE CELLTYPE IS RECORD(
    STATID  VARCHAR2(15),
    COL     NUMBER,
    R       NUMBER,
    CONTENT VARCHAR2(4096));

  CELL      CELLTYPE; --?????????????
  VDWMC     VARCHAR2(50); --????????????
  VUSERNAME T_REPORT_GEN_INFO.STATMAN%TYPE; --????????
  VND       T_REPORT_GEN_INFO.STATYEAR%TYPE; --????
  ROWNO     NUMBER := 0; --??????
  V_ttid   NUMBER := 0;
BEGIN
  V_ttid:=1182; --?????1182??????
  V_STEP_CODE := '00000';
  PRETURNMSG  := 'OK';
  PRETURNCODE := 'E';
  VREPORTID   := SUBSTR(REPORT_ID, 1, 5);
  VUSERNAME   := PSTATMAN;
  VND         := SUBSTR(PSTARTDATE, 1, 4);

  V_START_DATE := TO_NUMBER(SUBSTR(PSTARTDATE, 1, 8));
  V_END_DATE   := TO_NUMBER(SUBSTR(PENDDATE, 1, 8));

  --???????????????????????????
  DELETE FROM T_REPORT_DATA_INFO
   WHERE STATID IN
         (SELECT STATID FROM T_REPORT_GEN_INFO WHERE REPORTID = REPORT_ID);

  DELETE FROM T_REPORT_GEN_INFO
   WHERE STATID IN
         (SELECT STATID FROM T_REPORT_GEN_INFO WHERE REPORTID = REPORT_ID);

  V_STEP_CODE := '00001';
  --???,?T_RERORT_GEN_INFO?????????????
  --???????
  SELECT SEQ_STATID.NEXTVAL INTO VSTATID FROM DUAL;

  -- ??????????
  INSERT INTO T_REPORT_GEN_INFO
    (STATID,
     REPORTID,
     STATORGID,
     STATORGNAME,
     STATDATE,
     STATMAN,
     STATYEAR,
     BEGINDATE,
     ENDDATE,
     STAT_OTHER,
     STAT_TYPE)
  VALUES
    (VSTATID,
     VREPORTID,
     '',
     '',
     TO_CHAR(SYSDATE, 'yyyymmdd'),
     VUSERNAME,
     VND,
     V_START_DATE,
     V_END_DATE,
     SUBSTR(PENDDATE, 1, 1),
     TRIM(PTYPE));

  /* --?????? ??excel???0?????1??,????0???*/

  CELL.STATID := VSTATID;
  CELL.COL    := 0; --?1???
  CELL.R      := 2; --?3???
  --???????????????????????????????excel????????????????????

  FOR REC_DATA IN (
                  select  nvl(g.wbbdh, f.khbdh1) as khbdh,
      CASE when g.wbbdh is not null THEN nvl((select zttmc from tb_nbbdwbbddzpzb where wbbdh=g.wbbdh and khbdh=f.khbdh1) ,(select ttmc  from tb_ttxx  where ttid = g.ttid))
       ELSE (select ttmc  from tb_ttxx  where ttid = g.ttid) end as ttmc ,f.wbpafh  pah ,f.bbrxm  bbrxm,
 f.bbrzjh as bbrzjh,f.jarq AS jarq,(select nvl(p.ryrq,jzrq) from tb_zpaxx m,tb_lpfpxx p  where p.fpid=m.fpid and m.zpaid=h.zpaid) as jzrq,
 (select yymc from tb_zpaxx m,tb_lpfpxx p,tb_yyxx k  where p.fpid=m.fpid and m.zpaid=h.zpaid and k.yyid=p.yyid) as jzyy,
  nvl( f.pfje,0) zapfje,h.sjpfje zpapfje, (select zrmc from tb_zrxx g,tb_zpaxx m where  g.zrbm=m.pfzrdm and h.zpaid=m.zpaid ) as pfzrmc,
              (select aaa103 from aa10,tb_zpaxx m,tb_lpfpxx p  where p.fpid=m.fpid and aaa100='ZDLX' and aaa102=p.zdlx and m.zpaid=h.zpaid) as zdlx?
             /*(select sum(nvl(sjpfje,0)) from tb_zpaxx where ajid=f.ajid and pfzrdm like 'HI%' and nvl(zpajl,'x')!='02') as ????,*/
                h.sjzje as sjze,
                h.zfkcze as zf, h.zfkcsm zfsm,
                h.flzfkcze as flzf,h.flzfkcsm flzfsm,
               h.bhlfy as qt,h.qtkcsm qtsm,
               h.sbzfze tczf,
               h.cde as cde,
                h.dsfzfze as dsfzf,
              decode(sign( nvl(h.sjzje,0)-nvl(h.sbzfze,0)-nvl(h.sjpfje,0)- nvl(h.zfkcze,0)- nvl(h.flzfkcze,0)-nvl(h.bhlfy,0)-nvl(h.dsfzfze,0)-nvl(h.cde,0)),1,nvl(h.sjzje,0)-nvl(h.sbzfze,0)-nvl(h.sjpfje,0)- nvl(h.zfkcze,0)- nvl(h.flzfkcze,0)-nvl(h.bhlfy,0)-nvl(h.dsfzfze,0)-nvl(h.cde,0),0) as grzf,
            h.mpe as mpe ,
             (select case when a.zpajl='02' then (select trim(aaa103) from aa10 where aaa100='JFLY' and aaa102=a.JLSM1 )||' '||trim(a.JLSM2)    else '' end from tb_zpaxx a where a.zpaid=h.zpaid) as tbsm

     FROM (SELECT A.AJID AS AJID,A.FDID, A.PAH AS PAH,A.WBPAFH AS WBPAFH,A.BBRXM AS BBRXM,A.BBRZJH,A.SQRQ,A.JARQ,A.KHBDH  AS KHBDH1, A.AJPFJE AS PFJE
                              FROM TB_LPAJXX A
                             WHERE A.AJZT = '11'
                               AND A.TTID = V_ttid
                               AND SEQLOGID != -1
                               AND JARQ >= PSTARTDATE
                               AND JARQ <= PENDDATE) F,
                           TB_FDXX G,
                           (SELECT AJID,ZPAID,SUM(NVL(DATA51, 0)) AS SJZJE,SUM(NVL(DATA52, 0)) AS SJPFJE,
                                   SUM(NVL(DATA53, 0)) AS ZFKCZE,SUM(NVL(DATA55, 0)) AS FLZFKCZE,SUM(NVL(DATA57, 0)) AS BHLFY,SUM(NVL(DATA59, 0)) AS SBZFZE,
                                   SUM(NVL(DATA60, 0)) AS DSFZFZE,SUM(NVL(DATA61, 0)) AS MPE,SUM(NVL(DATA69, 0)) AS CDE,MAX(DATA54) ZFKCSM,
                                   MAX(DATA56) FLZFKCSM,MAX(DATA58) QTKCSM
                              FROM (SELECT A.AJID, /* (select ZRMC from tb_zrxx where zrid = a.zrid) as data47,
                                                  nvl(b.ryrq, b.jzrq) as data48,
                                                  b.jzyy as data49,
                                                  a.syfph as data50,*/
                                           A.ZPAID,
                                           TO_CHAR(TRIM(A.ZDZJE), '99999990.00') AS DATA51, --????
                                           TO_CHAR(NVL(A.SJPFJE, 0),
                                                   '99999990.00') AS DATA52, --??????
                                           CASE WHEN A.ZPAJL != '02' THEN
                                              TO_CHAR(TRIM((SELECT SUM(H.ZFJE)
                                                             FROM TB_ZPAXXDZB N, TB_FPXXFYXX H
                                                            WHERE N.ZPAID =A.ZPAID  AND N.XXID = H.XXID
                                                              AND N.ZFFYLSGZID IS NULL AND NVL(H.ZFJE, 0) > 0)),'99999990.00')
                                             ELSE  '' END AS DATA53, --????????
                                           CASE WHEN A.ZPAJL != '02' AND EXISTS (SELECT 'x'
                                                     FROM TB_ZPAXXDZB N, TB_FPXXFYXX H
                                                    WHERE N.ZPAID = A.ZPAID AND N.XXID = H.XXID AND N.ZFFYLSGZID IS NULL AND NVL(H.ZFJE, 0) > 0) THEN
                                              SF_P1_GET_STRZPAXXMXSM1(A.ZPAID, '1') ELSE ''  END AS DATA54, --??????
                                           CASE WHEN A.ZPAJL != '02' THEN TO_CHAR(TRIM((SELECT SUM(NVL(H.FLZFJE,  0))
                                                             FROM TB_ZPAXXDZB N, TB_FPXXFYXX H
                                                            WHERE N.ZPAID = A.ZPAID AND N.XXID = H.XXID AND N.HLBHFLLSGZID IS NOT NULL AND NVL(H.FLZFJE, 0) > 0)), '99999990.00') ELSE '' END AS DATA55, --??????
                                           CASE WHEN A.ZPAJL != '02' AND EXISTS
                                              (SELECT 'x' FROM TB_ZPAXXDZB N, TB_FPXXFYXX H
                                                    WHERE N.ZPAID = A.ZPAID AND N.XXID = H.XXID AND N.HLBHFLLSGZID IS NOT NULL  AND NVL(H.FLZFJE, 0) > 0) THEN SF_P1_GET_STRZPAXXMXSM1(A.ZPAID, '2')
                                             ELSE  '' END AS DATA56, --????????
                                           A.BHLFY AS DATA57,
                                           CASE WHEN NVL(A.BHLFY, 0) > 0 THEN
                                              SF_P1_GET_STRZPAXXMXSM1(A.ZPAID, '3')
                                             ELSE  ''  END AS DATA58,
                                           CASE WHEN A.SBBDX = '1' THEN '' ELSE TO_CHAR(A.SBZFZJE) END AS DATA59, --?????
                                           A.QTDSFZFJE AS DATA60, --?????????
                                           TO_CHAR(TRIM(A.MPE), '99999990.00') AS DATA61, --???
                                           A.CDEJE AS DATA69, --???
                                           '?????????????' AS DATA63,
                                           A.ZPAJL AS DATA75,
                                           (SELECT TRIM(AAA103)
                                              FROM AA10
                                             WHERE AAA100 = 'JFLY'
                                               AND AAA102 = A.JLSM1) AS DATA76,
                                           TRIM(A.JLSM2) AS DATA77
                                      FROM TB_LPFPXX B, TB_ZPAXX A
                                     WHERE B.FPID(+) = A.FPID
                                       AND A.AJID IN
                                           (SELECT AJID
                                              FROM TB_LPAJXX
                                             WHERE TTID = V_ttid
                                               AND AJZT = '11'
                                               AND JARQ >= PSTARTDATE
                                               AND JARQ <= PENDDATE
                                               AND SEQLOGID != -1)
                                       AND NVL(A.JLSM1, '0') != 'X69'
                                       AND (A.PFZRDM LIKE 'AIOP%' OR
                                            A.PFZRDM LIKE 'IP%' OR
                                            A.PFZRDM LIKE 'OP%' OR
                                            A.PFZRDM LIKE 'OIP%' OR
                                            A.PFZRDM LIKE 'MAT%' OR
                                            A.PFZRDM LIKE 'DE%' OR
                                            A.PFZRDM LIKE 'PE%')
                                       AND (A.FPID IS NOT NULL OR A.SFSDTJ = '1')
                                    UNION ALL
                                    SELECT A.AJID, /* (select ZRMC from tb_zrxx where zrid = a.zrid) as data47,
                                                  nvl(b.ryrq, b.jzrq) as data48,
                                                  b.jzyy as data49,
                                                  a.syfph as data50,*/
                                           A.ZPAID,
                                           TO_CHAR(TRIM(A.ZDZJE), '99999990.00') AS DATA51, --????
                                           TO_CHAR(NVL(A.SJPFJE, 0), '99999990.00') AS DATA52, --??????
                                           CASE
                                             WHEN A.ZPAJL != '02' THEN
                                              TO_CHAR(TRIM((SELECT SUM(H.ZFJE) FROM TB_ZPAXXDZB N, TB_FPXXFYXX H
                                                            WHERE N.ZPAID = A.ZPAID
                                                              AND N.XXID = H.XXID
                                                              AND N.ZFFYLSGZID IS NULL
                                                              AND NVL(H.ZFJE, 0) > 0)), '99999990.00')  ELSE '' END AS DATA53, --????????
                                           CASE
                                             WHEN A.ZPAJL != '02' AND EXISTS
                                              (SELECT 'x' FROM TB_ZPAXXDZB N, TB_FPXXFYXX H
                                                    WHERE N.ZPAID = A.ZPAID
                                                      AND N.XXID = H.XXID
                                                      AND N.ZFFYLSGZID IS NULL
                                                      AND NVL(H.ZFJE, 0) > 0) THEN
                                              SF_P1_GET_STRZPAXXMXSM1(A.ZPAID, '1') ELSE '' END AS DATA54, --??????
                                           CASE  WHEN A.ZPAJL != '02' THEN
                                              TO_CHAR(TRIM((SELECT SUM(NVL(H.FLZFJE, 0))
                                                             FROM TB_ZPAXXDZB N, TB_FPXXFYXX H
                                                            WHERE N.ZPAID = A.ZPAID
                                                              AND N.XXID = H.XXID
                                                              AND N.HLBHFLLSGZID IS NOT NULL
                                                              AND NVL(H.FLZFJE, 0) > 0)), '99999990.00')  ELSE ''  END AS DATA55, --??????
                                           CASE WHEN A.ZPAJL != '02' AND EXISTS (SELECT 'x'
                                                     FROM TB_ZPAXXDZB N, TB_FPXXFYXX H
                                                    WHERE N.ZPAID = A.ZPAID
                                                      AND N.XXID = H.XXID
                                                      AND N.HLBHFLLSGZID IS NOT NULL
                                                      AND NVL(H.FLZFJE, 0) > 0) THEN
                                              SF_P1_GET_STRZPAXXMXSM1(A.ZPAID, '2')
                                             ELSE '' END AS DATA56, --????????
                                           A.BHLFY AS DATA57,
                                           CASE WHEN NVL(A.BHLFY, 0) > 0 THEN
                                              SF_P1_GET_STRZPAXXMXSM1(A.ZPAID, '3')
                                             ELSE '' END AS DATA58,
                                           CASE WHEN A.SBBDX = '1' THEN  '' ELSE  TO_CHAR(A.SBZFZJE) END AS DATA59, --?????
                                           A.QTDSFZFJE AS DATA60, --?????????
                                           TO_CHAR(TRIM(A.MPE), '99999990.00') AS DATA61, --???
                                           A.CDEJE AS DATA69, --???
                                           '?????????????' AS DATA63,
                                           A.ZPAJL AS DATA75,
                                           (SELECT TRIM(AAA103) FROM AA10
                                             WHERE AAA100 = 'JFLY' AND AAA102 = A.JLSM1) AS DATA76,
                                           TRIM(A.JLSM2) AS DATA77
                                      FROM TB_LPFPXX B, TB_ZPAXX A
                                     WHERE B.FPID(+) = A.FPID
                                       AND A.AJID IN
                                           (SELECT AJID
                                              FROM TB_LPAJXX
                                             WHERE TTID = V_ttid
                                               AND AJZT = '11'
                                               AND JARQ >= PSTARTDATE
                                               AND JARQ <= PENDDATE
                                               AND SEQLOGID != -1)
                                       AND NVL(A.JLSM1, '0') != 'X69'
                                       AND (A.PFZRDM LIKE 'HI%') --?????
                                    )
                             GROUP BY AJID, ZPAID) H
                    WHERE F.FDID = G.FDID
                      AND F.AJID = H.AJID
                    ORDER BY F.KHBDH1, F.WBPAFH ASC

                   ) LOOP
    ROWNO:=ROWNO+1;
INSERT INTO T_REPORT_DATA_INFO (STATID, SHEET, COL, R, CONTENT) VALUES (CELL.STATID, 0, 0, CELL.R, to_char(ROWNO)); --?????
    INSERT INTO T_REPORT_DATA_INFO (STATID, SHEET, COL, R, CONTENT) VALUES (CELL.STATID, 0, 1, CELL.R, REC_DATA.khbdh); --?????
    INSERT INTO T_REPORT_DATA_INFO (STATID, SHEET, COL, R, CONTENT) VALUES (CELL.STATID, 0, 2, CELL.R, REC_DATA.ttmc); --????
    INSERT INTO T_REPORT_DATA_INFO (STATID, SHEET, COL, R, CONTENT) VALUES (CELL.STATID, 0, 3, CELL.R, REC_DATA.pah); --???
    INSERT INTO T_REPORT_DATA_INFO (STATID, SHEET, COL, R, CONTENT) VALUES (CELL.STATID, 0, 4, CELL.R, REC_DATA.bbrxm); --??
    INSERT INTO T_REPORT_DATA_INFO (STATID, SHEET, COL, R, CONTENT) VALUES (CELL.STATID, 0, 5, CELL.R, REC_DATA.bbrzjh); --????
    INSERT INTO T_REPORT_DATA_INFO (STATID, SHEET, COL, R, CONTENT) VALUES (CELL.STATID, 0, 6, CELL.R, REC_DATA.jarq); --????
    INSERT INTO T_REPORT_DATA_INFO (STATID, SHEET, COL, R, CONTENT) VALUES (CELL.STATID, 0, 7, CELL.R, REC_DATA.jzrq); --????
    INSERT INTO T_REPORT_DATA_INFO (STATID, SHEET, COL, R, CONTENT) VALUES (CELL.STATID, 0, 8, CELL.R, REC_DATA.jzyy); --????
    INSERT INTO T_REPORT_DATA_INFO (STATID, SHEET, COL, R, CONTENT) VALUES (CELL.STATID, 0, 9, CELL.R, REC_DATA.zapfje); --??????
    INSERT INTO T_REPORT_DATA_INFO (STATID, SHEET, COL, R, CONTENT) VALUES (CELL.STATID, 0, 10, CELL.R, REC_DATA.zpapfje); --???????
    INSERT INTO T_REPORT_DATA_INFO (STATID, SHEET, COL, R, CONTENT) VALUES (CELL.STATID, 0, 11, CELL.R, REC_DATA.pfzrmc); --  ??????
    INSERT INTO T_REPORT_DATA_INFO (STATID, SHEET, COL, R, CONTENT) VALUES (CELL.STATID, 0, 12, CELL.R, REC_DATA.zdlx); --????
    INSERT INTO T_REPORT_DATA_INFO (STATID, SHEET, COL, R, CONTENT) VALUES (CELL.STATID, 0, 13, CELL.R, REC_DATA.sjze); --????
    INSERT INTO T_REPORT_DATA_INFO (STATID, SHEET, COL, R, CONTENT) VALUES (CELL.STATID, 0, 14, CELL.R, REC_DATA.zf); --??
    INSERT INTO T_REPORT_DATA_INFO (STATID, SHEET, COL, R, CONTENT) VALUES (CELL.STATID, 0, 15, CELL.R, REC_DATA.zfsm); --????
    INSERT INTO T_REPORT_DATA_INFO (STATID, SHEET, COL, R, CONTENT) VALUES (CELL.STATID, 0, 16, CELL.R, REC_DATA.flzf); --????
    INSERT INTO T_REPORT_DATA_INFO (STATID, SHEET, COL, R, CONTENT) VALUES (CELL.STATID, 0, 17, CELL.R, REC_DATA.flzfsm); --??????
    INSERT INTO T_REPORT_DATA_INFO (STATID, SHEET, COL, R, CONTENT) VALUES (CELL.STATID, 0, 18, CELL.R, REC_DATA.qt); --??
    INSERT INTO T_REPORT_DATA_INFO (STATID, SHEET, COL, R, CONTENT) VALUES (CELL.STATID, 0, 19, CELL.R, REC_DATA.qtsm); --????
    INSERT INTO T_REPORT_DATA_INFO (STATID, SHEET, COL, R, CONTENT) VALUES (CELL.STATID, 0, 20, CELL.R, REC_DATA.tczf); --????
    INSERT INTO T_REPORT_DATA_INFO (STATID, SHEET, COL, R, CONTENT) VALUES (CELL.STATID, 0, 21, CELL.R, REC_DATA.cde); -- ???
    INSERT INTO T_REPORT_DATA_INFO (STATID, SHEET, COL, R, CONTENT) VALUES (CELL.STATID, 0, 22, CELL.R, REC_DATA.dsfzf); --???????
    INSERT INTO T_REPORT_DATA_INFO (STATID, SHEET, COL, R, CONTENT) VALUES (CELL.STATID, 0, 23, CELL.R, REC_DATA.grzf); --????
    INSERT INTO T_REPORT_DATA_INFO (STATID, SHEET, COL, R, CONTENT) VALUES (CELL.STATID, 0, 24, CELL.R, REC_DATA.mpe); --???
    INSERT INTO T_REPORT_DATA_INFO (STATID, SHEET, COL, R, CONTENT) VALUES (CELL.STATID, 0, 25, CELL.R, REC_DATA.tbsm); --????

    CELL.R := CELL.R + 1;

  END LOOP;

  --???????????
  /*9.??*/
  PRETURNCODE := '0'; /* ??????????????vstatid????????? */
  PRETURNMSG  := VSTATID;
  DBMS_OUTPUT.PUT_LINE('[LDS debug] ' || 'PReturncode= ' || PRETURNCODE);
  --COMMIT; ???java?????????

EXCEPTION
  WHEN OTHERS THEN
    --rollback;???java?????????????0?????????????????
    PRETURNCODE := 'E'; /*  ??????  */
    DBMS_OUTPUT.PUT_LINE('[yhs debug] ' || 'PReturncode= ' || PRETURNCODE);
    PRETURNMSG := ' rownum' || CELL.R || 'Error:' || SQLERRM; --???????????
    DBMS_OUTPUT.PUT_LINE(PRETURNMSG);
END SP_P1_30030;

/
