CREATE PROCEDURE      "PROC_UNLOCK_JOB" IS
	i_step  NUMBER(9);
	p_RtnCode NUMBER;
	p_RtnMsg VARCHAR2(512);
BEGIN
	i_step := 1;
	----????????????------
	  UPDATE TB_LOCK_INFO A
  SET
    A.PLAN_UNLOCK_DATE = SYSDATE+1,
    A.ZT = '20',
    A.CWYY = ''
  WHERE A.ZT IN('10','12')
  AND TO_CHAR(A.WD_LOCK_DATE,'YYYYMMDD') < TO_CHAR(SYSDATE,'YYYYMMDD')
  AND TO_CHAR(A.PLAN_UNLOCK_DATE,'YYYYMMDD') <> TO_CHAR(SYSDATE,'YYYYMMDD')
    AND NOT EXISTS (SELECT 1
                    FROM TB_LOCK_INFO C
                    WHERE C.ZT IN ('10','12')
                    AND TO_CHAR(C.WD_LOCK_DATE,'YYYYMMDD') = TO_CHAR(SYSDATE,'YYYYMMDD')
                    AND C.SUB_POLICY_REF=A.SUB_POLICY_REF
                    AND C.POLICY_REF = A.POLICY_REF);
 i_step := 2;
 UPDATE TB_FDXX A
    SET
      A.SDBZ = '0',
      A.SDRQ=''
    WHERE EXISTS (SELECT 1
                  FROM TB_LOCK_INFO B
                  WHERE A.FDH = B.SUB_POLICY_REF
                  AND A.WBBDH = B.POLICY_REF
                  AND B.ZT = '20'
                  AND (to_char(B.PLAN_UNLOCK_DATE,'yyyymmdd')=to_char(sysdate,'yyyymmdd')))
    AND NOT EXISTS (SELECT 1
                    FROM TB_LOCK_INFO C
                    WHERE A.FDH = c.SUB_POLICY_REF
                    AND A.WBBDH = C.POLICY_REF
                    AND C.ZT IN ('10','12')
                    AND (to_char(C.WD_LOCK_DATE,'yyyymmdd')=to_char(sysdate,'yyyymmdd')));
COMMIT;
EXCEPTION
	WHEN OTHERS THEN
        p_RtnCode := SQLCODE;
        p_RtnMsg := SQLERRM;
        ROLLBACK;
        Pkg_Error_Log.Pro_Error_In('PROC_UNLOCK_JOB', i_step, p_RtnCode, p_RtnMsg);
END PROC_UNLOCK_JOB;

/
