CREATE FUNCTION      "SF_STRCMPBYORDER" (p_src1 IN VARCHAR2, p_src2 IN VARCHAR2)
    RETURN NUMBER
AS
    v_length   NUMBER := LENGTH(trim(p_src1));
    v_start    NUMBER := 1;
    v_index    NUMBER;
BEGIN
	  v_index:=1;
   for i in 1..v_length loop
       if substr(p_src1,i,1)=substr(p_src2,i,1) then
          v_index:=i;
       else
          exit ;
     end if;
    END LOOP;
    RETURN v_index;
END SF_STRCMPBYORDER;

/
