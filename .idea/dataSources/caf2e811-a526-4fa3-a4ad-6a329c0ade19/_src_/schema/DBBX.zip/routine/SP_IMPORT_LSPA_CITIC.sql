CREATE procedure      SP_IMPORT_LSPA_CITIC(Pin_userid IN varCHAR2 /*,Pkhbdh in varCHAR2*/,PReturnCode OUT varchar2,
                              PReturnMsg    OUT varchar2) AS
/**@version 1.1 update by zhangjunpeng ????????????????? 2015-5-11
  *
  ***/
  cursor cur_lspc is  SELECT a.CLMNO as pch,LSPABWID,CLMNO as pah,
       --to_char(to_date(nvl(MAKEDATE,to_char(sysdate,'dd-mm-yyyy')), 'dd-mm-yyyy'), 'yyyymmdd') regdate,    -- -V 1.1
       to_char(to_date(nvl(MAKEDATE,to_char(sysdate,'yyyy-mm-dd')), 'yyyy-mm-dd'), 'yyyymmdd') regdate,      -- +V 1.1
       (select max(GRPNAME) from TB_TEMP_CLAIM_ROWS where LSPABWID=a.LSPABWID ) as ttmc,
       (select max(GRPCONTNO) from TB_TEMP_CLAIM_ROWS where LSPABWID=a.LSPABWID ) as wbbdh,
       (select count(1) from TB_TEMP_CLAIM_ROWS where LSPABWID=a.LSPABWID AND  to_number(nvl(standpay,'0')) <> 0 )  as ajs
  from TB_TEMP_CLAIM_BASE a
  where nvl(FLAG,'N')='N'  /*and  exists(select 'x' from tb_khxx b,tb_fdxx c where b.khid=c.bbrkhid and b.aac147=a.nationalid)*/
  order by MAKETIME asc;
    v_pch varchar2(30):='';
    v_LSPABWID number(16):=0;
  v_regdate varchar2(30):='';
  cursor cur_lspa is /*select a.*,946 as bxgsid ,a.RPTNO as pah
   from TB_TEMP_CLAIM_ROWS a where a.LSPABWID=v_LSPABWID  order by RPTNO,LSPAMXID asc;*/
select a.*,946 as bxgsid ,replace(a.rptno||to_char(ROWNUM,'000'),' ','') as pah
   from TB_TEMP_CLAIM_ROWS a where a.LSPABWID=v_LSPABWID
   AND to_number(nvl(a.standpay,'0')) <> 0 order BY LSPAMXID asc;
  v_pcid number(16):=1;
  v_ajid number(16):=1;
  v_pcajs number(5):=0;
  v_pczpas number(5):=0;
  myexception Exception;
  v_count number:=0;

begin
 -- DBMS_OUTPUT.ENABLE(1000000);
   PReturnCode:='E';
    PReturnMsg:='Error!';
  for rec_pc in cur_lspc loop
      select seq_pcid.nextval into v_pcid from dual;
      v_pch:=rec_pc.pch;
      v_LSPABWID:=rec_pc.LSPABWID;
      v_regdate:=rec_pc.regdate;
      --????????????????????
      select count(1) into v_count from tb_lppcxx where pch=rec_pc.pch;
      if v_count>0 then --????????????????????????
           select pcid into v_pcid from tb_lppcxx  where pch=rec_pc.pch;
          -- update tb_lppcxx set ajs=nvl(ajs,0)+ rec_pc.ajs  where pcid=v_pcid;
      else
             insert into tb_lppcxx (
              PCID     ,--NUMBER(16)                     ??ID
              PCH      ,--VARCHAR2(30)  Y                ???
              BXGSID   ,--NUMBER(16)                     ????ID
              BXGSQC   ,--VARCHAR2(200) Y                ??????
              TTID     ,--NUMBER(16)                     ??ID
              TTMC     ,--VARCHAR2(100) Y                ????
              SJRQ     ,--NUMBER(8)     Y                ????
              AJS      ,--NUMBER        Y                ???
              KHTJBH   ,--VARCHAR2(30)  Y                ??????
              KHJJR    ,--VARCHAR2(50)  Y                ?????
              SFZS     ,--VARCHAR2(1)   Y                ????
              JHSFRQ   ,--NUMBER(8)     Y                ??????
              PCJBR    ,--VARCHAR2(30)  Y                ?????
              KHFSRQ   ,--NUMBER(8)     Y                ??????
              BDID     ,--NUMBER(16)                     ??ID
              KHBDH    ,--VARCHAR2(50)                   ?????(???)
              PCFKZS   ,--VARCHAR2(2)   Y                ??????
              SFYQBZ   ,--VARCHAR2(1)   Y                ??????
              BXGSLXR  ,--VARCHAR2(30)  Y                ???????
              PCZT     ,--VARCHAR2(2)   Y                ????
              SJSFRQ   ,--NUMBER(8)     Y                ??????
              YQYY     ,--VARCHAR2(2)   Y                ????
              YQBZ     ,--VARCHAR2(500) Y                ????
              SFRID    ,--VARCHAR2(30)  Y                ???ID
              SFR      ,--VARCHAR2(30)  Y                ???
              CJSJ     ,--DATE          Y                ????
              ZJXGR    ,--VARCHAR2(30)  Y
              ZJXGSJ   ,--DATE          Y
              SLRQ     ,--NUMBER(8)     Y                ????
              LRRQ     ,--NUMBER(8)     Y                ????
              DYBZ     ,--VARCHAR2(1)   Y                ????
              DYR      ,--VARCHAR2(50)  Y                ???
              DYRQ     ,--NUMBER(8)     Y                ????
              BDYRQ    ,--NUMBER(8)     Y                ?????
              BDYR     ,--VARCHAR2(50)  Y                ????
              SEQLOGID ,--NUMBER        Y
              FPZS     ,--NUMBER(5)     Y                ????
              SFJJPC   --VARCHAR2(1)   Y                ??????0:? 1:?
              ) select v_PCID  as pcid   ,--NUMBER(16)                     ??ID
              rec_pc.PCH as pch     ,--VARCHAR2(30)  Y                ???
              946 as bxgsid   ,--NUMBER(16)                     ????ID
              (select bxgsqc from tb_bxgsxx where bxgsid=946) BXGSQC   ,--VARCHAR2(200) Y                ??????
             -- (select TTID from tb_ttxx where ttmc=rec_pc.????) as ttid     ,--NUMBER(16)                     ??ID
             b.ttid,
              b.TTMC     ,--VARCHAR2(100) Y                ????
              rec_pc.regdate SJRQ     ,--NUMBER(8)     Y                ????
              rec_pc.AJS      ,--NUMBER        Y                ???
              rec_pc.PCH KHTJBH   ,--VARCHAR2(30)  Y                ??????
              'system' KHJJR    ,--VARCHAR2(50)  Y                ?????
              '0' SFZS     ,--VARCHAR2(1)   Y                ????
              '' JHSFRQ   ,--NUMBER(8)     Y                ??????
              'system' PCJBR    ,--VARCHAR2(30)  Y                ?????
              '' KHFSRQ   ,--NUMBER(8)     Y                ??????
              b.BDID     ,--NUMBER(16)                     ??ID
              rec_pc.wbbdh    ,--VARCHAR2(50)                   ?????(???)
              '2' PCFKZS   ,--VARCHAR2(2)   Y                ??????
              '0' SFYQBZ   ,--VARCHAR2(1)   Y                ??????
              '' BXGSLXR  ,--VARCHAR2(30)  Y                ???????
              '05' PCZT     ,--VARCHAR2(2)   Y                ????
              '' SJSFRQ   ,--NUMBER(8)     Y                ??????
              '' YQYY     ,--VARCHAR2(2)   Y                ????
              '' YQBZ     ,--VARCHAR2(500) Y                ????
              'system' SFRID    ,--VARCHAR2(30)  Y                ???ID
              'system' SFR      ,--VARCHAR2(30)  Y                ???
              sysdate CJSJ     ,--DATE          Y                ????
              '' ZJXGR    ,--VARCHAR2(30)  Y
              '' ZJXGSJ   ,--DATE          Y
              rec_pc.regdate SLRQ     ,--NUMBER(8)     Y                ????
              rec_pc.regdate LRRQ     ,--NUMBER(8)     Y                ????
              '1' DYBZ     ,--VARCHAR2(1)   Y                ????
              'system' DYR      ,--VARCHAR2(50)  Y                ???
              rec_pc.regdate DYRQ     ,--NUMBER(8)     Y                ????
              '' BDYRQ    ,--NUMBER(8)     Y                ?????
              '' BDYR     ,--VARCHAR2(50)  Y                ????
              -1 SEQLOGID ,--NUMBER        Y
              rec_pc.ajs FPZS     ,--NUMBER(5)     Y                ????
              '0' SFJJPC   --VARCHAR2(1)   Y                ??????0:? 1:?
              from tb_bdxx b where  b.khbdh=rec_pc.wbbdh;
      end if;
              --??????????
              v_pcajs:=0;
              v_pczpas:=0;
     for rec_pa in cur_lspa loop
       -- ???????????????update??;
        select count(1),max(ajid) into v_count,v_ajid from tb_lpajxx where bxgsid=946 and pah like rec_pc.pah||'%'
                       and pah=rec_pa.RPTNO;
        if v_count=0 then
         select seq_ajid.nextval into v_ajid from dual;
        insert into tb_lpajxx(
        AJID        ,--NUMBER(16)                     ??ID
        LPPCID      ,--NUMBER(16)                     ????ID
        PAH         ,--VARCHAR2(30)  Y                ???
        BXGSID      ,--NUMBER(16)                     ????ID
        TTID        ,--NUMBER(16)                     ??ID
        ZTTID       ,--NUMBER(16)    Y                ???ID
        ZTTMC       ,--VARCHAR2(200) Y                ?????
        GJAJBZ      ,--VARCHAR2(1)   Y                ??????
        GLAJH       ,--VARCHAR2(30)  Y                ?????
        BBRXM       ,--VARCHAR2(30)  Y                ?????
        BBRKHID     ,--NUMBER(16)    Y                ?????ID
        BBRZJH      ,--VARCHAR2(20)  Y                ??????
        ZLDBZ       ,--VARCHAR2(1)   Y                ?/???????
        ZBBRKHID    ,--NUMBER(16)    Y                ??????ID
        KHBDH       ,--VARCHAR2(30)  Y                ????
        FDID        ,--NUMBER(16)    Y                ???
        SQRZJLX     ,--VARCHAR2(2)                    ???????
        SQRZJHM     ,--VARCHAR2(20)                   ???????
        SQRXM       ,--VARCHAR2(30)                   ?????
        SQRSJ       ,--VARCHAR2(30)  Y                ?????
        SQRDZ       ,--VARCHAR2(200) Y                ?????
        SQRYX       ,--VARCHAR2(30)  Y                ?????
        SQLX        ,--VARCHAR2(66)  Y                ????
        SQRQ        ,--NUMBER(8)     Y                ????
        BBRSCZT     ,--VARCHAR2(1)   Y                ???????
        BBRCJDM     ,--VARCHAR2(10)  Y                ???????
        BBRCJXM     ,--VARCHAR2(500) Y                ???????
        BBRCJDJ     ,--VARCHAR2(10)  Y                ???????
        BBRSWRQ     ,--NUMBER(8)     Y                ???????
        BBRYWSGFSRQ ,--NUMBER(8)     Y                ???????????
        JBID        ,--NUMBER(16)    Y                ??ID
        ZJDM        ,--VARCHAR2(20)  Y                ????
        ZJQZR       ,--NUMBER(8)     Y                ?????
        AJZT        ,--VARCHAR2(2)   Y                ????
        ZHCLRQ      ,--DATE          Y                ??????
        AJXGDM      ,--VARCHAR2(80)  Y                ??????
        AJXGLY      ,--VARCHAR2(300) Y                ??????
        XGRQ        ,--VARCHAR2(30)  Y                ????
        JARQ        ,--NUMBER(8)     Y                ????
        AJJL        ,--VARCHAR2(2)   Y                ????
        AJJLSM1     ,--VARCHAR2(10)  Y                ??????1
        AJJLSM      ,--VARCHAR2(200) Y                ??????(??)
        JBR         ,--VARCHAR2(30)  Y                ???
        AJPFJE      ,--NUMBER(16,2)  Y                ??????
        LPJSYR      ,--VARCHAR2(30)  Y                ??????
        AJPFFS      ,--VARCHAR2(1)   Y                ??????
        SFXNAJ      ,--VARCHAR2(1)            '0'     ??????
        SFZDSCZPA   ,--VARCHAR2(1)   Y        '0'     ?????????
        SCZPASJ     ,--DATE          Y                ???????
        LSSJ        ,--DATE          Y                ????
        SLRID       ,--NUMBER(19)    Y                ???id
        SLR         ,--VARCHAR2(50)  Y                ???
        LRRID       ,--NUMBER(19)    Y                ???id
        LRR         ,--VARCHAR2(50)  Y                ???
        SHRID       ,--NUMBER(19)    Y                ???ID
        SHR         ,--VARCHAR2(50)  Y                ???
        ZJRID       ,--NUMBER(19)    Y                ???ID
        ZJR         ,--VARCHAR2(50)  Y                ???
        ZJSJ        ,--DATE          Y                ????
        ZJJL        ,--VARCHAR2(1)   Y                ????
        ZJYJMS      ,--VARCHAR2(200) Y                ??????
        SSYLY       ,--VARCHAR2(200) Y                ?????
        KHSYR       ,--VARCHAR2(50)  Y                ?????
        SYJL        ,--VARCHAR2(1)   Y                ????
        SYRQ        ,--DATE          Y                ????
        SYYJMS      ,--VARCHAR2(200) Y                ??????
        BXCSSCZPABZ ,--VARCHAR2(1)   Y                ???????????
        DYSJSCBZ    ,--VARCHAR2(1)   Y                ????????
        DYSJSCSJ    ,--DATE          Y                ????????
        LPKGFKHH    ,--VARCHAR2(50)  Y                ????????
        LPKGFYHZH   ,--VARCHAR2(35)  Y                ?????????
        SKFXM       ,--VARCHAR2(50)  Y                ?????
        TQRQ        ,--DATE          Y                ????
        QCLSM       ,--VARCHAR2(300) Y                ?????
        SFRQ        ,--NUMBER(8)     Y                ????
        SEQLOGID    ,--NUMBER        Y
        DYBZ        ,--VARCHAR2(1)   Y                ????
        DYR         ,--VARCHAR2(50)  Y                ???
        DYRQ        ,--NUMBER(8)     Y                ????
        BDYRQ       ,--NUMBER(8)     Y                ?????
        BDYR        ,--VARCHAR2(50)  Y                ????
        FPS         ,--NUMBER(3)     Y                ???
        SFJJAJ      ,--VARCHAR2(1)   Y                ?????? 0? 1 ?
        CSRID       ,--NUMBER(16)    Y                ???ID
        CSR         ,--VARCHAR2(50)  Y                ???
        CSJG        ,--VARCHAR2(1)   Y                ???? 1?? ?? ???
        CSCWDM      ,--VARCHAR2(50)  Y                ?????(???)
        CSCWMS      ,--VARCHAR2(200) Y                ??????
        FSRID       ,--NUMBER(16)    Y                ???ID
        FSR         ,--VARCHAR2(50)  Y                ???
        FSJG        ,--VARCHAR2(1)   Y                ???? 1?? ?? ???
        FSCWDM      ,--VARCHAR2(50)  Y                ?????(???)
        FSCWMS      ,--VARCHAR2(200) Y                ??????
        AJSFSD      ,--VARCHAR2(1)   Y                ??????0??? 1?
        SDKSSJ      ,--DATE          Y                ??????
        DQCZR       ,--VARCHAR2(50)  Y                ?????
        ZBBRGX      ,--VARCHAR2(2)   Y                ?????????
        SFGS        ,--VARCHAR2(1)   Y                ????
        YWSGDD      ,--VARCHAR2(200) Y                ??????
        YWSGYY      ,--VARCHAR2(200) Y                ??????
        SSWBYY      )--VARCHAR2(100) Y                ??????
        select v_ajid as ajid,
        v_pcid LPPCID      ,--NUMBER(16)                     ????ID
        rec_pa.pah PAH         ,--VARCHAR2(30)  Y                ???
        rec_pa.BXGSID      ,--NUMBER(16)                     ????ID
        (select TTID from tb_lppcxx where pcid=v_pcid) TTID        ,--NUMBER(16)                     ??ID
       '' zttid       ,--NUMBERt(16)    Y                ???ID
      ''ZTTMC       ,--VARCHAR2(200) Y                ?????
        '' GJAJBZ      ,--VARCHAR2(1)   Y                ??????
        '' GLAJH       ,--VARCHAR2(30)  Y                ?????
        rec_pa.CUSTOMERNAME as BBRXM       ,--VARCHAR2(30)  Y                ?????
      b.khid as  BBRKHID     ,--NUMBER(16)    Y                ?????ID
      b.aac147 as   BBRZJH      ,--VARCHAR2(20)  Y                ??????
      '0'  ZLDBZ       ,--VARCHAR2(1)   Y                ?/???????
      ''  ZBBRKHID    ,--NUMBER(16)    Y                ??????ID
      (select khbdh from tb_lppcxx where pcid=v_pcid)  KHBDH       ,--VARCHAR2(30)  Y                ????
      a.fdid  FDID        ,--NUMBER(16)    Y                ???
      '01'  SQRZJLX     ,--VARCHAR2(2)                    ???????
      b.aac147 as  SQRZJHM     ,--VARCHAR2(20)                   ???????
      rec_pa.CUSTOMERNAME   SQRXM       ,--VARCHAR2(30)                   ?????
      b.sjh  SQRSJ       ,--VARCHAR2(30)  Y                ?????
      b.GZDJZD  SQRDZ       ,--VARCHAR2(200) Y                ?????
      b.email  SQRYX       ,--VARCHAR2(30)  Y                ?????
      'S1'  SQLX        ,--VARCHAR2(66)  Y                ????
     to_char(to_date(rec_pa.RGTDATE, 'yyyy-mm-dd'), 'yyyymmdd')  SQRQ        ,--NUMBER(8)     Y                ????
      '0'   BBRSCZT     ,--VARCHAR2(1)   Y                ???????
      ''  BBRCJDM     ,--VARCHAR2(10)  Y                ???????
      ''  BBRCJXM     ,--VARCHAR2(500) Y                ???????
      ''  BBRCJDJ     ,--VARCHAR2(10)  Y                ???????
      ''  BBRSWRQ     ,--NUMBER(8)     Y                ???????
      ''  BBRYWSGFSRQ ,--NUMBER(8)     Y                ???????????
      ''  JBID        ,--NUMBER(16)    Y                ??ID
      ''  ZJDM        ,--VARCHAR2(20)  Y                ????
      ''  ZJQZR       ,--NUMBER(8)     Y                ?????
      '11'  AJZT        ,--VARCHAR2(2)   Y                ????
      ''  ZHCLRQ      ,--DATE          Y                ??????
      ''  AJXGDM      ,--VARCHAR2(80)  Y                ??????
      ''  AJXGLY      ,--VARCHAR2(300) Y                ??????
      ''  XGRQ        ,--VARCHAR2(30)  Y                ????
      to_char(to_date(rec_pa.ENDCASEDATE,'yyyy-mm-dd'),'yyyymmdd')  JARQ        ,--NUMBER(8)     Y                ????
      '01'  AJJL        ,--VARCHAR2(2)   Y                ????
       '' AJJLSM1     ,--VARCHAR2(10)  Y                ??????1
      rec_pa.GIVETYPEDESC  AJJLSM      ,--VARCHAR2(200) Y                ??????(??)
      ''  JBR         ,--VARCHAR2(30)  Y                ???
      rec_pa.STANDPAY  AJPFJE      ,--NUMBER(16,2)  Y                ??????
      rec_pa.CUSTOMERNAME  LPJSYR      ,--VARCHAR2(30)  Y                ??????
      '1'  AJPFFS      ,--VARCHAR2(1)   Y                ??????
      '0'  SFXNAJ      ,--VARCHAR2(1)            '0'     ??????
      '0'  SFZDSCZPA   ,--VARCHAR2(1)   Y        '0'     ?????????
      null  SCZPASJ     ,--DATE          Y                ???????
      null  LSSJ        ,--DATE          Y                ????
      ''   SLRID       ,--NUMBER(19)    Y                ???id
      ''   SLR         ,--VARCHAR2(50)  Y                ???
      ''   LRRID       ,--NUMBER(19)    Y                ???id
      ''   LRR         ,--VARCHAR2(50)  Y                ???
      ''   SHRID       ,--NUMBER(19)    Y                ???ID
      ''   SHR         ,--VARCHAR2(50)  Y                ???
      ''   ZJRID       ,--NUMBER(19)    Y                ???ID
      ''   ZJR         ,--VARCHAR2(50)  Y                ???
      ''   ZJSJ        ,--DATE          Y                ????
      ''   ZJJL        ,--VARCHAR2(1)   Y                ????
      ''   ZJYJMS      ,--VARCHAR2(200) Y                ??????
      ''   SSYLY       ,--VARCHAR2(200) Y                ?????
      ''   KHSYR       ,--VARCHAR2(50)  Y                ?????
      ''   SYJL        ,--VARCHAR2(1)   Y                ????
      ''   SYRQ        ,--DATE          Y                ????
      ''   SYYJMS      ,--VARCHAR2(200) Y                ??????
      ''   BXCSSCZPABZ ,--VARCHAR2(1)   Y                ???????????
      ''   DYSJSCBZ    ,--VARCHAR2(1)   Y                ????????
      ''   DYSJSCSJ    ,--DATE          Y                ????????
      ''  LPKGFKHH    ,--VARCHAR2(50)  Y                ????????
      ''  LPKGFYHZH   ,--VARCHAR2(35)  Y                ?????????
      rec_pa.CUSTOMERNAME  SKFXM       ,--VARCHAR2(50)  Y                ?????
       to_date( to_char(to_date(rec_pa.ENDCASEDATE,'yyyy-mm-dd'),'yyyymmdd'),'yyyy-mm-dd')   TQRQ        ,--DATE          Y                ????
      ''  QCLSM       ,--VARCHAR2(300) Y                ?????
      to_char(to_date(rec_pa.ENDCASEDATE,'yyyy-mm-dd'),'yyyymmdd')  SFRQ        ,--NUMBER(8)     Y                ????
      -1  SEQLOGID    ,--NUMBER        Y
      '1'  DYBZ        ,--VARCHAR2(1)   Y                ????
      'system'  DYR         ,--VARCHAR2(50)  Y                ???
      ''  DYRQ        ,--NUMBER(8)     Y                ????
      ''  BDYRQ       ,--NUMBER(8)     Y                ?????
      ''  BDYR        ,--VARCHAR2(50)  Y                ????
      1  FPS         ,--NUMBER(3)     Y                ???
      '0'  SFJJAJ      ,--VARCHAR2(1)   Y                ?????? 0? 1 ?
      ''  CSRID       ,--NUMBER(16)    Y                ???ID
      ''  CSR         ,--VARCHAR2(50)  Y                ???
      ''  CSJG        ,--VARCHAR2(1)   Y                ???? 1?? ?? ???
      ''  CSCWDM      ,--VARCHAR2(50)  Y                ?????(???)
      ''  CSCWMS      ,--VARCHAR2(200) Y                ??????
      ''  FSRID       ,--NUMBER(16)    Y                ???ID
      ''  FSR         ,--VARCHAR2(50)  Y                ???
      ''  FSJG        ,--VARCHAR2(1)   Y                ???? 1?? ?? ???
      ''  FSCWDM      ,--VARCHAR2(50)  Y                ?????(???)
      ''  FSCWMS      ,--VARCHAR2(200) Y                ??????
      ''  AJSFSD      ,--VARCHAR2(1)   Y                ??????0??? 1?
      ''  SDKSSJ      ,--DATE          Y                ??????
      ''  DQCZR       ,--VARCHAR2(50)  Y                ?????
      '00'  ZBBRGX      ,--VARCHAR2(2)   Y                ?????????
      '0'   SFGS        ,--VARCHAR2(1)   Y                ????
      ''   YWSGDD      ,--VARCHAR2(200) Y                ??????
      rec_pa.ACCIDENTREASON  YWSGYY      ,--VARCHAR2(200) Y                ??????
      ''  SSWBYY  from tb_fdxx a,tb_khxx b where nvl(wbbdh,khbdh)=rec_pc.wbbdh and a.bbrkhid=b.khid and b.aac147=rec_pa.IDNO
      and b.xm= rec_pa.CUSTOMERNAME
      and exists(select 'x' from tb_fdzrmx f,tb_zrxx h where f.zrid=h.zrid and f.fdid=a.fdid
    and h.ZRBM in(select aaa102 from tb_zddmbxgsdmdzb where bxgsid=946 and AAA100='ZRDM' /*and QTSM3=rec_pa.GETDUTYNAME*/ and  nvl(qtsm2, rec_pa.relation)= rec_pa.relation)
           )
      and rownum<2;
   /*   IF SQL%rowcount=0 THEN
         DBMS_OUTPUT.PUT_LINE('TB_LPAJXX DATA ERROR!AAC147='||rec_pa.IDNO||'??????'||rec_pa.GETDUTYNAME);
         RAISE MYEXCEPTION;
      END IF;*/
         v_pcajs:=v_pcajs+sql%rowcount;
        --???????
          insert into tb_zpaxx(
          ZPAID     ,--NUMBER(16)                      ???ID
          AJID      ,--NUMBER(16)                      ??ID
          ZPAH      ,--VARCHAR2(30)   Y                ?????
          JBID      ,--NUMBER(16)     Y                ??ID
          ZDDM      ,--VARCHAR2(20)   Y                ????
          ZRID      ,--NUMBER(16)                      ??ID
          PFZRDM    ,--VARCHAR2(10)   Y                ??????
          ZDZJE     ,--NUMBER(16,2)   Y                ?????
          SBZFZJE   ,--NUMBER(16,2)   Y                ???????
          ZFJE      ,--NUMBER(16,2)   Y                ????
          FLZFJE    ,--NUMBER(16,2)   Y                ??????
          QTDSFZFJE ,--NUMBER(16,2)   Y                ?????????
          BHLFY     ,--NUMBER(16,2)   Y                ?????
          BXZRWJE   ,--NUMBER(16,2)   Y                ???????
          XLLSPFJE  ,--NUMBER(16,2)   Y                ????????
          RGTZJE    ,--NUMBER(16,2)   Y                ??????
          SJPFJE    ,--NUMBER(16,2)   Y                ??????
          MPE       ,--NUMBER(16,2)   Y                ???
          XGDM      ,--VARCHAR2(100)  Y                ????
          XGDMMS    ,--VARCHAR2(1024) Y                ??????
          ZT        ,--VARCHAR2(1)    Y                ??
          ZPAJL     ,--VARCHAR2(2)    Y                ?????
          JLSM1     ,--VARCHAR2(10)   Y                ????1
          JLSM2     ,--VARCHAR2(500)  Y                ????2
          SHYYJ     ,--VARCHAR2(200)  Y                ?????
          SJGFTS    ,--NUMBER         Y                ???????
          SSXM      ,--VARCHAR2(30)   Y                ????
          SSPFBL    ,--NUMBER(5,2)    Y                ??????
          MPTS      ,--NUMBER         Y                ????
          SFSDTJ    ,--VARCHAR2(1)             '0'     ??????
          LSSJ      ,--DATE           Y                ????
          SYFPH     ,--VARCHAR2(500)  Y                ?????
          FPID      ,--NUMBER(16)     Y                ??ID
          SEQLOGID  ,--NUMBER         Y
          FDID      ,--NUMBER(16)     Y                ??????
          SBBDX     ,--VARCHAR2(1)    Y                ???????
          CDEJE     --NUMBER(16,2)   Y                ?????
          )
          select       seq_ZPAID.nextval as zpaid     ,--NUMBER(16)                      ???ID
          v_AJID      ,--NUMBER(16)                      ??ID
          rec_pa.pah||'001' as ZPAH      ,--VARCHAR2(30)   Y                ?????
          (select jbid from tb_jbkxx where jbdm=(select max(aaa102) from TB_ZDDMBXGSDMDZB where aaa100='TB_JBKXX' and bxgsxmbm=rec_pa.DISEASECODE and bxgsid=946)) as JBID      ,--NUMBER(16)     Y                ??ID
          (select max(aaa102) from TB_ZDDMBXGSDMDZB where aaa100='TB_JBKXX' and bxgsxmbm=rec_pa.DISEASECODE and bxgsid=946) as ZDDM      ,--VARCHAR2(20)   Y                ????
          b.ZRID      ,--NUMBER(16)                      ??ID
          c.zrbm PFZRDM    ,--VARCHAR2(10)   Y                ??????
          rec_pa.FEE ZDZJE     ,--NUMBER(16,2)   Y                ?????
          rec_pa.INSURANCEPMT SBZFZJE   ,--NUMBER(16,2)   Y                ???????
          rec_pa.SELFAMNT ZFJE      ,--NUMBER(16,2)   Y                ????   ,
          rec_pa.PAYMENTB FLZFJE    ,--NUMBER(16,2)   Y                ??????
          '' QTDSFZFJE ,--NUMBER(16,2)   Y                ?????????
          '' BHLFY     ,--NUMBER(16,2)   Y                ?????
          '' BXZRWJE   ,--NUMBER(16,2)   Y                ???????
          '' XLLSPFJE  ,--NUMBER(16,2)   Y                ????????
          '' RGTZJE    ,--NUMBER(16,2)   Y                ??????
          rec_pa.STANDPAY SJPFJE    ,--NUMBER(16,2)   Y                ??????
          rec_pa.OUTDUTYAMNT MPE       ,--NUMBER(16,2)   Y                ???
          '' XGDM      ,--VARCHAR2(100)  Y                ????
          '' XGDMMS    ,--VARCHAR2(1024) Y                ??????
          '1' ZT        ,--VARCHAR2(1)    Y                ??
          '01' ZPAJL     ,--VARCHAR2(2)    Y                ?????
          '' JLSM1     ,--VARCHAR2(10)   Y                ????1
          '' JLSM2     ,--VARCHAR2(500)  Y                ????2
          '' SHYYJ     ,--VARCHAR2(200)  Y                ?????
        case when nvl(b.zrbe,0)>0 and c.zrbm like 'HI%' then to_char(round(rec_pa.STANDPAY/b.zrbe)) else '' end SJGFTS    ,--NUMBER         Y                ???????
          '' SSXM      ,--VARCHAR2(30)   Y                ????
          '' SSPFBL    ,--NUMBER(5,2)    Y                ??????
          '' MPTS      ,--NUMBER         Y                ????
          '0' SFSDTJ    ,--VARCHAR2(1)             '0'     ??????
          '' LSSJ      ,--DATE           Y                ????
          '' SYFPH     ,--VARCHAR2(500)  Y                ?????
          '' FPID      ,--NUMBER(16)     Y                ??ID
          -1 SEQLOGID  ,--NUMBER         Y
          a.FDID      ,--NUMBER(16)     Y                ??????
          '0' SBBDX     ,--VARCHAR2(1)    Y                ???????
          '' CDEJE     --NUMBER(16,2)   Y                ?????
          from tb_lpajxx a,tb_fdzrmx b,tb_zrxx c where a.ajid=v_ajid and a.fdid=b.fdid and b.zrid=c.zrid
           --  and c.zrbm  like decode(rec_pa.BenefitCode,'AHI','AIOP','SHIP','AIOP','NONSHIP','AIOP','HI','HI','IPAY','IP','IPAN','IP','OP','OP','MBRN','MAT','MBRY','MAT','error')||'%'
            and c.zrbm=case when rec_pa.relation='??' then FUNC_GETCODEBYBXGSDM(946,'ZRDM',rec_pa.DUTYCODE,rec_pa.relation,'') else  FUNC_GETCODEBYBXGSDM(946,'ZRDM',rec_pa.DUTYCODE,'','') end
              and rownum<2;
           v_pczpas:=v_pczpas+sql%rowcount;
     /*     IF SQL%rowcount!=1 THEN
             DBMS_OUTPUT.PUT_LINE('TB_ZPAXX DATA ERROR!AAC147='||rec_pa.idno);
             RAISE MYEXCEPTION;
          END IF;*/
       else   --??????????????
           update tb_lpajxx set  (BBRXM,BBRKHID,BBRZJH,KHBDH,FDID,SQRZJHM,sqrxm,SQRQ,JARQ,
           zbbrgx,AJPFJE,LPJSYR,ajjl,SKFXM,YWSGYY) =
     (  select   rec_pa.CUSTOMERNAME as BBRXM ,--VARCHAR2(30)  Y                ?????
      b.khid as  BBRKHID     ,--NUMBER(16)    Y                ?????ID
      b.aac147 as   BBRZJH      ,--VARCHAR2(20)  Y                ??????
      (select khbdh from tb_lppcxx where pcid=v_pcid)  KHBDH       ,--VARCHAR2(30)  Y                ????
      a.fdid  FDID        ,--NUMBER(16)    Y                ???
      b.aac147 as  SQRZJHM     ,--VARCHAR2(20)                   ???????
      rec_pa.CUSTOMERNAME   SQRXM       ,--VARCHAR2(30)                   ?????
      to_char(to_date(rec_pa.rgtdate, 'yyyy-mm-dd'), 'yyyymmdd')  SQRQ        ,--NUMBER(8)     Y                ????
      to_char(to_date(rec_pa.ENDCASEDATE,'yyyy-mm-dd'),'yyyymmdd')  JARQ        ,--NUMBER(8)     Y                ????
      '' zbbrgx,
      rec_pa.STANDPAY  AJPFJE      ,--NUMBER(16,2)  Y                ??????
      rec_pa.CUSTOMERNAME  LPJSYR      ,--VARCHAR2(30)  Y                ??????
      '01' ,--?????????
      rec_pa.CUSTOMERNAME  SKFXM       ,--VARCHAR2(50)  Y                ?????
      rec_pa.ACCIDENTREASON  YWSGYY      --VARCHAR2(200) Y                ??????
      from tb_fdxx a,tb_khxx b where nvl(wbbdh,khbdh)=rec_pc.wbbdh and a.bbrkhid=b.khid and b.aac147=rec_pa.IDNO
      and b.xm= rec_pa.CUSTOMERNAME
      and exists(select 'x' from tb_fdzrmx f,tb_zrxx h where f.zrid=h.zrid and f.fdid=a.fdid
    and h.ZRBM in(select aaa102 from tb_zddmbxgsdmdzb where bxgsid=946 and AAA100='ZRDM' /*and QTSM3=rec_pa.GETDUTYNAME*/ and  nvl(qtsm2, rec_pa.relation)= rec_pa.relation)
           )
      and rownum<2)   where ajid=v_ajid;
        --??????????????
         --  update tb_zpaxx  set     where ajid=v_ajid;
       end if;

       end loop;
       --???????
       if rec_pc.ajs!=v_pcajs or rec_pc.ajs!=v_pczpas then
          dbms_output.put_line('????????????'||rec_pc.pch||'?????'||to_char(rec_pc.ajs)||'?????'||to_char(v_pcajs)||'??????'||to_char(v_pczpas));
         else
            dbms_output.put_line('????'||rec_pc.pch||'?????'||to_char(rec_pc.ajs)||'?????'||to_char(v_pcajs)||'??????'||to_char(v_pczpas)||', ???????');
       end if;
       update tb_temp_claim_base t set t.flag = 'Y',t.update_time =  sysdate where t.lspabwid = rec_pc.LSPABWID;
    end loop;
      PReturnCode:='0';
    PReturnMsg:='????????!';
    return;
    EXCEPTION
    WHEN OTHERS THEN
      rollback;
    DBMS_OUTPUT.PUT_LINE('[yhs debug] ' || 'PReturncode= ' ||'E');
    PReturnMsg := 'Error:' || sqlerrm;
        update tb_temp_claim_base t set t.flag = 'E',t.update_time =  SYSDATE
    ,t.reason = PReturnMsg  where t.lspabwid = v_LSPABWID;
    DBMS_OUTPUT.PUT_LINE(PReturnMsg);
end SP_IMPORT_LSPA_CITIC;

/
