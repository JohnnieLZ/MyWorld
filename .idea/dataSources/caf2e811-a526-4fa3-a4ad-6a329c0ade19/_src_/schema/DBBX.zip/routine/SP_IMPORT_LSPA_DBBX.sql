CREATE procedure SP_IMPORT_LSPA_DBBX(Pin_userid IN varCHAR2 ,Pkhbdh in varCHAR2,pBxgsid in varCHAR2,PReturnCode OUT varchar2,
                              PReturnMsg    OUT varchar2) AS
  cursor cur_lspa is  select 
姓名                                  ,
身份证                                ,
人员类别                              ,
/*就诊科室代码                          ,
就诊科室名称                          ,*/
结算凭证号                      ,
签约服务协议ID                       ,
商保机构编码                         ,
商报机构名称                         ,
服务点编码                           ,
服务点名称                           ,
sum(nvl(to_number(居保大病基金支付数),0)) as ajpfje ,
sum(nvl(to_number(医保结算范围费用),0)) as 医保结算范围费用,
sum(nvl(to_number(交易费用总额),0))   as 交易费用总额,
sum(nvl(to_number(自负),0))           as 自负,
sum(nvl(to_number(非医保个人自费),0)) as 非医保个人自费
from temp_his_dbbxxx    where   处理标志 is null        
         group  by 姓名                                  ,
身份证                                ,
人员类别                              ,
/*就诊科室代码                          ,
就诊科室名称                          ,*/
结算凭证号                      ,
签约服务协议ID                       ,
商保机构编码                         ,
商报机构名称                         ,
服务点编码                           ,
服务点名称                           
order by 身份证,结算凭证号 asc;
  v_pch varchar2(30):='';
  v_regdate varchar2(30):='';
  
  v_khid number(16):=1;
  v_pcid number(16):=1;
  v_ajid number(16):=1;
  v_pcajs number(5):=0;
  v_pczpas number(5):=0;
  myexception Exception;
  v_count number:=0;
 v_bxgsid number:=trim(pBxgsid);
 v_zpaid number:=0;
begin
 -- DBMS_OUTPUT.ENABLE(1000000);
   PReturnCode:='E';
    PReturnMsg:='Error!';
    if v_bxgsid is null then
      v_bxgsid:=733;
  end if;
     select count(1) into v_count from temp_his_dbbxxx    where   处理标志 is null    ;
     if v_count=0 then
          DBMS_OUTPUT.PUT_LINE('没有需要导入的数据!失败码='||PReturnCode);
         return;
     end if;
       --一次导入统一生成到一个批次中
    select seq_pcid.nextval,'CPIC'||to_char(sysdate,'yyyymmddhh24miss') into v_pcid,v_pch from dual; 
   insert into tb_lppcxx (
              PCID     ,--NUMBER(16)                     批次ID        
              PCH      ,--VARCHAR2(30)  Y                批次号        
              BXGSID   ,--NUMBER(16)                     保险公司ID    
              BXGSQC   ,--VARCHAR2(200) Y                保险公司名称   
              TTID     ,--NUMBER(16)                     团体ID        
              TTMC     ,--VARCHAR2(100) Y                团体名称      
              SJRQ     ,--NUMBER(8)     Y                收件日期      
              AJS      ,--NUMBER        Y                案件数        
              KHTJBH   ,--VARCHAR2(30)  Y                客户提交编号   
              KHJJR    ,--VARCHAR2(50)  Y                客户寄件人     
              SFZS     ,--VARCHAR2(1)   Y                释放指示      
              JHSFRQ   ,--NUMBER(8)     Y                计划释放日期   
              PCJBR    ,--VARCHAR2(30)  Y                批次经办人     
              KHFSRQ   ,--NUMBER(8)     Y                客户发送日期   
              BDID     ,--NUMBER(16)                     保单ID        
              KHBDH    ,--VARCHAR2(50)                   客户保单号(可多选) 
              PCFKZS   ,--VARCHAR2(2)   Y                批次付款指示   
              SFYQBZ   ,--VARCHAR2(1)   Y                释放延期标志   
              BXGSLXR  ,--VARCHAR2(30)  Y                保险公司联系人 
              PCZT     ,--VARCHAR2(2)   Y                批次状态      
              SJSFRQ   ,--NUMBER(8)     Y                实际释放日期   
              YQYY     ,--VARCHAR2(2)   Y                延期原因      
              YQBZ     ,--VARCHAR2(500) Y                延期备注      
              SFRID    ,--VARCHAR2(30)  Y                释放人ID      
              SFR      ,--VARCHAR2(30)  Y                释放人        
              CJSJ     ,--DATE          Y                创建时间      
              ZJXGR    ,--VARCHAR2(30)  Y                              
              ZJXGSJ   ,--DATE          Y                              
              SLRQ     ,--NUMBER(8)     Y                受理日期      
              LRRQ     ,--NUMBER(8)     Y                录入日期      
              DYBZ     ,--VARCHAR2(1)   Y                打印标志      
              DYR      ,--VARCHAR2(50)  Y                打印人        
              DYRQ     ,--NUMBER(8)     Y                打印日期      
              BDYRQ    ,--NUMBER(8)     Y                补打印日期     
              BDYR     ,--VARCHAR2(50)  Y                补打印人      
              SEQLOGID ,--NUMBER        Y                              
              FPZS     ,--NUMBER(5)     Y                发票张数      
              SFJJPC   --VARCHAR2(1)   Y                是否紧急批次0:否 1:是 
              ) select v_PCID  as pcid   ,--NUMBER(16)                     批次ID        
              v_PCH as pch     ,--VARCHAR2(30)  Y                批次号        
              v_bxgsid as bxgsid   ,--NUMBER(16)                     保险公司ID    
              (select bxgsqc from tb_bxgsxx where bxgsid=v_bxgsid) BXGSQC   ,--VARCHAR2(200) Y                保险公司名称   
             -- (select TTID from tb_ttxx where ttmc=rec_pc.投保单位) as ttid     ,--NUMBER(16)                     团体ID       
              b.ttid, 
              b.TTMC     ,--VARCHAR2(100) Y                团体名称      
             (select max(就诊日期) from  temp_his_dbbxxx    where   处理标志 is null ) SJRQ     ,--NUMBER(8)     Y                收件日期      
            (select count(distinct 结算单号) from  temp_his_dbbxxx    where   处理标志 is null) as AJS      ,--NUMBER        Y                案件数        
              v_PCH as KHTJBH   ,--VARCHAR2(30)  Y                客户提交编号   
              'system' KHJJR    ,--VARCHAR2(50)  Y                客户寄件人     
              '0' SFZS     ,--VARCHAR2(1)   Y                释放指示      
              '' JHSFRQ   ,--NUMBER(8)     Y                计划释放日期   
              'system' PCJBR    ,--VARCHAR2(30)  Y                批次经办人     
              '' KHFSRQ   ,--NUMBER(8)     Y                客户发送日期   
              b.BDID     ,--NUMBER(16)                     保单ID        
              b.KHBDH    ,--VARCHAR2(50)                   客户保单号(可多选) 
              '2' PCFKZS   ,--VARCHAR2(2)   Y                批次付款指示   
              '0' SFYQBZ   ,--VARCHAR2(1)   Y                释放延期标志   
              '' BXGSLXR  ,--VARCHAR2(30)  Y                保险公司联系人 
              '05' PCZT     ,--VARCHAR2(2)   Y                批次状态      
              '' SJSFRQ   ,--NUMBER(8)     Y                实际释放日期   
              '' YQYY     ,--VARCHAR2(2)   Y                延期原因      
              '' YQBZ     ,--VARCHAR2(500) Y                延期备注      
              'system' SFRID    ,--VARCHAR2(30)  Y                释放人ID      
              'system' SFR      ,--VARCHAR2(30)  Y                释放人        
              sysdate CJSJ     ,--DATE          Y                创建时间      
              '' ZJXGR    ,--VARCHAR2(30)  Y                              
              '' ZJXGSJ   ,--DATE          Y                              
              (select max(就诊日期) from  temp_his_dbbxxx    where   处理标志 is null ) as  SLRQ     ,--NUMBER(8)     Y                受理日期      
             null as  LRRQ     ,--NUMBER(8)     Y                录入日期      
              '1' DYBZ     ,--VARCHAR2(1)   Y                打印标志      
              'system' DYR      ,--VARCHAR2(50)  Y                打印人        
             '' DYRQ     ,--NUMBER(8)     Y                打印日期      
              '' BDYRQ    ,--NUMBER(8)     Y                补打印日期     
              '' BDYR     ,--VARCHAR2(50)  Y                补打印人      
              -1 SEQLOGID ,--NUMBER        Y                              
              v_count as  FPZS     ,--NUMBER(5)     Y                发票张数      
              '0' SFJJPC   --VARCHAR2(1)   Y                是否紧急批次0:否 1:是 
              from  (select bdid,khbdh,ttid,ttmc from  tb_bdxx b where b.bxgsid=v_bxgsid and rownum<2 union all select -1 as bdid,'' as khbdh,-1 as ttid,'' as ttmc from dual) b where rownum<2 ;     
       
              --根据批次插入按件信息
              v_pcajs:=0;
              v_pczpas:=0;
     for rec_pa in cur_lspa loop
        --先检查下人员信息存在不
        select count(1),max(khid) into v_count,v_khid from tb_khxx where aac147=rec_pa.身份证;
        if v_khid is null then
            SELECT  seq_khid.nextval  INTO v_khid FROM DUAL;
            insert into tb_khxx ( KHID   ,
                  KHBH        ,-- VARCHAR2(50)  Y                客户编号 
                  XM          ,-- VARCHAR2(100) Y                姓名     
                  AAC058      ,-- VARCHAR2(2)   Y                证件类型 
                  AAC147      ,-- VARCHAR2(20)  Y                证件号码 
                  SCZT        ,-- VARCHAR2(1)                    生存状态 
                  XB          ,-- VARCHAR2(1)   Y                性别     
                  CSRQ        ,-- NUMBER(8)     Y                出生日期 
                  SWRQ        ,-- NUMBER(8)     Y                死亡日期 
                  ZZBZ        ,-- VARCHAR2(2)   Y                在职标志 
                  ZYDJ        ,-- VARCHAR2(2)   Y                职业等级 
                  YBBS        ,-- VARCHAR2(2)   Y                医保标识 
                  YBKH        -- VARCHAR2(20)  Y                医保卡号
                   ) values(v_khid,v_khid,rec_pa.姓名,'01',rec_pa.身份证,'1' , case when substr(rec_pa.身份证,17,1) in('1','3','5','7','9') then '1' else '2' end ,
                      substr(rec_pa.身份证,7,8) ,'' ,'' ,rec_pa.人员类别 ,'02' ,(select max(医保卡号) from temp_his_dbbxxx where 结算凭证号=rec_pa.结算凭证号));
        else 
            null;
        end if;          
        select seq_ajid.nextval into v_ajid from dual;
        insert into tb_lpajxx(
        AJID        ,--NUMBER(16)                     案件ID          
        LPPCID      ,--NUMBER(16)                     理赔批次ID      
        PAH         ,--VARCHAR2(30)  Y                赔案号          
        BXGSID      ,--NUMBER(16)                     保险公司ID      
        TTID        ,--NUMBER(16)                     团体ID          
        ZTTID       ,--NUMBER(16)    Y                子团体ID        
        ZTTMC       ,--VARCHAR2(200) Y                子团体名称       
        GJAJBZ      ,--VARCHAR2(1)   Y                关联案件标志     
        GLAJH       ,--VARCHAR2(30)  Y                关联案件号       
        BBRXM       ,--VARCHAR2(30)  Y                被保人姓名       
        BBRKHID     ,--NUMBER(16)    Y                被保人客户ID     
        BBRZJH      ,--VARCHAR2(20)  Y                被保人证件号     
        ZLDBZ       ,--VARCHAR2(1)   Y                主/连带被保人标志 
        ZBBRKHID    ,--NUMBER(16)    Y                主被保人客户ID   
        KHBDH       ,--VARCHAR2(30)  Y                保单编号        
        FDID        ,--NUMBER(16)    Y                分单号          
        SQRZJLX     ,--VARCHAR2(2)                    申请人证件类型   
        SQRZJHM     ,--VARCHAR2(20)                   申请人证件号码   
        SQRXM       ,--VARCHAR2(30)                   申请人姓名       
        SQRSJ       ,--VARCHAR2(30)  Y                申请人手机       
        SQRDZ       ,--VARCHAR2(200) Y                申请人地址       
        SQRYX       ,--VARCHAR2(30)  Y                申请人邮箱       
        SQLX        ,--VARCHAR2(66)  Y                申请类型        
        SQRQ        ,--NUMBER(8)     Y                申请日期        
        BBRSCZT     ,--VARCHAR2(1)   Y                被保人生存状态   
        BBRCJDM     ,--VARCHAR2(10)  Y                被保人残疾代码   
        BBRCJXM     ,--VARCHAR2(500) Y                被保人残疾项目   
        BBRCJDJ     ,--VARCHAR2(10)  Y                被保人残疾等级   
        BBRSWRQ     ,--NUMBER(8)     Y                被保人死亡日期   
        BBRYWSGFSRQ ,--NUMBER(8)     Y                被保人意外事故发生日期 
        JBID        ,--NUMBER(16)    Y                重疾ID          
        ZJDM        ,--VARCHAR2(20)  Y                重疾代码        
        ZJQZR       ,--NUMBER(8)     Y                重疾确诊日       
        AJZT        ,--VARCHAR2(2)   Y                案件状态        
        ZHCLRQ      ,--DATE          Y                最后处理日期     
        AJXGDM      ,--VARCHAR2(80)  Y                案件悬挂代码     
        AJXGLY      ,--VARCHAR2(300) Y                案件悬挂理由     
        XGRQ        ,--VARCHAR2(30)  Y                悬挂日期        
        JARQ        ,--NUMBER(8)     Y                结案日期        
        AJJL        ,--VARCHAR2(2)   Y                案件结论        
        AJJLSM1     ,--VARCHAR2(10)  Y                案件结论说明1    
        AJJLSM      ,--VARCHAR2(200) Y                案件结论说明(备注) 
        JBR         ,--VARCHAR2(30)  Y                经办人          
        AJPFJE      ,--NUMBER(16,2)  Y                案件赔付金额     
        LPJSYR      ,--VARCHAR2(30)  Y                理赔金受益人     
        AJPFFS      ,--VARCHAR2(1)   Y                案件赔付方式     
        SFXNAJ      ,--VARCHAR2(1)            '0'     是否虚拟案件     
        SFZDSCZPA   ,--VARCHAR2(1)   Y        '0'     是否自动生成子赔案 
        SCZPASJ     ,--DATE          Y                生成子赔案时间   
        LSSJ        ,--DATE          Y                理算时间        
        SLRID       ,--NUMBER(19)    Y                受理人id        
        SLR         ,--VARCHAR2(50)  Y                受理人          
        LRRID       ,--NUMBER(19)    Y                录入人id        
        LRR         ,--VARCHAR2(50)  Y                录入人          
        SHRID       ,--NUMBER(19)    Y                审核人ID        
        SHR         ,--VARCHAR2(50)  Y                审核人          
        ZJRID       ,--NUMBER(19)    Y                质检人ID        
        ZJR         ,--VARCHAR2(50)  Y                质检人          
        ZJSJ        ,--DATE          Y                质检时间        
        ZJJL        ,--VARCHAR2(1)   Y                质检结论        
        ZJYJMS      ,--VARCHAR2(200) Y                质检意见描述     
        SSYLY       ,--VARCHAR2(200) Y                送审阅理由       
        KHSYR       ,--VARCHAR2(50)  Y                客户审阅人       
        SYJL        ,--VARCHAR2(1)   Y                审阅结论        
        SYRQ        ,--DATE          Y                审阅日期        
        SYYJMS      ,--VARCHAR2(200) Y                审阅意见描述     
        BXCSSCZPABZ ,--VARCHAR2(1)   Y                必须重新生成子赔案标志 
        DYSJSCBZ    ,--VARCHAR2(1)   Y                打印数据生成标志 
        DYSJSCSJ    ,--DATE          Y                打印数据生成时间 
        LPKGFKHH    ,--VARCHAR2(50)  Y                理赔款给付开户行 
        LPKGFYHZH   ,--VARCHAR2(35)  Y                理赔款给付银行账号 
        SKFXM       ,--VARCHAR2(50)  Y                收款方姓名       
        TQRQ        ,--DATE          Y                提取日期        
        QCLSM       ,--VARCHAR2(300) Y                缺材料说明       
        SFRQ        ,--NUMBER(8)     Y                释放日期        
        SEQLOGID    ,--NUMBER        Y                                
        DYBZ        ,--VARCHAR2(1)   Y                打印标志        
        DYR         ,--VARCHAR2(50)  Y                打印人          
        DYRQ        ,--NUMBER(8)     Y                打印日期        
        BDYRQ       ,--NUMBER(8)     Y                补打印日期       
        BDYR        ,--VARCHAR2(50)  Y                补打印人        
        FPS         ,--NUMBER(3)     Y                发票数          
        SFJJAJ      ,--VARCHAR2(1)   Y                是否紧急案件 0否 1 是 
        CSRID       ,--NUMBER(16)    Y                初审人ID        
        CSR         ,--VARCHAR2(50)  Y                初审人          
        CSJG        ,--VARCHAR2(1)   Y                初审结果 1通过 其他 未通过 
        CSCWDM      ,--VARCHAR2(50)  Y                初审错误项(可多选) 
        CSCWMS      ,--VARCHAR2(200) Y                初审错误描述     
        FSRID       ,--NUMBER(16)    Y                复审人ID        
        FSR         ,--VARCHAR2(50)  Y                复审人          
        FSJG        ,--VARCHAR2(1)   Y                复审结果 1通过 其他 未通过 
        FSCWDM      ,--VARCHAR2(50)  Y                复审错误项(可多选) 
        FSCWMS      ,--VARCHAR2(200) Y                复审错误描述     
        AJSFSD      ,--VARCHAR2(1)   Y                案件是否锁定0或空否 1是 
        SDKSSJ      ,--DATE          Y                锁定开始时间     
        DQCZR       ,--VARCHAR2(50)  Y                当前操作人       
        ZBBRGX      ,--VARCHAR2(2)   Y                申请人与被保人关系 
        SFGS        ,--VARCHAR2(1)   Y                是否工伤        
        YWSGDD      ,--VARCHAR2(200) Y                意外事故地点     
        YWSGYY      ,--VARCHAR2(200) Y                意外事故原因     
        SSWBYY      )--VARCHAR2(100) Y                损伤外部原因  
        select v_ajid as ajid,
        v_pcid LPPCID      ,--NUMBER(16)                     理赔批次ID      
        rec_pa.结算凭证号 as pah         ,--VARCHAR2(30)  Y                赔案号          
        v_BXGSID      ,--NUMBER(16)                     保险公司ID      
        (select TTID from tb_lppcxx where pcid=v_pcid) TTID        ,--NUMBER(16)                     团体ID          
        '' as zttid       ,--NUMBERt(16)    Y                子团体ID        
        '' as  ZTTMC       ,--VARCHAR2(200) Y                子团体名称       
        '' GJAJBZ      ,--VARCHAR2(1)   Y                关联案件标志     
        '' GLAJH       ,--VARCHAR2(30)  Y                关联案件号       
        rec_pa.姓名 as BBRXM       ,--VARCHAR2(30)  Y                被保人姓名       
     v_khid as  BBRKHID     ,--NUMBER(16)    Y                被保人客户ID     
     rec_pa.身份证 as   BBRZJH      ,--VARCHAR2(20)  Y                被保人证件号     
      '0'  ZLDBZ       ,--VARCHAR2(1)   Y                主/连带被保人标志 
      ''  ZBBRKHID    ,--NUMBER(16)    Y                主被保人客户ID   
      (select khbdh from tb_lppcxx where pcid=v_pcid)  KHBDH       ,--VARCHAR2(30)  Y                保单编号        
      '' as FDID        ,--NUMBER(16)    Y                分单号          
      '01'  SQRZJLX     ,--VARCHAR2(2)                    申请人证件类型   
      
      
      b.aac147 as  SQRZJHM     ,--VARCHAR2(20)                   申请人证件号码   
      rec_pa.姓名   SQRXM       ,--VARCHAR2(30)                   申请人姓名       
      b.sjh  SQRSJ       ,--VARCHAR2(30)  Y                申请人手机       
      b.GZDJZD  SQRDZ       ,--VARCHAR2(200) Y                申请人地址       
      b.email  SQRYX       ,--VARCHAR2(30)  Y                申请人邮箱       
      rec_pa.人员类别 as   SQLX        ,--VARCHAR2(66)  Y                申请类型        
     (select max(就诊日期) from temp_his_dbbxxx where 结算凭证号=rec_pa.结算凭证号)  SQRQ        ,--NUMBER(8)     Y                申请日期        
      '0'   BBRSCZT     ,--VARCHAR2(1)   Y                被保人生存状态   
      ''  BBRCJDM     ,--VARCHAR2(10)  Y                被保人残疾代码   
      ''  BBRCJXM     ,--VARCHAR2(500) Y                被保人残疾项目   
      ''  BBRCJDJ     ,--VARCHAR2(10)  Y                被保人残疾等级   
      ''  BBRSWRQ     ,--NUMBER(8)     Y                被保人死亡日期   
      ''  BBRYWSGFSRQ ,--NUMBER(8)     Y                被保人意外事故发生日期 
      ''  JBID        ,--NUMBER(16)    Y                重疾ID          
      ''  ZJDM        ,--VARCHAR2(20)  Y                重疾代码        
      ''  ZJQZR       ,--NUMBER(8)     Y                重疾确诊日       
      '11'  AJZT        ,--VARCHAR2(2)   Y                案件状态        
      ''  ZHCLRQ      ,--DATE          Y                最后处理日期     
      ''  AJXGDM      ,--VARCHAR2(80)  Y                案件悬挂代码     
      ''  AJXGLY      ,--VARCHAR2(300) Y                案件悬挂理由     
      ''  XGRQ        ,--VARCHAR2(30)  Y                悬挂日期        
     (select max(居民大病完成理赔日期) from temp_his_dbbxxx where 结算凭证号=rec_pa.结算凭证号)  JARQ        ,--NUMBER(8)     Y                结案日期        
      '01'  AJJL        ,--VARCHAR2(2)   Y                案件结论        
      ''  AJJLSM1     ,--VARCHAR2(10)  Y                案件结论说明1    
      ''  AJJLSM      ,--VARCHAR2(200) Y                案件结论说明(备注) 
      ''  JBR         ,--VARCHAR2(30)  Y                经办人          
      rec_pa.ajpfje as   AJPFJE      ,--NUMBER(16,2)  Y                案件赔付金额     
      substrb(rec_pa.姓名,1,30)  LPJSYR      ,--VARCHAR2(30)  Y                理赔金受益人     
      '1'  AJPFFS      ,--VARCHAR2(1)   Y                案件赔付方式     
      '0'  SFXNAJ      ,--VARCHAR2(1)            '0'     是否虚拟案件     
      '0'  SFZDSCZPA   ,--VARCHAR2(1)   Y        '0'     是否自动生成子赔案 
      null  SCZPASJ     ,--DATE          Y                生成子赔案时间   
      null  LSSJ        ,--DATE          Y                理算时间        
      ''   SLRID       ,--NUMBER(19)    Y                受理人id        
      ''   SLR         ,--VARCHAR2(50)  Y                受理人          
      ''   LRRID       ,--NUMBER(19)    Y                录入人id        
      ''   LRR         ,--VARCHAR2(50)  Y                录入人          
      (select max(受理报销人员工号) from temp_his_dbbxxx where 结算凭证号=rec_pa.结算凭证号 ) as   SHRID       ,--NUMBER(19)    Y                审核人ID        
      (select max(受理报销人员姓名) from temp_his_dbbxxx where 结算凭证号=rec_pa.结算凭证号 and 受理报销人员工号=(select max(受理报销人员工号) from temp_his_dbbxxx where 结算凭证号=rec_pa.结算凭证号 ) )   SHR         ,--VARCHAR2(50)  Y                审核人          
      ''   ZJRID       ,--NUMBER(19)    Y                质检人ID        
      ''   ZJR         ,--VARCHAR2(50)  Y                质检人          
      ''   ZJSJ        ,--DATE          Y                质检时间        
      ''   ZJJL        ,--VARCHAR2(1)   Y                质检结论        
      ''   ZJYJMS      ,--VARCHAR2(200) Y                质检意见描述     
      ''   SSYLY       ,--VARCHAR2(200) Y                送审阅理由       
      ''   KHSYR       ,--VARCHAR2(50)  Y                客户审阅人       
      ''   SYJL        ,--VARCHAR2(1)   Y                审阅结论        
      ''   SYRQ        ,--DATE          Y                审阅日期        
      ''   SYYJMS      ,--VARCHAR2(200) Y                审阅意见描述     
      ''   BXCSSCZPABZ ,--VARCHAR2(1)   Y                必须重新生成子赔案标志 
      ''   DYSJSCBZ    ,--VARCHAR2(1)   Y                打印数据生成标志 
      ''   DYSJSCSJ    ,--DATE          Y                打印数据生成时间 
      ''  LPKGFKHH    ,--VARCHAR2(50)  Y                理赔款给付开户行 
      ''  LPKGFYHZH   ,--VARCHAR2(35)  Y                理赔款给付银行账号 
      rec_pa.姓名  SKFXM       ,--VARCHAR2(50)  Y                收款方姓名       
       (select to_date(max(居民大病完成理赔日期),'yyyy-mm-dd') from temp_his_dbbxxx where 结算凭证号=rec_pa.结算凭证号) as   TQRQ        ,--DATE          Y                提取日期        
      ''  QCLSM       ,--VARCHAR2(300) Y                缺材料说明       
      '' as   SFRQ        ,--NUMBER(8)     Y                释放日期        
      -1  SEQLOGID    ,--NUMBER        Y                                
      ''  DYBZ        ,--VARCHAR2(1)   Y                打印标志        
      'system'  DYR         ,--VARCHAR2(50)  Y                打印人          
      ''  DYRQ        ,--NUMBER(8)     Y                打印日期        
      ''  BDYRQ       ,--NUMBER(8)     Y                补打印日期       
      ''  BDYR        ,--VARCHAR2(50)  Y                补打印人        
      (select count(1) from temp_his_dbbxxx where 结算凭证号=rec_pa.结算凭证号)  FPS         ,--NUMBER(3)     Y                发票数          
      '0'  SFJJAJ      ,--VARCHAR2(1)   Y                是否紧急案件 0否 1 是 
      ''  CSRID       ,--NUMBER(16)    Y                初审人ID        
      ''  CSR         ,--VARCHAR2(50)  Y                初审人          
      ''  CSJG        ,--VARCHAR2(1)   Y                初审结果 1通过 其他 未通过 
      ''  CSCWDM      ,--VARCHAR2(50)  Y                初审错误项(可多选) 
      ''  CSCWMS      ,--VARCHAR2(200) Y                初审错误描述     
      ''  FSRID       ,--NUMBER(16)    Y                复审人ID        
      ''  FSR         ,--VARCHAR2(50)  Y                复审人          
      ''  FSJG        ,--VARCHAR2(1)   Y                复审结果 1通过 其他 未通过 
      ''  FSCWDM      ,--VARCHAR2(50)  Y                复审错误项(可多选) 
      ''  FSCWMS      ,--VARCHAR2(200) Y                复审错误描述     
      ''  AJSFSD      ,--VARCHAR2(1)   Y                案件是否锁定0或空否 1是 
      ''  SDKSSJ      ,--DATE          Y                锁定开始时间     
      ''  DQCZR       ,--VARCHAR2(50)  Y                当前操作人       
      '00'  ZBBRGX      ,--VARCHAR2(2)   Y                申请人与被保人关系 
      '0'   SFGS        ,--VARCHAR2(1)   Y                是否工伤        
      rec_pa.服务点名称 as   YWSGDD      ,--VARCHAR2(200) Y                意外事故地点     
      rec_pa.服务点编码  YWSGYY      ,--VARCHAR2(200) Y                意外事故原因     
      ''  SSWBYY  from tb_khxx b where b.khid=v_khid;
  
      IF SQL%rowcount=0 THEN
         DBMS_OUTPUT.PUT_LINE('TB_LPAJXX DATA ERROR!AAC147='||rec_pa.身份证||'赔案号生成失败 ' ||rec_pa.结算凭证号);
         RAISE MYEXCEPTION;
      END IF;    
      --生成子赔案信息
    select  seq_ZPAID.nextval into v_zpaid from dual;
          insert into tb_zpaxx(
          ZPAID     ,--NUMBER(16)                      子赔案ID  
          AJID      ,--NUMBER(16)                      案件ID    
          ZPAH      ,--VARCHAR2(30)   Y                子赔案编号 
          JBID      ,--NUMBER(16)     Y                疾病ID    
          ZDDM      ,--VARCHAR2(20)   Y                诊断代码  
          ZRID      ,--NUMBER(16)                      责任ID    
          PFZRDM    ,--VARCHAR2(10)   Y                赔付责任代码 
          ZDZJE     ,--NUMBER(16,2)   Y                账单总金额 
          SBZFZJE   ,--NUMBER(16,2)   Y                社保支付总金额 
          ZFJE      ,--NUMBER(16,2)   Y                自费金额  
          FLZFJE    ,--NUMBER(16,2)   Y                分类自负金额 
          QTDSFZFJE ,--NUMBER(16,2)   Y                其他第三方支付金额 
          BHLFY     ,--NUMBER(16,2)   Y                不合理费用 
          BXZRWJE   ,--NUMBER(16,2)   Y                保险责任外金额 
          XLLSPFJE  ,--NUMBER(16,2)   Y                系统理算赔付金额 
          RGTZJE    ,--NUMBER(16,2)   Y                人工调整金额 
          SJPFJE    ,--NUMBER(16,2)   Y                实际赔付金额 
          MPE       ,--NUMBER(16,2)   Y                免赔额    
          XGDM      ,--VARCHAR2(100)  Y                悬挂代码  
          XGDMMS    ,--VARCHAR2(1024) Y                悬挂代码描述 
          ZT        ,--VARCHAR2(1)    Y                状态      
          ZPAJL     ,--VARCHAR2(2)    Y                子赔案结论 
          JLSM1     ,--VARCHAR2(10)   Y                结论说明1 
          JLSM2     ,--VARCHAR2(500)  Y                结论说明2 
          SHYYJ     ,--VARCHAR2(200)  Y                审核员意见 
          SJGFTS    ,--NUMBER         Y                实际可理算天数 
          SSXM      ,--VARCHAR2(30)   Y                手术项目  
          SSPFBL    ,--NUMBER(5,2)    Y                手术赔付比例 
          MPTS      ,--NUMBER         Y                免赔天数  
          SFSDTJ    ,--VARCHAR2(1)             '0'     是否手动添加 
          LSSJ      ,--DATE           Y                理算时间  
          SYFPH     ,--VARCHAR2(500)  Y                所有发票号 
          FPID      ,--NUMBER(16)     Y                发票ID    
          SEQLOGID  ,--NUMBER         Y                          
          FDID      ,--NUMBER(16)     Y                责任对应分单 
          SBBDX     ,--VARCHAR2(1)    Y                社保比大小情况 
          CDEJE     --NUMBER(16,2)   Y                超大额金额 
          )
          select       v_zpaid as zpaid     ,--NUMBER(16)                      子赔案ID  
          v_AJID      ,--NUMBER(16)                      案件ID    
          rec_pa.结算凭证号 as ZPAH      ,--VARCHAR2(30)   Y                子赔案编号 
          (select jbid from tb_jbkxx where jbdm=(select 疾病诊断编码 from temp_his_dbbxxx where 结算凭证号=rec_pa.结算凭证号 and rownum<2)) as JBID      ,--NUMBER(16)     Y                疾病ID    
          (select 疾病诊断编码 from temp_his_dbbxxx where 结算凭证号=rec_pa.结算凭证号 and rownum<2) as ZDDM      ,--VARCHAR2(20)   Y                诊断代码  
         '' as ZRID      ,--NUMBER(16)                      责任ID    
         case when exists(select 'x' from temp_his_dbbxxx where 结算凭证号=rec_pa.结算凭证号 and 住院号 is not null ) then '1' else '0' end as  PFZRDM    ,--VARCHAR2(10)   Y                赔付责任代码  
          nvl(rec_pa.交易费用总额,0)+nvl(rec_pa.非医保个人自费,0 ) as ZDZJE     ,--NUMBER(16,2)   Y                账单总金额 
           nvl(rec_pa.交易费用总额,0)-nvl(rec_pa.自负,0 ) SBZFZJE   ,--NUMBER(16,2)   Y                社保支付总金额 
          nvl(rec_pa.非医保个人自费,0 ) ZFJE      ,--NUMBER(16,2)   Y                自费金额   ,
          '' FLZFJE    ,--NUMBER(16,2)   Y                分类自负金额 
          '' QTDSFZFJE ,--NUMBER(16,2)   Y                其他第三方支付金额 
          '' BHLFY     ,--NUMBER(16,2)   Y                不合理费用 
          '' BXZRWJE   ,--NUMBER(16,2)   Y                保险责任外金额 
          '' XLLSPFJE  ,--NUMBER(16,2)   Y                系统理算赔付金额 
          '' RGTZJE    ,--NUMBER(16,2)   Y                人工调整金额 
          rec_pa.aJPFJE    ,--NUMBER(16,2)   Y                实际赔付金额 
          '' MPE       ,--NUMBER(16,2)   Y                免赔额    
          '' XGDM      ,--VARCHAR2(100)  Y                悬挂代码  
          '' XGDMMS    ,--VARCHAR2(1024) Y                悬挂代码描述 
          '1' ZT        ,--VARCHAR2(1)    Y                状态      
          '01' ZPAJL     ,--VARCHAR2(2)    Y                子赔案结论 
          '' JLSM1     ,--VARCHAR2(10)   Y                结论说明1 
          '' JLSM2     ,--VARCHAR2(500)  Y                结论说明2 
          '' SHYYJ     ,--VARCHAR2(200)  Y                审核员意见 
        '' SJGFTS    ,--NUMBER         Y                实际可理算天数 
          '' SSXM      ,--VARCHAR2(30)   Y                手术项目  
          '' SSPFBL    ,--NUMBER(5,2)    Y                手术赔付比例 
          '' MPTS      ,--NUMBER         Y                免赔天数  
          '0' SFSDTJ    ,--VARCHAR2(1)             '0'     是否手动添加 
          '' LSSJ      ,--DATE           Y                理算时间  
          '' SYFPH     ,--VARCHAR2(500)  Y                所有发票号 
          '' FPID      ,--NUMBER(16)     Y                发票ID    
          -1 SEQLOGID  ,--NUMBER         Y                          
         '' as FDID      ,--NUMBER(16)     Y                责任对应分单 
          '0' SBBDX     ,--VARCHAR2(1)    Y                社保比大小情况 
          '' CDEJE     --NUMBER(16,2)   Y                超大额金额
          from tb_lpajxx a where a.ajid=v_ajid and rownum<2;
          IF SQL%rowcount!=1 THEN
             DBMS_OUTPUT.PUT_LINE('TB_ZPAXX DATA ERROR!结算凭证号='||rec_pa.结算凭证号);
             RAISE MYEXCEPTION;
          END IF;             
          v_pczpas:=v_pczpas+sql%rowcount;
          --发票信息生成
          insert into tb_lpfpxx(
            FPID     ,--NUMBER(16)                     发票ID                                                                            
            AJID     ,--NUMBER(16)                     案件ID                                                                            
            YBJYLSH  ,--VARCHAR2(30)  Y                医保交易流水号                                                                    
            FPHM     ,--VARCHAR2(30)  Y                发票号码                                                                          
            BBRKHID  ,--NUMBER(16)    Y                被保人客户ID                                                                      
            BBRXM    ,--VARCHAR2(30)  Y                被保人姓名                                                                        
            FPHBLX   ,--VARCHAR2(3)   Y                发票货币类型                                                                      
            ZDLX     ,--VARCHAR2(2)   Y                账单类型                                                                          
            JZYY     ,--VARCHAR2(150) Y                就诊医院                                                                          
            YYID     ,--NUMBER(16)    Y                就诊医院代码                                                                      
            JZKS     ,--VARCHAR2(50)  Y                就诊科室                                                                          
            JZKSID   ,--VARCHAR2(30)  Y                就诊科室代码                                                                      
            JBDM     ,--VARCHAR2(100) Y                疾病代码                                                                          
            FPRQ     ,--NUMBER(8)     Y                发票日期                                                                          
            JZRQ     ,--NUMBER(8)     Y                就诊日期                                                                          
            RYRQ     ,--NUMBER(8)     Y                入院日期                                                                          
            CYRQ     ,--NUMBER(8)     Y                出院日期                                                                          
            ZYTS     ,--NUMBER(5,1)   Y                住院天数                                                                          
            FPZE     ,--NUMBER(16,2)                   发票总额                                                                          
            TCZFE    ,--NUMBER(16,2)  Y                统筹支付额                                                                        
            FJZFE    ,--NUMBER(16,2)  Y                附加支付额                                                                        
            SBZFE    ,--NUMBER(16,2)  Y                其他社保支付                                                                      
            GRZFZFE  ,--NUMBER(16,2)  Y                个人帐户支付额                                                                    
            XJZFE    ,--NUMBER(16,2)  Y                现金支付额                                                                        
            FLZFZE   ,--NUMBER(16,2)  Y                分类自负总额                                                                      
            ZFZE     ,--NUMBER(16,2)  Y                自费总额                                                                          
            BHLFY    ,--NUMBER(16,2)  Y                剔除总金额                                                                        
            SFSYYBK  ,--VARCHAR2(1)            '0'     是否使用医保卡                                                                    
            SFYWYL   ,--VARCHAR2(1)            '0'     是否意外医疗                                                                      
            SFYSS    ,--VARCHAR2(1)            '0'     是否有手术                                                                        
            XGDM     ,--VARCHAR2(200) Y                悬挂代码                                                                          
            SFICU    ,--VARCHAR2(1)            '0'     是否ICU                                                                           
            JZLSH    ,--VARCHAR2(32)  Y                就诊流水号                                                                        
            ZYH      ,--VARCHAR2(50)  Y                住院号                                                                            
            ZYJSKSSJ ,--NUMBER(8)     Y                住院结算开始时间                                                                  
            ZYJSJSSJ ,--NUMBER(8)     Y                住院结算结束时间                                                                  
            JYKH     ,--VARCHAR2(20)  Y                就医使用卡号                                                                      
            JYKLX    ,--VARCHAR2(3)   Y                就医使用卡类型                                                                    
            ZDSM     ,--VARCHAR2(500) Y                诊断说明                                                                          
            JZLX     ,--VARCHAR2(3)   Y                卫生就诊类型                                                                      
            YBJSLX   ,--VARCHAR2(3)   Y                医保结算类型                                                                      
            CJLSH    ,--NUMBER(16)    Y                对应采集流水号                                                                    
            SJLX     ,--VARCHAR2(2)   Y                收据类型                                                                          
            QTSBLX   ,--VARCHAR2(100) Y                其他社保类型                                                                      
            DSFZFLX  ,--VARCHAR2(100) Y                其他第三方支付类型                                                                
            DSFZFJE  ,--NUMBER(16,2)  Y                其他补助                                                                          
            ZFYJE    ,--NUMBER(16,2)  Y                自负一金额(北京地区就诊填写)                                                      
            QFJE     ,--NUMBER(16,2)  Y                起付金额                                                                          
            SFAZZY   ,--VARCHAR2(1)   Y                是否癌症住院                                                                      
            AZZYTS   ,--NUMBER(5,1)   Y                癌症住院天数                                                                      
            ICUZYTS  ,--NUMBER(5,1)   Y                ICU住院天数                                                                       
            SFGS     ,--VARCHAR2(2)   Y                是否工伤                                                                          
            FPXM     ,--VARCHAR2(50)  Y                发票姓名                                                                          
            SFQCL    ,--VARCHAR2(1)   Y                是否缺材料                                                                        
            QCLDM    ,--VARCHAR2(3)   Y                大病报销项目(1  化疗 2  放疗 3  血透 4  腹透 6  肾移植抗排异 7  同位素治疗 8  介入治疗 9  中医药治疗 A  精神病 B  血友病 C  再生障碍性贫血) 
            QCLSM    ,--VARCHAR2(500) Y                大病项目名称                                                                      
            CSBZ     ,--VARCHAR2(200) Y                初审备注                                                                          
            CDEJE    ,--NUMBER(16,2)  Y                红会支付总金额                                                                    
            FPLYSFYC ,--VARCHAR2(1)   Y                录入是否差错                                                                      
            LRCCYY   ,--VARCHAR2(100) Y                录入出错原因                                                                      
            LRCCBZ   ,--VARCHAR2(200) Y                差错描述                                                                          
            FPYXID   ,--NUMBER(16)    Y                发票影像ID                                                                        
            BLYXID   ,--NUMBER(16)    Y                病历影像ID                                                                        
            PFJE     ,--NUMBER(16,2)  Y                发票赔付金额                                                                      
            FDBFY    ,--NUMBER(16,4)  Y                非大病费用                                                                        
            HCBZ     )--VARCHAR2(1)   Y                ‘1’ 是 其它 否 
            select  seq_FPID.nextval as fpid     ,
            v_AJID     ,
            trim(f.结算单号) as YBJYLSH  ,
            '' as FPHM     ,
            v_khid as BBRKHID  ,
            rec_pa.姓名 as BBRXM    ,
            '1' as FPHBLX   ,
          case when trim(f.住院号) is not null then '1' else '0' end as   ZDLX     ,
          trim(f.就诊定点医疗机构名称) as   JZYY     ,
          (select yyid from tb_yyxx where yymc=trim(f.就诊定点医疗机构名称))  YYID     ,
          trim(f.就诊科室名称) as   JZKS     ,
          trim(f.就诊科室代码) as  JZKSID   ,
          trim(f.疾病诊断编码) as  JBDM     ,
          trim(f.就诊日期) as   FPRQ     ,
          trim(f.就诊日期) as   JZRQ     ,
          trim(f.就诊日期) as   RYRQ     ,
          case when trim(f.住院号) is not null then  to_char(to_date(trim(f.就诊日期),'yyyy-mm-dd')+to_number(f.住院天数),'yyyymmdd')  else null  end as   CYRQ     ,
          trim(f.住院天数)  ZYTS     ,
          nvl(to_number(f.交易费用总额),0)+nvl(to_number(f.非医保个人自费),0) as   FPZE ,
          --nvl(to_number(f.交易费用总额),0)+nvl(to_number(f.自负),0) as   TCZFE    ,
          nvl(to_number(f.交易费用总额),0)-nvl(to_number(f.自负),0) as   TCZFE    ,
          null as  FJZFE    ,
          null as  SBZFE    ,
          null as  GRZFZFE  ,
          null as  XJZFE    ,
          null as  FLZFZE   ,
          nvl(to_number(f.非医保个人自费),0)  ZFZE     ,
          null as  BHLFY    ,
          case when trim(f.医保卡号) is not null then '1' else '0' end as    SFSYYBK  ,
          '0' as  SFYWYL   ,
          '0' as  SFYSS    ,
          null as  XGDM     ,
          '0' as  SFICU    ,
          null as  JZLSH    ,
          trim(f.住院号)  ZYH      ,
          null as  ZYJSKSSJ ,
          null as  ZYJSJSSJ ,
          trim(f.医保卡号)  JYKH     ,
          null as   JYKLX    ,
          null as  ZDSM     ,
          null as  JZLX     ,
          null as  YBJSLX   ,
          trim(f.结算单号)  CJLSH    ,
          null as  SJLX     ,
          null as  QTSBLX   ,
          null as  DSFZFLX  ,
          null as  DSFZFJE  ,
          nvl(to_number(f.自负),0) as   ZFYJE    ,
          null as    QFJE     ,
          null as    SFAZZY   ,
          null as    AZZYTS   ,
          null as    ICUZYTS  ,
          '0' as    SFGS     ,
          trim(f.姓名)  FPXM     ,
          '0' as    SFQCL    ,
          trim(f.报销大病项目) as    QCLDM    ,
          null as    QCLSM    ,
          null as    CSBZ     ,
          null as    CDEJE    ,
          null as    FPLYSFYC ,
          null as    LRCCYY   ,
          null as    LRCCBZ   ,
          null as    FPYXID   ,
          null as    BLYXID   ,
          nvl(to_number(f.居保大病基金支付数),0) PFJE ,
          null as   FDBFY    ,
          '0' as   HCBZ      from temp_his_dbbxxx f where 结算凭证号=rec_pa.结算凭证号;
          --发票剔除细项导入
          
          --子赔案细项对照表
          insert into tb_zpaxxdzb(
                    XXDZID  ,--NUMBER(16)                   细项对照ID
                    ZPAID  ,--NUMBER(16)                   子赔案ID
                    XXID   ,--NUMBER(16)                   细项ID
                    XXJFLY ,--VARCHAR2(4) Y                细项拒付理由
                    AJID )--NUMBER(16)                   案件ID
                    select seq_XXDZID.nextval as XXDZID, v_zpaid as ZPAID,
                    b.fpid as xxid,'' as XXJFLY, v_AJID  as ajid
                    from TB_LPFPXX  b where b.ajid=v_ajid;
          --更新处理标志
          update temp_his_dbbxxx set 处理标志='1',处理日期=to_char(sysdate,'yyyymmdd') where 处理标志 is null and  结算凭证号=rec_pa.结算凭证号;
     end loop;
     --校验数据准确性     
    dbms_output.put_line('批次号：'||v_pch||'实际案件数'||to_char(v_pcajs)||'实际子赔案数'||to_char(v_pczpas)||', 数据导入成功！');
  
    PReturnCode:='0';
    PReturnMsg:='案件审核处理成功!';
    return;    
    EXCEPTION
    WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('[yhs debug] ' || 'PReturncode= ' ||'E');
    PReturnCode:='E';
    PReturnMsg := 'Error:' || sqlerrm;
    DBMS_OUTPUT.PUT_LINE(PReturnMsg);                  
end SP_IMPORT_LSPA_DBBX;
/
