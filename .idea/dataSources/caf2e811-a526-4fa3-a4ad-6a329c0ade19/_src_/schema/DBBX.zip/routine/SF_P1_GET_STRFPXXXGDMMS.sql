CREATE function SF_P1_GET_STRFPXXXGDMMS(pFpid in varchar2,p_aaa100 in varchar2,pXxid in varchar2) return varchar2 is
v_kfckxzqhdm varchar2(10):='';
 v_zpaxgdm varchar2(1024):='';
 v_kfcklx  varchar2(2):='';
--细项涉及到的发票悬挂项
cursor cur_rec is select distinct rec_xy.aaa102,trim(rec_xy.aaa103) as aaa103 from aa10 rec_xy where    
--rec_xy.aaa102 in(select trim(COLUMN_VALUE) from TABLE(sf_splitstr(p_aaa100,',')) H )
p_aaa100 like '%'|| rec_xy.aaa102 ||'%'
/*and rec_xy.aaa100='FPXGDM' and rec_xy.aaa102 in(trim('SY001-1'),
trim('SY001-2'),
trim('SY002  '),
trim('SY003  '),
trim('SY004  '),
trim('SY005  '),
trim('SY006  '),
trim('SY007  ')) 
and  exists(select 'x' from tb_fpxxfyxx d, tb_lpajxx b,tb_khxx c,tb_lpfpxx a,tb_sbshgzpzxx e where d.xxid=pXxid and b.ajid = a.ajid
                     and b.bbrkhid=c.khid and d.fpid=a.fpid and e.ZSDBM=d.XXDM and e.ZSDLB=d.xmlb
                     and e.status='1' and e.AAA102=substr(rec_xy.aaa102,1,5)
                     and ( (rec_xy.aaa102 in('SY001-1','SY001-2') and e.shys2=decode(rec_xy.aaa102,'SY001-1','1','2'))
                        or (rec_xy.aaa102 not in('SY001-1','SY001-2')
                     and ( (e.shys1='02' and c.CSRQ< to_char(add_months(to_date(nvl(a.ryrq,jzrq),'yyyy-mm-dd'),-216),'yyyymmdd')) --儿童年龄在0-18周岁/
                                               and (nvl(e.XZQH,v_kfckxzqhdm)=nvl(v_kfckxzqhdm,'xxxx') or e.xzqh is null)
or (e.shys1='03' and c.CSRQ<to_char(add_months(to_date(nvl(a.ryrq,jzrq),'yyyy-mm-dd'),-12),'yyyymmdd')) -- //新生儿年龄在0-1周岁
                          or (e.shys1='04' and a.zdlx!='0') --门诊限用
                          or (e.shys1='05' and a.zdlx!='1')--/住院限用
                          or (e.shys1='07' and d.zddm not in(select ZDDM from tb_bdtyshgzzddmpz h,tb_bdxx m,tb_fdzrmx n where h.bdid=m.bdid and m.khbdh=b.khbdh and n.fdid=b.fdid and n.zrid=h.zrid and h.YXZT='1' and h.JBLX='10'  ) ) -- //生育限用
                          ))))*/;
v_zpaid number:=0;       
exist_zpaxxxg number:=0;--子赔案里找到细项悬挂描述标志，0 未有 1 有
 
                   
--细项涉及到的子赔案悬挂项,如果是SY009的悬挂，则还需要列病症的类别
cursor cur_dt is select distinct rec_xy.aaa102,case when rec_xy.aaa102='SY009' then (select trim(rec_xy.aaa103)||'--'|| max(c.aaa103) from tb_sbshgzpzxx e,tb_fpxxfyxx d,aa10 c where e.aaa102=rec_xy.aaa102 and e.zsdbm=d.xxdm and d.xxid=pXxid and e.shys2=c.aaa102 
                                                                             and c.aaa100='JBLB' and e.status='1'  ) else trim(rec_xy.aaa103) end as aaa103 from aa10 rec_xy where    
--rec_xy.aaa102 in(select trim(COLUMN_VALUE) from TABLE(sf_splitstr((select xgdm from tb_zpaxx where zpaid=v_zpaid),',')) H )
 v_zpaxgdm like '%'|| rec_xy.aaa102 ||'%'
/*and rec_xy.aaa100='XTXGDM' and rec_xy.aaa102 in(trim('CL87  '),
trim('CL88  '),
trim('CL89  '),
trim('CL90  '),
trim('SY008 '),
trim('SY009 '),
trim('CL92  '),
trim('CL93  '),
trim('CL94  '),
trim('CL95  ')
)  and ( exists(select 'x' from tb_sbshgzpzxx e,tb_fpxxfyxx d ,tb_zpaxx a 
                          where a.zpaid=v_zpaid and  d.xxid=pXxid and e.ZSDBM=d.XXDM and e.ZSDLB=d.xmlb
                                 and e.status='1' and e.AAA102=substr(rec_xy.aaa102,1,5)
                                and ((  e.AAA102='SY008' and d.ZDDM not in(select shys2 from tb_sbshgzpzxx h where  h.aaa102=e.aaa102 and h.status='1' and h.zsdbm=e.zsdbm)) 
                                    or (e.AAA102='SY009' and e.shys1='09' and d.ZDDM not in(select ZDDM  as xxx from
                                   tb_bdtyshgzzddmpz  h,tb_fdxx y  where h.bdid=y.bdid and y.fdid=a.fdid  and h.zrid=a.zrid   and h.jblx=e.SHYS2 and h.YXZT='1'))
                                   )
                )
      or exists (
          select 'x' from TB_TYSHGZYJXX e ,tb_fpxxfyxx d  where  d.xxid=pXxid and e.ZSDBM=d.xxDM and e.ZSDLB=d.xmlb
                and e.status='1' and e.SHYS1=decode( rec_xy.aaa102,'CL87','11','CL88','12','CL89','13',rec_xy.aaa102)                
                ) --看费用悬挂描述获取CL87-CL89
      or   exists(select 'x' from TB_TYSHGZYJXX e,tb_fpxxfyxx d where  d.xxid=pXxid and e.ZSDBM=d.zdDM and e.ZSDLB='3'
                                                                   and e.status='1' and e.SHYS1=decode( rec_xy.aaa102,'CL90','13','CL92','1L','CL93','1N','CL94','02','CL95','03',rec_xy.aaa102)
                 ) --看诊断类悬挂描述获取('CL90', 'CL92','CL93','CL94','CL95')
      )*/;                                   
v_FPXGDMMS varchar2(4028):='';


Result varchar2(4028):='' ;

BEGIN
   --获取扣费参考地区划
    select  (select kfcklx from tb_bdxx where khbdh=b.khbdh) as kfcklx,
     (select decode (nvl(kfcklx,'1'),'1' ,(select b.xzqhdm from tb_yyxx b ,tb_lpfpxx a where b.yyid=a.yyid and a.fpid=Pfpid),'2' , cbdqh,'3',KFZDQH,'') as kfckxzqhdm from tb_bdxx where khbdh=b.khbdh) as kfckxzqhdm into v_kfcklx,v_kfckxzqhdm 
     from  tb_lpajxx b where  ajid=(select ajid from tb_lpfpxx where fpid=pFpid);
 /*    
  select max(khid),max(csrq),max(xb) into rec_khxx.khid,rec_khxx.csrq,rec_khxx.xb from tb_khxx where khid =(selec bbrkhid from tb_lpajxx where ajid=(select ajid from tb_lpfpxx where fpid=pFpid));
  if rec_khxx.khid is null then
      select substr(max(a.bbrzjh),7,8),max(b.xb) into rec_khxx.csrq,rec_khxx.xb  from tb_lpajxx a,tb_ajqtxx b where a.ajid=b.ajid and a.ajid=(select ajid from tb_lpfpxx where fpid=pFpid);
  end if ;
  */
 if length(trim(pFpid))=0 then
    Result:='无';
  end if;
 --先处理发票中的悬挂针对细项的描述
  for rec_xy in cur_rec loop 
       if v_FPXGDMMS is null or v_FPXGDMMS='' then 
           v_FPXGDMMS:='发票悬挂:';
       end if;    
          v_FPXGDMMS:=v_FPXGDMMS||rec_xy.aaa102||'('||rec_xy.aaa103||')、';         
          if  v_FPXGDMMS like '%、' then 
            v_FPXGDMMS:=substr(v_FPXGDMMS,1,length(trim(v_FPXGDMMS))-1);
          end if;          
           Result:=Result||v_FPXGDMMS||'。';    
  end loop;
  --看发票细项有没被子赔案用到，且用到的子赔案有悬挂代码，则继续列出涉及的子赔案悬挂代码描述
  select max(b.zpaid),max(b.xgdm) into v_zpaid,v_zpaxgdm from tb_zpaxxdzb a,tb_zpaxx b where a.zpaid=b.zpaid and a.xxid=pXxid and (b.xgdm  like '%CL87%'
                    or b.xgdm like '%'||trim('CL88  ')||'%'
                    or b.xgdm like '%'||trim('CL89  ')||'%'
                    or b.xgdm like '%'||trim('CL90  ')||'%'
                    or b.xgdm like '%'||trim('SY008 ')||'%'
                    or b.xgdm like '%'||trim('SY009 ')||'%'
                    or b.xgdm like '%'||trim('CL92  ')||'%'
                    or b.xgdm like '%'||trim('CL93  ')||'%'
                    or b.xgdm like '%'||trim('CL94  ')||'%'
                    or b.xgdm like '%'||trim('CL95  ')||'%');
  if v_zpaid is not null then
   
      for rec_dt in cur_dt loop
          if (v_FPXGDMMS is null or v_FPXGDMMS='') and  exist_zpaxxxg=0 then
              v_FPXGDMMS:='子赔案悬挂:';
              exist_zpaxxxg:=1;
          end if;
          if  exist_zpaxxxg=0 then --处理第一个细项时增加开头描述
              v_FPXGDMMS:=Result||'子赔案悬挂:';
          end if;
          v_FPXGDMMS:=v_FPXGDMMS||rec_dt.aaa102||'('||rec_dt.aaa103||')、';         
          if  v_FPXGDMMS like '%、' then 
            v_FPXGDMMS:=substr(v_FPXGDMMS,1,length(trim(v_FPXGDMMS))-1);
          end if;          
         exist_zpaxxxg:=1;
      end loop;
       Result:=v_FPXGDMMS;  
  end if;
  
  if  Result like '%、' then 
    Result:=substr(Result,1,length(trim(Result))-1);
  end if;
--dbms_output.put_line(Result);
return(Result);
END SF_P1_GET_STRFPXXXGDMMS;
/
