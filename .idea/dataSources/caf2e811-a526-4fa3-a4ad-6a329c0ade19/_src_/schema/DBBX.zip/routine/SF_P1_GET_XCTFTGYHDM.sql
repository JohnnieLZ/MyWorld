CREATE FUNCTION      "SF_P1_GET_XCTFTGYHDM" (khyh in varchar2,lpkgfh in varchar2) return varchar2 is
Result varchar2(1024):='';
yhdm  varchar2(1024):='';
s_khyh varchar2(1024):='';
s_lpkgfh varchar2(1024):='';
v_khyh varchar2(1024):='';
v_lpkgfh varchar2(1024):='';
v_all varchar2(1024):='';
v_change varchar2(1024):='';
i int:=1;
v_no number:=0;
BEGIN
 if khyh is null or lpkgfh is null
   then
     yhdm:='??????';
 else
 if (length(trim(khyh))=0 or length(trim(lpkgfh))=0) then
    yhdm:='';
 else
   s_khyh:=trim(khyh);
   s_lpkgfh:=trim(lpkgfh);
   loop
     select substr(s_khyh,i,1)into v_change from dual;
     if(v_khyh is null or v_khyh='')
     then
     v_khyh:='%'||v_change||'%';
     i:=i+1;
     else
       v_khyh:=v_khyh||v_change||'%';
       i:=i+1;
     end if;
     exit when i=length(s_khyh)+1;
   end loop;
   i:=1;
   /***********-v1.1.1 start*************/
   /*loop
      select substr(s_lpkgfh,i,1)into v_change from dual;
     if(v_lpkgfh is null or v_lpkgfh='')
     then
       v_lpkgfh:=v_change||'%';
       i:=i+1;
     else
       v_lpkgfh:=v_lpkgfh||v_change||'%';
       i:=i+1;
     end if;
     exit when i=length(s_lpkgfh)+1;
   end loop;*/
   /************-v1.1.1 end************/
   /************+v1.1.1 start**********/
   loop
      select substr(s_lpkgfh,i,1)into v_change from dual;
     if(v_lpkgfh is null or v_lpkgfh='')
     then
       v_lpkgfh:=v_change;
       i:=i+1;
     else
       v_lpkgfh:=v_lpkgfh||'%'||v_change;
       i:=i+1;
     end if;
     exit when i=length(s_lpkgfh)+1;
   end loop;
   /***************+v1.1.1 end*********/
   v_all:=v_khyh||v_lpkgfh;
   select count(1) into v_no from  tb_zddmbxgsdmdzb where aaa102 like v_all;
   if(v_no=0) then yhdm:='????????';
   elsif(v_no>1) then yhdm:='??????????';
   elsif(v_no=1)
    then
     select bxgsxmbm into yhdm from  tb_zddmbxgsdmdzb where aaa102 like v_all;
   end if;
   end if;
   end if;
 Result:=yhdm;

return(Result);
END SF_P1_GET_XCTFTGYHDM;

/
