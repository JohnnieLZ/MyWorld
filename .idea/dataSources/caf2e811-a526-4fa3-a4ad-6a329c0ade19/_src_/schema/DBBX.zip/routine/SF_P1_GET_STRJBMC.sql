CREATE FUNCTION "SF_P1_GET_STRJBMC" (p_ZRBHS in varchar2) return varchar2 is

v_tempstr varchar2(256):=p_ZRBHS;
v_pos number:=1;  --???????????
v_jbdm varchar2(30):='';
v_jbgs number:=0;--??????
Result varchar2(1024):='' ;
v_str1 varchar2(255):='';
BEGIN
if v_tempstr is not null  then

        if  instr(v_tempstr,',')=0 then
            v_jbdm:=v_tempstr;
              select  max(b.JBMC) as jbmc into Result from tb_jbkxx b where v_jbdm = b.jbdm  ;
        else
           loop
               if instr(v_tempstr,',',1,v_jbgs+1)>0 then
                  v_jbdm:=substr(v_tempstr,v_pos,instr(v_tempstr,',',1,v_jbgs+1)-v_pos);
                else
                  v_jbdm:=substr(v_tempstr,v_pos,lengthb(v_tempstr)-v_pos+1);
               end if;

               select max(b.JBMC) as jbmc into v_str1 from tb_jbkxx b where v_jbdm = b.jbdm  ;
                 Result:=Result||v_str1||',';
                if instr(v_tempstr,',',1,v_jbgs+1)=0 then
                    exit;
                end if ;
                v_pos:=instr(v_tempstr,',',1,v_jbgs+1)+1;
                v_jbgs:=v_jbgs+1;

             end loop;
             Result:=substr(Result,1,length(Result)-1);
          end if;
          return (Result);
end if;




 if length(trim(v_tempstr))=0 then

    Result:='?';

  end if;

  /*for rec in cur_rec loop
     Result:=Result||rec.jbmc||',';
  end loop;*/
  Result:=substr(Result,1,length(trim(Result))-1);
--dbms_output.put_line(Result);
return(Result);

END SF_P1_GET_STRJBMC;

/
