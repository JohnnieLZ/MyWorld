CREATE TRIGGER TR_RB_HOSPITAL
BEFORE INSERT OR UPDATE OR DELETE
  ON HOSPITAL
FOR EACH ROW
  declare
  op_type   number;
  pk_values HISTORY_UTIL.ant_type_table;
  c_values  HISTORY_UTIL.ant_type_table;
  seqid     number;
  action    number;
  rec_SYNCDATA TB_YFZFB_SYNCDATA%rowtype;
  v_ret_code varchar2(10) := 'E';
  v_ret_MSG  varchar2(10) := 'ERROR';
begin
 HISTORY_UTIL.get_sequence(seqid, action);
  /*
  if action = HISTORY_UTIL.ACTION_ROLLBACK then
    return;
  end if;*/
  if inserting then
    op_type := HISTORY_UTIL.OPTYPE_INSERT;
    pk_values(pk_values.count + 1) := any_type('YYID',
                                               'number',
                                               null,
                                               :new.YYID,
                                               null);
    :new.SEQLOGID := seqid;
  elsif updating then
    op_type := HISTORY_UTIL.OPTYPE_UPDATE;
    pk_values(pk_values.count + 1) := any_type('YYID',
                                               'number',
                                               null,
                                               :old.YYID,
                                               null);
    :new.SEQLOGID := seqid;
    if history_util.bool_xor(:new.SEQLOGID is null, :old.SEQLOGID is null) or
       :new.SEQLOGID != :old.SEQLOGID then
      c_values(c_values.count + 1) := any_type('SEQLOGID',
                                               'number',
                                               null,
                                               :old.SEQLOGID,
                                               null);
    end if;
    if history_util.bool_xor(:new.YYDM is null, :old.YYDM is null) or
       :new.YYDM != :old.YYDM then
      c_values(c_values.count + 1) := any_type('YYDM',
                                               'string',
                                               :old.YYDM,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.YYMC is null, :old.YYMC is null) or
       :new.YYMC != :old.YYMC then
      c_values(c_values.count + 1) := any_type('YYMC',
                                               'string',
                                               :old.YYMC,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.BXGSID is null, :old.BXGSID is null) or
       :new.BXGSID != :old.BXGSID then
      c_values(c_values.count + 1) := any_type('BXGSID',
                                               'number',
                                               null,
                                               :old.BXGSID,
                                               null);
    end if;
    insert into H_HOSPITAL
      (YYID, SEQLOGID, YYDM, YYMC, BXGSID, NEW_SEQLOGID)
    values
      (:old.YYID, :old.SEQLOGID, :old.YYDM, :old.YYMC, :old.BXGSID, seqid);
  else
    op_type := HISTORY_UTIL.OPTYPE_DELETE;
    pk_values(pk_values.count + 1) := any_type('YYID',
                                               'number',
                                               null,
                                               :old.YYID,
                                               null);
    c_values(c_values.count + 1) := any_type('SEQLOGID',
                                             'number',
                                             null,
                                             :old.SEQLOGID,
                                             null);
    c_values(c_values.count + 1) := any_type('YYDM',
                                             'string',
                                             :old.YYDM,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('YYMC',
                                             'string',
                                             :old.YYMC,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('BXGSID',
                                             'number',
                                             null,
                                             :old.BXGSID,
                                             null);
    insert into H_HOSPITAL
      (YYID, SEQLOGID, YYDM, YYMC, BXGSID, NEW_SEQLOGID)
    values
      (:old.YYID, :old.SEQLOGID, :old.YYDM, :old.YYMC, :old.BXGSID, seqid);
  end if;
  HISTORY_UTIL.to_history(op_type, 'HOSPITAL', pk_values, c_values, 1);
     select case
           when op_type = '1' then
            'A'
           when op_type = '2' then
            'U'
           else
            'D'
         end,
         SEQ_OPTID.Nextval,
         sysdate,
         '1' as Opt_Object,
         'A' as sys_type
    into rec_SYNCDATA.Op_Type,
         rec_SYNCDATA.Opt_Id,
         rec_SYNCDATA.Opt_Datetime,
         rec_SYNCDATA.Opt_Object,
         rec_SYNCDATA.Sys_Type
    from dual;
  rec_SYNCDATA.content := '{';
  if rec_SYNCDATA.Op_Type in ('A', 'U') then
    rec_SYNCDATA.Object_Id := :new.yyid;
    rec_SYNCDATA.content   := rec_SYNCDATA.content || '"yyid":"' ||
                              to_char(:New.yyid) || '","yymc":"' ||
                              to_char(:New.yymc) || '","bxgsid":"' ||
                              to_char(:New.bxgsid);
    rec_SYNCDATA.content   := rec_SYNCDATA.content || '","yydm":"' ||
                              to_char(:New.yydm) || '","seqlogid":"' ||
                              to_char(:New.seqlogid) || '"';
  else
    rec_SYNCDATA.content := rec_SYNCDATA.content || '"yyid":"' ||
                            to_char(:New.yyid) || '"';
  end if;
  rec_SYNCDATA.content := rec_SYNCDATA.content || '}';
  SP_GEN_SYNCDATA(v_ret_code, v_ret_MSG, rec_SYNCDATA); --调用共用的中间表生成程序
end;
/
