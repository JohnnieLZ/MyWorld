CREATE TRIGGER TR_RB_TB_LPAJXX
BEFORE INSERT OR UPDATE OR DELETE
  ON TB_LPAJXX
FOR EACH ROW
  declare
  op_type   number;
  pk_values HISTORY_UTIL.ant_type_table;
  c_values  HISTORY_UTIL.ant_type_table;
  seqid     number;
  action    number;
begin
  HISTORY_UTIL.get_sequence(seqid, action);
  if action = HISTORY_UTIL.ACTION_ROLLBACK then
    return;
  end if;
  if inserting then
    op_type := HISTORY_UTIL.OPTYPE_INSERT;
    pk_values(pk_values.count + 1) := any_type('AJID',
                                               'number',
                                               null,
                                               :new.AJID,
                                               null);
    :new.SEQLOGID := seqid;
  Elsif updating then
    op_type := HISTORY_UTIL.OPTYPE_UPDATE;
    pk_values(pk_values.count + 1) := any_type('AJID',
                                               'number',
                                               null,
                                               :old.AJID,
                                               null);
    if history_util.bool_xor(:new.WBPAZH is null, :old.WBPAZH is null) or
       :new.WBPAZH != :old.WBPAZH then
      c_values(c_values.count + 1) := any_type('WBPAZH',
                                               'string',
                                               :old.WBPAZH,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.WBPAFH is null, :old.WBPAFH is null) or
       :new.WBPAFH != :old.WBPAFH then
      c_values(c_values.count + 1) := any_type('WBPAFH',
                                               'string',
                                               :old.WBPAFH,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.SFWB is null, :old.SFWB is null) or
       :new.SFWB != :old.SFWB then
      c_values(c_values.count + 1) := any_type('SFWB',
                                               'string',
                                               :old.SFWB,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.SFBLC is null, :old.SFBLC is null) or
       :new.SFBLC != :old.SFBLC then
      c_values(c_values.count + 1) := any_type('SFBLC',
                                               'string',
                                               :old.SFBLC,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.WBDCRQ is null, :old.WBDCRQ is null) or
       :new.WBDCRQ != :old.WBDCRQ then
      c_values(c_values.count + 1) := any_type('WBDCRQ',
                                               'number',
                                               null,
                                               :old.WBDCRQ,
                                               null);
    end if;
    if history_util.bool_xor(:new.WBDRRQ is null, :old.WBDRRQ is null) or
       :new.WBDRRQ != :old.WBDRRQ then
      c_values(c_values.count + 1) := any_type('WBDRRQ',
                                               'number',
                                               null,
                                               :old.WBDRRQ,
                                               null);
    end if;
    if history_util.bool_xor(:new.WBLYCC is null, :old.WBLYCC is null) or
       :new.WBLYCC != :old.WBLYCC then
      c_values(c_values.count + 1) := any_type('WBLYCC',
                                               'string',
                                               :old.WBLYCC,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.WBFPR is null, :old.WBFPR is null) or
       :new.WBFPR != :old.WBFPR then
      c_values(c_values.count + 1) := any_type('WBFPR',
                                               'string',
                                               :old.WBFPR,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.FPSJ is null, :old.FPSJ is null) or
       :new.FPSJ != :old.FPSJ then
      c_values(c_values.count + 1) := any_type('FPSJ',
                                               'date',
                                               null,
                                               null,
                                               :old.FPSJ);
    end if;
    if history_util.bool_xor(:new.WBGSID is null, :old.WBGSID is null) or
       :new.WBGSID != :old.WBGSID then
      c_values(c_values.count + 1) := any_type('WBGSID',
                                               'number',
                                               null,
                                               :old.WBGSID,
                                               null);
    end if;
    if history_util.bool_xor(:new.WBGSMC is null, :old.WBGSMC is null) or
       :new.WBGSMC != :old.WBGSMC then
      c_values(c_values.count + 1) := any_type('WBGSMC',
                                               'string',
                                               :old.WBGSMC,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.SCZPASJ is null, :old.SCZPASJ is null) or
       :new.SCZPASJ != :old.SCZPASJ then
      c_values(c_values.count + 1) := any_type('SCZPASJ',
                                               'date',
                                               null,
                                               null,
                                               :old.SCZPASJ);
    end if;
    if history_util.bool_xor(:new.LSSJ is null, :old.LSSJ is null) or
       :new.LSSJ != :old.LSSJ then
      c_values(c_values.count + 1) := any_type('LSSJ',
                                               'date',
                                               null,
                                               null,
                                               :old.LSSJ);
    end if;
    if history_util.bool_xor(:new.SLRID is null, :old.SLRID is null) or
       :new.SLRID != :old.SLRID then
      c_values(c_values.count + 1) := any_type('SLRID',
                                               'number',
                                               null,
                                               :old.SLRID,
                                               null);
    end if;
    if history_util.bool_xor(:new.SLR is null, :old.SLR is null) or
       :new.SLR != :old.SLR then
      c_values(c_values.count + 1) := any_type('SLR',
                                               'string',
                                               :old.SLR,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.LRRID is null, :old.LRRID is null) or
       :new.LRRID != :old.LRRID then
      c_values(c_values.count + 1) := any_type('LRRID',
                                               'number',
                                               null,
                                               :old.LRRID,
                                               null);
    end if;
    if history_util.bool_xor(:new.LRR is null, :old.LRR is null) or
       :new.LRR != :old.LRR then
      c_values(c_values.count + 1) := any_type('LRR',
                                               'string',
                                               :old.LRR,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.SHRID is null, :old.SHRID is null) or
       :new.SHRID != :old.SHRID then
      c_values(c_values.count + 1) := any_type('SHRID',
                                               'number',
                                               null,
                                               :old.SHRID,
                                               null);
    end if;
    if history_util.bool_xor(:new.SHR is null, :old.SHR is null) or
       :new.SHR != :old.SHR then
      c_values(c_values.count + 1) := any_type('SHR',
                                               'string',
                                               :old.SHR,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.ZJRID is null, :old.ZJRID is null) or
       :new.ZJRID != :old.ZJRID then
      c_values(c_values.count + 1) := any_type('ZJRID',
                                               'number',
                                               null,
                                               :old.ZJRID,
                                               null);
    end if;
    if history_util.bool_xor(:new.ZJR is null, :old.ZJR is null) or
       :new.ZJR != :old.ZJR then
      c_values(c_values.count + 1) := any_type('ZJR',
                                               'string',
                                               :old.ZJR,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.ZJSJ is null, :old.ZJSJ is null) or
       :new.ZJSJ != :old.ZJSJ then
      c_values(c_values.count + 1) := any_type('ZJSJ',
                                               'date',
                                               null,
                                               null,
                                               :old.ZJSJ);
    end if;
    if history_util.bool_xor(:new.ZJJL is null, :old.ZJJL is null) or
       :new.ZJJL != :old.ZJJL then
      c_values(c_values.count + 1) := any_type('ZJJL',
                                               'string',
                                               :old.ZJJL,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.ZJYJMS is null, :old.ZJYJMS is null) or
       :new.ZJYJMS != :old.ZJYJMS then
      c_values(c_values.count + 1) := any_type('ZJYJMS',
                                               'string',
                                               :old.ZJYJMS,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.SSYLY is null, :old.SSYLY is null) or
       :new.SSYLY != :old.SSYLY then
      c_values(c_values.count + 1) := any_type('SSYLY',
                                               'string',
                                               :old.SSYLY,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.KHSYR is null, :old.KHSYR is null) or
       :new.KHSYR != :old.KHSYR then
      c_values(c_values.count + 1) := any_type('KHSYR',
                                               'string',
                                               :old.KHSYR,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.SYJL is null, :old.SYJL is null) or
       :new.SYJL != :old.SYJL then
      c_values(c_values.count + 1) := any_type('SYJL',
                                               'string',
                                               :old.SYJL,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.SYRQ is null, :old.SYRQ is null) or
       :new.SYRQ != :old.SYRQ then
      c_values(c_values.count + 1) := any_type('SYRQ',
                                               'date',
                                               null,
                                               null,
                                               :old.SYRQ);
    end if;
    if history_util.bool_xor(:new.SYYJMS is null, :old.SYYJMS is null) or
       :new.SYYJMS != :old.SYYJMS then
      c_values(c_values.count + 1) := any_type('SYYJMS',
                                               'string',
                                               :old.SYYJMS,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.BXCSSCZPABZ is null,
                             :old.BXCSSCZPABZ is null) or
       :new.BXCSSCZPABZ != :old.BXCSSCZPABZ then
      c_values(c_values.count + 1) := any_type('BXCSSCZPABZ',
                                               'string',
                                               :old.BXCSSCZPABZ,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.DYSJSCBZ is null, :old.DYSJSCBZ is null) or
       :new.DYSJSCBZ != :old.DYSJSCBZ then
      c_values(c_values.count + 1) := any_type('DYSJSCBZ',
                                               'string',
                                               :old.DYSJSCBZ,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.DYSJSCSJ is null, :old.DYSJSCSJ is null) or
       :new.DYSJSCSJ != :old.DYSJSCSJ then
      c_values(c_values.count + 1) := any_type('DYSJSCSJ',
                                               'date',
                                               null,
                                               null,
                                               :old.DYSJSCSJ);
    end if;
    if history_util.bool_xor(:new.LPKGFKHH is null, :old.LPKGFKHH is null) or
       :new.LPKGFKHH != :old.LPKGFKHH then
      c_values(c_values.count + 1) := any_type('LPKGFKHH',
                                               'string',
                                               :old.LPKGFKHH,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.LPKGFYHZH is null, :old.LPKGFYHZH is null) or
       :new.LPKGFYHZH != :old.LPKGFYHZH then
      c_values(c_values.count + 1) := any_type('LPKGFYHZH',
                                               'string',
                                               :old.LPKGFYHZH,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.SKFXM is null, :old.SKFXM is null) or
       :new.SKFXM != :old.SKFXM then
      c_values(c_values.count + 1) := any_type('SKFXM',
                                               'string',
                                               :old.SKFXM,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.TQRQ is null, :old.TQRQ is null) or
       :new.TQRQ != :old.TQRQ then
      c_values(c_values.count + 1) := any_type('TQRQ',
                                               'date',
                                               null,
                                               null,
                                               :old.TQRQ);
    end if;
    if history_util.bool_xor(:new.QCLSM is null, :old.QCLSM is null) or
       :new.QCLSM != :old.QCLSM then
      c_values(c_values.count + 1) := any_type('QCLSM',
                                               'string',
                                               :old.QCLSM,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.SFRQ is null, :old.SFRQ is null) or
       :new.SFRQ != :old.SFRQ then
      c_values(c_values.count + 1) := any_type('SFRQ',
                                               'number',
                                               null,
                                               :old.SFRQ,
                                               null);
    end if;
    :new.SEQLOGID := seqid;
    if history_util.bool_xor(:new.SEQLOGID is null, :old.SEQLOGID is null) or
       :new.SEQLOGID != :old.SEQLOGID then
      c_values(c_values.count + 1) := any_type('SEQLOGID',
                                               'number',
                                               null,
                                               :old.SEQLOGID,
                                               null);
    end if;
    if history_util.bool_xor(:new.DYBZ is null, :old.DYBZ is null) or
       :new.DYBZ != :old.DYBZ then
      c_values(c_values.count + 1) := any_type('DYBZ',
                                               'string',
                                               :old.DYBZ,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.DYR is null, :old.DYR is null) or
       :new.DYR != :old.DYR then
      c_values(c_values.count + 1) := any_type('DYR',
                                               'string',
                                               :old.DYR,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.DYRQ is null, :old.DYRQ is null) or
       :new.DYRQ != :old.DYRQ then
      c_values(c_values.count + 1) := any_type('DYRQ',
                                               'number',
                                               null,
                                               :old.DYRQ,
                                               null);
    end if;
    if history_util.bool_xor(:new.BDYRQ is null, :old.BDYRQ is null) or
       :new.BDYRQ != :old.BDYRQ then
      c_values(c_values.count + 1) := any_type('BDYRQ',
                                               'number',
                                               null,
                                               :old.BDYRQ,
                                               null);
    end if;
    if history_util.bool_xor(:new.BDYR is null, :old.BDYR is null) or
       :new.BDYR != :old.BDYR then
      c_values(c_values.count + 1) := any_type('BDYR',
                                               'string',
                                               :old.BDYR,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.FPS is null, :old.FPS is null) or
       :new.FPS != :old.FPS then
      c_values(c_values.count + 1) := any_type('FPS',
                                               'number',
                                               null,
                                               :old.FPS,
                                               null);
    end if;
    if history_util.bool_xor(:new.SFJJAJ is null, :old.SFJJAJ is null) or
       :new.SFJJAJ != :old.SFJJAJ then
      c_values(c_values.count + 1) := any_type('SFJJAJ',
                                               'string',
                                               :old.SFJJAJ,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.CSRID is null, :old.CSRID is null) or
       :new.CSRID != :old.CSRID then
      c_values(c_values.count + 1) := any_type('CSRID',
                                               'number',
                                               null,
                                               :old.CSRID,
                                               null);
    end if;
    if history_util.bool_xor(:new.CSR is null, :old.CSR is null) or
       :new.CSR != :old.CSR then
      c_values(c_values.count + 1) := any_type('CSR',
                                               'string',
                                               :old.CSR,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.CSJG is null, :old.CSJG is null) or
       :new.CSJG != :old.CSJG then
      c_values(c_values.count + 1) := any_type('CSJG',
                                               'string',
                                               :old.CSJG,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.CSCWDM is null, :old.CSCWDM is null) or
       :new.CSCWDM != :old.CSCWDM then
      c_values(c_values.count + 1) := any_type('CSCWDM',
                                               'string',
                                               :old.CSCWDM,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.CSCWMS is null, :old.CSCWMS is null) or
       :new.CSCWMS != :old.CSCWMS then
      c_values(c_values.count + 1) := any_type('CSCWMS',
                                               'string',
                                               :old.CSCWMS,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.FSRID is null, :old.FSRID is null) or
       :new.FSRID != :old.FSRID then
      c_values(c_values.count + 1) := any_type('FSRID',
                                               'number',
                                               null,
                                               :old.FSRID,
                                               null);
    end if;
    if history_util.bool_xor(:new.FSR is null, :old.FSR is null) or
       :new.FSR != :old.FSR then
      c_values(c_values.count + 1) := any_type('FSR',
                                               'string',
                                               :old.FSR,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.FSJG is null, :old.FSJG is null) or
       :new.FSJG != :old.FSJG then
      c_values(c_values.count + 1) := any_type('FSJG',
                                               'string',
                                               :old.FSJG,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.FSCWDM is null, :old.FSCWDM is null) or
       :new.FSCWDM != :old.FSCWDM then
      c_values(c_values.count + 1) := any_type('FSCWDM',
                                               'string',
                                               :old.FSCWDM,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.FSCWMS is null, :old.FSCWMS is null) or
       :new.FSCWMS != :old.FSCWMS then
      c_values(c_values.count + 1) := any_type('FSCWMS',
                                               'string',
                                               :old.FSCWMS,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.AJSFSD is null, :old.AJSFSD is null) or
       :new.AJSFSD != :old.AJSFSD then
      c_values(c_values.count + 1) := any_type('AJSFSD',
                                               'string',
                                               :old.AJSFSD,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.SDKSSJ is null, :old.SDKSSJ is null) or
       :new.SDKSSJ != :old.SDKSSJ then
      c_values(c_values.count + 1) := any_type('SDKSSJ',
                                               'date',
                                               null,
                                               null,
                                               :old.SDKSSJ);
    end if;
    if history_util.bool_xor(:new.DQCZR is null, :old.DQCZR is null) or
       :new.DQCZR != :old.DQCZR then
      c_values(c_values.count + 1) := any_type('DQCZR',
                                               'string',
                                               :old.DQCZR,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.ZBBRGX is null, :old.ZBBRGX is null) or
       :new.ZBBRGX != :old.ZBBRGX then
      c_values(c_values.count + 1) := any_type('ZBBRGX',
                                               'string',
                                               :old.ZBBRGX,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.SFGS is null, :old.SFGS is null) or
       :new.SFGS != :old.SFGS then
      c_values(c_values.count + 1) := any_type('SFGS',
                                               'string',
                                               :old.SFGS,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.YWSGDD is null, :old.YWSGDD is null) or
       :new.YWSGDD != :old.YWSGDD then
      c_values(c_values.count + 1) := any_type('YWSGDD',
                                               'string',
                                               :old.YWSGDD,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.YWSGYY is null, :old.YWSGYY is null) or
       :new.YWSGYY != :old.YWSGYY then
      c_values(c_values.count + 1) := any_type('YWSGYY',
                                               'string',
                                               :old.YWSGYY,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.SSWBYY is null, :old.SSWBYY is null) or
       :new.SSWBYY != :old.SSWBYY then
      c_values(c_values.count + 1) := any_type('SSWBYY',
                                               'string',
                                               :old.SSWBYY,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.HCCGBZ is null, :old.HCCGBZ is null) or
       :new.HCCGBZ != :old.HCCGBZ then
      c_values(c_values.count + 1) := any_type('HCCGBZ',
                                               'string',
                                               :old.HCCGBZ,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.HCCLRQ is null, :old.HCCLRQ is null) or
       :new.HCCLRQ != :old.HCCLRQ then
      c_values(c_values.count + 1) := any_type('HCCLRQ',
                                               'number',
                                               null,
                                               :old.HCCLRQ,
                                               null);
    end if;
    if history_util.bool_xor(:new.HCCLR is null, :old.HCCLR is null) or
       :new.HCCLR != :old.HCCLR then
      c_values(c_values.count + 1) := any_type('HCCLR',
                                               'string',
                                               :old.HCCLR,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.LPPCID is null, :old.LPPCID is null) or
       :new.LPPCID != :old.LPPCID then
      c_values(c_values.count + 1) := any_type('LPPCID',
                                               'number',
                                               null,
                                               :old.LPPCID,
                                               null);
    end if;
    if history_util.bool_xor(:new.PAH is null, :old.PAH is null) or
       :new.PAH != :old.PAH then
      c_values(c_values.count + 1) := any_type('PAH',
                                               'string',
                                               :old.PAH,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.BXGSID is null, :old.BXGSID is null) or
       :new.BXGSID != :old.BXGSID then
      c_values(c_values.count + 1) := any_type('BXGSID',
                                               'number',
                                               null,
                                               :old.BXGSID,
                                               null);
    end if;
    if history_util.bool_xor(:new.TTID is null, :old.TTID is null) or
       :new.TTID != :old.TTID then
      c_values(c_values.count + 1) := any_type('TTID',
                                               'number',
                                               null,
                                               :old.TTID,
                                               null);
    end if;
    if history_util.bool_xor(:new.ZTTID is null, :old.ZTTID is null) or
       :new.ZTTID != :old.ZTTID then
      c_values(c_values.count + 1) := any_type('ZTTID',
                                               'number',
                                               null,
                                               :old.ZTTID,
                                               null);
    end if;
    if history_util.bool_xor(:new.ZTTMC is null, :old.ZTTMC is null) or
       :new.ZTTMC != :old.ZTTMC then
      c_values(c_values.count + 1) := any_type('ZTTMC',
                                               'string',
                                               :old.ZTTMC,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.GJAJBZ is null, :old.GJAJBZ is null) or
       :new.GJAJBZ != :old.GJAJBZ then
      c_values(c_values.count + 1) := any_type('GJAJBZ',
                                               'string',
                                               :old.GJAJBZ,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.GLAJH is null, :old.GLAJH is null) or
       :new.GLAJH != :old.GLAJH then
      c_values(c_values.count + 1) := any_type('GLAJH',
                                               'string',
                                               :old.GLAJH,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.BBRXM is null, :old.BBRXM is null) or
       :new.BBRXM != :old.BBRXM then
      c_values(c_values.count + 1) := any_type('BBRXM',
                                               'string',
                                               :old.BBRXM,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.BBRKHID is null, :old.BBRKHID is null) or
       :new.BBRKHID != :old.BBRKHID then
      c_values(c_values.count + 1) := any_type('BBRKHID',
                                               'number',
                                               null,
                                               :old.BBRKHID,
                                               null);
    end if;
    if history_util.bool_xor(:new.BBRZJH is null, :old.BBRZJH is null) or
       :new.BBRZJH != :old.BBRZJH then
      c_values(c_values.count + 1) := any_type('BBRZJH',
                                               'string',
                                               :old.BBRZJH,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.ZLDBZ is null, :old.ZLDBZ is null) or
       :new.ZLDBZ != :old.ZLDBZ then
      c_values(c_values.count + 1) := any_type('ZLDBZ',
                                               'string',
                                               :old.ZLDBZ,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.ZBBRKHID is null, :old.ZBBRKHID is null) or
       :new.ZBBRKHID != :old.ZBBRKHID then
      c_values(c_values.count + 1) := any_type('ZBBRKHID',
                                               'number',
                                               null,
                                               :old.ZBBRKHID,
                                               null);
    end if;
    if history_util.bool_xor(:new.KHBDH is null, :old.KHBDH is null) or
       :new.KHBDH != :old.KHBDH then
      c_values(c_values.count + 1) := any_type('KHBDH',
                                               'string',
                                               :old.KHBDH,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.FDID is null, :old.FDID is null) or
       :new.FDID != :old.FDID then
      c_values(c_values.count + 1) := any_type('FDID',
                                               'number',
                                               null,
                                               :old.FDID,
                                               null);
    end if;
    if history_util.bool_xor(:new.SQRZJLX is null, :old.SQRZJLX is null) or
       :new.SQRZJLX != :old.SQRZJLX then
      c_values(c_values.count + 1) := any_type('SQRZJLX',
                                               'string',
                                               :old.SQRZJLX,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.SQRZJHM is null, :old.SQRZJHM is null) or
       :new.SQRZJHM != :old.SQRZJHM then
      c_values(c_values.count + 1) := any_type('SQRZJHM',
                                               'string',
                                               :old.SQRZJHM,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.SQRXM is null, :old.SQRXM is null) or
       :new.SQRXM != :old.SQRXM then
      c_values(c_values.count + 1) := any_type('SQRXM',
                                               'string',
                                               :old.SQRXM,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.SQRSJ is null, :old.SQRSJ is null) or
       :new.SQRSJ != :old.SQRSJ then
      c_values(c_values.count + 1) := any_type('SQRSJ',
                                               'string',
                                               :old.SQRSJ,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.SQRDZ is null, :old.SQRDZ is null) or
       :new.SQRDZ != :old.SQRDZ then
      c_values(c_values.count + 1) := any_type('SQRDZ',
                                               'string',
                                               :old.SQRDZ,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.SQRYX is null, :old.SQRYX is null) or
       :new.SQRYX != :old.SQRYX then
      c_values(c_values.count + 1) := any_type('SQRYX',
                                               'string',
                                               :old.SQRYX,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.SQLX is null, :old.SQLX is null) or
       :new.SQLX != :old.SQLX then
      c_values(c_values.count + 1) := any_type('SQLX',
                                               'string',
                                               :old.SQLX,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.SQRQ is null, :old.SQRQ is null) or
       :new.SQRQ != :old.SQRQ then
      c_values(c_values.count + 1) := any_type('SQRQ',
                                               'number',
                                               null,
                                               :old.SQRQ,
                                               null);
    end if;
    if history_util.bool_xor(:new.BBRSCZT is null, :old.BBRSCZT is null) or
       :new.BBRSCZT != :old.BBRSCZT then
      c_values(c_values.count + 1) := any_type('BBRSCZT',
                                               'string',
                                               :old.BBRSCZT,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.BBRCJDM is null, :old.BBRCJDM is null) or
       :new.BBRCJDM != :old.BBRCJDM then
      c_values(c_values.count + 1) := any_type('BBRCJDM',
                                               'string',
                                               :old.BBRCJDM,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.BBRCJXM is null, :old.BBRCJXM is null) or
       :new.BBRCJXM != :old.BBRCJXM then
      c_values(c_values.count + 1) := any_type('BBRCJXM',
                                               'string',
                                               :old.BBRCJXM,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.BBRCJDJ is null, :old.BBRCJDJ is null) or
       :new.BBRCJDJ != :old.BBRCJDJ then
      c_values(c_values.count + 1) := any_type('BBRCJDJ',
                                               'string',
                                               :old.BBRCJDJ,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.BBRSWRQ is null, :old.BBRSWRQ is null) or
       :new.BBRSWRQ != :old.BBRSWRQ then
      c_values(c_values.count + 1) := any_type('BBRSWRQ',
                                               'number',
                                               null,
                                               :old.BBRSWRQ,
                                               null);
    end if;
    if history_util.bool_xor(:new.BBRYWSGFSRQ is null,
                             :old.BBRYWSGFSRQ is null) or
       :new.BBRYWSGFSRQ != :old.BBRYWSGFSRQ then
      c_values(c_values.count + 1) := any_type('BBRYWSGFSRQ',
                                               'number',
                                               null,
                                               :old.BBRYWSGFSRQ,
                                               null);
    end if;
    if history_util.bool_xor(:new.JBID is null, :old.JBID is null) or
       :new.JBID != :old.JBID then
      c_values(c_values.count + 1) := any_type('JBID',
                                               'number',
                                               null,
                                               :old.JBID,
                                               null);
    end if;
    if history_util.bool_xor(:new.ZJDM is null, :old.ZJDM is null) or
       :new.ZJDM != :old.ZJDM then
      c_values(c_values.count + 1) := any_type('ZJDM',
                                               'string',
                                               :old.ZJDM,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.ZJQZR is null, :old.ZJQZR is null) or
       :new.ZJQZR != :old.ZJQZR then
      c_values(c_values.count + 1) := any_type('ZJQZR',
                                               'number',
                                               null,
                                               :old.ZJQZR,
                                               null);
    end if;
    if history_util.bool_xor(:new.AJZT is null, :old.AJZT is null) or
       :new.AJZT != :old.AJZT then
      c_values(c_values.count + 1) := any_type('AJZT',
                                               'string',
                                               :old.AJZT,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.ZHCLRQ is null, :old.ZHCLRQ is null) or
       :new.ZHCLRQ != :old.ZHCLRQ then
      c_values(c_values.count + 1) := any_type('ZHCLRQ',
                                               'date',
                                               null,
                                               null,
                                               :old.ZHCLRQ);
    end if;
    if history_util.bool_xor(:new.AJXGDM is null, :old.AJXGDM is null) or
       :new.AJXGDM != :old.AJXGDM then
      c_values(c_values.count + 1) := any_type('AJXGDM',
                                               'string',
                                               :old.AJXGDM,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.AJXGLY is null, :old.AJXGLY is null) or
       :new.AJXGLY != :old.AJXGLY then
      c_values(c_values.count + 1) := any_type('AJXGLY',
                                               'string',
                                               :old.AJXGLY,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.XGRQ is null, :old.XGRQ is null) or
       :new.XGRQ != :old.XGRQ then
      c_values(c_values.count + 1) := any_type('XGRQ',
                                               'string',
                                               :old.XGRQ,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.JARQ is null, :old.JARQ is null) or
       :new.JARQ != :old.JARQ then
      c_values(c_values.count + 1) := any_type('JARQ',
                                               'number',
                                               null,
                                               :old.JARQ,
                                               null);
    end if;
    if history_util.bool_xor(:new.AJJL is null, :old.AJJL is null) or
       :new.AJJL != :old.AJJL then
      c_values(c_values.count + 1) := any_type('AJJL',
                                               'string',
                                               :old.AJJL,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.AJJLSM1 is null, :old.AJJLSM1 is null) or
       :new.AJJLSM1 != :old.AJJLSM1 then
      c_values(c_values.count + 1) := any_type('AJJLSM1',
                                               'string',
                                               :old.AJJLSM1,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.AJJLSM is null, :old.AJJLSM is null) or
       :new.AJJLSM != :old.AJJLSM then
      c_values(c_values.count + 1) := any_type('AJJLSM',
                                               'string',
                                               :old.AJJLSM,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.JBR is null, :old.JBR is null) or
       :new.JBR != :old.JBR then
      c_values(c_values.count + 1) := any_type('JBR',
                                               'string',
                                               :old.JBR,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.AJPFJE is null, :old.AJPFJE is null) or
       :new.AJPFJE != :old.AJPFJE then
      c_values(c_values.count + 1) := any_type('AJPFJE',
                                               'number',
                                               null,
                                               :old.AJPFJE,
                                               null);
    end if;
    if history_util.bool_xor(:new.LPJSYR is null, :old.LPJSYR is null) or
       :new.LPJSYR != :old.LPJSYR then
      c_values(c_values.count + 1) := any_type('LPJSYR',
                                               'string',
                                               :old.LPJSYR,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.AJPFFS is null, :old.AJPFFS is null) or
       :new.AJPFFS != :old.AJPFFS then
      c_values(c_values.count + 1) := any_type('AJPFFS',
                                               'string',
                                               :old.AJPFFS,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.SFXNAJ is null, :old.SFXNAJ is null) or
       :new.SFXNAJ != :old.SFXNAJ then
      c_values(c_values.count + 1) := any_type('SFXNAJ',
                                               'string',
                                               :old.SFXNAJ,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.SFZDSCZPA is null, :old.SFZDSCZPA is null) or
       :new.SFZDSCZPA != :old.SFZDSCZPA then
      c_values(c_values.count + 1) := any_type('SFZDSCZPA',
                                               'string',
                                               :old.SFZDSCZPA,
                                               null,
                                               null);
    end if;
    --保存历史表
    insert into h_tb_lpajxx ( 
            AJID         ,--NUMBER(16)                              
            LPPCID       ,--NUMBER(16)                              
            PAH          ,--VARCHAR2(30)  Y                         
            BXGSID       ,--NUMBER(16)                              
            TTID         ,--NUMBER(16)                              
            ZTTID        ,--NUMBER(16)    Y                         
            ZTTMC        ,--VARCHAR2(200) Y                         
            GJAJBZ       ,--VARCHAR2(1)   Y                         
            GLAJH        ,--VARCHAR2(30)  Y                         
            BBRXM        ,--VARCHAR2(30)  Y                         
            BBRKHID      ,--NUMBER(16)    Y                         
            BBRZJH       ,--VARCHAR2(20)  Y                         
            ZLDBZ        ,--VARCHAR2(1)   Y                         
            ZBBRKHID     ,--NUMBER(16)    Y                         
            KHBDH        ,--VARCHAR2(30)  Y                         
            FDID         ,--NUMBER(16)    Y                         
            SQRZJLX      ,--VARCHAR2(2)   Y                         
            SQRZJHM      ,--VARCHAR2(20)  Y                         
            SQRXM        ,--VARCHAR2(30)  Y                         
            SQRSJ        ,--VARCHAR2(30)  Y                         
            SQRDZ        ,--VARCHAR2(200) Y                         
            SQRYX        ,--VARCHAR2(200) Y                         
            SQLX         ,--VARCHAR2(66)  Y                         
            SQRQ         ,--NUMBER(8)     Y                         
            BBRSCZT      ,--VARCHAR2(1)   Y                         
            BBRCJDM      ,--VARCHAR2(10)  Y                         
            BBRCJXM      ,--VARCHAR2(500) Y                         
            BBRCJDJ      ,--VARCHAR2(10)  Y                         
            BBRSWRQ      ,--NUMBER(8)     Y                         
            BBRYWSGFSRQ  ,--NUMBER(8)     Y                         
            JBID         ,--NUMBER(16)    Y                         
            ZJDM         ,--VARCHAR2(20)  Y                         
            ZJQZR        ,--NUMBER(8)     Y                         
            AJZT         ,--VARCHAR2(2)   Y                         
            ZHCLRQ       ,--DATE          Y                         
            AJXGDM       ,--VARCHAR2(80)  Y                         
            AJXGLY       ,--VARCHAR2(300) Y                         
            XGRQ         ,--VARCHAR2(30)  Y                         
            JARQ         ,--NUMBER(8)     Y                         
            AJJL         ,--VARCHAR2(2)   Y                         
            AJJLSM1      ,--VARCHAR2(10)  Y                         
            AJJLSM       ,--VARCHAR2(200) Y                         
            JBR          ,--VARCHAR2(30)  Y                         
            AJPFJE       ,--NUMBER(16,2)  Y                         
            LPJSYR       ,--VARCHAR2(30)  Y                         
            AJPFFS       ,--VARCHAR2(1)   Y                         
            SFXNAJ       ,--VARCHAR2(1)                             
            SFZDSCZPA    ,--VARCHAR2(1)   Y                         
            SCZPASJ      ,--DATE          Y                         
            LSSJ         ,--DATE          Y                         
            SLRID        ,--NUMBER(19)    Y                         
            SLR          ,--VARCHAR2(50)  Y                         
            LRRID        ,--NUMBER(19)    Y                         
            LRR          ,--VARCHAR2(50)  Y                         
            SHRID        ,--NUMBER(19)    Y                         
            SHR          ,--VARCHAR2(50)  Y                         
            ZJRID        ,--NUMBER(19)    Y                         
            ZJR          ,--VARCHAR2(50)  Y                         
            ZJSJ         ,--DATE          Y                         
            ZJJL         ,--VARCHAR2(1)   Y                         
            ZJYJMS       ,--VARCHAR2(200) Y                         
            SSYLY        ,--VARCHAR2(200) Y                         
            KHSYR        ,--VARCHAR2(50)  Y                         
            SYJL         ,--VARCHAR2(1)   Y                         
            SYRQ         ,--DATE          Y                         
            SYYJMS       ,--VARCHAR2(200) Y                         
            BXCSSCZPABZ  ,--VARCHAR2(1)   Y                         
            DYSJSCBZ     ,--VARCHAR2(1)   Y                         
            DYSJSCSJ     ,--DATE          Y                         
            LPKGFKHH     ,--VARCHAR2(50)  Y                         
            LPKGFYHZH    ,--VARCHAR2(35)  Y                         
            SKFXM        ,--VARCHAR2(50)  Y                         
            TQRQ         ,--DATE          Y                         
            QCLSM        ,--VARCHAR2(300) Y                         
            SFRQ         ,--NUMBER(8)     Y                         
            SEQLOGID     ,--NUMBER        Y                         
            DYBZ         ,--VARCHAR2(1)   Y                         
            DYR          ,--VARCHAR2(50)  Y                         
            DYRQ         ,--NUMBER(8)     Y                         
            BDYRQ        ,--NUMBER(8)     Y                         
            BDYR         ,--VARCHAR2(50)  Y                         
            FPS          ,--NUMBER(3)     Y                         
            SFJJAJ       ,--VARCHAR2(1)   Y                         
            CSRID        ,--NUMBER(16)    Y                         
            CSR          ,--VARCHAR2(50)  Y                         
            CSJG         ,--VARCHAR2(1)   Y                         
            CSCWDM       ,--VARCHAR2(50)  Y                         
            CSCWMS       ,--VARCHAR2(200) Y                         
            FSRID        ,--NUMBER(16)    Y                         
            FSR          ,--VARCHAR2(50)  Y                         
            FSJG         ,--VARCHAR2(1)   Y                         
            FSCWDM       ,--VARCHAR2(50)  Y                         
            FSCWMS       ,--VARCHAR2(200) Y                         
            AJSFSD       ,--VARCHAR2(1)   Y                         
            SDKSSJ       ,--DATE          Y                         
            DQCZR        ,--VARCHAR2(50)  Y                         
            ZBBRGX       ,--VARCHAR2(2)   Y                         
            SFGS         ,--VARCHAR2(1)   Y                         
            YWSGDD       ,--VARCHAR2(200) Y                         
            YWSGYY       ,--VARCHAR2(200) Y                         
            SSWBYY       ,--VARCHAR2(100) Y                         
            HCCGBZ       ,--VARCHAR2(1)   Y                         
            HCCLRQ       ,--NUMBER(8)     Y                         
            HCCLR        ,--VARCHAR2(30)  Y                         
            WBPAZH       ,--VARCHAR2(20)  Y                         
            WBPAFH       ,--VARCHAR2(30)  Y                         
            NEW_SEQLOGID ,--NUMBER        Y                         
            SFWB         ,--VARCHAR2(1)   Y                         
            SFBLC        ,--VARCHAR2(1)   Y        '0'              
            WBDCRQ       ,--NUMBER(8)     Y                         
            WBDRRQ       ,--NUMBER(8)     Y                         
            WBLYCC       ,--VARCHAR2(50)  Y                         
            WBFPR        ,--VARCHAR2(30)  Y                         
            FPSJ         ,--DATE          Y                         
            WBGSID       ,--NUMBER(16)    Y                         
            WBGSMC      )--VARCHAR2(100) Y 
           values (
            :old.AJID         ,--NUMBER(16)                              
            :old.LPPCID       ,--NUMBER(16)                              
            :old.PAH          ,--VARCHAR2(30)  Y                         
            :old.BXGSID       ,--NUMBER(16)                              
            :old.TTID         ,--NUMBER(16)                              
            :old.ZTTID        ,--NUMBER(16)    Y                         
            :old.ZTTMC        ,--VARCHAR2(200) Y                         
            :old.GJAJBZ       ,--VARCHAR2(1)   Y                         
            :old.GLAJH        ,--VARCHAR2(30)  Y                         
            :old.BBRXM        ,--VARCHAR2(30)  Y                         
            :old.BBRKHID      ,--NUMBER(16)    Y                         
            :old.BBRZJH       ,--VARCHAR2(20)  Y                         
            :old.ZLDBZ        ,--VARCHAR2(1)   Y                         
            :old.ZBBRKHID     ,--NUMBER(16)    Y                         
            :old.KHBDH        ,--VARCHAR2(30)  Y                         
            :old.FDID         ,--NUMBER(16)    Y                         
            :old.SQRZJLX      ,--VARCHAR2(2)   Y                         
            :old.SQRZJHM      ,--VARCHAR2(20)  Y                         
            :old.SQRXM        ,--VARCHAR2(30)  Y                         
            :old.SQRSJ        ,--VARCHAR2(30)  Y                         
            :old.SQRDZ        ,--VARCHAR2(200) Y                         
            :old.SQRYX        ,--VARCHAR2(200) Y                         
            :old.SQLX         ,--VARCHAR2(66)  Y                         
            :old.SQRQ         ,--NUMBER(8)     Y                         
            :old.BBRSCZT      ,--VARCHAR2(1)   Y                         
            :old.BBRCJDM      ,--VARCHAR2(10)  Y                         
            :old.BBRCJXM      ,--VARCHAR2(500) Y                         
            :old.BBRCJDJ      ,--VARCHAR2(10)  Y                         
            :old.BBRSWRQ      ,--NUMBER(8)     Y                         
            :old.BBRYWSGFSRQ  ,--NUMBER(8)     Y                         
            :old.JBID         ,--NUMBER(16)    Y                         
            :old.ZJDM         ,--VARCHAR2(20)  Y                         
            :old.ZJQZR        ,--NUMBER(8)     Y                         
            :old.AJZT         ,--VARCHAR2(2)   Y                         
            :old.ZHCLRQ       ,--DATE          Y                         
            :old.AJXGDM       ,--VARCHAR2(80)  Y                         
            :old.AJXGLY       ,--VARCHAR2(300) Y                         
            :old.XGRQ         ,--VARCHAR2(30)  Y                         
            :old.JARQ         ,--NUMBER(8)     Y                         
            :old.AJJL         ,--VARCHAR2(2)   Y                         
            :old.AJJLSM1      ,--VARCHAR2(10)  Y                         
            :old.AJJLSM       ,--VARCHAR2(200) Y                         
            :old.JBR          ,--VARCHAR2(30)  Y                         
            :old.AJPFJE       ,--NUMBER(16,2)  Y                         
            :old.LPJSYR       ,--VARCHAR2(30)  Y                         
            :old.AJPFFS       ,--VARCHAR2(1)   Y                         
            :old.SFXNAJ       ,--VARCHAR2(1)                             
            :old.SFZDSCZPA    ,--VARCHAR2(1)   Y                         
            :old.SCZPASJ      ,--DATE          Y                         
            :old.LSSJ         ,--DATE          Y                         
            :old.SLRID        ,--NUMBER(19)    Y                         
            :old.SLR          ,--VARCHAR2(50)  Y                         
            :old.LRRID        ,--NUMBER(19)    Y                         
            :old.LRR          ,--VARCHAR2(50)  Y                         
            :old.SHRID        ,--NUMBER(19)    Y                         
            :old.SHR          ,--VARCHAR2(50)  Y                         
            :old.ZJRID        ,--NUMBER(19)    Y                         
            :old.ZJR          ,--VARCHAR2(50)  Y                         
            :old.ZJSJ         ,--DATE          Y                         
            :old.ZJJL         ,--VARCHAR2(1)   Y                         
            :old.ZJYJMS       ,--VARCHAR2(200) Y                         
            :old.SSYLY        ,--VARCHAR2(200) Y                         
            :old.KHSYR        ,--VARCHAR2(50)  Y                         
            :old.SYJL         ,--VARCHAR2(1)   Y                         
            :old.SYRQ         ,--DATE          Y                         
            :old.SYYJMS       ,--VARCHAR2(200) Y                         
            :old.BXCSSCZPABZ  ,--VARCHAR2(1)   Y                         
            :old.DYSJSCBZ     ,--VARCHAR2(1)   Y                         
            :old.DYSJSCSJ     ,--DATE          Y                         
            :old.LPKGFKHH     ,--VARCHAR2(50)  Y                         
            :old.LPKGFYHZH    ,--VARCHAR2(35)  Y                         
            :old.SKFXM        ,--VARCHAR2(50)  Y                         
            :old.TQRQ         ,--DATE          Y                         
            :old.QCLSM        ,--VARCHAR2(300) Y                         
            :old.SFRQ         ,--NUMBER(8)     Y                         
            :old.SEQLOGID     ,--NUMBER        Y                         
            :old.DYBZ         ,--VARCHAR2(1)   Y                         
            :old.DYR          ,--VARCHAR2(50)  Y                         
            :old.DYRQ         ,--NUMBER(8)     Y                         
            :old.BDYRQ        ,--NUMBER(8)     Y                         
            :old.BDYR         ,--VARCHAR2(50)  Y                         
            :old.FPS          ,--NUMBER(3)     Y                         
            :old.SFJJAJ       ,--VARCHAR2(1)   Y                         
            :old.CSRID        ,--NUMBER(16)    Y                         
            :old.CSR          ,--VARCHAR2(50)  Y                         
            :old.CSJG         ,--VARCHAR2(1)   Y                         
            :old.CSCWDM       ,--VARCHAR2(50)  Y                         
            :old.CSCWMS       ,--VARCHAR2(200) Y                         
            :old.FSRID        ,--NUMBER(16)    Y                         
            :old.FSR          ,--VARCHAR2(50)  Y                         
            :old.FSJG         ,--VARCHAR2(1)   Y                         
            :old.FSCWDM       ,--VARCHAR2(50)  Y                         
            :old.FSCWMS       ,--VARCHAR2(200) Y                         
            :old.AJSFSD       ,--VARCHAR2(1)   Y                         
            :old.SDKSSJ       ,--DATE          Y                         
            :old.DQCZR        ,--VARCHAR2(50)  Y                         
            :old.ZBBRGX       ,--VARCHAR2(2)   Y                         
            :old.SFGS         ,--VARCHAR2(1)   Y                         
            :old.YWSGDD       ,--VARCHAR2(200) Y                         
            :old.YWSGYY       ,--VARCHAR2(200) Y                         
            :old.SSWBYY       ,--VARCHAR2(100) Y                         
            :old.HCCGBZ       ,--VARCHAR2(1)   Y                         
            :old.HCCLRQ       ,--NUMBER(8)     Y                         
            :old.HCCLR        ,--VARCHAR2(30)  Y                         
            :old.WBPAZH       ,--VARCHAR2(20)  Y                         
            :old.WBPAFH       ,--VARCHAR2(30)  Y                         
            seqid ,--NUMBER    NEW_SEQLOGID     Y                         
            :old.SFWB         ,--VARCHAR2(1)   Y                         
            :old.SFBLC        ,--VARCHAR2(1)   Y        '0'              
            :old.WBDCRQ       ,--NUMBER(8)     Y                         
            :old.WBDRRQ       ,--NUMBER(8)     Y                         
            :old.WBLYCC       ,--VARCHAR2(50)  Y                         
            :old.WBFPR        ,--VARCHAR2(30)  Y                         
            :old.FPSJ         ,--DATE          Y                         
            :old.WBGSID       ,--NUMBER(16)    Y                         
            :old.WBGSMC );      
           
  else
    op_type := HISTORY_UTIL.OPTYPE_DELETE;
    pk_values(pk_values.count + 1) := any_type('AJID',
                                               'number',
                                               null,
                                               :old.AJID,
                                               null);
    c_values(c_values.count + 1) := any_type('WBPAZH',
                                             'string',
                                             :old.WBPAZH,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('WBPAFH',
                                             'string',
                                             :old.WBPAFH,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('SFWB',
                                             'string',
                                             :old.SFWB,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('SFBLC',
                                             'string',
                                             :old.SFBLC,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('WBDCRQ',
                                             'number',
                                             null,
                                             :old.WBDCRQ,
                                             null);
    c_values(c_values.count + 1) := any_type('WBDRRQ',
                                             'number',
                                             null,
                                             :old.WBDRRQ,
                                             null);
    c_values(c_values.count + 1) := any_type('WBLYCC',
                                             'string',
                                             :old.WBLYCC,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('WBFPR',
                                             'string',
                                             :old.WBFPR,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('FPSJ',
                                             'date',
                                             null,
                                             null,
                                             :old.FPSJ);
    c_values(c_values.count + 1) := any_type('WBGSID',
                                             'number',
                                             null,
                                             :old.WBGSID,
                                             null);
    c_values(c_values.count + 1) := any_type('WBGSMC',
                                             'string',
                                             :old.WBGSMC,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('SCZPASJ',
                                             'date',
                                             null,
                                             null,
                                             :old.SCZPASJ);
    c_values(c_values.count + 1) := any_type('LSSJ',
                                             'date',
                                             null,
                                             null,
                                             :old.LSSJ);
    c_values(c_values.count + 1) := any_type('SLRID',
                                             'number',
                                             null,
                                             :old.SLRID,
                                             null);
    c_values(c_values.count + 1) := any_type('SLR',
                                             'string',
                                             :old.SLR,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('LRRID',
                                             'number',
                                             null,
                                             :old.LRRID,
                                             null);
    c_values(c_values.count + 1) := any_type('LRR',
                                             'string',
                                             :old.LRR,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('SHRID',
                                             'number',
                                             null,
                                             :old.SHRID,
                                             null);
    c_values(c_values.count + 1) := any_type('SHR',
                                             'string',
                                             :old.SHR,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('ZJRID',
                                             'number',
                                             null,
                                             :old.ZJRID,
                                             null);
    c_values(c_values.count + 1) := any_type('ZJR',
                                             'string',
                                             :old.ZJR,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('ZJSJ',
                                             'date',
                                             null,
                                             null,
                                             :old.ZJSJ);
    c_values(c_values.count + 1) := any_type('ZJJL',
                                             'string',
                                             :old.ZJJL,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('ZJYJMS',
                                             'string',
                                             :old.ZJYJMS,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('SSYLY',
                                             'string',
                                             :old.SSYLY,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('KHSYR',
                                             'string',
                                             :old.KHSYR,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('SYJL',
                                             'string',
                                             :old.SYJL,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('SYRQ',
                                             'date',
                                             null,
                                             null,
                                             :old.SYRQ);
    c_values(c_values.count + 1) := any_type('SYYJMS',
                                             'string',
                                             :old.SYYJMS,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('BXCSSCZPABZ',
                                             'string',
                                             :old.BXCSSCZPABZ,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('DYSJSCBZ',
                                             'string',
                                             :old.DYSJSCBZ,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('DYSJSCSJ',
                                             'date',
                                             null,
                                             null,
                                             :old.DYSJSCSJ);
    c_values(c_values.count + 1) := any_type('LPKGFKHH',
                                             'string',
                                             :old.LPKGFKHH,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('LPKGFYHZH',
                                             'string',
                                             :old.LPKGFYHZH,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('SKFXM',
                                             'string',
                                             :old.SKFXM,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('TQRQ',
                                             'date',
                                             null,
                                             null,
                                             :old.TQRQ);
    c_values(c_values.count + 1) := any_type('QCLSM',
                                             'string',
                                             :old.QCLSM,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('SFRQ',
                                             'number',
                                             null,
                                             :old.SFRQ,
                                             null);
    c_values(c_values.count + 1) := any_type('SEQLOGID',
                                             'number',
                                             null,
                                             :old.SEQLOGID,
                                             null);
    c_values(c_values.count + 1) := any_type('DYBZ',
                                             'string',
                                             :old.DYBZ,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('DYR',
                                             'string',
                                             :old.DYR,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('DYRQ',
                                             'number',
                                             null,
                                             :old.DYRQ,
                                             null);
    c_values(c_values.count + 1) := any_type('BDYRQ',
                                             'number',
                                             null,
                                             :old.BDYRQ,
                                             null);
    c_values(c_values.count + 1) := any_type('BDYR',
                                             'string',
                                             :old.BDYR,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('FPS',
                                             'number',
                                             null,
                                             :old.FPS,
                                             null);
    c_values(c_values.count + 1) := any_type('SFJJAJ',
                                             'string',
                                             :old.SFJJAJ,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('CSRID',
                                             'number',
                                             null,
                                             :old.CSRID,
                                             null);
    c_values(c_values.count + 1) := any_type('CSR',
                                             'string',
                                             :old.CSR,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('CSJG',
                                             'string',
                                             :old.CSJG,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('CSCWDM',
                                             'string',
                                             :old.CSCWDM,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('CSCWMS',
                                             'string',
                                             :old.CSCWMS,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('FSRID',
                                             'number',
                                             null,
                                             :old.FSRID,
                                             null);
    c_values(c_values.count + 1) := any_type('FSR',
                                             'string',
                                             :old.FSR,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('FSJG',
                                             'string',
                                             :old.FSJG,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('FSCWDM',
                                             'string',
                                             :old.FSCWDM,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('FSCWMS',
                                             'string',
                                             :old.FSCWMS,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('AJSFSD',
                                             'string',
                                             :old.AJSFSD,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('SDKSSJ',
                                             'date',
                                             null,
                                             null,
                                             :old.SDKSSJ);
    c_values(c_values.count + 1) := any_type('DQCZR',
                                             'string',
                                             :old.DQCZR,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('ZBBRGX',
                                             'string',
                                             :old.ZBBRGX,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('SFGS',
                                             'string',
                                             :old.SFGS,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('YWSGDD',
                                             'string',
                                             :old.YWSGDD,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('YWSGYY',
                                             'string',
                                             :old.YWSGYY,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('SSWBYY',
                                             'string',
                                             :old.SSWBYY,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('HCCGBZ',
                                             'string',
                                             :old.HCCGBZ,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('HCCLRQ',
                                             'number',
                                             null,
                                             :old.HCCLRQ,
                                             null);
    c_values(c_values.count + 1) := any_type('HCCLR',
                                             'string',
                                             :old.HCCLR,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('LPPCID',
                                             'number',
                                             null,
                                             :old.LPPCID,
                                             null);
    c_values(c_values.count + 1) := any_type('PAH',
                                             'string',
                                             :old.PAH,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('BXGSID',
                                             'number',
                                             null,
                                             :old.BXGSID,
                                             null);
    c_values(c_values.count + 1) := any_type('TTID',
                                             'number',
                                             null,
                                             :old.TTID,
                                             null);
    c_values(c_values.count + 1) := any_type('ZTTID',
                                             'number',
                                             null,
                                             :old.ZTTID,
                                             null);
    c_values(c_values.count + 1) := any_type('ZTTMC',
                                             'string',
                                             :old.ZTTMC,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('GJAJBZ',
                                             'string',
                                             :old.GJAJBZ,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('GLAJH',
                                             'string',
                                             :old.GLAJH,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('BBRXM',
                                             'string',
                                             :old.BBRXM,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('BBRKHID',
                                             'number',
                                             null,
                                             :old.BBRKHID,
                                             null);
    c_values(c_values.count + 1) := any_type('BBRZJH',
                                             'string',
                                             :old.BBRZJH,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('ZLDBZ',
                                             'string',
                                             :old.ZLDBZ,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('ZBBRKHID',
                                             'number',
                                             null,
                                             :old.ZBBRKHID,
                                             null);
    c_values(c_values.count + 1) := any_type('KHBDH',
                                             'string',
                                             :old.KHBDH,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('FDID',
                                             'number',
                                             null,
                                             :old.FDID,
                                             null);
    c_values(c_values.count + 1) := any_type('SQRZJLX',
                                             'string',
                                             :old.SQRZJLX,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('SQRZJHM',
                                             'string',
                                             :old.SQRZJHM,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('SQRXM',
                                             'string',
                                             :old.SQRXM,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('SQRSJ',
                                             'string',
                                             :old.SQRSJ,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('SQRDZ',
                                             'string',
                                             :old.SQRDZ,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('SQRYX',
                                             'string',
                                             :old.SQRYX,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('SQLX',
                                             'string',
                                             :old.SQLX,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('SQRQ',
                                             'number',
                                             null,
                                             :old.SQRQ,
                                             null);
    c_values(c_values.count + 1) := any_type('BBRSCZT',
                                             'string',
                                             :old.BBRSCZT,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('BBRCJDM',
                                             'string',
                                             :old.BBRCJDM,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('BBRCJXM',
                                             'string',
                                             :old.BBRCJXM,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('BBRCJDJ',
                                             'string',
                                             :old.BBRCJDJ,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('BBRSWRQ',
                                             'number',
                                             null,
                                             :old.BBRSWRQ,
                                             null);
    c_values(c_values.count + 1) := any_type('BBRYWSGFSRQ',
                                             'number',
                                             null,
                                             :old.BBRYWSGFSRQ,
                                             null);
    c_values(c_values.count + 1) := any_type('JBID',
                                             'number',
                                             null,
                                             :old.JBID,
                                             null);
    c_values(c_values.count + 1) := any_type('ZJDM',
                                             'string',
                                             :old.ZJDM,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('ZJQZR',
                                             'number',
                                             null,
                                             :old.ZJQZR,
                                             null);
    c_values(c_values.count + 1) := any_type('AJZT',
                                             'string',
                                             :old.AJZT,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('ZHCLRQ',
                                             'date',
                                             null,
                                             null,
                                             :old.ZHCLRQ);
    c_values(c_values.count + 1) := any_type('AJXGDM',
                                             'string',
                                             :old.AJXGDM,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('AJXGLY',
                                             'string',
                                             :old.AJXGLY,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('XGRQ',
                                             'string',
                                             :old.XGRQ,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('JARQ',
                                             'number',
                                             null,
                                             :old.JARQ,
                                             null);
    c_values(c_values.count + 1) := any_type('AJJL',
                                             'string',
                                             :old.AJJL,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('AJJLSM1',
                                             'string',
                                             :old.AJJLSM1,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('AJJLSM',
                                             'string',
                                             :old.AJJLSM,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('JBR',
                                             'string',
                                             :old.JBR,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('AJPFJE',
                                             'number',
                                             null,
                                             :old.AJPFJE,
                                             null);
    c_values(c_values.count + 1) := any_type('LPJSYR',
                                             'string',
                                             :old.LPJSYR,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('AJPFFS',
                                             'string',
                                             :old.AJPFFS,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('SFXNAJ',
                                             'string',
                                             :old.SFXNAJ,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('SFZDSCZPA',
                                             'string',
                                             :old.SFZDSCZPA,
                                             null,
                                             null);
  end if;
  HISTORY_UTIL.to_history(op_type, 'TB_LPAJXX', pk_values, c_values);
end;
/
