CREATE TRIGGER TR_RB_TB_BXGSXX
BEFORE INSERT OR UPDATE OR DELETE
  ON TB_BXGSXX
FOR EACH ROW
  declare
  op_type   number;
  pk_values HISTORY_UTIL.ant_type_table;
  c_values  HISTORY_UTIL.ant_type_table;
  seqid     number;
  action    number;
  rec_SYNCDATA TB_YFZFB_SYNCDATA%rowtype;
/*  v1.1 ++ begin*/
v_ret_code varchar2(10):='E';
v_ret_MSG varchar2(10):='ERROR';
/*  v1.1 ++ end*/
begin
  HISTORY_UTIL.get_sequence(seqid, action);
/*  if action = HISTORY_UTIL.ACTION_ROLLBACK then
    return;
  end if;*/
  if inserting then
    op_type := HISTORY_UTIL.OPTYPE_INSERT;
    pk_values(pk_values.count + 1) := any_type('BXGSID',
                                               'number',
                                               null,
                                               :new.BXGSID,
                                               null);
    :new.SEQLOGID := seqid;
  elsif updating then
    op_type := HISTORY_UTIL.OPTYPE_UPDATE;
    pk_values(pk_values.count + 1) := any_type('BXGSID',
                                               'number',
                                               null,
                                               :old.BXGSID,
                                               null);
    :new.SEQLOGID := seqid;
    if history_util.bool_xor(:new.SEQLOGID is null, :old.SEQLOGID is null) or
       :new.SEQLOGID != :old.SEQLOGID then
      c_values(c_values.count + 1) := any_type('SEQLOGID',
                                               'number',
                                               null,
                                               :old.SEQLOGID,
                                               null);
    end if;
    if history_util.bool_xor(:new.BXGSBH is null, :old.BXGSBH is null) or
       :new.BXGSBH != :old.BXGSBH then
      c_values(c_values.count + 1) := any_type('BXGSBH',
                                               'string',
                                               :old.BXGSBH,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.BXGSQC is null, :old.BXGSQC is null) or
       :new.BXGSQC != :old.BXGSQC then
      c_values(c_values.count + 1) := any_type('BXGSQC',
                                               'string',
                                               :old.BXGSQC,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.BXGSJC is null, :old.BXGSJC is null) or
       :new.BXGSJC != :old.BXGSJC then
      c_values(c_values.count + 1) := any_type('BXGSJC',
                                               'string',
                                               :old.BXGSJC,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.ZFGSBZ is null, :old.ZFGSBZ is null) or
       :new.ZFGSBZ != :old.ZFGSBZ then
      c_values(c_values.count + 1) := any_type('ZFGSBZ',
                                               'string',
                                               :old.ZFGSBZ,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.ZGSMC is null, :old.ZGSMC is null) or
       :new.ZGSMC != :old.ZGSMC then
      c_values(c_values.count + 1) := any_type('ZGSMC',
                                               'string',
                                               :old.ZGSMC,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.FRDB is null, :old.FRDB is null) or
       :new.FRDB != :old.FRDB then
      c_values(c_values.count + 1) := any_type('FRDB',
                                               'string',
                                               :old.FRDB,
                                               null,
                                               null);
    end if;
    /*if history_util.bool_xor(:new.FRDBZ is null, :old.FRDBZ is null) or
       :new.FRDBZ != :old.FRDBZ then
      c_values(c_values.count + 1) := any_type('FRDBZ',
                                               'unknown',
                                               null,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.SB is null, :old.SB is null) or
       :new.SB != :old.SB then
      c_values(c_values.count + 1) := any_type('SB',
                                               'unknown',
                                               null,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.DZGZ is null, :old.DZGZ is null) or
       :new.DZGZ != :old.DZGZ then
      c_values(c_values.count + 1) := any_type('DZGZ',
                                               'unknown',
                                               null,
                                               null,
                                               null);
    end if;*/
    if history_util.bool_xor(:new.LXDZ is null, :old.LXDZ is null) or
       :new.LXDZ != :old.LXDZ then
      c_values(c_values.count + 1) := any_type('LXDZ',
                                               'string',
                                               :old.LXDZ,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.YB is null, :old.YB is null) or
       :new.YB != :old.YB then
      c_values(c_values.count + 1) := any_type('YB',
                                               'string',
                                               :old.YB,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.LXDH is null, :old.LXDH is null) or
       :new.LXDH != :old.LXDH then
      c_values(c_values.count + 1) := any_type('LXDH',
                                               'string',
                                               :old.LXDH,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.LXR is null, :old.LXR is null) or
       :new.LXR != :old.LXR then
      c_values(c_values.count + 1) := any_type('LXR',
                                               'string',
                                               :old.LXR,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.GSLX is null, :old.GSLX is null) or
       :new.GSLX != :old.GSLX then
      c_values(c_values.count + 1) := any_type('GSLX',
                                               'string',
                                               :old.GSLX,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.SFZS is null, :old.SFZS is null) or
       :new.SFZS != :old.SFZS then
      c_values(c_values.count + 1) := any_type('SFZS',
                                               'string',
                                               :old.SFZS,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.LPGFFS is null, :old.LPGFFS is null) or
       :new.LPGFFS != :old.LPGFFS then
      c_values(c_values.count + 1) := any_type('LPGFFS',
                                               'string',
                                               :old.LPGFFS,
                                               null,
                                               null);
    end if;
    insert into H_TB_BXGSXX
      (BXGSID,
       SEQLOGID,
       BXGSBH,
       BXGSQC,
       BXGSJC,
       ZFGSBZ,
       ZGSMC,
       FRDB,
       FRDBZ,
       SB,
       DZGZ,
       LXDZ,
       YB,
       LXDH,
       LXR,
       GSLX,
       SFZS,
       LPGFFS,
       NEW_SEQLOGID)
    values
      (:old.BXGSID,
       :old.SEQLOGID,
       :old.BXGSBH,
       :old.BXGSQC,
       :old.BXGSJC,
       :old.ZFGSBZ,
       :old.ZGSMC,
       :old.FRDB,
       :old.FRDBZ,
       :old.SB,
       :old.DZGZ,
       :old.LXDZ,
       :old.YB,
       :old.LXDH,
       :old.LXR,
       :old.GSLX,
       :old.SFZS,
       :old.LPGFFS,
       seqid);
  else
    op_type := HISTORY_UTIL.OPTYPE_DELETE;
    pk_values(pk_values.count + 1) := any_type('BXGSID',
                                               'number',
                                               null,
                                               :old.BXGSID,
                                               null);
    c_values(c_values.count + 1) := any_type('SEQLOGID',
                                             'number',
                                             null,
                                             :old.SEQLOGID,
                                             null);
    c_values(c_values.count + 1) := any_type('BXGSBH',
                                             'string',
                                             :old.BXGSBH,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('BXGSQC',
                                             'string',
                                             :old.BXGSQC,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('BXGSJC',
                                             'string',
                                             :old.BXGSJC,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('ZFGSBZ',
                                             'string',
                                             :old.ZFGSBZ,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('ZGSMC',
                                             'string',
                                             :old.ZGSMC,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('FRDB',
                                             'string',
                                             :old.FRDB,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('FRDBZ',
                                             'unknown',
                                             null,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('SB',
                                             'unknown',
                                             null,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('DZGZ',
                                             'unknown',
                                             null,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('LXDZ',
                                             'string',
                                             :old.LXDZ,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('YB',
                                             'string',
                                             :old.YB,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('LXDH',
                                             'string',
                                             :old.LXDH,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('LXR',
                                             'string',
                                             :old.LXR,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('GSLX',
                                             'string',
                                             :old.GSLX,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('SFZS',
                                             'string',
                                             :old.SFZS,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('LPGFFS',
                                             'string',
                                             :old.LPGFFS,
                                             null,
                                             null);
    insert into H_TB_BXGSXX
      (BXGSID,
       SEQLOGID,
       BXGSBH,
       BXGSQC,
       BXGSJC,
       ZFGSBZ,
       ZGSMC,
       FRDB,
       FRDBZ,
       SB,
       DZGZ,
       LXDZ,
       YB,
       LXDH,
       LXR,
       GSLX,
       SFZS,
       LPGFFS,
       NEW_SEQLOGID)
    values
      (:old.BXGSID,
       :old.SEQLOGID,
       :old.BXGSBH,
       :old.BXGSQC,
       :old.BXGSJC,
       :old.ZFGSBZ,
       :old.ZGSMC,
       :old.FRDB,
       :old.FRDBZ,
       :old.SB,
       :old.DZGZ,
       :old.LXDZ,
       :old.YB,
       :old.LXDH,
       :old.LXR,
       :old.GSLX,
       :old.SFZS,
       :old.LPGFFS,
       seqid);
  end if;
  HISTORY_UTIL.to_history(op_type, 'TB_BXGSXX', pk_values, c_values, 1);
  /*v1.1++ begin */
  select case when op_type='1' then 'A' when op_type='2' then 'U' else 'D' end,
  SEQ_OPTID.Nextval,sysdate ,'1' as Opt_Object,'A' as sys_type
  into rec_SYNCDATA.Op_Type,rec_SYNCDATA.Opt_Id,rec_SYNCDATA.Opt_Datetime ,
  rec_SYNCDATA.Opt_Object,rec_SYNCDATA.Sys_Type from dual;
   rec_SYNCDATA.content:='{';
   if  rec_SYNCDATA.Op_Type in('A','U') then
     rec_SYNCDATA.Object_Id:=:new.bxgsid;
       rec_SYNCDATA.content:=rec_SYNCDATA.content||'"bxgsid":"'||to_char(:New.bxgsid)||'","bxgsqc":"'||to_char(:New.bxgsqc)||'","lxdz":"'||to_char(:New.lxdz);
       rec_SYNCDATA.content:=rec_SYNCDATA.content||'","lxr":"'||to_char(:New.lxr)||'","lxdh":"'||to_char(:New.lxdh)||'","bxgsbh":"'||to_char(:New.bxgsbh)||'","bxgsjc":"'||to_char(:New.BXGSJC)||'"';
   else
        rec_SYNCDATA.content:=rec_SYNCDATA.content||'"bxgsid":"'||to_char(:New.bxgsid)||'"';
   end if;
   rec_SYNCDATA.content:=rec_SYNCDATA.content||'}';
   SP_GEN_SYNCDATA(v_ret_code,v_ret_msg, rec_SYNCDATA); --调用共用的中间表生成程序
  /*v1.1++ end */

end;
/
