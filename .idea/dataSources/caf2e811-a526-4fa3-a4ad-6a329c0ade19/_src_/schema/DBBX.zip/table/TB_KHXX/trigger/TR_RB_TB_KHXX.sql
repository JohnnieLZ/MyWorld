CREATE TRIGGER TR_RB_TB_KHXX
BEFORE INSERT OR UPDATE OR DELETE
  ON TB_KHXX
FOR EACH ROW
  declare
  op_type      number;
  pk_values    HISTORY_UTIL.ant_type_table;
  c_values     HISTORY_UTIL.ant_type_table;
  seqid        number;
  action       number;
  rec_SYNCDATA TB_YFZFB_SYNCDATA%rowtype;
  v_flag       number := 0; --判断是否需要建立同步数据到中间表
  v_ret_code   varchar2(10) := 'E';
  v_ret_MSG    varchar2(10) := 'ERROR';
  v_bxgsid     varchar2(100) := ''; --团体所属保险公司id
  rec_khxx     tb_khxx%rowtype;
begin
  HISTORY_UTIL.get_sequence(seqid, action);
  /*
  if action = HISTORY_UTIL.ACTION_ROLLBACK then
    return;
  end if;*/
  if inserting then
    op_type := HISTORY_UTIL.OPTYPE_INSERT;
    pk_values(pk_values.count + 1) := any_type('KHID',
                                               'number',
                                               null,
                                               :new.KHID,
                                               null);
    :new.SEQLOGID := seqid;
  elsif updating then
    op_type := HISTORY_UTIL.OPTYPE_UPDATE;
    pk_values(pk_values.count + 1) := any_type('KHID',
                                               'number',
                                               null,
                                               :old.KHID,
                                               null);
    if history_util.bool_xor(:new.BBRTBYD is null, :old.BBRTBYD is null) or
       :new.BBRTBYD != :old.BBRTBYD then
      c_values(c_values.count + 1) := any_type('BBRTBYD',
                                               'string',
                                               :old.BBRTBYD,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.GZDXZQH is null, :old.GZDXZQH is null) or
       :new.GZDXZQH != :old.GZDXZQH then
      c_values(c_values.count + 1) := any_type('GZDXZQH',
                                               'string',
                                               :old.GZDXZQH,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.YBDXZQH is null, :old.YBDXZQH is null) or
       :new.YBDXZQH != :old.YBDXZQH then
      c_values(c_values.count + 1) := any_type('YBDXZQH',
                                               'string',
                                               :old.YBDXZQH,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.JZDXZQH is null, :old.JZDXZQH is null) or
       :new.JZDXZQH != :old.JZDXZQH then
      c_values(c_values.count + 1) := any_type('JZDXZQH',
                                               'string',
                                               :old.JZDXZQH,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.SFMZZYGYED is null,
                             :old.SFMZZYGYED is null) or
       :new.SFMZZYGYED != :old.SFMZZYGYED then
      c_values(c_values.count + 1) := any_type('SFMZZYGYED',
                                               'string',
                                               :old.SFMZZYGYED,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.BGSJ is null, :old.BGSJ is null) or
       :new.BGSJ != :old.BGSJ then
      c_values(c_values.count + 1) := any_type('BGSJ',
                                               'number',
                                               null,
                                               :old.BGSJ,
                                               null);
    end if;
    if history_util.bool_xor(:new.CZSJ is null, :old.CZSJ is null) or
       :new.CZSJ != :old.CZSJ then
      c_values(c_values.count + 1) := any_type('CZSJ',
                                               'date',
                                               null,
                                               null,
                                               :old.CZSJ);
    end if;
    if history_util.bool_xor(:new.BANKCODE is null, :old.BANKCODE is null) or
       :new.BANKCODE != :old.BANKCODE then
      c_values(c_values.count + 1) := any_type('BANKCODE',
                                               'string',
                                               :old.BANKCODE,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.BANKSELFCODE is null,
                             :old.BANKSELFCODE is null) or
       :new.BANKSELFCODE != :old.BANKSELFCODE then
      c_values(c_values.count + 1) := any_type('BANKSELFCODE',
                                               'string',
                                               :old.BANKSELFCODE,
                                               null,
                                               null);
    end if;
    :new.SEQLOGID := seqid;
    if history_util.bool_xor(:new.SEQLOGID is null, :old.SEQLOGID is null) or
       :new.SEQLOGID != :old.SEQLOGID then
      c_values(c_values.count + 1) := any_type('SEQLOGID',
                                               'number',
                                               null,
                                               :old.SEQLOGID,
                                               null);
    end if;
    if history_util.bool_xor(:new.BXGSID is null, :old.BXGSID is null) or
       :new.BXGSID != :old.BXGSID then
      c_values(c_values.count + 1) := any_type('BXGSID',
                                               'number',
                                               null,
                                               :old.BXGSID,
                                               null);
    end if;
    if history_util.bool_xor(:new.RYLB is null, :old.RYLB is null) or
       :new.RYLB != :old.RYLB then
      c_values(c_values.count + 1) := any_type('RYLB',
                                               'string',
                                               :old.RYLB,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.AGE is null, :old.AGE is null) or
       :new.AGE != :old.AGE then
      c_values(c_values.count + 1) := any_type('AGE',
                                               'number',
                                               null,
                                               :old.AGE,
                                               null);
    end if;
    if history_util.bool_xor(:new.KHBH is null, :old.KHBH is null) or
       :new.KHBH != :old.KHBH then
      c_values(c_values.count + 1) := any_type('KHBH',
                                               'string',
                                               :old.KHBH,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.XM is null, :old.XM is null) or
       :new.XM != :old.XM then
      c_values(c_values.count + 1) := any_type('XM',
                                               'string',
                                               :old.XM,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.AAC058 is null, :old.AAC058 is null) or
       :new.AAC058 != :old.AAC058 then
      c_values(c_values.count + 1) := any_type('AAC058',
                                               'string',
                                               :old.AAC058,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.AAC147 is null, :old.AAC147 is null) or
       :new.AAC147 != :old.AAC147 then
      c_values(c_values.count + 1) := any_type('AAC147',
                                               'string',
                                               :old.AAC147,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.SCZT is null, :old.SCZT is null) or
       :new.SCZT != :old.SCZT then
      c_values(c_values.count + 1) := any_type('SCZT',
                                               'string',
                                               :old.SCZT,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.XB is null, :old.XB is null) or
       :new.XB != :old.XB then
      c_values(c_values.count + 1) := any_type('XB',
                                               'string',
                                               :old.XB,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.CSRQ is null, :old.CSRQ is null) or
       :new.CSRQ != :old.CSRQ then
      c_values(c_values.count + 1) := any_type('CSRQ',
                                               'number',
                                               null,
                                               :old.CSRQ,
                                               null);
    end if;
    if history_util.bool_xor(:new.SWRQ is null, :old.SWRQ is null) or
       :new.SWRQ != :old.SWRQ then
      c_values(c_values.count + 1) := any_type('SWRQ',
                                               'number',
                                               null,
                                               :old.SWRQ,
                                               null);
    end if;
    if history_util.bool_xor(:new.ZZBZ is null, :old.ZZBZ is null) or
       :new.ZZBZ != :old.ZZBZ then
      c_values(c_values.count + 1) := any_type('ZZBZ',
                                               'string',
                                               :old.ZZBZ,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.ZYDJ is null, :old.ZYDJ is null) or
       :new.ZYDJ != :old.ZYDJ then
      c_values(c_values.count + 1) := any_type('ZYDJ',
                                               'string',
                                               :old.ZYDJ,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.ZYDM is null, :old.ZYDM is null) or
       :new.ZYDM != :old.ZYDM then
      c_values(c_values.count + 1) := any_type('ZYDM',
                                               'string',
                                               :old.ZYDM,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.GH is null, :old.GH is null) or
       :new.GH != :old.GH then
      c_values(c_values.count + 1) := any_type('GH',
                                               'string',
                                               :old.GH,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.KHYH is null, :old.KHYH is null) or
       :new.KHYH != :old.KHYH then
      c_values(c_values.count + 1) := any_type('KHYH',
                                               'string',
                                               :old.KHYH,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.ZHMC is null, :old.ZHMC is null) or
       :new.ZHMC != :old.ZHMC then
      c_values(c_values.count + 1) := any_type('ZHMC',
                                               'string',
                                               :old.ZHMC,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.YHZH is null, :old.YHZH is null) or
       :new.YHZH != :old.YHZH then
      c_values(c_values.count + 1) := any_type('YHZH',
                                               'string',
                                               :old.YHZH,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.KHHSZS is null, :old.KHHSZS is null) or
       :new.KHHSZS != :old.KHHSZS then
      c_values(c_values.count + 1) := any_type('KHHSZS',
                                               'string',
                                               :old.KHHSZS,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.KHHSZSHI is null, :old.KHHSZSHI is null) or
       :new.KHHSZSHI != :old.KHHSZSHI then
      c_values(c_values.count + 1) := any_type('KHHSZSHI',
                                               'string',
                                               :old.KHHSZSHI,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.FWTT is null, :old.FWTT is null) or
       :new.FWTT != :old.FWTT then
      c_values(c_values.count + 1) := any_type('FWTT',
                                               'string',
                                               :old.FWTT,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.FWTTMC is null, :old.FWTTMC is null) or
       :new.FWTTMC != :old.FWTTMC then
      c_values(c_values.count + 1) := any_type('FWTTMC',
                                               'string',
                                               :old.FWTTMC,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.FWZTTBH is null, :old.FWZTTBH is null) or
       :new.FWZTTBH != :old.FWZTTBH then
      c_values(c_values.count + 1) := any_type('FWZTTBH',
                                               'string',
                                               :old.FWZTTBH,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.BMBH is null, :old.BMBH is null) or
       :new.BMBH != :old.BMBH then
      c_values(c_values.count + 1) := any_type('BMBH',
                                               'string',
                                               :old.BMBH,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.BMMC is null, :old.BMMC is null) or
       :new.BMMC != :old.BMMC then
      c_values(c_values.count + 1) := any_type('BMMC',
                                               'string',
                                               :old.BMMC,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.YBBS is null, :old.YBBS is null) or
       :new.YBBS != :old.YBBS then
      c_values(c_values.count + 1) := any_type('YBBS',
                                               'string',
                                               :old.YBBS,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.YBKH is null, :old.YBKH is null) or
       :new.YBKH != :old.YBKH then
      c_values(c_values.count + 1) := any_type('YBKH',
                                               'string',
                                               :old.YBKH,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.YBD is null, :old.YBD is null) or
       :new.YBD != :old.YBD then
      c_values(c_values.count + 1) := any_type('YBD',
                                               'string',
                                               :old.YBD,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.GZDJZD is null, :old.GZDJZD is null) or
       :new.GZDJZD != :old.GZDJZD then
      c_values(c_values.count + 1) := any_type('GZDJZD',
                                               'string',
                                               :old.GZDJZD,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.HYZK is null, :old.HYZK is null) or
       :new.HYZK != :old.HYZK then
      c_values(c_values.count + 1) := any_type('HYZK',
                                               'string',
                                               :old.HYZK,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.EMAIL is null, :old.EMAIL is null) or
       :new.EMAIL != :old.EMAIL then
      c_values(c_values.count + 1) := any_type('EMAIL',
                                               'string',
                                               :old.EMAIL,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.SJH is null, :old.SJH is null) or
       :new.SJH != :old.SJH then
      c_values(c_values.count + 1) := any_type('SJH',
                                               'string',
                                               :old.SJH,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.YX is null, :old.YX is null) or
       :new.YX != :old.YX then
      c_values(c_values.count + 1) := any_type('YX',
                                               'number',
                                               null,
                                               :old.YX,
                                               null);
    end if;
    if history_util.bool_xor(:new.XGBZ is null, :old.XGBZ is null) or
       :new.XGBZ != :old.XGBZ then
      c_values(c_values.count + 1) := any_type('XGBZ',
                                               'string',
                                               :old.XGBZ,
                                               null,
                                               null);
    end if;
    insert into H_TB_KHXX
      (KHID,
       BBRTBYD,
       GZDXZQH,
       YBDXZQH,
       JZDXZQH,
       SFMZZYGYED,
       BGSJ,
       CZSJ,
       BANKCODE,
       BANKSELFCODE,
       SEQLOGID,
       BXGSID,
       RYLB,
       AGE,
       KHBH,
       XM,
       AAC058,
       AAC147,
       SCZT,
       XB,
       CSRQ,
       SWRQ,
       ZZBZ,
       ZYDJ,
       ZYDM,
       GH,
       KHYH,
       ZHMC,
       YHZH,
       KHHSZS,
       KHHSZSHI,
       FWTT,
       FWTTMC,
       FWZTTBH,
       BMBH,
       BMMC,
       YBBS,
       YBKH,
       YBD,
       GZDJZD,
       HYZK,
       EMAIL,
       SJH,
       YX,
       XGBZ,
       NEW_SEQLOGID)
    values
      (:old.KHID,
       :old.BBRTBYD,
       :old.GZDXZQH,
       :old.YBDXZQH,
       :old.JZDXZQH,
       :old.SFMZZYGYED,
       :old.BGSJ,
       :old.CZSJ,
       :old.BANKCODE,
       :old.BANKSELFCODE,
       :old.SEQLOGID,
       :old.BXGSID,
       :old.RYLB,
       :old.AGE,
       :old.KHBH,
       :old.XM,
       :old.AAC058,
       :old.AAC147,
       :old.SCZT,
       :old.XB,
       :old.CSRQ,
       :old.SWRQ,
       :old.ZZBZ,
       :old.ZYDJ,
       :old.ZYDM,
       :old.GH,
       :old.KHYH,
       :old.ZHMC,
       :old.YHZH,
       :old.KHHSZS,
       :old.KHHSZSHI,
       :old.FWTT,
       :old.FWTTMC,
       :old.FWZTTBH,
       :old.BMBH,
       :old.BMMC,
       :old.YBBS,
       :old.YBKH,
       :old.YBD,
       :old.GZDJZD,
       :old.HYZK,
       :old.EMAIL,
       :old.SJH,
       :old.YX,
       :old.XGBZ,
       seqid);
  else
    op_type := HISTORY_UTIL.OPTYPE_DELETE;
    pk_values(pk_values.count + 1) := any_type('KHID',
                                               'number',
                                               null,
                                               :old.KHID,
                                               null);
    c_values(c_values.count + 1) := any_type('BBRTBYD',
                                             'string',
                                             :old.BBRTBYD,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('GZDXZQH',
                                             'string',
                                             :old.GZDXZQH,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('YBDXZQH',
                                             'string',
                                             :old.YBDXZQH,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('JZDXZQH',
                                             'string',
                                             :old.JZDXZQH,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('SFMZZYGYED',
                                             'string',
                                             :old.SFMZZYGYED,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('BGSJ',
                                             'number',
                                             null,
                                             :old.BGSJ,
                                             null);
    c_values(c_values.count + 1) := any_type('CZSJ',
                                             'date',
                                             null,
                                             null,
                                             :old.CZSJ);
    c_values(c_values.count + 1) := any_type('BANKCODE',
                                             'string',
                                             :old.BANKCODE,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('BANKSELFCODE',
                                             'string',
                                             :old.BANKSELFCODE,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('SEQLOGID',
                                             'number',
                                             null,
                                             :old.SEQLOGID,
                                             null);
    c_values(c_values.count + 1) := any_type('BXGSID',
                                             'number',
                                             null,
                                             :old.BXGSID,
                                             null);
    c_values(c_values.count + 1) := any_type('RYLB',
                                             'string',
                                             :old.RYLB,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('AGE',
                                             'number',
                                             null,
                                             :old.AGE,
                                             null);
    c_values(c_values.count + 1) := any_type('KHBH',
                                             'string',
                                             :old.KHBH,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('XM',
                                             'string',
                                             :old.XM,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('AAC058',
                                             'string',
                                             :old.AAC058,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('AAC147',
                                             'string',
                                             :old.AAC147,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('SCZT',
                                             'string',
                                             :old.SCZT,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('XB',
                                             'string',
                                             :old.XB,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('CSRQ',
                                             'number',
                                             null,
                                             :old.CSRQ,
                                             null);
    c_values(c_values.count + 1) := any_type('SWRQ',
                                             'number',
                                             null,
                                             :old.SWRQ,
                                             null);
    c_values(c_values.count + 1) := any_type('ZZBZ',
                                             'string',
                                             :old.ZZBZ,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('ZYDJ',
                                             'string',
                                             :old.ZYDJ,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('ZYDM',
                                             'string',
                                             :old.ZYDM,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('GH',
                                             'string',
                                             :old.GH,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('KHYH',
                                             'string',
                                             :old.KHYH,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('ZHMC',
                                             'string',
                                             :old.ZHMC,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('YHZH',
                                             'string',
                                             :old.YHZH,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('KHHSZS',
                                             'string',
                                             :old.KHHSZS,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('KHHSZSHI',
                                             'string',
                                             :old.KHHSZSHI,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('FWTT',
                                             'string',
                                             :old.FWTT,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('FWTTMC',
                                             'string',
                                             :old.FWTTMC,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('FWZTTBH',
                                             'string',
                                             :old.FWZTTBH,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('BMBH',
                                             'string',
                                             :old.BMBH,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('BMMC',
                                             'string',
                                             :old.BMMC,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('YBBS',
                                             'string',
                                             :old.YBBS,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('YBKH',
                                             'string',
                                             :old.YBKH,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('YBD',
                                             'string',
                                             :old.YBD,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('GZDJZD',
                                             'string',
                                             :old.GZDJZD,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('HYZK',
                                             'string',
                                             :old.HYZK,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('EMAIL',
                                             'string',
                                             :old.EMAIL,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('SJH',
                                             'string',
                                             :old.SJH,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('YX',
                                             'number',
                                             null,
                                             :old.YX,
                                             null);
    c_values(c_values.count + 1) := any_type('XGBZ',
                                             'string',
                                             :old.XGBZ,
                                             null,
                                             null);
    insert into H_TB_KHXX
      (KHID,
       BBRTBYD,
       GZDXZQH,
       YBDXZQH,
       JZDXZQH,
       SFMZZYGYED,
       BGSJ,
       CZSJ,
       BANKCODE,
       BANKSELFCODE,
       SEQLOGID,
       BXGSID,
       RYLB,
       AGE,
       KHBH,
       XM,
       AAC058,
       AAC147,
       SCZT,
       XB,
       CSRQ,
       SWRQ,
       ZZBZ,
       ZYDJ,
       ZYDM,
       GH,
       KHYH,
       ZHMC,
       YHZH,
       KHHSZS,
       KHHSZSHI,
       FWTT,
       FWTTMC,
       FWZTTBH,
       BMBH,
       BMMC,
       YBBS,
       YBKH,
       YBD,
       GZDJZD,
       HYZK,
       EMAIL,
       SJH,
       YX,
       XGBZ,
       NEW_SEQLOGID)
    values
      (:old.KHID,
       :old.BBRTBYD,
       :old.GZDXZQH,
       :old.YBDXZQH,
       :old.JZDXZQH,
       :old.SFMZZYGYED,
       :old.BGSJ,
       :old.CZSJ,
       :old.BANKCODE,
       :old.BANKSELFCODE,
       :old.SEQLOGID,
       :old.BXGSID,
       :old.RYLB,
       :old.AGE,
       :old.KHBH,
       :old.XM,
       :old.AAC058,
       :old.AAC147,
       :old.SCZT,
       :old.XB,
       :old.CSRQ,
       :old.SWRQ,
       :old.ZZBZ,
       :old.ZYDJ,
       :old.ZYDM,
       :old.GH,
       :old.KHYH,
       :old.ZHMC,
       :old.YHZH,
       :old.KHHSZS,
       :old.KHHSZSHI,
       :old.FWTT,
       :old.FWTTMC,
       :old.FWZTTBH,
       :old.BMBH,
       :old.BMMC,
       :old.YBBS,
       :old.YBKH,
       :old.YBD,
       :old.GZDJZD,
       :old.HYZK,
       :old.EMAIL,
       :old.SJH,
       :old.YX,
       :old.XGBZ,
       seqid);
  end if;
  HISTORY_UTIL.to_history(op_type, 'TB_KHXX', pk_values, c_values, 1);

  if op_type in ('2', '3') then
  
    select count(1)
      into v_flag
      from tb_fdxx a, tb_bdxx b /*,tb_khxx c */
     where a.bdid = b.bdid
       and a.bbrkhid /*=c.khid and c.khid*/
           = :Old.khid
       and (a.tbdh like 'ZFB%' or exists
            (select 'x'
               from tb_ttfwbzxx b
              where b.ttid = a.ttid
                and b.yjlx like '%4%'));
    if v_flag > 0 then
      select max(case
                   when exists (select 'x'
                           from tb_fdxx a, tb_bdxx b
                          where b.ttid = a.ttid
                            and b.tbdh like 'ZFB%'
                            and a.bbrkhid = :Old.khid) and exists
                    (select 'x'
                           from tb_fdxx a, tb_ttfwbzxx b
                          where b.ttid = a.ttid
                            and b.yjlx like '%4%'
                            and a.bbrkhid = :Old.khid) then
                    'A'
                   when not exists (select 'x'
                           from tb_fdxx a, tb_bdxx b
                          where b.ttid = a.ttid
                            and b.tbdh like 'ZFB%'
                            and a.bbrkhid = :Old.khid) and exists
                    (select 'x'
                           from tb_fdxx a, tb_ttfwbzxx b
                          where b.ttid = a.ttid
                            and b.yjlx like '%4%'
                            and a.bbrkhid = :Old.khid) then
                    'F'
                   when exists (select 'x'
                           from tb_fdxx a, tb_bdxx b
                          where b.ttid = a.ttid
                            and b.tbdh like 'ZFB%'
                            and a.bbrkhid = :Old.khid) and not exists
                    (select 'x'
                           from tb_fdxx a, tb_ttfwbzxx b
                          where b.ttid = a.ttid
                            and b.yjlx like '%4%'
                            and a.bbrkhid = :Old.khid) then
                    'Z'
                   else
                    'Z'
                 end)
        into rec_SYNCDATA.Sys_Type
        from dual z
      /*        where  z.khid= case when op_type in('1','2') then :New.khid else :Old.khid end*/
      ;
      if v_flag >= 1 then
        select case
                 when op_type = '1' then
                  'A'
                 when op_type = '2' then
                  'U'
                 else
                  'D'
               end,
               SEQ_OPTID.Nextval,
               sysdate,
               '5' as Opt_Object
          into rec_SYNCDATA.Op_Type,
               rec_SYNCDATA.Opt_Id,
               rec_SYNCDATA.Opt_Datetime,
               rec_SYNCDATA.Opt_Object
          from dual;
      
        rec_SYNCDATA.content := '{';
        if rec_SYNCDATA.Op_Type in ('A', 'U') then
          rec_SYNCDATA.Object_Id := :new.khid;
        
          select khbdh,
                 (select max(ttbh) from tb_ttxx where ttid = f.ttid),
                 (select bxgsid from tb_bdxx where bdid = f.bdid),
                 (select c.bxgsqc
                    from tb_bdxx b, tb_bxgsxx c
                   where b.bdid = f.bdid
                     and b.bxgsid = c.bxgsid)
            into v_bxgsid, rec_khxx.fwtt, rec_khxx.khid, rec_khxx.xm
            from tb_fdxx f
           where f.fdid =
                 (select max(fdid) from tb_fdxx where bbrkhid = :Old.khid);
        
          rec_SYNCDATA.content := rec_SYNCDATA.content || '"khid":"' ||
                                  to_char(:New.khid) || '","xm":"' ||
                                  to_char(:New.xm) || '","sjh":"' ||
                                  to_char(:New.sjh);
          rec_SYNCDATA.content := rec_SYNCDATA.content || '","email":"' ||
                                  :New.email || '","aac147":"' ||
                                  :New.aac147 || '","aac058":"' ||
                                  to_char(:New.aac058)|| '","rylb":"' ||
                                  to_char(:New.rylb);
          rec_SYNCDATA.content := rec_SYNCDATA.content || '","ttbh":"' ||
                                  to_char(rec_khxx.fwtt) || '","xb":"' ||
                                  to_char(:New.xb) || '","cardno":"' ||
                                  :New.aac147 || '","khbdh":"' || v_bxgsid ||
                                  '","bxgsid":"' || to_char(rec_khxx.khid) ||
                                  '","bxgsqc":"' || rec_khxx.xm || '"';
          rec_SYNCDATA.content := rec_SYNCDATA.content || '}';
        else
          rec_SYNCDATA.content := rec_SYNCDATA.content || '"khid":"' ||
                                  to_char(:Old.khid) || '"';
        end if;
        rec_SYNCDATA.content := rec_SYNCDATA.content || '}';
        SP_GEN_SYNCDATA(v_ret_code, v_ret_msg, rec_SYNCDATA); --调用共用的中间表生成程序
      
      end if;
    end if;
  end if;
end;
/
