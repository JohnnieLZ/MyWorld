CREATE TRIGGER TR_RB_KHGX
BEFORE INSERT OR UPDATE OR DELETE
  ON KHGX
FOR EACH ROW
  declare
  op_type   number;
  pk_values HISTORY_UTIL.ant_type_table;
  c_values  HISTORY_UTIL.ant_type_table;
  seqid     number;
  action    number;
  rec_SYNCDATA TB_YFZFB_SYNCDATA%rowtype;
  v_ret_code varchar2(10) := 'E';
  v_ret_MSG  varchar2(10) := 'ERROR';
begin
  HISTORY_UTIL.get_sequence(seqid, action);
  /*
  if action = HISTORY_UTIL.ACTION_ROLLBACK then
    return;
  end if;*/
  if inserting then
    op_type := HISTORY_UTIL.OPTYPE_INSERT;
    pk_values(pk_values.count + 1) := any_type('GXID',
                                               'number',
                                               null,
                                               :new.GXID,
                                               null);
    :new.SEQLOGID := seqid;
  elsif updating then
    op_type := HISTORY_UTIL.OPTYPE_UPDATE;
    pk_values(pk_values.count + 1) := any_type('GXID',
                                               'number',
                                               null,
                                               :old.GXID,
                                               null);
    if history_util.bool_xor(:new.KHID is null, :old.KHID is null) or
       :new.KHID != :old.KHID then
      c_values(c_values.count + 1) := any_type('KHID',
                                               'number',
                                               null,
                                               :old.KHID,
                                               null);
    end if;
    if history_util.bool_xor(:new.YYID is null, :old.YYID is null) or
       :new.YYID != :old.YYID then
      c_values(c_values.count + 1) := any_type('YYID',
                                               'number',
                                               null,
                                               :old.YYID,
                                               null);
    end if;
    if history_util.bool_xor(:new.YSID is null, :old.YSID is null) or
       :new.YSID != :old.YSID then
      c_values(c_values.count + 1) := any_type('YSID',
                                               'number',
                                               null,
                                               :old.YSID,
                                               null);
    end if;
    if history_util.bool_xor(:new.JBID is null, :old.JBID is null) or
       :new.JBID != :old.JBID then
      c_values(c_values.count + 1) := any_type('JBID',
                                               'number',
                                               null,
                                               :old.JBID,
                                               null);
    end if;
    if history_util.bool_xor(:new.YPID is null, :old.YPID is null) or
       :new.YPID != :old.YPID then
      c_values(c_values.count + 1) := any_type('YPID',
                                               'number',
                                               null,
                                               :old.YPID,
                                               null);
    end if;
    if history_util.bool_xor(:new.BDID is null, :old.BDID is null) or
       :new.BDID != :old.BDID then
      c_values(c_values.count + 1) := any_type('BDID',
                                               'number',
                                               null,
                                               :old.BDID,
                                               null);
    end if;
    if history_util.bool_xor(:new.QYSJ is null, :old.QYSJ is null) or
       :new.QYSJ != :old.QYSJ then
      c_values(c_values.count + 1) := any_type('QYSJ',
                                               'number',
                                               null,
                                               :old.QYSJ,
                                               null);
    end if;
    if history_util.bool_xor(:new.AZDD is null, :old.AZDD is null) or
       :new.AZDD != :old.AZDD then
      c_values(c_values.count + 1) := any_type('AZDD',
                                               'string',
                                               :old.AZDD,
                                               null,
                                               null);
    end if;
    :new.SEQLOGID := seqid;
    if history_util.bool_xor(:new.SEQLOGID is null, :old.SEQLOGID is null) or
       :new.SEQLOGID != :old.SEQLOGID then
      c_values(c_values.count + 1) := any_type('SEQLOGID',
                                               'number',
                                               null,
                                               :old.SEQLOGID,
                                               null);
    end if;
    insert into H_KHGX
      (GXID,
       KHID,
       YYID,
       YSID,
       JBID,
       YPID,
       BDID,
       QYSJ,
       AZDD,
       SEQLOGID,
       NEW_SEQLOGID)
    values
      (:old.GXID,
       :old.KHID,
       :old.YYID,
       :old.YSID,
       :old.JBID,
       :old.YPID,
       :old.BDID,
       :old.QYSJ,
       :old.AZDD,
       :old.SEQLOGID,
       seqid);
  else
    op_type := HISTORY_UTIL.OPTYPE_DELETE;
    pk_values(pk_values.count + 1) := any_type('GXID',
                                               'number',
                                               null,
                                               :old.GXID,
                                               null);
    c_values(c_values.count + 1) := any_type('KHID',
                                             'number',
                                             null,
                                             :old.KHID,
                                             null);
    c_values(c_values.count + 1) := any_type('YYID',
                                             'number',
                                             null,
                                             :old.YYID,
                                             null);
    c_values(c_values.count + 1) := any_type('YSID',
                                             'number',
                                             null,
                                             :old.YSID,
                                             null);
    c_values(c_values.count + 1) := any_type('JBID',
                                             'number',
                                             null,
                                             :old.JBID,
                                             null);
    c_values(c_values.count + 1) := any_type('YPID',
                                             'number',
                                             null,
                                             :old.YPID,
                                             null);
    c_values(c_values.count + 1) := any_type('BDID',
                                             'number',
                                             null,
                                             :old.BDID,
                                             null);
    c_values(c_values.count + 1) := any_type('QYSJ',
                                             'number',
                                             null,
                                             :old.QYSJ,
                                             null);
    c_values(c_values.count + 1) := any_type('AZDD',
                                             'string',
                                             :old.AZDD,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('SEQLOGID',
                                             'number',
                                             null,
                                             :old.SEQLOGID,
                                             null);
    insert into H_KHGX
      (GXID,
       KHID,
       YYID,
       YSID,
       JBID,
       YPID,
       BDID,
       QYSJ,
       AZDD,
       SEQLOGID,
       NEW_SEQLOGID)
    values
      (:old.GXID,
       :old.KHID,
       :old.YYID,
       :old.YSID,
       :old.JBID,
       :old.YPID,
       :old.BDID,
       :old.QYSJ,
       :old.AZDD,
       :old.SEQLOGID,
       seqid);
  end if;
  HISTORY_UTIL.to_history(op_type, 'KHGX', pk_values, c_values, 1);
    select case
           when op_type = '1' then
            'A'
           when op_type = '2' then
            'U'
           else
            'D'
         end,
         SEQ_OPTID.Nextval,
         sysdate,
         '1' as Opt_Object,
         'A' as sys_type
    into rec_SYNCDATA.Op_Type,
         rec_SYNCDATA.Opt_Id,
         rec_SYNCDATA.Opt_Datetime,
         rec_SYNCDATA.Opt_Object,
         rec_SYNCDATA.Sys_Type
    from dual;
  rec_SYNCDATA.content := '{';
  if rec_SYNCDATA.Op_Type in ('A', 'U') then
    rec_SYNCDATA.Object_Id := :new.gxid;
    rec_SYNCDATA.content   := rec_SYNCDATA.content || '"gxid":"' ||
                              to_char(:New.gxid) || '","khid":"' ||
                              to_char(:New.khid) || '","yyid":"' ||
                              to_char(:New.yyid)|| '","ysid":"' ||
                              to_char(:New.ysid)|| '","jbid":"' ||
                              to_char(:New.jbid);
    rec_SYNCDATA.content   := rec_SYNCDATA.content || '","ypid":"' ||
                              to_char(:New.ypid)|| '","bdid":"' ||
                              to_char(:New.bdid)|| '","qysj":"' ||
                              to_char(:New.qysj)|| '","azdd":"' ||
                              to_char(:New.azdd)|| '","seqlogid":"' ||
                              to_char(:New.seqlogid) || '"';
  else
    rec_SYNCDATA.content := rec_SYNCDATA.content || '"yyid":"' ||
                            to_char(:New.yyid) || '"';
  end if;
  rec_SYNCDATA.content := rec_SYNCDATA.content || '}';
  SP_GEN_SYNCDATA(v_ret_code, v_ret_MSG, rec_SYNCDATA); --调用共用的中间表生成程序
end;
/
