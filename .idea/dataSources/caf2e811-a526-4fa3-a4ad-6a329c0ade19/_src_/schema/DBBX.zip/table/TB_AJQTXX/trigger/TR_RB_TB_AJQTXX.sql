CREATE TRIGGER TR_RB_TB_AJQTXX
BEFORE INSERT OR UPDATE OR DELETE
  ON TB_AJQTXX
FOR EACH ROW
  declare
  op_type   number;
  pk_values HISTORY_UTIL.ant_type_table;
  c_values  HISTORY_UTIL.ant_type_table;
  seqid     number;
  action    number;
begin
  HISTORY_UTIL.get_sequence(seqid, action);
  if action = HISTORY_UTIL.ACTION_ROLLBACK then
    return;
  end if;
  if inserting then
    op_type := HISTORY_UTIL.OPTYPE_INSERT;
    pk_values(pk_values.count + 1) := any_type('AJID',
                                               'number',
                                               null,
                                               :new.AJID,
                                               null);
    :new.SEQLOGID := seqid;
  elsif updating then
    op_type := HISTORY_UTIL.OPTYPE_UPDATE;
    pk_values(pk_values.count + 1) := any_type('AJID',
                                               'number',
                                               null,
                                               :old.AJID,
                                               null);
    :new.SEQLOGID := seqid;
    if history_util.bool_xor(:new.SEQLOGID is null, :old.SEQLOGID is null) or
       :new.SEQLOGID != :old.SEQLOGID then
      c_values(c_values.count + 1) := any_type('SEQLOGID',
                                               'number',
                                               null,
                                               :old.SEQLOGID,
                                               null);
    end if;
    if history_util.bool_xor(:new.SQRXB is null, :old.SQRXB is null) or
       :new.SQRXB != :old.SQRXB then
      c_values(c_values.count + 1) := any_type('SQRXB',
                                               'string',
                                               :old.SQRXB,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.SQRYB is null, :old.SQRYB is null) or
       :new.SQRYB != :old.SQRYB then
      c_values(c_values.count + 1) := any_type('SQRYB',
                                               'string',
                                               :old.SQRYB,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.AAC058 is null, :old.AAC058 is null) or
       :new.AAC058 != :old.AAC058 then
      c_values(c_values.count + 1) := any_type('AAC058',
                                               'string',
                                               :old.AAC058,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.AAC004 is null, :old.AAC004 is null) or
       :new.AAC004 != :old.AAC004 then
      c_values(c_values.count + 1) := any_type('AAC004',
                                               'string',
                                               :old.AAC004,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.BARQ is null, :old.BARQ is null) or
       :new.BARQ != :old.BARQ then
      c_values(c_values.count + 1) := any_type('BARQ',
                                               'number',
                                               null,
                                               :old.BARQ,
                                               null);
    end if;
    if history_util.bool_xor(:new.CXRQ is null, :old.CXRQ is null) or
       :new.CXRQ != :old.CXRQ then
      c_values(c_values.count + 1) := any_type('CXRQ',
                                               'number',
                                               null,
                                               :old.CXRQ,
                                               null);
    end if;
    if history_util.bool_xor(:new.CCJZRQ is null, :old.CCJZRQ is null) or
       :new.CCJZRQ != :old.CCJZRQ then
      c_values(c_values.count + 1) := any_type('CCJZRQ',
                                               'number',
                                               null,
                                               :old.CCJZRQ,
                                               null);
    end if;
    if history_util.bool_xor(:new.CXJG is null, :old.CXJG is null) or
       :new.CXJG != :old.CXJG then
      c_values(c_values.count + 1) := any_type('CXJG',
                                               'string',
                                               :old.CXJG,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.SCJDRQ is null, :old.SCJDRQ is null) or
       :new.SCJDRQ != :old.SCJDRQ then
      c_values(c_values.count + 1) := any_type('SCJDRQ',
                                               'number',
                                               null,
                                               :old.SCJDRQ,
                                               null);
    end if;
    if history_util.bool_xor(:new.LKRLX is null, :old.LKRLX is null) or
       :new.LKRLX != :old.LKRLX then
      c_values(c_values.count + 1) := any_type('LKRLX',
                                               'string',
                                               :old.LKRLX,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.SQLX2 is null, :old.SQLX2 is null) or
       :new.SQLX2 != :old.SQLX2 then
      c_values(c_values.count + 1) := any_type('SQLX2',
                                               'string',
                                               :old.SQLX2,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.SYRSL is null, :old.SYRSL is null) or
       :new.SYRSL != :old.SYRSL then
      c_values(c_values.count + 1) := any_type('SYRSL',
                                               'number',
                                               null,
                                               :old.SYRSL,
                                               null);
    end if;
    if history_util.bool_xor(:new.BBRZJYXQS is null, :old.BBRZJYXQS is null) or
       :new.BBRZJYXQS != :old.BBRZJYXQS then
      c_values(c_values.count + 1) := any_type('BBRZJYXQS',
                                               'number',
                                               null,
                                               :old.BBRZJYXQS,
                                               null);
    end if;
    if history_util.bool_xor(:new.BBRZJYXQZ is null, :old.BBRZJYXQZ is null) or
       :new.BBRZJYXQZ != :old.BBRZJYXQZ then
      c_values(c_values.count + 1) := any_type('BBRZJYXQZ',
                                               'number',
                                               null,
                                               :old.BBRZJYXQZ,
                                               null);
    end if;
    if history_util.bool_xor(:new.SQRZJYXQS is null, :old.SQRZJYXQS is null) or
       :new.SQRZJYXQS != :old.SQRZJYXQS then
      c_values(c_values.count + 1) := any_type('SQRZJYXQS',
                                               'number',
                                               null,
                                               :old.SQRZJYXQS,
                                               null);
    end if;
    if history_util.bool_xor(:new.SQRZJYXQZ is null, :old.SQRZJYXQZ is null) or
       :new.SQRZJYXQZ != :old.SQRZJYXQZ then
      c_values(c_values.count + 1) := any_type('SQRZJYXQZ',
                                               'number',
                                               null,
                                               :old.SQRZJYXQZ,
                                               null);
    end if;
    if history_util.bool_xor(:new.BBRZY is null, :old.BBRZY is null) or
       :new.BBRZY != :old.BBRZY then
      c_values(c_values.count + 1) := any_type('BBRZY',
                                               'string',
                                               :old.BBRZY,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.BBRGZDW is null, :old.BBRGZDW is null) or
       :new.BBRGZDW != :old.BBRGZDW then
      c_values(c_values.count + 1) := any_type('BBRGZDW',
                                               'string',
                                               :old.BBRGZDW,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.SFYYJSDZYJ is null,
                             :old.SFYYJSDZYJ is null) or
       :new.SFYYJSDZYJ != :old.SFYYJSDZYJ then
      c_values(c_values.count + 1) := any_type('SFYYJSDZYJ',
                                               'string',
                                               :old.SFYYJSDZYJ,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.LPKGFZH is null, :old.LPKGFZH is null) or
       :new.LPKGFZH != :old.LPKGFZH then
      c_values(c_values.count + 1) := any_type('LPKGFZH',
                                               'string',
                                               :old.LPKGFZH,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.LPKGFFH is null, :old.LPKGFFH is null) or
       :new.LPKGFFH != :old.LPKGFFH then
      c_values(c_values.count + 1) := any_type('LPKGFFH',
                                               'string',
                                               :old.LPKGFFH,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.SFXYSCYX is null, :old.SFXYSCYX is null) or
       :new.SFXYSCYX != :old.SFXYSCYX then
      c_values(c_values.count + 1) := any_type('SFXYSCYX',
                                               'string',
                                               :old.SFXYSCYX,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.SCSJ is null, :old.SCSJ is null) or
       :new.SCSJ != :old.SCSJ then
      c_values(c_values.count + 1) := any_type('SCSJ',
                                               'date',
                                               null,
                                               null,
                                               :old.SCSJ);
    end if;
    if history_util.bool_xor(:new.ZIPNAME is null, :old.ZIPNAME is null) or
       :new.ZIPNAME != :old.ZIPNAME then
      c_values(c_values.count + 1) := any_type('ZIPNAME',
                                               'string',
                                               :old.ZIPNAME,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.CSRQ is null, :old.CSRQ is null) or
       :new.CSRQ != :old.CSRQ then
      c_values(c_values.count + 1) := any_type('CSRQ',
                                               'number',
                                               null,
                                               :old.CSRQ,
                                               null);
    end if;
    if history_util.bool_xor(:new.FSRQ is null, :old.FSRQ is null) or
       :new.FSRQ != :old.FSRQ then
      c_values(c_values.count + 1) := any_type('FSRQ',
                                               'number',
                                               null,
                                               :old.FSRQ,
                                               null);
    end if;
    if history_util.bool_xor(:new.BBRNL is null, :old.BBRNL is null) or
       :new.BBRNL != :old.BBRNL then
      c_values(c_values.count + 1) := any_type('BBRNL',
                                               'number',
                                               null,
                                               :old.BBRNL,
                                               null);
    end if;
    if history_util.bool_xor(:new.SQRNL is null, :old.SQRNL is null) or
       :new.SQRNL != :old.SQRNL then
      c_values(c_values.count + 1) := any_type('SQRNL',
                                               'number',
                                               null,
                                               :old.SQRNL,
                                               null);
    end if;
    if history_util.bool_xor(:new.SQRZY is null, :old.SQRZY is null) or
       :new.SQRZY != :old.SQRZY then
      c_values(c_values.count + 1) := any_type('SQRZY',
                                               'string',
                                               :old.SQRZY,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.BBRSJH is null, :old.BBRSJH is null) or
       :new.BBRSJH != :old.BBRSJH then
      c_values(c_values.count + 1) := any_type('BBRSJH',
                                               'string',
                                               :old.BBRSJH,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.SFTJ is null, :old.SFTJ is null) or
       :new.SFTJ != :old.SFTJ then
      c_values(c_values.count + 1) := any_type('SFTJ',
                                               'string',
                                               :old.SFTJ,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.SDR is null, :old.SDR is null) or
       :new.SDR != :old.SDR then
      c_values(c_values.count + 1) := any_type('SDR',
                                               'string',
                                               :old.SDR,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.FBSJ is null, :old.FBSJ is null) or
       :new.FBSJ != :old.FBSJ then
      c_values(c_values.count + 1) := any_type('FBSJ',
                                               'date',
                                               null,
                                               null,
                                               :old.FBSJ);
    end if;
    if history_util.bool_xor(:new.SBSJ is null, :old.SBSJ is null) or
       :new.SBSJ != :old.SBSJ then
      c_values(c_values.count + 1) := any_type('SBSJ',
                                               'date',
                                               null,
                                               null,
                                               :old.SBSJ);
    end if;
    if history_util.bool_xor(:new.AJWTLX is null, :old.AJWTLX is null) or
       :new.AJWTLX != :old.AJWTLX then
      c_values(c_values.count + 1) := any_type('AJWTLX',
                                               'string',
                                               :old.AJWTLX,
                                               null,
                                               null);
    end if;
    if history_util.bool_xor(:new.SSYSJ is null, :old.SSYSJ is null) or
       :new.SSYSJ != :old.SSYSJ then
      c_values(c_values.count + 1) := any_type('SSYSJ',
                                               'date',
                                               null,
                                               null,
                                               :old.SSYSJ);
    end if;
    if history_util.bool_xor(:new.LASJFSSJ is null, :old.LASJFSSJ is null) or
       :new.LASJFSSJ != :old.LASJFSSJ then
      c_values(c_values.count + 1) := any_type('LASJFSSJ',
                                               'date',
                                               null,
                                               null,
                                               :old.LASJFSSJ);
    end if;
    if history_util.bool_xor(:new.LASJWJM is null, :old.LASJWJM is null) or
       :new.LASJWJM != :old.LASJWJM then
      c_values(c_values.count + 1) := any_type('LASJWJM',
                                               'string',
                                               :old.LASJWJM,
                                               null,
                                               null);
    end if;
    insert into H_TB_AJQTXX
      (AJID,
       SEQLOGID,
       SQRXB,
       SQRYB,
       AAC058,
       AAC004,
       BARQ,
       CXRQ,
       CCJZRQ,
       CXJG,
       SCJDRQ,
       LKRLX,
       SQLX2,
       SYRSL,
       BBRZJYXQS,
       BBRZJYXQZ,
       SQRZJYXQS,
       SQRZJYXQZ,
       BBRZY,
       BBRGZDW,
       SFYYJSDZYJ,
       LPKGFZH,
       LPKGFFH,
       SFXYSCYX,
       SCSJ,
       ZIPNAME,
       CSRQ,
       FSRQ,
       BBRNL,
       SQRNL,
       SQRZY,
       BBRSJH,
       SFTJ,
       SDR,
       FBSJ,
       SBSJ,
       AJWTLX,
       SSYSJ,
       LASJFSSJ,
       LASJWJM,
       NEW_SEQLOGID)
    values
      (:old.AJID,
       :old.SEQLOGID,
       :old.SQRXB,
       :old.SQRYB,
       :old.AAC058,
       :old.AAC004,
       :old.BARQ,
       :old.CXRQ,
       :old.CCJZRQ,
       :old.CXJG,
       :old.SCJDRQ,
       :old.LKRLX,
       :old.SQLX2,
       :old.SYRSL,
       :old.BBRZJYXQS,
       :old.BBRZJYXQZ,
       :old.SQRZJYXQS,
       :old.SQRZJYXQZ,
       :old.BBRZY,
       :old.BBRGZDW,
       :old.SFYYJSDZYJ,
       :old.LPKGFZH,
       :old.LPKGFFH,
       :old.SFXYSCYX,
       :old.SCSJ,
       :old.ZIPNAME,
       :old.CSRQ,
       :old.FSRQ,
       :old.BBRNL,
       :old.SQRNL,
       :old.SQRZY,
       :old.BBRSJH,
       :old.SFTJ,
       :old.SDR,
       :old.FBSJ,
       :old.SBSJ,
       :old.AJWTLX,
       :old.SSYSJ,
       :old.LASJFSSJ,
       :old.LASJWJM,
       seqid);
  else
    op_type := HISTORY_UTIL.OPTYPE_DELETE;
    pk_values(pk_values.count + 1) := any_type('AJID',
                                               'number',
                                               null,
                                               :old.AJID,
                                               null);
    c_values(c_values.count + 1) := any_type('SEQLOGID',
                                             'number',
                                             null,
                                             :old.SEQLOGID,
                                             null);
    c_values(c_values.count + 1) := any_type('SQRXB',
                                             'string',
                                             :old.SQRXB,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('SQRYB',
                                             'string',
                                             :old.SQRYB,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('AAC058',
                                             'string',
                                             :old.AAC058,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('AAC004',
                                             'string',
                                             :old.AAC004,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('BARQ',
                                             'number',
                                             null,
                                             :old.BARQ,
                                             null);
    c_values(c_values.count + 1) := any_type('CXRQ',
                                             'number',
                                             null,
                                             :old.CXRQ,
                                             null);
    c_values(c_values.count + 1) := any_type('CCJZRQ',
                                             'number',
                                             null,
                                             :old.CCJZRQ,
                                             null);
    c_values(c_values.count + 1) := any_type('CXJG',
                                             'string',
                                             :old.CXJG,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('SCJDRQ',
                                             'number',
                                             null,
                                             :old.SCJDRQ,
                                             null);
    c_values(c_values.count + 1) := any_type('LKRLX',
                                             'string',
                                             :old.LKRLX,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('SQLX2',
                                             'string',
                                             :old.SQLX2,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('SYRSL',
                                             'number',
                                             null,
                                             :old.SYRSL,
                                             null);
    c_values(c_values.count + 1) := any_type('BBRZJYXQS',
                                             'number',
                                             null,
                                             :old.BBRZJYXQS,
                                             null);
    c_values(c_values.count + 1) := any_type('BBRZJYXQZ',
                                             'number',
                                             null,
                                             :old.BBRZJYXQZ,
                                             null);
    c_values(c_values.count + 1) := any_type('SQRZJYXQS',
                                             'number',
                                             null,
                                             :old.SQRZJYXQS,
                                             null);
    c_values(c_values.count + 1) := any_type('SQRZJYXQZ',
                                             'number',
                                             null,
                                             :old.SQRZJYXQZ,
                                             null);
    c_values(c_values.count + 1) := any_type('BBRZY',
                                             'string',
                                             :old.BBRZY,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('BBRGZDW',
                                             'string',
                                             :old.BBRGZDW,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('SFYYJSDZYJ',
                                             'string',
                                             :old.SFYYJSDZYJ,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('LPKGFZH',
                                             'string',
                                             :old.LPKGFZH,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('LPKGFFH',
                                             'string',
                                             :old.LPKGFFH,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('SFXYSCYX',
                                             'string',
                                             :old.SFXYSCYX,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('SCSJ',
                                             'date',
                                             null,
                                             null,
                                             :old.SCSJ);
    c_values(c_values.count + 1) := any_type('ZIPNAME',
                                             'string',
                                             :old.ZIPNAME,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('CSRQ',
                                             'number',
                                             null,
                                             :old.CSRQ,
                                             null);
    c_values(c_values.count + 1) := any_type('FSRQ',
                                             'number',
                                             null,
                                             :old.FSRQ,
                                             null);
    c_values(c_values.count + 1) := any_type('BBRNL',
                                             'number',
                                             null,
                                             :old.BBRNL,
                                             null);
    c_values(c_values.count + 1) := any_type('SQRNL',
                                             'number',
                                             null,
                                             :old.SQRNL,
                                             null);
    c_values(c_values.count + 1) := any_type('SQRZY',
                                             'string',
                                             :old.SQRZY,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('BBRSJH',
                                             'string',
                                             :old.BBRSJH,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('TB_AJQTXX',
                                             'string',
                                             :old.SFTJ,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('SDR',
                                             'string',
                                             :old.SDR,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('FBSJ',
                                             'date',
                                             null,
                                             null,
                                             :old.FBSJ);
    c_values(c_values.count + 1) := any_type('SBSJ',
                                             'date',
                                             null,
                                             null,
                                             :old.SBSJ);
    c_values(c_values.count + 1) := any_type('AJWTLX',
                                             'string',
                                             :old.AJWTLX,
                                             null,
                                             null);
    c_values(c_values.count + 1) := any_type('SSYSJ',
                                             'date',
                                             null,
                                             null,
                                             :old.SSYSJ);
    c_values(c_values.count + 1) := any_type('LASJFSSJ',
                                             'date',
                                             null,
                                             null,
                                             :old.LASJFSSJ);
    c_values(c_values.count + 1) := any_type('LASJWJM',
                                             'string',
                                             :old.LASJWJM,
                                             null,
                                             null);
    insert into H_TB_AJQTXX
      (AJID,
       SEQLOGID,
       SQRXB,
       SQRYB,
       AAC058,
       AAC004,
       BARQ,
       CXRQ,
       CCJZRQ,
       CXJG,
       SCJDRQ,
       LKRLX,
       SQLX2,
       SYRSL,
       BBRZJYXQS,
       BBRZJYXQZ,
       SQRZJYXQS,
       SQRZJYXQZ,
       BBRZY,
       BBRGZDW,
       SFYYJSDZYJ,
       LPKGFZH,
       LPKGFFH,
       SFXYSCYX,
       SCSJ,
       ZIPNAME,
       CSRQ,
       FSRQ,
       BBRNL,
       SQRNL,
       SQRZY,
       BBRSJH,
       SFTJ,
       SDR,
       FBSJ,
       SBSJ,
       AJWTLX,
       SSYSJ,
       LASJFSSJ,
       LASJWJM,
       NEW_SEQLOGID)
    values
      (:old.AJID,
       :old.SEQLOGID,
       :old.SQRXB,
       :old.SQRYB,
       :old.AAC058,
       :old.AAC004,
       :old.BARQ,
       :old.CXRQ,
       :old.CCJZRQ,
       :old.CXJG,
       :old.SCJDRQ,
       :old.LKRLX,
       :old.SQLX2,
       :old.SYRSL,
       :old.BBRZJYXQS,
       :old.BBRZJYXQZ,
       :old.SQRZJYXQS,
       :old.SQRZJYXQZ,
       :old.BBRZY,
       :old.BBRGZDW,
       :old.SFYYJSDZYJ,
       :old.LPKGFZH,
       :old.LPKGFFH,
       :old.SFXYSCYX,
       :old.SCSJ,
       :old.ZIPNAME,
       :old.CSRQ,
       :old.FSRQ,
       :old.BBRNL,
       :old.SQRNL,
       :old.SQRZY,
       :old.BBRSJH,
       :old.SFTJ,
       :old.SDR,
       :old.FBSJ,
       :old.SBSJ,
       :old.AJWTLX,
       :old.SSYSJ,
       :old.LASJFSSJ,
       :old.LASJWJM,
       seqid);
  end if;
  HISTORY_UTIL.to_history(op_type, 'TB_AJQTXX', pk_values, c_values, 1);
end;
/
