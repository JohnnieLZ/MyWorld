CREATE VIEW V_DBTJXM AS select aaa102 as sqlx,'0' as zdlx from aa10 where aaa100='SQLX'
      union all   select aaa102 as sqlx,'1' as zdlx from aa10 where aaa100='SQLX'
/
