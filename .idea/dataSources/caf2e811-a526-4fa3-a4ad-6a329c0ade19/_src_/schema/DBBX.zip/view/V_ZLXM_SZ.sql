CREATE VIEW V_ZLXM_SZ AS select '1' as ZLXMLB,
       '诊疗项目' as ZLXMLBNAME,
       ZLXMID,
       XMBM,
       XMMC,
       FYLB DXDM,
       (select aaa103
          from aa10
         where aaa100 = 'FYLB'
           and aaa102 = FYLB) as DXMC,
       ZLXMID as tyid,
       XZQH,
       '' as zfbz,
       null as zfbl,
       '' as pysxbm,
       '' jxbm
  from tb_zlxmxx WHERE XZQH=320500
union all
select '2' as ZLXMLB,
       '基本药品' as ZLXMLBNAME,
       RSBYPID as ZLXMID,
       JBYPBM as XMBM,
       SPMC as XMMC,
       case
         when YPLB = '01' then
          '08'
         when YPLB = '02' then
          '09'
         else
          '10'
       end as DXDM,
       case
         when YPLB = '01' then
          '西药费'
         when YPLB = '02' then
          '中成药费'
         else
          '中草药费'
       end as DXMC,
       YPID as tyid,
       XZQH,
       '' as zfbz,
       null as zfbl,
       '' as pysxbm,
       JXBM as jxbm
  from tb_ypjbxx where xzqh=320500
/
