CREATE TYPE "SPELL_CODE"                                                                                                                                                                                                        as object(spell varchar2(10),code number)

/
