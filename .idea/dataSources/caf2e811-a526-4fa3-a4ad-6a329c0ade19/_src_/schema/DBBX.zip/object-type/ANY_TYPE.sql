CREATE TYPE "ANY_TYPE"                                                                          as object (
    NAME varchar2(30),
    TYPE varchar2(30),
    STRING_VALUE varchar2(4000),
    NUMBER_VALUE number,
    DATE_VALUE date
);


/
