CREATE TYPE "T_SPELLCODE"                                                                                                                                                                                                        is table of spell_code

/
