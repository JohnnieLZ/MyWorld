CREATE package ARRAY_UTIL is

  -- Author  : SUHUALIN
  -- Created : 2008-7-26 1:58:14
  -- Purpose : 数组处理工具包


  -- Public type declarations
  TYPE number_table IS TABLE OF NUMBER
  INDEX BY binary_integer;

  TYPE varchar2_table IS TABLE OF VARCHAR2(2000)
  INDEX BY binary_integer;

  TYPE varchar2_table_table is TABLE OF varchar2_table
  INDEX BY binary_integer;

  -- Public constant declarations

  EMPTY_VARCHAR2_TABLE varchar2_table;
  EMPTY_NUMBER_TABLE number_table;

  -- Public variable declarations
  --<VariableName> <Datatype>;

  -- Public function and procedure declarations
  function split(seperatedString in varchar2,seperator in varchar2,low_bound in integer := 0)
           return varchar2_table;

  function join(array in varchar2_table,seperator in varchar2)
           return varchar2;

  function convert(array in varchar2_table) return number_table;

  function convert(array in number_table) return varchar2_table;

  --转换ARRAY_UTIL包的数组类型为DMBS_SQL包对应的数组类型
  function to_dbms_sql_array(array varchar2_table) return dbms_sql.varchar2_table;
   --转换ARRAY_UTIL包的数组类型为DMBS_SQL包对应的数组类型
  function to_dbms_sql_array(array number_table) return dbms_sql.number_table;
   --转换DMBS_SQL包的数组类型为ARRAY_UTIL包对应的数组类型
  function from_dbms_sql_array(array dbms_sql.varchar2_table) return varchar2_table;
   --转换DMBS_SQL包的数组类型为ARRAY_UTIL包对应的数组类型
  function from_dbms_sql_array(array dbms_sql.number_table) return number_table;

  function get_columns(sql_columns in varchar2,table_name in varchar2,columnsize in integer) return varchar2_table_table;
end ARRAY_UTIL;


/
