CREATE package body ARRAY_UTIL is
    -- Author  : SUHUALIN
    -- Created : 2008-7-26 1:58:14
    -- Purpose :
    v_count int;

 --获取表的列

    SQL_GET_COLUMNS constant varchar2(1000)
                  := 'select a.COLUMN_NAME from user_tab_columns a where a.TABLE_NAME=:table_name';
  --获取表主键字段

    SQL_GET_PK_COLUMNS constant varchar2(1000):=
       'select a.column_name from user_cons_columns a,user_constraints b'
       ||' where a.constraint_name=b.constraint_name and b.CONSTRAINT_TYPE=''P''and b.table_name=:table_name';

    -- Function and procedure implementations
    function split(seperatedString in varchar2,seperator in varchar2,low_bound in integer:=0) return varchar2_table is
         array_result varchar2_table;
         i int:=0;
         j int:=0;
         len int:=0;
         temp varchar2(2000);
    begin
      if seperatedString is null or length(seperatedString)=0 then
         return array_result;
      end if;

      temp:=seperatedString;
      len:=length(seperator);

      while true loop
        i:=instr(temp,seperator);
        if i<=0 then
          exit;
        end if;

        array_result(j+low_bound):=substr(temp,1,i-1);

        temp:=substr(temp,i+len);

        j:=j+1;
      end loop;

      array_result(j+low_bound):=temp;

      return array_result;
    end;

    function join(array in varchar2_table,seperator in varchar2)
             return varchar2 is
         result varchar2(2000);
         i int:=0;
    begin
         result:='';
         if array.count>0 then
           for i in array.first .. array.last loop
               if i>array.first then
                  result:=result||seperator;
               end if;
               result:=result||array(i);
           end loop;
         end if;
         return result;
    end;

   function convert(array varchar2_table) return number_table is
         result number_table;
         i int:=0;
    begin
         if array.count>0 then
           for i in array.first .. array.last loop
               result(i):=to_number(array(i));
           end loop;
         end if;
         return result;
    end;

    function convert(array number_table) return varchar2_table is
         result varchar2_table;
         i int:=0;
    begin
         if array.count>0 then
           for i in array.first .. array.last loop
               result(i):=trim(to_char(array(i)));
           end loop;
         end if;
         return result;
    end;


    function to_dbms_sql_array(array varchar2_table) return dbms_sql.varchar2_table is
         result dbms_sql.varchar2_table;
         i int:=0;
    begin
         if array.count>0 then
           for i in array.first .. array.last loop
               result(i):=array(i);
           end loop;
         end if;
         return result;
    end;

    function to_dbms_sql_array(array number_table) return dbms_sql.number_table is
         result dbms_sql.number_table;
         i int:=0;
    begin
         if array.count>0 then
           for i in array.first .. array.last loop
               result(i):=array(i);
           end loop;
         end if;
         return result;
    end;


    function from_dbms_sql_array(array dbms_sql.varchar2_table) return varchar2_table is
         result varchar2_table;
         i int:=0;
    begin
         if array.count>0 then
           for i in array.first .. array.last loop
               result(i):=array(i);
           end loop;
         end if;
         return result;
    end;


    function from_dbms_sql_array(array dbms_sql.number_table) return number_table is
         result number_table;
         i int:=0;
    begin
         if array.count>0 then
           for i in array.first .. array.last loop
               result(i):=array(i);
           end loop;
         end if;
         return result;
    end;

  function get_columns(sql_columns in varchar2,table_name in varchar2,columnsize in integer)
           return varchar2_table_table is
    type result_type is table of DBMS_SQL.Varchar2_Table INDEX BY binary_integer;
    result_array result_type;

    temp_array varchar2_table;

    result varchar2_table_table;
    v_cursor int;
    i int;
  begin
    for i in 1..columnsize loop
        result_array(i):= to_dbms_sql_array(temp_array);
    end loop;

    v_cursor:=dbms_sql.open_cursor();
    dbms_sql.parse(v_cursor,sql_columns,dbms_sql.native);
    for i in 1..columnsize loop
        dbms_sql.define_array(v_cursor,i,result_array(i),10,1);
    end loop;
    dbms_sql.bind_variable(v_cursor,':table_name',table_name);
    v_count:=dbms_sql.execute(v_cursor);
    loop
         v_count:=dbms_sql.fetch_rows(v_cursor);

         for i in 1..columnsize loop
             dbms_sql.column_value(v_cursor,i,result_array(i));
         end loop;

         exit when v_count!=10;
    end loop;
    dbms_sql.close_cursor(v_cursor);
    for i in 1..columnsize loop
        result(i):=ARRAY_UTIL.from_dbms_sql_array(result_array(i));
    end loop;
    return result;

    exception
    when others then
         if dbms_sql.is_open(v_cursor) then
            dbms_sql.close_cursor(v_cursor);
         end if;

         raise;
  end;


  begin
    -- Initialization
    --<Statement>;
    null;
  end ARRAY_UTIL;


/
