CREATE package body ROLLBACK_UTIL is

  v_count int;

  -------------常量----------------
  --获取表的列

  SQL_GET_COLUMNS constant varchar2(1000)
                  := 'select a.COLUMN_NAME from all_tab_columns a where a.TABLE_NAME=:table_name';
  --获取表主键字段

  SQL_GET_PK_COLUMNS constant varchar2(1000):=
       'select a.column_name from user_cons_columns a,user_constraints b'
       ||' where a.constraint_name=b.constraint_name and b.CONSTRAINT_TYPE=''P''and b.table_name=:table_name';
  --获取子表，返回表名，外键列字串[F1,F2,...]，主键列字串[P1,P2,...]
  SQL_GET_CHILDTABLES  constant varchar2(1000):=
     'select b.table_name,c.column_name as fk_columns,d.column_name as pk_columns'
     ||' from user_constraints a,user_constraints b,user_cons_columns c,user_cons_columns d'
     ||' where a.table_name=upper(:table_name)'
     ||' and a.constraint_name=b.r_constraint_name'
     ||' and c.constraint_name=b.constraint_name'
     ||' and d.constraint_name=a.constraint_name'
     ||' and a.constraint_type=''P'''
     ||' and b.constraint_type=''R'''
     ||' and b.status=''ENABLED'''
     ||' and b.delete_rule=''CASCADE''';

  --获取表列
  function get_columns(sql_columns in varchar2,table_name in varchar2) return ARRAY_UTIL.varchar2_table is
    result_array DBMS_SQL.Varchar2_Table;
    v_cursor int;
  begin
    v_cursor:=dbms_sql.open_cursor();
    dbms_sql.parse(v_cursor,sql_columns,dbms_sql.native);
    dbms_sql.define_array(v_cursor,1,result_array,10,1);
    dbms_sql.bind_variable(v_cursor,':table_name',table_name);
    v_count:=dbms_sql.execute(v_cursor);
    loop
         v_count:=dbms_sql.fetch_rows(v_cursor);
         dbms_sql.column_value(v_cursor,1,result_array);

         exit when v_count!=10;
    end loop;
    dbms_sql.close_cursor(v_cursor);
    return ARRAY_UTIL.from_dbms_sql_array(result_array);


    exception
    when others then
         if dbms_sql.is_open(v_cursor) then
            dbms_sql.close_cursor(v_cursor);
         end if;

         raise;
  end;

  procedure get_child_tables(
            table_name in varchar2
           ,child_table_array out ARRAY_UTIL.varchar2_table
           ,pk_column_array out ARRAY_UTIL.varchar2_table
           ,fk_column_array out ARRAY_UTIL.varchar2_table
  )is
    v_child_tables DBMS_SQL.varchar2_table;
    v_pk_columns DBMS_SQL.varchar2_table;
    v_fk_columns DBMS_SQL.varchar2_table;

    v_cursor int;
  begin
    v_cursor:=dbms_sql.open_cursor();
    dbms_sql.parse(v_cursor,SQL_GET_CHILDTABLES,dbms_sql.native);
    dbms_sql.define_array(v_cursor,1,v_child_tables,10,1);
    dbms_sql.define_array(v_cursor,2,v_fk_columns,10,1);
    dbms_sql.define_array(v_cursor,3,v_pk_columns,10,1);
    dbms_sql.bind_variable(v_cursor,':table_name',table_name);
    v_count:=dbms_sql.execute(v_cursor);
    loop
         v_count:=dbms_sql.fetch_rows(v_cursor);
         dbms_sql.column_value(v_cursor,1,v_child_tables);
         dbms_sql.column_value(v_cursor,2,v_fk_columns);
         dbms_sql.column_value(v_cursor,3,v_pk_columns);

         exit when v_count!=10;
    end loop;
    dbms_sql.close_cursor(v_cursor);

    child_table_array:=ARRAY_UTIL.from_dbms_sql_array(v_child_tables);
    pk_column_array:=ARRAY_UTIL.from_dbms_sql_array(v_pk_columns);
    fk_column_array:=ARRAY_UTIL.from_dbms_sql_array(v_fk_columns);

    exception
    when others then
         if dbms_sql.is_open(v_cursor) then
            dbms_sql.close_cursor(v_cursor);
         end if;

         raise;
  end;

  function execute_update(sql_update in varchar2
           ,varchar2_name_array in ARRAY_UTIL.varchar2_table
           ,varchar2_value_array in ARRAY_UTIL.varchar2_table
           ,number_name_array in ARRAY_UTIL.varchar2_table
           ,number_value_array in ARRAY_UTIL.number_table
           ,seqlog_id in number:=0) return number is
    v_cursor int;
    v_row int;
    i int;
  begin
    v_cursor:=dbms_sql.open_cursor();
    dbms_sql.parse(v_cursor,sql_update,dbms_sql.native);
    if varchar2_name_array.count>0 then
       for i in varchar2_name_array.first..varchar2_name_array.last loop
           dbms_sql.bind_variable(v_cursor,varchar2_name_array(i),varchar2_value_array(i));
       end loop;
    end if;
    if number_name_array.count>0 then
       for i in number_name_array.first..number_name_array.last loop
           dbms_sql.bind_variable(v_cursor,number_name_array(i),number_value_array(i));
       end loop;
    end if;
    if seqlog_id>0 then
        dbms_sql.bind_variable(v_cursor,':seqlog_id',seqlog_id);
    end if;
    v_row:=dbms_sql.execute(v_cursor);

    dbms_sql.close_cursor(v_cursor);
    return v_row;

    exception
    when others then
         if dbms_sql.is_open(v_cursor) then
            dbms_sql.close_cursor(v_cursor);
         end if;

         raise;
  end;

  function execute_update(sql_update in varchar2,varchar2_names in varchar2,varchar2_values in varchar2
           ,number_names in varchar2,number_values in varchar2,seqlog_id in number:=0) return number is
    varchar2_name_array ARRAY_UTIL.varchar2_table;
    varchar2_value_array ARRAY_UTIL.varchar2_table;
    number_name_array ARRAY_UTIL.varchar2_table;
    number_value_array ARRAY_UTIL.number_table;
  begin
    varchar2_name_array:=ARRAY_UTIL.split(varchar2_names,',');
    varchar2_value_array:=ARRAY_UTIL.split(varchar2_values,',');
    number_name_array:=ARRAY_UTIL.split(number_names,',');
    number_value_array:=ARRAY_UTIL.convert(ARRAY_UTIL.split(number_values,','));
    return execute_update(sql_update,varchar2_name_array,varchar2_value_array,number_name_array,number_value_array,seqlog_id);
  end;

  function execute_count(sql_count in varchar2
           ,varchar2_name_array in ARRAY_UTIL.varchar2_table
           ,varchar2_value_array in ARRAY_UTIL.varchar2_table
           ,number_name_array in ARRAY_UTIL.varchar2_table
           ,number_value_array in ARRAY_UTIL.number_table
           ,seqlog_id in number:=0) return number is
    v_cursor int;
    v_row int;
    v_count int;
    i int;
  begin
    v_cursor:=dbms_sql.open_cursor();
    dbms_sql.parse(v_cursor,sql_count,dbms_sql.native);
    dbms_sql.define_column(v_cursor,1,v_count);
    if varchar2_name_array.count>0 then
       for i in varchar2_name_array.first..varchar2_name_array.last loop
           dbms_sql.bind_variable(v_cursor,varchar2_name_array(i),varchar2_value_array(i));
       end loop;
    end if;
    if number_name_array.count>0 then
       for i in number_name_array.first..number_name_array.last loop
           dbms_sql.bind_variable(v_cursor,number_name_array(i),number_value_array(i));
       end loop;
    end if;
    if seqlog_id>0 then
        dbms_sql.bind_variable(v_cursor,':seqlog_id',seqlog_id);
    end if;
    v_row:=dbms_sql.execute(v_cursor);
    v_row:=dbms_sql.fetch_rows(v_cursor);
    dbms_sql.column_value(v_cursor,1,v_count);

    dbms_sql.close_cursor(v_cursor);

    return v_count;

    exception
    when others then
         if dbms_sql.is_open(v_cursor) then
            dbms_sql.close_cursor(v_cursor);
         end if;

         raise;
  end;

  function execute_count(sql_count in varchar2,varchar2_names in varchar2,varchar2_values in varchar2
           ,number_names in varchar2,number_values in varchar2,seqlog_id in number:=0) return number is
    varchar2_name_array ARRAY_UTIL.varchar2_table;
    varchar2_value_array ARRAY_UTIL.varchar2_table;
    number_name_array ARRAY_UTIL.varchar2_table;
    number_value_array ARRAY_UTIL.number_table;
  begin
    varchar2_name_array:=ARRAY_UTIL.split(varchar2_names,',');
    varchar2_value_array:=ARRAY_UTIL.split(varchar2_values,',');
    number_name_array:=ARRAY_UTIL.split(number_names,',');
    number_value_array:=ARRAY_UTIL.convert(ARRAY_UTIL.split(number_values,','));
    return execute_count(sql_count,varchar2_name_array,varchar2_value_array,number_name_array,number_value_array,seqlog_id);
  end;



  --创建回退线索日志
  procedure create_sequencelog(
    pObjectIds in varchar2,--对象标识
    pObjectTypes in varchar2,--对象类型
    pBusinessAction in varchar2,--业务操作
    pOperatorId in varchar2,--用户标识
    pOperatorName in varchar2,--用户姓名
    pIpAddr in varchar2,--客户端IP地址
    pMacAddr in varchar2,--客户端MAC地址
    pOperateTime in out date, --输出操作时间
    pSeqlogId out number, --输出索引编号
    pMemo in varchar2 default null --注释
  ) is
    v_object_id_array ARRAY_UTIL.varchar2_table;
    v_object_type_array ARRAY_UTIL.varchar2_table;

    i int;
  begin
    select seq_rb_sequencelog.nextval into pSeqlogId from dual;
    if pOperateTime is null then
        select sysdate into pOperateTime from dual;
    end if;

    insert into RB_SEQUENCELOG(SEQLOGID,BUSINESS_ACTION,ROLLBACKED,REJECTED,
        OPERATORID,OPERATORNAME,OPERATETIME,IPADDR,MACADDR,MEMO)
    values(pSeqlogId,pBusinessAction,'0','0',pOperatorId,pOperatorName,
        pOperateTime,pIpAddr,pMacAddr,pMemo);

    --创建线索
    add_reference_object(pSeqlogId,pObjectIds,pObjectTypes);

    --创建历史线索
    history_util.create_sequence(pSeqlogId,history_util.ACTION_NORMAL);
  end;

  --完成线索
  procedure complete_sequence(pSeqlogId in number) is
  begin
       history_util.remove_sequence(pSeqlogId);
  end;

  --增加回退线索对象
  procedure add_reference_object(
    pSeqlogId in number,--线索日志编号
    pObjectIds in varchar2,--对象标识
    pObjectTypes in varchar2--对象类型
  )is
    v_object_id_array ARRAY_UTIL.varchar2_table;
    v_object_type_array ARRAY_UTIL.varchar2_table;
  begin
    v_object_id_array:=ARRAY_UTIL.split(pObjectIds,',');
    v_object_type_array:=ARRAY_UTIL.split(pObjectTypes,',');
    if v_object_id_array.count>0 then
      for i in v_object_id_array.first .. v_object_id_array.last loop
         begin
             insert into RB_OBJECT_LIST(OBJECT_ID,OBJECT_TYPE,SEQLOGID)
                  values(v_object_id_array(i),v_object_type_array(i),pSeqlogId);
             exception when others then
                    null;
         end;
      end loop;
    end if;
  end;


  --设置注释
  procedure set_memo(
     pSeqlogId in number,--线索日志编号
     pMemo in varchar2--注释
  ) is
  begin
    update rb_sequencelog a set a.memo=pMemo where a.seqlogid=pSeqlogId;
    exception when others then
          null;
  end;

  --创建回退结果日志
  procedure create_resultlog(
    pSeqlogId in varchar2, --待回退索引日志编号
    pOperatorId in varchar2,--用户标识
    pOperatorName in varchar2,--用户姓名
    pIpAddr in varchar2,--客户端IP地址
    pMacAddr in varchar2,--客户端MAC地址
    pMemo in varchar2,--客户端MAC地址
    pOperateTime in out date, --输出操作时间
    pResultlogId out number --输出结果编号
  ) is

  begin
    select seq_rb_sequencelog.nextval into pResultlogId from dual;

    if pOperateTime is null then
      select sysdate into pOperateTime from dual;
    end if;

    insert into RB_RESULTLOG(RESULTLOGID,SEQLOGID,OPERATORID,OPERATORNAME,OPERATETIME
        ,IPADDR,MACADDR,MEMO)
    values(pResultlogId,pSeqlogId,pOperatorId,pOperatorName,pOperateTime,pIpAddr,pMacAddr,pMemo);

    update RB_SEQUENCELOG a set a.rollbacked='1' where a.seqlogid=pSeqlogId;

  end;

    --业务回退
    procedure rollback(
      seqlog_id in number,--回退业务日志编号
      operatorId in varchar2,--操作员标识

      operatorName in varchar2,--操作员姓名

      ipaddr in varchar2,--客户端IP地址
      macaddr in varchar2,--客户端MAC地址
      memo in varchar2,--备注
      operateTime in out date,--操作时间
      resultlogId out number,--结果日志编号
      retcode out integer,--返回代码，0标识成功，其他失败

      errmsg out varchar2,--错误信息
      errdetail out varchar2--错误明细
    )is
    --游标取当前业务日志信息


    cursor cur_seqlog(log_id varchar2) is
           select * from RB_SEQUENCELOG a
           where a.SEQLOGID=log_id
           for update nowait;
    --游标行定义


    row_seqlog cur_seqlog%rowtype;

    cursor cur_business_action(busiatn varchar2) is
      select SELFRELATED,ROLLBACKABLE,TABLELIST,USERULE,RULELIST
      from RB_BUSINESS_ACTION
      where ACTIONCODE=busiatn;

    cursor cur_business_relation(busiatn varchar2) is
      (select a.l_actioncode actioncode FROM RB_BUSINESS_RELATION a where a.r_actioncode=busiatn)
              union
      (select a.r_actioncode actioncode FROM RB_BUSINESS_RELATION a where a.l_actioncode=busiatn);

    v_business_relation_array ARRAY_UTIL.varchar2_table;
    validate_rule_array ARRAY_UTIL.varchar2_table;
    --游标行定义


    row_business_action cur_business_action%rowtype;
    row_business_relation cur_business_relation%rowtype;

    v_busiatn varchar2(10);
    v_userule varchar2(1);
    v_tablelist varchar2(500);
    v_rulelist varchar2(500);

    v_relate_businessaction varchar2(500);

    v_sql_check varchar2(2000); --检查SQL

    v_cursor number; --定义光标
    v_row integer;        --行数
    v_count integer;      -- 统计记录

    v_rule varchar2(30);
    i int:=0;
  begin
    --初始化返回代码


    retcode:=0;

    --判断业务日志存在性

    begin
      open cur_seqlog(seqlog_id);
      fetch cur_seqlog into row_seqlog;
      if cur_seqlog%notfound then
         retcode:=1;
         errmsg:='回退失败';
         errdetail:='对应的日志不存在';
      else
         v_busiatn:=row_seqlog.BUSINESS_ACTION;
         --是否已经回退
         if row_seqlog.ROLLBACKED='1' then
           retcode:=2;
           errmsg:='回退失败';
           errdetail:='在您执行回退操作前，该业务已被回退';
         end if;
      end if;
      close cur_seqlog;

      exception when others then
          retcode:=9;
          errmsg:='回退失败';
          errdetail:='该业务正处于回退操作中';
    end;
    if retcode>0 then
      return;
    end if;

    --业务类型
    open cur_business_action(v_busiatn);
    fetch cur_business_action into row_business_action;
    if cur_business_action%notfound then
       retcode:=1;
       errmsg:='回退失败';
       errdetail:='对应的业务类型不存在';
       return;
    else
      v_userule:=row_business_action.USERULE;
      v_tablelist:=row_business_action.TABLELIST;
      v_rulelist:=row_business_action.RULELIST;
      --将自我关联加入到关联列表中

      if row_business_action.selfrelated='1' then
         v_business_relation_array(v_business_relation_array.count):=v_busiatn;
      end if;
    end if;
    close cur_business_action;

    open cur_business_relation(v_busiatn);
    loop
      fetch cur_business_relation into row_business_relation;
      exit when cur_business_relation%NOTFOUND;
      v_business_relation_array(v_business_relation_array.count):=row_business_relation.actioncode;
    end loop;
    close cur_business_relation;


      --取当前操作对象最后业务的日志编号，判断是否可回退
      v_cursor:=dbms_sql.open_cursor; --为处理打开光标

      v_sql_check:='select count(*) from RB_SEQUENCELOG a,RB_OBJECT_LIST b,RB_OBJECT_LIST c'
       ||' where b.SEQLOGID=a.SEQLOGID and a.ROLLBACKED=''0'' and a.SEQLOGID>:seqlog_id'
       ||' and c.SEQLOGID=:seqlog_id and b.OBJECT_ID=c.OBJECT_ID and b.OBJECT_TYPE=c.OBJECT_TYPE';

      if v_business_relation_array.count>0 then
         v_sql_check:=v_sql_check||' and a.BUSINESS_ACTION in('''||
         ARRAY_UTIL.join(v_business_relation_array,''',''')||''')';
      end if;

      v_count:=v_business_relation_array.count;
      if v_count>0 then --如果不存在业务关联，则不做判断

        dbms_sql.parse(v_cursor,v_sql_check,dbms_sql.native);
        dbms_sql.define_column(v_cursor,1,v_count);

        dbms_sql.bind_variable(v_cursor,':seqlog_id',seqlog_id); --绑定变量
        v_row:=dbms_sql.execute(v_cursor);
        v_row:=dbms_sql.fetch_rows(v_cursor);
        dbms_sql.column_value(v_cursor,1,v_count);

        dbms_sql.close_cursor(v_cursor);
      end if;

      if v_count>0 then
         retcode:=3;
         errmsg:='回退失败';
         errdetail:='业务已经发生变更，无法回退';
         return;
      end if;

      --从规则串抽取规则数组
      if v_userule='1' then
        if v_rulelist is not null and length(trim(v_rulelist))!=0 then
           validate_rule_array:=ARRAY_UTIL.split(v_rulelist,',');
           for i in validate_rule_array.first..validate_rule_array.last loop
              v_rule:=trim(upper(validate_rule_array(i)));
              v_sql_check:='begin '||v_rule||'(:seqlog_id,:retcode,:errmsg); end;';
              EXECUTE IMMEDIATE v_sql_check using in seqlog_id,out retcode,out errdetail;
              if retcode!=0 then
                 errmsg:='回退失败';
                 return;
              end if;
           end loop;
        end if;
      end if;

  create_resultlog(seqlog_id,operatorId,operatorName,ipaddr,macaddr,memo,operateTime,resultlogId);
  history_util.rollback(seqlog_id,resultlogId);

  exception
  when others then
       if cur_business_action%ISOPEN then
          close cur_business_action;
       end if;
       if cur_seqlog%ISOPEN then
          close cur_seqlog;
       end if;
       if dbms_sql.is_open(v_cursor) then
          dbms_sql.close_cursor(v_cursor); --关闭光标;
       end if;

       raise;
  end;

begin
  --初始化代码

  null;
end ROLLBACK_UTIL;
/
