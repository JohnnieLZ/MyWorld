CREATE package LONGCODEC_UTIL is

  --获取CLOB字节长度
  function clobByteLength(c in clob) return number;

  --编码字符串到CLOB
  function encode(
           str in varchar2 --编码字符串
           ,c in clob default null --目标CLOB
  ) return clob;--返回结果CLOB

  --编码CLOB字符串到CLOB
  function encodeClob(
           str in clob --编码CLOB
           ,c in clob default null --目标CLOB
  ) return clob; --返回结果CLOB

  --将二维数组编码为一个字符串，结果为CLOB
  function encodeRecords(
           array_values in CODEC_UTIL.varchar2_table_table --二维字符串数组表示的记录集
           ,recordSperator in varchar2 default null --记录分隔字符
           ,fieldSeperator in varchar2 default null --字段分隔字符
           ,c in clob default null --目标CLOB
  ) return clob;--返回结果CLOB

  --将一维数组编码为一个字符串，结果为CLOB
  function encodeRecord(
           array_values in CODEC_UTIL.varchar2_table --以为字符串数组表示的记录
           ,fieldSeperator in varchar2 default null --字段分隔字符
           ,c in clob default null --目标CLOB
  ) return clob;--返回结果CLOB

  --将二维维数组编码为一个列表字符串，结果为CLOB
  function encodeList(
           array_values in CODEC_UTIL.varchar2_table_table --二维字符串数组表示的记录集
           ,listSeperator in varchar2 --列表分隔字符，如$$records$$
           ,recordSperator in varchar2 default null --记录分隔字符
           ,fieldSeperator in varchar2 default null --字段分隔字符
           ,c in clob default null --目标CLOB
  ) return clob;--返回结果CLOB

  --包装字符串为指定长度，补足长度用空格填充
  function encodeString(
           rawString in varchar2 --原字符串
           ,fixsize in integer --补足长度
           ,fix in varchar2:=' ' --补足字符
  ) return varchar2;--返回补足长度字符串

  --包装数字为指定长度字串，不足长度前补0
  function encodeNumber(
           rawNumber in number  --原数字
           ,fixsize in integer  --补足长度，含小数点
           ,scale in integer:=0 --小数点位数
  ) return varchar2;--返回补足长度数字字符串

  --将数字包装为指定长度的16进制大写字串
  function encodeNumber16(
           rawNumber in integer  --原数字
           ,fixsize in integer:=8 --补足长度
  ) return varchar2;--返回结果16进制大写字串

  --解码CLOB记录集合
  function decodeRecords(
           encodeString in clob --编码CLOB字串
           ,offset in out number --偏移量，从1开始
           ,btoffset in out number--字节偏移量，0:正常情况，1:中文字符第二个字节
           ,itemsize in CODEC_UTIL.number_table--字段定义
           ,retcode out integer--结果码,0:成功,其他值:失败
           ,retmsg out varchar2--结果消息,对应失败的错误信息
           ,recordSeperator in varchar2 default null --记录分隔符
           ,fieldSeperator  in varchar2 default null --字段分隔符
  ) return CODEC_UTIL.varchar2_table_table; --返回二维字符串数组

  --解码CLOB单条记录
  function decodeRecord(
           encodeString in clob --编码CLOB字串
           ,offset in out number --偏移量，从1开始
           ,btoffset in out number--字节偏移量，0:正常情况，1:中文字符第二个字节
           ,itemsize in CODEC_UTIL.number_table--字段定义
           ,retcode out integer--结果码,0:成功,其他值:失败
           ,retmsg out varchar2--结果消息,对应失败的错误信息
           ,fieldSeperator  in varchar2 default null --字段分隔符
  ) return CODEC_UTIL.varchar2_table; --返回一维字符串数组

  --解码CLOB单个元素
  function decodeItem(
           encodeString in clob --编码CLOB字串
           ,offset in out number --偏移量，从1开始
           ,btoffset in out number--字节偏移量，0:正常情况，1:中文字符第二个字节
           ,itemsize in number --字段长度
           ,retcode out integer--结果码,0:成功,其他值:失败
           ,retmsg out varchar2--结果消息,对应失败的错误信息
  ) return varchar2; --返回字符串

  --解码CLOB期望字串的单个元素
  function decodeItem(
           encodeString in clob --编码CLOB字串
           ,offset in out number --偏移量，从1开始
           ,btoffset in out number--字节偏移量，0:正常情况，1:中文字符第二个字节
           ,expect in varchar2 --期望字符串
           ,retcode out integer--结果码,0:成功,其他值:失败
           ,retmsg out varchar2--结果消息,对应失败的错误信息
  ) return varchar2; --返回字符串

   --解码CLOB列表
  function decodeList(
           encodeString in clob --编码CLOB字串
           ,offset in out number --偏移量，从1开始
           ,btoffset in out number--字节偏移量，0:正常情况，1:中文字符第二个字节
           ,itemsize in CODEC_UTIL.number_table--字段定义
           ,retcode out integer--结果码,0:成功,其他值:失败
           ,retmsg out varchar2--结果消息,对应失败的错误信息
           ,sizeLength in integer:=8 --指定列表大小的16进制数字位数
           ,recordSeperator in varchar2 default null --记录分隔符
           ,fieldSeperator  in varchar2 default null --字段分隔符
 ) return CODEC_UTIL.varchar2_table_table;

   --解码CLOB列表
  function decodeList(
           encodeString in clob  --编码CLOB字串
           ,listSeperator in varchar2 --记录分隔符
           ,offset in out number --偏移量，从1开始
           ,itemsize in CODEC_UTIL.number_table--字段定义
           ,retcode out integer--结果码,0:成功,其他值:失败
           ,retmsg out varchar2--结果消息,对应失败的错误信息
           ,recordSeperator in varchar2 default null --记录分隔符
           ,fieldSeperator  in varchar2 default null --字段分隔符
  ) return CODEC_UTIL.varchar2_table_table;  --返回二维字符串数组

end LONGCODEC_UTIL;

/
