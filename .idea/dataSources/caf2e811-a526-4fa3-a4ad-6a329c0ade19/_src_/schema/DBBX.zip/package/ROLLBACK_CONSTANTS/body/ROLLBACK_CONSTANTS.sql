CREATE package body ROLLBACK_CONSTANTS is

begin
  -- Initialization
  NULL;
end ROLLBACK_CONSTANTS;

/
