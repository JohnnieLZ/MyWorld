CREATE package body LONGCODEC_UTIL is
  --获取CLOB字节长度
  function clobByteLength(c in clob) return number is
      temp varchar2(2048);
      offset number:=1;
      len number;

      result number:=0;
  begin
      len:=DBMS_LOB.getlength(c);
      if len<>0 then
        loop
            temp:=DBMS_LOB.substr(c,1024,offset);
            offset:=offset+length(temp);
            result:=result+lengthb(temp);
            exit when offset>len;
        end loop;
      end if;
      return result;
  end;
  --对应clob的substr方法
  --按字节获取指定偏移量（含字节偏移）指定长度的子字符串
  function clobSubstrb(
           c in clob --原CLOB
           ,offset in out number --偏移量，从1开始
           ,btoffset in out number --字节偏移量,0或1
           ,len in number --截取字节长度
 ) return varchar2 is --返回结果字符串
          temp varchar2(32767):='';
      result varchar2(32767):='';
      bLen integer;--字节长度
      cLen integer;
  begin
      if offset<=0 then
         return '';
      end if;
      temp:=DBMS_LOB.substr(c,len,offset+btoffset);
      result:=substrb(temp,1,len-btoffset);
      if btoffset=1 then
         result:='?'||result;
      end if;
      bLen:=lengthb(result);
      cLen:=length(result);
      if bLen>cLen then
         if substr(result,cLen,1)=substr(temp,cLen-btoffset,1) then
            btoffset:=0;
         else
            result:=substr(result,1,cLen-1)||'?';
            btoffset:=1;
         end if;
      end if;
      if bLen<len then
         offset:=-1;
      else
         offset:=offset+cLen-btoffset;
      end if;
      if offset> DBMS_LOB.getlength(c) then
         offset:=0;
      end if;
      return result;
  end;

  --根据关闭符号获取子clob，如clobSubstr('aaa$$sdsfsdf$$aaa',4,'$$')='sdsfsdf'
  function clobSubstr(
           c in clob --原CLOB
           ,offset in out number --字符偏移量，从1开始
           ,enclose in varchar2 --关闭字符串：开始和结束字符串
  ) return clob is --返回结果CLOB
      temp varchar2(32767):='';
      len integer;
      pos integer;
      result clob;
  begin
      len:=DBMS_LOB.getlength(c);

      if offset>(len-length(enclose)*2) then --偏移量超过clob长度-关闭符号长度
         offset:=-1;
         return result;
      end if;

      if offset<=0 then --非法的偏移量
         return result;
      end if;

      temp:=DBMS_LOB.substr(c,length(enclose),offset);
      if temp<>enclose then --判定开始字串
         offset:=-1;
         return result;
      end if;
      offset:=offset+length(enclose);
      pos:=DBMS_LOB.instr(c,enclose,offset);
      if pos<=0 then
         offset:=-1;
         return result;
      end if;
      result:=DBMS_LOB.substr(c,pos-offset,offset);
      offset:=pos+length(enclose);
      if offset>len then--已到末端
         offset:=0;
      end if;
      return result;
  end;

  --编码字符串到CLOB
  function encode(str in varchar2,c in clob default null) return clob is
        result CLOB:=' ';
  begin
        if str is null or length(str)=0 then
           return c;
        end if;

        if c is not null then
           result:=c;
           DBMS_LOB.OPEN(result, DBMS_LOB.LOB_READWRITE);
           DBMS_LOB.writeappend(result,length(str),str);
           DBMS_LOB.CLOSE(result);
        else
           result:=' ';
           DBMS_LOB.OPEN(result, DBMS_LOB.LOB_READWRITE);
           DBMS_LOB.write(result,length(str),1,str);
           DBMS_LOB.CLOSE(result);
        end if;
        return result;
  end;
  --编码CLOB字符串到CLOB
  function encodeClob(str in clob,c in clob default null) return clob is
        result CLOB;
  begin
        if str is null or DBMS_LOB.getlength(str)=0 then
           return c;
        end if;

        if c is not null then
           result:=c;
           DBMS_LOB.copy(result,str,DBMS_LOB.getlength(str),DBMS_LOB.getlength(result)+1);
        else
           result:=' ';
           DBMS_LOB.copy(result,str,DBMS_LOB.getlength(str));
        end if;
        return result;
  end;
  --将二维数组编码为一个字符串
  function encodeRecords(array_values in CODEC_UTIL.varchar2_table_table,recordSperator in varchar2 default null,fieldSeperator in varchar2 default null,c in clob default null) return clob is
        result CLOB;
        i integer;
  begin
        if c is not null then
           result:=c;
        end if;
        if array_values.count>0 then
           for i in array_values.first..array_values.last loop
               result:=encodeRecord(array_values(i),fieldSeperator,result);
               if recordSperator is not null and i<>array_values.last then
                  result:=encode(recordSperator,result);
               end if;
           end loop;
        end if;
        return result;
  end;

--将一维数组编码为一个字符串，结果为CLOB
  function encodeRecord(array_values in CODEC_UTIL.varchar2_table,fieldSeperator in varchar2 default null,c in clob default null) return clob is
        result CLOB;
        i integer;
  begin
        if c is not null then
           result:=c;
        end if;
        if array_values.count>0 then
           for i in array_values.first..array_values.last loop
               result:=encode(array_values(i),result);
               if fieldSeperator is not null and i<>array_values.last then
                  result:=encode(fieldSeperator,result);
               end if;
           end loop;
        end if;
        return result;
  end;
  --将二维维数组编码为一个列表字符串，结果为CLOB
  function encodeList(array_values in CODEC_UTIL.varchar2_table_table,listSeperator in varchar2,recordSperator in varchar2 default null,fieldSeperator in varchar2 default null,c in clob default null) return clob is
           result CLOB;
  begin
        if c is not null then
           result:=c;
        end if;
        result:=encode(listSeperator,result);
        result:=encodeRecords(array_values,recordSperator,fieldSeperator,result);
        result:=encode(listSeperator,result);
        return result;
  end;
  --包装字符串为指定长度，不足长度用空格填充
  function encodeString(rawString in varchar2,fixsize in integer,fix in varchar2:=' ') return varchar2 is
       result varchar2(32767);
       blen integer;
  begin
       if rawString is null or length(rawString)=0 then
          result:=fix;
       else
          result:=rawString;
       end if;
       blen:=lengthb(result);
       if blen=fixsize then --等长，直接返回
          null;
       elsif blen>fixsize then --大于指定长度，截断
          result:=substrb(result,1,fixsize);
          if result<>substr(rawString,1,length(result)) then
             result:=substrb(rawString,1,fixsize-1)||'?';
          end if;
       else --小于指定长度，补足
          result:=result||rpad(fix,fixsize-blen,fix);
       end if;
       return result;
  end;

  --包装数字为指定长度字串，不足长度前补0
  function encodeNumber(rawNumber in number,fixsize in integer,scale in integer:=0) return varchar2 is
      ipart integer;
      format varchar2(200);
      temp number;
      result varchar2(200);
  begin
      if rawNumber is null then
         temp:=0;
      else
         temp:=rawNumber;
      end if;

      if scale>0 then
         ipart:=fixsize-scale-1;
      else
         ipart:=fixsize;
      end if;

      if temp<0 then
         ipart:=ipart-1;
      end if;

      format:=lpad('0',ipart,'0');
      if scale>0 then
         format:=format||'.'||lpad('0',scale,'0');
      end if;

      result:=trim(to_char(temp,format));
      return encodeString(result,fixsize);
  end;

 function encodeNumber16(rawNumber in integer,fixsize in integer:=8) return varchar2 is
 begin
          return trim(to_char(rawNumber,lpad('X',fixsize,'0')));
 end;

  --解码CLOB记录集合
  function decodeRecords(encodeString in clob,offset in out number,btoffset in out number
           ,itemsize in CODEC_UTIL.number_table,retcode out integer,retmsg out varchar2
           ,recordSeperator in varchar2 default null --记录分隔符
           ,fieldSeperator  in varchar2 default null --字段分隔符
  ) return CODEC_UTIL.varchar2_table_table is
     result CODEC_UTIL.varchar2_table_table;
     temp varchar2(2000);
  begin
     retcode:=0;
     loop
         result(result.count+1):=decodeRecord(encodeString,offset,btoffset,itemsize,retcode,retmsg,fieldSeperator);
         if retcode<>0 then
            return result;
         end if;
         if recordSeperator is not null and offset>0 then
          temp:=decodeItem(encodeString,offset,btoffset,length(recordSeperator),retcode,retmsg);
          if retcode<>0 then
              return result;
          end if;
         end if;
         exit when offset<=0;
     end loop;
     return result;
  end;
  --解码CLOB单条记录
  function decodeRecord(encodeString in clob,offset in out number,btoffset in out number
           ,itemsize in CODEC_UTIL.number_table,retcode out integer,retmsg out varchar2
           ,fieldSeperator  in varchar2 default null --字段分隔符
           ) return CODEC_UTIL.varchar2_table is
    result CODEC_UTIL.varchar2_table;
    i integer;
    temp varchar2(2000);
  begin
    retcode:=0;
    for i in itemsize.first..itemsize.last loop
        result(i):=rtrim(decodeItem(encodeString,offset,btoffset,itemsize(i),retcode,retmsg));
        if retcode<>0 then
           return result;
        end if;
        if fieldSeperator is not null and i<>itemsize.last then
           temp:=decodeItem(encodeString,offset,btoffset,length(fieldSeperator),retcode,retmsg);
           if retcode<>0 then
              return result;
           end if;
        end if;
    end loop;
    return result;
  end;

  --解码CLOB单个元素
  function decodeItem(encodeString in clob,offset in out number,btoffset in out number
           ,itemsize in number,retcode out integer,retmsg out varchar2) return varchar2 is
      result varchar2(32767);
      len integer;
      oldOffset integer;
  begin
      if offset<=0 then
         retcode:=-1;
         retmsg:='错误的偏移量offset,从1开始,实际为'||offset;
         return result;
      end if;
      retcode:=0;
      retmsg:='';
      if encodeString is null or len=0 then
         retcode:=-1;
         retmsg:='参数不能为空';
         return result;
      end if;
      oldOffset:=offset;
      result:=clobSubstrb(encodeString,offset,btoffset,itemsize);
      if result is null or lengthb(result)<itemsize then
          retcode:=2;
          retmsg:='非预期的长度,预期为:'||itemsize||',实际为:'||lengthb(result)||'(位置:'||oldOffset||',值:'||result||')';
          return result;
      end if;

      return result;
  end;
  --解码CLOB期望字串的单个元素
  function decodeItem(
           encodeString in clob --编码CLOB字串
           ,offset in out number --偏移量，从1开始
           ,btoffset in out number--字节偏移量，0:正常情况，1:中文字符第二个字节
           ,expect in varchar2 --期望字符串
           ,retcode out integer--结果码,0:成功,其他值:失败
           ,retmsg out varchar2--结果消息,对应失败的错误信息
  )return varchar2 is
    temp varchar2(32767);
  begin
    temp:=decodeItem(encodeString,offset,btoffset,length(expect),retcode,retmsg);
    if retcode=0 then
       if temp<>expect then
          retcode:=-2;
          retmsg:='解析元素出错,期望值:'||expect||',实际值:'||temp;
       end if;
    end if;
    return temp;
  end;
  --解码CLOB列表
  function decodeList(encodeString in clob,offset in out number,btoffset in out number,
           itemsize in CODEC_UTIL.number_table,retcode out integer,retmsg out varchar2
           ,sizeLength in integer:=8
           ,recordSeperator in varchar2 default null --记录分隔符
           ,fieldSeperator  in varchar2 default null --字段分隔符
           ) return CODEC_UTIL.varchar2_table_table is
     listSize number;
     temp varchar2(32767);
     i integer;

     result CODEC_UTIL.varchar2_table_table;
  begin
     retcode:=0;
     temp:=decodeItem(encodeString,offset,btoffset,sizeLength,retcode,retmsg);
     if retcode<>0 then
        return result;
     end if;
     begin
         listSize:=to_number(temp,lpad('X',sizeLength,'0'));
         EXCEPTION WHEN OTHERS THEN
              retcode:=-2;
              retmsg:='列表大小字串'||temp||'不是合法的16进制数';
     end;
     if retcode!=0 then
        return result;
     end if;

     for i in 1..listSize loop
         result(i):=decodeRecord(encodeString,offset,btoffset,itemsize,retcode,retmsg,fieldSeperator);
         if retcode<>0 then
            return result;
         end if;
         if recordSeperator is not null and i<>listSize then
            temp:=decodeItem(encodeString,offset,btoffset,length(recordSeperator),retcode,retmsg);
            if retcode<>0 then
                return result;
            end if;
         end if;
     end loop;
     return result;
  end;

  --解码CLOB列表
  function decodeList(encodeString in clob
           ,listSeperator in varchar2 --列表分隔符
           ,offset in out number
           ,itemsize in CODEC_UTIL.number_table
           ,retcode out integer,retmsg out varchar2
           ,recordSeperator in varchar2 default null --记录分隔符
           ,fieldSeperator  in varchar2 default null --字段分隔符
  ) return CODEC_UTIL.varchar2_table_table is
     result CODEC_UTIL.varchar2_table_table;
     temp clob;
     pOffset integer:=1;
     pBtOffset integer:=0;
  begin
     retcode:=0;
     temp:=clobSubstr(encodeString,offset,listSeperator);
     if offset<0 then
        retcode:=-1;
        retmsg:='找不到列表分隔符'||listSeperator;
        return result;
     end if;
     result:=decodeRecords(temp,pOffset,pBtOffset,itemsize,retcode,retmsg,recordSeperator,fieldSeperator);
     if retcode<>0 then
        return result;
     end if;
     return result;
  end;
begin
  -- Initialization
  null;
end LONGCODEC_UTIL;

/
