CREATE package ROLLBACK_CONSTANTS is

  -- Author  : SUHUALIN
  -- Created : 2008-12-2 20:29:59
  -- Purpose : 回退常量

  -- Public type declarations

  -- Public constant declarations
  REF_COMPANY constant varchar2(1) := '1';
  REF_PERSON constant varchar2(1) := '2';
  REF_HOSPITAL constant varchar2(1) := '3';
  REF_ORGAN constant varchar2(1) := '4';
  REF_ACCOUNTBOOK constant varchar2(1) := '8';
  REF_FAMILY constant varchar2(1) := '9';
  REF_BATCH constant varchar2(1) := 'B';


end ROLLBACK_CONSTANTS;

/
