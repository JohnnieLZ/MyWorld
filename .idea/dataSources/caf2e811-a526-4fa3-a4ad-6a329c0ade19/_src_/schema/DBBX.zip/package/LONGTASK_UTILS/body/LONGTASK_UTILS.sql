CREATE package body longtask_utils is

  -- Private type declarations
  --type <TypeName> is <Datatype>;

  -- Private constant declarations
  --<ConstantName> constant <Datatype> := <Value>;

  -- Private variable declarations
  --<VariableName> <Datatype>;

  -- Function and procedure implementations
  --创建长任务

  function create_longtask(
           pTaskType in varchar2 --任务类型，即任务定义表的任务代码
           ,pTaskKey in varchar2 --任务关键字，允许以业务的方式识别任务，尽量保证同一任务类型内的唯一性

           ,pOperatorId in varchar2 --操作员标识

           ,pOperatorName in varchar2 --操作员姓名

           ,pResult out integer --操作结果，0：成功，其他：失败

           ,pErrMsg out varchar2 --错误信息，当失败时回写

  ) return number is
    --匿名事务，不受全局事务影响
		PRAGMA AUTONOMOUS_TRANSACTION;

    CURSOR CUR_LTASK_DEFINITION(t varchar2) is
           SELECT * FROM LTASK_DEFINITION a where a.code=t FOR UPDATE;

    v_ltask_definition_row CUR_LTASK_DEFINITION%ROWTYPE;

    vCount integer;

    vTaskId number;
  begin
    pResult:=0;

    --检查任务类型

    OPEN CUR_LTASK_DEFINITION(pTaskType);
    FETCH CUR_LTASK_DEFINITION INTO v_ltask_definition_row;
    if CUR_LTASK_DEFINITION%NOTFOUND then
       pResult:=-1;
       pErrMsg:='[创建任务]找不到['||pTaskType||']对应的任务类型';
    end if;
    CLOSE CUR_LTASK_DEFINITION;
    if pResult<>0 then
       COMMIT;
       return 0;
    end if;

    if v_ltask_definition_row.instance_mode=INSTANCE_SINGLETON then
       SELECT COUNT(*) INTO vCount
       FROM LTASK_RECORD a
       WHERE a.task_code=pTaskType and a.task_key=pTaskKey and (a.state=STATE_RUNNING or a.result=RESULT_SUCCESS);

       if vCount>0 then
          pResult:=-2;
          pErrMsg:='[创建任务]已执行过或正在执行相同的任务';
          COMMIT;
          return 0;
       end if;
    end if;

    --生成任务标识
    SELECT SEQ_LTASK_RECORD.nextval INTO vTaskId FROM DUAL;

    --创建任务记录
    INSERT INTO LTASK_RECORD(
           id,task_code,task_key,begin_time,update_time,
           complete_rate,operator_id,operator_name,state
    )VALUES(
           vTaskId,pTaskType,pTaskKey,sysdate,sysdate,0
           ,pOperatorId,pOperatorName,STATE_RUNNING
    );

    COMMIT;

    return vTaskId;

    EXCEPTION WHEN OTHERS THEN
         ROLLBACK;

         if CUR_LTASK_DEFINITION%ISOPEN then
            CLOSE CUR_LTASK_DEFINITION;
         end if;

         pResult:=-99;
         pErrMsg:='[创建任务]['||SQLCODE||']'||SQLERRM;
  end;
  --更新长任务

  procedure update_longtask(
            pTaskId in number --任务标识
            ,pCompleteRate in integer --完成度，1-100之间
            ,pResult out integer --操作结果，0：成功，其他：失败

            ,pErrMsg out varchar2 --错误信息，当失败时回写

  )is
    --匿名事务，不受全局事务影响
		PRAGMA AUTONOMOUS_TRANSACTION;
  begin
    pResult:=0;

    UPDATE LTASK_RECORD a
    SET a.complete_rate=pCompleteRate,a.update_time=sysdate
    WHERE a.id=pTaskId;

    if SQL%ROWCOUNT=0 then
       pResult:=-1;
       pErrMsg:='[更新任务]不存在标识为'||pTaskId||'的任务记录';
    end if;

    COMMIT;

    EXCEPTION WHEN OTHERS THEN
         ROLLBACK;
         pResult:=-99;
         pErrMsg:='[更新任务]['||SQLCODE||']'||SQLERRM;
  end;


  --完成长任务

  procedure complete_longtask(
            pTaskId in number --任务标识
            ,pTaskResult in integer --任务执行结果，0：成功，其他值：失败
            ,pFailedReason in varchar2 --任务失败原因
            ,pResult out integer --操作结果，0：成功，其他：失败

            ,pErrMsg out varchar2 --错误信息，当失败时回写

  )is
    --匿名事务，不受全局事务影响
		PRAGMA AUTONOMOUS_TRANSACTION;

    vCount integer;
  begin

    pResult:=0;

    SELECT COUNT(*) INTO vCount FROM LTASK_RECORD a WHERE a.id=pTaskId;
    if vCount=0 then
       pResult:=-1;
       pErrMsg:='[结束任务]不存在标识为'||pTaskId||'的任务记录';
    end if;

    UPDATE LTASK_RECORD a
    SET a.COMPLETE_RATE=100,a.state=STATE_COMPLETE,a.result=pTaskResult,a.failed_reason=pFailedReason
        ,a.end_time=sysdate,a.update_time=sysdate,a.cost_time=(sysdate-a.begin_time)*SECONDS_ONE_DAY
    WHERE a.id=pTaskId and a.state<>STATE_COMPLETE;

    COMMIT;

    EXCEPTION WHEN OTHERS THEN
         ROLLBACK;
         pResult:=-99;
         pErrMsg:='[结束任务]['||SQLCODE||']'||SQLERRM;
  end;

  --增加任务参数
  procedure add_longtask_parameter(
            pTaskId in number --任务标识
            ,pParamName in varchar2 --参数名称
            ,pParamValue in varchar2 --参数值

            ,pResult out integer --操作结果，0：成功，其他：失败

            ,pErrMsg out varchar2 --错误信息，当失败时回写


  )is
    --匿名事务，不受全局事务影响
		PRAGMA AUTONOMOUS_TRANSACTION;

    vCount integer;
  begin
    pResult:=0;

    SELECT COUNT(*) INTO vCount FROM LTASK_EXECUTE_PARAMS a WHERE a.task_record_id=pTaskId;

    INSERT INTO LTASK_EXECUTE_PARAMS(task_record_id,parameter_name,parameter_value,xh)
    VALUES(pTaskId,pParamName,pParamValue,vCount);


    COMMIT;

    EXCEPTION WHEN OTHERS THEN
         ROLLBACK;
         pResult:=-99;
         pErrMsg:='[增加参数]['||SQLCODE||']'||SQLERRM;
  end;


  --添加任务结果
  procedure add_longtask_result(
            pTaskId in number --任务标识
            ,pItemName in varchar2 --项目名称
            ,pItemValue in varchar2 --项目值

            ,pResult out integer --操作结果，0：成功，其他：失败

            ,pErrMsg out varchar2 --错误信息，当失败时回写

  )is
		PRAGMA AUTONOMOUS_TRANSACTION;

    vCount integer;
  begin
    pResult:=0;

    SELECT COUNT(*) INTO vCount FROM LTASK_EXECUTE_RESULT a WHERE a.task_record_id=pTaskId;


    INSERT INTO LTASK_EXECUTE_RESULT(TASK_RECORD_ID,ITEM_NAME,ITEM_VALUE,XH)
    VALUES(pTaskId,pItemName,pItemValue,vCount);


    COMMIT;
    EXCEPTION WHEN OTHERS THEN
         ROLLBACK;
         pResult:=-99;
         pErrMsg:='[添加结果]['||SQLCODE||']'||SQLERRM;
  end;

  --统计当前运行的任务数
  function count_running_longtask(
            pTaskType in varchar2 --任务类型
            ,pTaskKey in varchar2 --任务关键字

            ,pParameterNames in varchar2 --参数名，以;分隔
            ,pParameterValues in varchar2 --参数值，以;分隔
            ,pParameterExact in integer --参数精确匹配，0表示不精确，其他标识精确
            ,pResult out integer --操作结果，0：成功，其他：失败

            ,pErrMsg out varchar2 --错误信息，当失败时回写


  ) return number is
    --匿名事务，不受全局事务影响
		PRAGMA AUTONOMOUS_TRANSACTION;

    v_paramnames_array varchar2_table;
    v_paramvalues_array varchar2_table;
    v_sql varchar2(2000);
    v_cursor number;
    v_count number;
  begin
    pResult:=0;

    v_sql :='select count(*) from LTASK_RECORD a where a.state=1';
    if pTaskType is not null then
       v_sql:=v_sql||' and a.task_code='''||pTaskType||'''';
    end if;
    if pTaskKey is not null then
       v_sql:=v_sql||' and a.task_key='''||pTaskKey||'''';
    end if;
    if pParameterNames is not null then
       v_paramnames_array:=split(pParameterNames,';');
       v_paramvalues_array:=split(pParameterValues,';');
       if v_paramnames_array.count<>v_paramvalues_array.count then
           pResult:=-1;
           pErrMsg:='[统计运行]参数名和参数值个数不一致';
           return 0;
       end if;

       for v_count in v_paramnames_array.first..v_paramvalues_array.last loop
           INSERT INTO LTASK_TEMP_PARAMS(PARAMETER_NAME,PARAMETER_VALUE)
           VALUES(v_paramnames_array(v_count),v_paramvalues_array(v_count));
       end loop;

       if pParameterExact=0 then
             v_sql:=v_sql||' and (select count(*) from LTASK_EXECUTE_PARAMS b,LTASK_TEMP_PARAMS c where b.TASK_RECORD_ID=a.id and b.parameter_name=c.parameter_name and b.parameter_value=c.parameter_value)='||v_paramnames_array.count;
       else
             v_sql:=v_sql||' and (select count(*) from LTASK_EXECUTE_PARAMS b,LTASK_TEMP_PARAMS c where b.TASK_RECORD_ID=a.id and b.parameter_name=c.parameter_name and b.parameter_value=c.parameter_value)='||v_paramnames_array.count;
              v_sql:=v_sql||' and (select count(*) from LTASK_EXECUTE_PARAMS b where b.TASK_RECORD_ID=a.id)='||v_paramnames_array.count;
       end if;
    end if;

    v_cursor:=dbms_sql.open_cursor();
    dbms_sql.parse(v_cursor,v_sql,dbms_sql.native);
    dbms_sql.define_column(v_cursor,1,v_count);
    v_count:=dbms_sql.execute(v_cursor);
    v_count:=dbms_sql.fetch_rows(v_cursor);
    dbms_sql.column_value(v_cursor,1,v_count);
    dbms_sql.close_cursor(v_cursor);

    ROLLBACK;

    return v_count;

    EXCEPTION WHEN OTHERS THEN
         ROLLBACK;
         if dbms_sql.is_open(v_cursor) then
            dbms_sql.close_cursor(v_cursor);
         end if;
         pResult:=-99;
         pErrMsg:='[统计运行]['||SQLCODE||']'||SQLERRM;
  end;

  procedure get_longtask_parameters(
            pTaskId in number --任务标识
            ,pParameterNames out varchar2 --参数名称，以;分隔
            ,pParameterValues out varchar2 --参数值，以;分隔
            ,pResult out integer --操作结果，0：成功，其他：失败

            ,pErrMsg out varchar2 --错误信息，当失败时回写

  ) is
     CURSOR cur_task_parameter(tid number) is
           select * from LTASK_EXECUTE_PARAMS a where a.task_record_id=tid order by a.xh;

     row_task_parameter cur_task_parameter%ROWTYPE;
     v_paramnames_array varchar2_table;
     v_paramvalues_array varchar2_table;
     vIndex integer;
  begin
     pResult:=0;
     vIndex:=0;

     OPEN cur_task_parameter(pTaskId);
     LOOP
          FETCH cur_task_parameter INTO row_task_parameter;
          EXIT WHEN cur_task_parameter%NOTFOUND;
          v_paramnames_array(vIndex):=row_task_parameter.parameter_name;
          v_paramvalues_array(vIndex):=row_task_parameter.parameter_value;
          vIndex:=vIndex+1;
     END LOOP;
     CLOSE cur_task_parameter;


     pParameterNames:=join(v_paramnames_array,';');
     pParameterValues:=join(v_paramvalues_array,';');

     EXCEPTION WHEN OTHERS THEN
          if cur_task_parameter%ISOPEN then
             CLOSE cur_task_parameter;
          end if;

         pResult:=-99;
         pErrMsg:='[获取参数]['||SQLCODE||']'||SQLERRM;
  end;


  --获取任务结果
  procedure get_longtask_results(
            pTaskId in number --任务标识
            ,pItemNames out varchar2 --参数名称，以;分隔
            ,pItemValues out varchar2 --参数值，以;分隔
            ,pResult out integer --操作结果，0：成功，其他：失败

            ,pErrMsg out varchar2 --错误信息，当失败时回写

  ) is
     CURSOR cur_task_result(tid number) is
           select * from LTASK_EXECUTE_RESULT a where a.task_record_id=tid order by a.xh;

     row_task_result cur_task_result%ROWTYPE;
     v_itemnames_array varchar2_table;
     v_itemvalues_array varchar2_table;
     vIndex integer;
  begin
     pResult:=0;
     vIndex:=0;

     OPEN cur_task_result(pTaskId);
     LOOP
          FETCH cur_task_result INTO row_task_result;
          EXIT WHEN cur_task_result%NOTFOUND;
          v_itemnames_array(vIndex):=row_task_result.item_name;
          v_itemvalues_array(vIndex):=row_task_result.item_value;
          vIndex:=vIndex+1;
     END LOOP;
     CLOSE cur_task_result;


     pItemNames:=join(v_itemnames_array,';');
     pItemValues:=join(v_itemvalues_array,';');

     EXCEPTION WHEN OTHERS THEN
          if cur_task_result%ISOPEN then
             CLOSE cur_task_result;
          end if;

         pResult:=-99;
         pErrMsg:='[获取参数]['||SQLCODE||']'||SQLERRM;
  end;
 --分割字符串

  function split(seperatedString in varchar2,
                 seperator       in varchar2,
                 low_bound       in integer := 0) return varchar2_table is
    array_result varchar2_table;
    i            int := 0;
    j            int := 0;
    len          int := 0;
    temp         varchar2(2000);
  begin
    if seperatedString is null or length(seperatedString) = 0 then
      return array_result;
    end if;

    temp := seperatedString;
    len  := length(seperator);

    while true loop
      i := instr(temp, seperator);
      if i <= 0 then
        exit;
      end if;

      array_result(j + low_bound) := substr(temp, 1, i - 1);

      temp := substr(temp, i + len);

      j := j + 1;
    end loop;

    array_result(j + low_bound) := temp;

    return array_result;
  end;
  --合并字符串

  function join(array in varchar2_table, seperator in varchar2)
    return varchar2 is
    result varchar2(2000);
    i      int := 0;
  begin
    result := '';
    if array.count > 0 then
      for i in array.first .. array.last loop
        if i > array.first then
          result := result || seperator;
        end if;
        if array(i) is not null then
           result := result || array(i);
        end if;
      end loop;
    end if;
    return result;
  end;
begin
  -- Initialization
  null;
end longtask_utils;


spool E:\YHS\健康险第三方系统需求\健康险系统构建\8.ROLLBACK_UTIL.log;
@E:\YHS\健康险第三方系统需求\健康险系统构建\ROLLBACK_UTIL.sql;

spool E:\YHS\健康险第三方系统需求\健康险系统构建\sa通用审批.log;
@E:\YHS\健康险第三方系统需求\健康险系统构建\sa通用审批.pck;

spool E:\YHS\健康险第三方系统需求\健康险系统构建\9.sq_apply.log;
@E:\YHS\健康险第三方系统需求\健康险系统构建\9.sq_apply.sql;

spool E:\YHS\健康险第三方系统需求\健康险系统构建\00.sso.log;
@E:\YHS\健康险第三方系统需求\健康险系统构建\00.sso.sql;

spool E:\YHS\健康险第三方系统需求\健康险系统构建\88.BACKUP_UTILS.log;
@E:\YHS\健康险第三方系统需求\健康险系统构建\BACKUP_UTILS.sql;

spool off;




/
