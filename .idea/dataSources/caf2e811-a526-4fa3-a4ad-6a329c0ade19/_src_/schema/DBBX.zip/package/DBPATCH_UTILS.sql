CREATE package DBPATCH_UTILS is

  -- Author  : SUHUALIN
  -- Created : 2008-8-14 11:04:49
  -- Purpose :

  -- Public type declarations

  -- Public constant declarations

  -- Public variable declarations

  -- Public function and procedure declarations
  procedure create_sequence;

  procedure create_sequence(tables in varchar2);

  procedure create_guidelines(increment varchar2:='1');

  procedure create_rollback_support;

  procedure create_rollback_support(tables in varchar2);

  procedure remove_rollback_support;

  procedure remove_rollback_support(tables in varchar2);

  procedure create_event_support;

  procedure create_event_support(tables in varchar2);

  procedure remove_event_support;

  procedure remove_event_support(tables in varchar2);
end DBPATCH_UTILS;

/
