CREATE package body DBPATCH_UTILS is

  -- Function and procedure implementations
  procedure create_sequence is
    cursor cur_seq_columns is
           select distinct a.column_name
           from user_tab_columns a
           where length(a.COLUMN_NAME)=6
           and substr(a.COLUMN_NAME,3,1)='Z'
           and not exists(
               select 1 from user_sequences b
               where substr(b.sequence_name,5)=a.COLUMN_NAME
           );
    seq_column_row cur_seq_columns%Rowtype;
    seq_sql varchar2(1000);
  begin

    open cur_seq_columns;
    loop
         fetch cur_seq_columns into seq_column_row;
         exit when cur_seq_columns%notfound;

         begin
           seq_sql:='create sequence SEQ_'||seq_column_row.column_name||' minvalue 1 maxvalue 9999999999999999 start with 1 increment by 1 cache 20';
           EXECUTE IMMEDIATE seq_sql;
           EXCEPTION WHEN OTHERS THEN
                seq_sql:=SQLERRM;
         end;
    end loop;
    close cur_seq_columns;
  end;

   procedure create_sequence(tables in varchar2) is
     arr_tables array_util.varchar2_table;
     i integer;
     v_tab_name varchar2(10);
     cursor cur_seq_columns is
           select distinct a.column_name
           from user_tab_columns a
           where length(a.COLUMN_NAME)=6
           and substr(a.COLUMN_NAME,3,1)='Z'
           and a.TABLE_NAME=v_tab_name
           and not exists(
               select 1 from user_sequences b
               where substr(b.sequence_name,5)=a.COLUMN_NAME
           );
    seq_column_row cur_seq_columns%Rowtype;
    seq_sql varchar2(1000);
  begin
        arr_tables:=array_util.split(tables,',');
        if arr_tables.count=0 then
           return;
        end if;

        for i in arr_tables.first..arr_tables.last loop
           v_tab_name:=arr_tables(i);
           open cur_seq_columns;
            loop
                 fetch cur_seq_columns into seq_column_row;
                 exit when cur_seq_columns%notfound;

                 begin
                   seq_sql:='create sequence SEQ_'||seq_column_row.column_name||' minvalue 1 maxvalue 9999999999999999 start with 1 increment by 1 cache 20';
                   EXECUTE IMMEDIATE seq_sql;
                   EXCEPTION WHEN OTHERS THEN
                        seq_sql:=SQLERRM;
                 end;
            end loop;
            close cur_seq_columns;
        end loop;
  end;

  procedure create_guidelines(increment varchar2:='1') is
    cursor cur_guidelines is
      select b.TABLE_NAME,b.COLUMN_NAME,b.DATA_TYPE,b.DATA_LENGTH,b.DATA_PRECISION,b.DATA_SCALE,b.NULLABLE,c.comments
      from user_tab_columns b,user_col_comments c
      where b.TABLE_NAME=c.table_name and b.COLUMN_NAME=c.column_name
      and length(b.TABLE_NAME)=4
      order by b.COLUMN_NAME
    ;

    cursor cur_guidelines_increments is
      select b.TABLE_NAME,b.COLUMN_NAME,b.DATA_TYPE,b.DATA_LENGTH,b.DATA_PRECISION,b.DATA_SCALE,b.NULLABLE,c.comments
      from user_tab_columns b,user_col_comments c
      where b.TABLE_NAME=c.table_name and b.COLUMN_NAME=c.column_name
      and length(b.TABLE_NAME)=4
      and not exists(select 1 from guide_line g where g.item_code=b.COLUMN_NAME)
      order by b.COLUMN_NAME
    ;

    row_guidelines cur_guidelines%ROWTYPE;
    precolumn varchar2(30);
    pitemtype varchar2(30);
    prequire varchar2(1);
  begin
    if increment='1' then --增量
      precolumn:='*';
      open cur_guidelines_increments;
      loop
           fetch cur_guidelines_increments into row_guidelines;
           exit when cur_guidelines_increments%notfound;

           if row_guidelines.column_name!=precolumn then --不处理重复字段
             if instr('CHARACTER|VARCHAR2|VARACHAR',row_guidelines.data_type)>0 then
                pitemtype:='string';
             elsif instr('INTEGER|NUMBER',row_guidelines.data_type)>0 then
                pitemtype:='number';
             elsif instr('DATE|TIMESTAMP',row_guidelines.data_type)>0 then
                pitemtype:='date';
             else
                pitemtype:='unknown';
             end if;

             if row_guidelines.nullable='Y' then
                prequire:='0';
             else
                prequire:='1';
             end if;

             if pitemtype!='number' then
               insert into guide_line(id,item_code,item_name,item_type,item_length,item_precision,item_require,need_validate)
               values(SEQ_GUIDE_LINE.nextval,row_guidelines.column_name,nvl(row_guidelines.comments,row_guidelines.column_name),pitemtype,row_guidelines.data_length
                      ,null,prequire,'1');
             else
               insert into guide_line(id,item_code,item_name,item_type,item_length,item_precision,item_require,need_validate)
               values(SEQ_GUIDE_LINE.nextval,row_guidelines.column_name,nvl(row_guidelines.comments,row_guidelines.column_name),pitemtype,nvl(row_guidelines.data_precision,row_guidelines.data_length)
                      ,nvl(row_guidelines.data_scale,0),prequire,'1');
             end if;
             precolumn:=row_guidelines.column_name;
           else
               null;
           end if;
      end loop;
      close cur_guidelines_increments;
    else
      --删除原有指标
      delete from guide_line a
      where a.item_code in (
            select distinct b.column_name
            from user_tab_columns b
            where length(b.COLUMN_NAME)=6 and length(b.TABLE_NAME)=4
      );

      precolumn:='*';
      open cur_guidelines;
      loop
           fetch cur_guidelines into row_guidelines;
           exit when cur_guidelines%notfound;

           if row_guidelines.column_name!=precolumn then --不处理重复字段
             if instr('CHARACTER|VARCHAR2|VARACHAR',row_guidelines.data_type)>0 then
                pitemtype:='string';
             elsif instr('INTEGER|NUMBER',row_guidelines.data_type)>0 then
                pitemtype:='number';
             elsif instr('DATE|TIMESTAMP',row_guidelines.data_type)>0 then
                pitemtype:='date';
             else
                pitemtype:='unknown';
             end if;

             if row_guidelines.nullable='Y' then
                prequire:='0';
             else
                prequire:='1';
             end if;

             if pitemtype!='number' then
               insert into guide_line(id,item_code,item_name,item_type,item_length,item_precision,item_require,need_validate)
               values(SEQ_GUIDE_LINE.nextval,row_guidelines.column_name,row_guidelines.comments,pitemtype,row_guidelines.data_length
                      ,null,prequire,'1');
             else
               insert into guide_line(id,item_code,item_name,item_type,item_length,item_precision,item_require,need_validate)
               values(SEQ_GUIDE_LINE.nextval,row_guidelines.column_name,row_guidelines.comments,pitemtype,row_guidelines.data_precision
                      ,row_guidelines.data_scale,prequire,'1');
             end if;
             precolumn:=row_guidelines.column_name;
           else
               null;
           end if;
      end loop;
      close cur_guidelines;

    end if;

    null;
  end;

  /*
  *创建所有指标库表的回退支持
  */
  procedure create_rollback_support is
    cursor cur_tables is
           select a.TABLE_NAME
           from user_tables a
           where length(a.table_name)=4;
    row_tables cur_tables%ROWTYPE;
  begin
    open cur_tables;
    loop
         fetch cur_tables into row_tables;
         exit when cur_tables%NOTFOUND;

         create_rollback_support(row_tables.table_name);
    end loop;
    close cur_tables;
  end;

  procedure create_rollback_support(tables in varchar2) is
        arr_tables array_util.varchar2_table;
        temp_sql varchar2(1000);
        i integer;
  begin
        arr_tables:=array_util.split(tables,',');
        if arr_tables.count=0 then
           return;
        end if;

        for i in arr_tables.first..arr_tables.last loop
            begin
              temp_sql:='ALTER TABLE '||arr_tables(i)||' ADD SEQLOGID NUMBER(19)';
              EXECUTE IMMEDIATE temp_sql;
              temp_sql:='comment on column '||arr_tables(i)||'.SEQLOGID is ''回退线索日志编号''';
              EXECUTE IMMEDIATE temp_sql;
              EXCEPTION WHEN OTHERS THEN
                        NULL;
            end;
        end loop;
  end;

  procedure remove_rollback_support is
    cursor cur_tables is
           select a.TABLE_NAME
           from user_tables a
           where length(a.table_name)=4;
    row_tables cur_tables%ROWTYPE;
  begin
    open cur_tables;
    loop
         fetch cur_tables into row_tables;
         exit when cur_tables%NOTFOUND;

         remove_rollback_support(row_tables.table_name);
    end loop;
    close cur_tables;
  end;

  procedure remove_rollback_support(tables in varchar2) is
        arr_tables array_util.varchar2_table;
        temp_sql varchar2(1000);
        i integer;
  begin
        arr_tables:=array_util.split(tables,',');
        if arr_tables.count=0 then
           return;
        end if;

        for i in arr_tables.first..arr_tables.last loop
            begin
              temp_sql:='ALTER TABLE '||arr_tables(i)||' DROP COLUMN SEQLOGID';
              EXECUTE IMMEDIATE temp_sql;
              EXCEPTION WHEN OTHERS THEN
                        NULL;
            end;
        end loop;
  end;

  procedure create_event_support is
    cursor cur_event_tables is
           select a.TABLE_NAME
           from user_tables a,user_tab_columns b
           where a.table_name=b.TABLE_NAME
           and b.COLUMN_NAME='BAE127'
           and length(a.table_name)=4;
    row_event_tables cur_event_tables%ROWTYPE;
  begin
    open cur_event_tables;
    loop
         fetch cur_event_tables into row_event_tables;
         exit when cur_event_tables%NOTFOUND;

         create_event_support(row_event_tables.table_name);
    end loop;
    close cur_event_tables;
  end;

/*AAE013 VARCHAR2(100) Y                备注
AAE011 VARCHAR2(10)                   经办人
AAE036 DATE                           经办时间
AAE016 VARCHAR2(1)                    复核标志
AAE014 VARCHAR2(10)  Y                复核人
AAE015 DATE          Y                复核时间
AAZ002 CHAR(16)                       业务日志ID
*/
/*2010-6-8:用途：方便业务查询
AAZ010 VARCHAR2(20)                   当事人ID
AAA028 VARCHAR2(1)                    当事人类别
AAE410 VARCHAR2(6)                    业务经办月度
AAE411 VARCHAR2(6)                    业务复核月度
*/
  procedure create_event_support(tables in varchar2) is
        arr_tables array_util.varchar2_table;
        temp_sql varchar2(1000);
        i integer;
  begin
        arr_tables:=array_util.split(tables,',');
        if arr_tables.count=0 then
           return;
        end if;

        for i in arr_tables.first..arr_tables.last loop
            begin
              temp_sql:='ALTER TABLE '||arr_tables(i)||' ADD BAE128 VARCHAR2(100)';
              EXECUTE IMMEDIATE temp_sql;
              temp_sql:='comment on column '||arr_tables(i)||'.BAE128 is ''业务描述''';
              EXECUTE IMMEDIATE temp_sql;
              EXCEPTION WHEN OTHERS THEN
                        NULL;
            end;
            begin
              temp_sql:='ALTER TABLE '||arr_tables(i)||' ADD AAA121 VARCHAR2(12)';
              EXECUTE IMMEDIATE temp_sql;
              temp_sql:='comment on column '||arr_tables(i)||'.AAA121 is ''业务类型''';
              EXECUTE IMMEDIATE temp_sql;
              EXCEPTION WHEN OTHERS THEN
                        NULL;
            end;
            begin
              temp_sql:='ALTER TABLE '||arr_tables(i)||' ADD AAE011 VARCHAR2(10)';
              EXECUTE IMMEDIATE temp_sql;
              temp_sql:='comment on column '||arr_tables(i)||'.AAE011 is ''经办人''';
              EXECUTE IMMEDIATE temp_sql;
              EXCEPTION WHEN OTHERS THEN
                        NULL;
            end;
            begin
              temp_sql:='ALTER TABLE '||arr_tables(i)||' ADD BAE125 VARCHAR2(50)';
              EXECUTE IMMEDIATE temp_sql;
              temp_sql:='comment on column '||arr_tables(i)||'.BAE125 is ''经办人姓名''';
              EXECUTE IMMEDIATE temp_sql;
              EXCEPTION WHEN OTHERS THEN
                        NULL;
            end;

            begin
              temp_sql:='ALTER TABLE '||arr_tables(i)||' ADD AAE036 DATE';
              EXECUTE IMMEDIATE temp_sql;
              temp_sql:='comment on column '||arr_tables(i)||'.AAE036 is ''经办时间''';
              EXECUTE IMMEDIATE temp_sql;
              EXCEPTION WHEN OTHERS THEN
                        NULL;
            end;
            begin
              temp_sql:='ALTER TABLE '||arr_tables(i)||' ADD AAE016 VARCHAR2(1)';
              EXECUTE IMMEDIATE temp_sql;
              temp_sql:='comment on column '||arr_tables(i)||'.AAE016 is ''复核标志''';
              EXECUTE IMMEDIATE temp_sql;
              EXCEPTION WHEN OTHERS THEN
                        NULL;
            end;
            begin
              temp_sql:='ALTER TABLE '||arr_tables(i)||' ADD AAE014 VARCHAR2(10)';
              EXECUTE IMMEDIATE temp_sql;
              temp_sql:='comment on column '||arr_tables(i)||'.AAE014 is ''复核人''';
              EXECUTE IMMEDIATE temp_sql;
              EXCEPTION WHEN OTHERS THEN
                        NULL;
            end;
            begin
              temp_sql:='ALTER TABLE '||arr_tables(i)||' ADD BAE126 VARCHAR2(50)';
              EXECUTE IMMEDIATE temp_sql;
              temp_sql:='comment on column '||arr_tables(i)||'.BAE126 is ''复核人姓名''';
              EXECUTE IMMEDIATE temp_sql;
              EXCEPTION WHEN OTHERS THEN
                        NULL;
            end;
            begin
              temp_sql:='ALTER TABLE '||arr_tables(i)||' ADD AAE015 DATE';
              EXECUTE IMMEDIATE temp_sql;
              temp_sql:='comment on column '||arr_tables(i)||'.AAE015 is ''复核时间''';
              EXECUTE IMMEDIATE temp_sql;
              EXCEPTION WHEN OTHERS THEN
                        NULL;
            end;
            begin
              temp_sql:='ALTER TABLE '||arr_tables(i)||' ADD AAZ002 CHAR(16)';
              EXECUTE IMMEDIATE temp_sql;
              temp_sql:='comment on column '||arr_tables(i)||'.AAZ002 is ''业务日志ID''';
              EXECUTE IMMEDIATE temp_sql;
              EXCEPTION WHEN OTHERS THEN
                        NULL;
            end;
            /*用途：方便业务查询
              AAZ010 VARCHAR2(20)                   当事人ID
              AAA028 VARCHAR2(1)                    当事人类别
              AAE410 VARCHAR2(6)                    业务经办月度
              AAE411 VARCHAR2(6)                    业务复核月度
            */
            begin
              temp_sql:='ALTER TABLE '||arr_tables(i)||' ADD AAZ010 VARCHAR2(20)';
              EXECUTE IMMEDIATE temp_sql;
              temp_sql:='comment on column '||arr_tables(i)||'.AAZ010 is ''当事人ID''';
              EXECUTE IMMEDIATE temp_sql;
              EXCEPTION WHEN OTHERS THEN
                        NULL;
            end;
            begin
              temp_sql:='ALTER TABLE '||arr_tables(i)||' ADD AAA028 VARCHAR2(20)';
              EXECUTE IMMEDIATE temp_sql;
              temp_sql:='comment on column '||arr_tables(i)||'.AAA028 is ''当事人类别''';
              EXECUTE IMMEDIATE temp_sql;
              EXCEPTION WHEN OTHERS THEN
                        NULL;
            end;
            begin
              temp_sql:='ALTER TABLE '||arr_tables(i)||' ADD AAE410 VARCHAR2(20)';
              EXECUTE IMMEDIATE temp_sql;
              temp_sql:='comment on column '||arr_tables(i)||'.AAE410 is ''业务经办月度''';
              EXECUTE IMMEDIATE temp_sql;
              EXCEPTION WHEN OTHERS THEN
                        NULL;
            end;
            begin
              temp_sql:='ALTER TABLE '||arr_tables(i)||' ADD AAE411 VARCHAR2(20)';
              EXECUTE IMMEDIATE temp_sql;
              temp_sql:='comment on column '||arr_tables(i)||'.AAE411 is ''业务复核月度 ''';
              EXECUTE IMMEDIATE temp_sql;
              EXCEPTION WHEN OTHERS THEN
                        NULL;
            end;
        end loop;
  end;

  procedure remove_event_support is
    cursor cur_event_tables is
           select a.TABLE_NAME
           from user_tables a,user_tab_columns b
           where a.table_name=b.TABLE_NAME
           and b.COLUMN_NAME='BAE127'
           and length(a.table_name)=4;
    row_event_tables cur_event_tables%ROWTYPE;
  begin
    open cur_event_tables;
    loop
         fetch cur_event_tables into row_event_tables;
         exit when cur_event_tables%NOTFOUND;

         remove_event_support(row_event_tables.table_name);
    end loop;
    close cur_event_tables;
  end;

  procedure remove_event_support(tables in varchar2) is
        arr_tables array_util.varchar2_table;
        temp_sql varchar2(1000);
        i integer;
  begin
        arr_tables:=array_util.split(tables,',');
        if arr_tables.count=0 then
           return;
        end if;

        for i in arr_tables.first..arr_tables.last loop
            begin
              temp_sql:='ALTER TABLE '||arr_tables(i)||' DROP COLUMN BAE128';
              EXECUTE IMMEDIATE temp_sql;
              EXCEPTION WHEN OTHERS THEN
                        NULL;
            end;
            begin
              temp_sql:='ALTER TABLE '||arr_tables(i)||' DROP COLUMN AAA121';
              EXECUTE IMMEDIATE temp_sql;
              EXCEPTION WHEN OTHERS THEN
                        NULL;
            end;
            begin
              temp_sql:='ALTER TABLE '||arr_tables(i)||' DROP COLUMN AAE011';
              EXECUTE IMMEDIATE temp_sql;
              EXCEPTION WHEN OTHERS THEN
                        NULL;
            end;
            begin
              temp_sql:='ALTER TABLE '||arr_tables(i)||'  DROP COLUMN AAE036';
              EXECUTE IMMEDIATE temp_sql;
              EXCEPTION WHEN OTHERS THEN
                        NULL;
            end;
            begin
              temp_sql:='ALTER TABLE '||arr_tables(i)||' DROP COLUMN AAE016';
              EXECUTE IMMEDIATE temp_sql;
              EXCEPTION WHEN OTHERS THEN
                        NULL;
            end;
            begin
              temp_sql:='ALTER TABLE '||arr_tables(i)||' DROP COLUMN AAE014';
              EXECUTE IMMEDIATE temp_sql;
              EXCEPTION WHEN OTHERS THEN
                        NULL;
            end;
            begin
              temp_sql:='ALTER TABLE '||arr_tables(i)||' DROP COLUMN AAE015';
              EXECUTE IMMEDIATE temp_sql;
              EXCEPTION WHEN OTHERS THEN
                        NULL;
            end;
            begin
              temp_sql:='ALTER TABLE '||arr_tables(i)||' DROP COLUMN AAZ002';
              EXECUTE IMMEDIATE temp_sql;
              EXCEPTION WHEN OTHERS THEN
                        NULL;
            end;
            begin
              temp_sql:='ALTER TABLE '||arr_tables(i)||' DROP COLUMN BAE125';
              EXECUTE IMMEDIATE temp_sql;
              EXCEPTION WHEN OTHERS THEN
                        NULL;
            end;
            begin
              temp_sql:='ALTER TABLE '||arr_tables(i)||' DROP COLUMN BAE126';
              EXECUTE IMMEDIATE temp_sql;
              EXCEPTION WHEN OTHERS THEN
                        NULL;
            end;
            /*用途：方便业务查询
              AAZ010 VARCHAR2(20)                   当事人ID
              AAA028 VARCHAR2(1)                    当事人类别
              AAE410 VARCHAR2(6)                    业务经办月度
              AAE411 VARCHAR2(6)                    业务复核月度
            */
            begin
              temp_sql:='ALTER TABLE '||arr_tables(i)||' DROP COLUMN AAZ010';
              EXECUTE IMMEDIATE temp_sql;
              EXCEPTION WHEN OTHERS THEN
                        NULL;
            end;
            begin
              temp_sql:='ALTER TABLE '||arr_tables(i)||' DROP COLUMN AAA028';
              EXECUTE IMMEDIATE temp_sql;
              EXCEPTION WHEN OTHERS THEN
                        NULL;
            end;
            begin
              temp_sql:='ALTER TABLE '||arr_tables(i)||' DROP COLUMN AAE410';
              EXECUTE IMMEDIATE temp_sql;
              EXCEPTION WHEN OTHERS THEN
                        NULL;
            end;
            begin
              temp_sql:='ALTER TABLE '||arr_tables(i)||' DROP COLUMN AAE411';
              EXECUTE IMMEDIATE temp_sql;
              EXCEPTION WHEN OTHERS THEN
                        NULL;
            end;

        end loop;
  end;
begin
  -- Initialization
  null;
end DBPATCH_UTILS;

/
