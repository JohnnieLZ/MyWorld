CREATE package longtask_utils is

  -- Author  : SUHUALIN
  -- Created : 2009-3-3 13:14:53
  -- Purpose : 长任务处理工具类

  -- Public type declarations
  --type <TypeName> is <Datatype>;

  TYPE varchar2_table IS TABLE OF VARCHAR2(2000)
  INDEX BY binary_integer;

  TYPE varchar2_table_table is TABLE OF varchar2_table
  INDEX BY binary_integer;
  -- Public constant declarations
  --<ConstantName> constant <Datatype> := <Value>;
  INSTANCE_SINGLETON constant integer:=0;
  INSTANCE_MULTIPLE constant integer:=1;

  STATE_RUNNING constant integer:=1;
  STATE_COMPLETE constant integer:=0;

  RESULT_SUCCESS constant integer:=0;

  SECONDS_ONE_DAY constant integer:=24*60*60;
  -- Public variable declarations
  --<VariableName> <Datatype>;

  -- Public function and procedure declarations
  --创建长任务

  function create_longtask(
           pTaskType in varchar2 --任务类型，即任务定义表的任务代码
           ,pTaskKey in varchar2 --任务关键字，允许以业务的方式识别任务，尽量保证同一任务类型内的唯一性

           ,pOperatorId in varchar2 --操作员标识

           ,pOperatorName in varchar2 --操作员姓名

           ,pResult out integer --操作结果，0：成功，其他：失败

           ,pErrMsg out varchar2 --错误信息，当失败时回写

  ) return number; --返回任务标识

  --更新长任务

  procedure update_longtask(
            pTaskId in number --任务标识
            ,pCompleteRate in integer --完成度，1-100之间
            ,pResult out integer --操作结果，0：成功，其他：失败

            ,pErrMsg out varchar2 --错误信息，当失败时回写

  );

  --完成长任务

  procedure complete_longtask(
            pTaskId in number --任务标识
            ,pTaskResult in integer --任务执行结果，0：成功，其他值：失败
            ,pFailedReason in varchar2 --任务失败原因
            ,pResult out integer --操作结果，0：成功，其他：失败

            ,pErrMsg out varchar2 --错误信息，当失败时回写

  );

  --增加任务参数
  procedure add_longtask_parameter(
            pTaskId in number --任务标识
            ,pParamName in varchar2 --参数名称
            ,pParamValue in varchar2 --参数值

            ,pResult out integer --操作结果，0：成功，其他：失败

            ,pErrMsg out varchar2 --错误信息，当失败时回写

  );

  --添加任务结果
  procedure add_longtask_result(
            pTaskId in number --任务标识
            ,pItemName in varchar2 --项目名称
            ,pItemValue in varchar2 --项目值

            ,pResult out integer --操作结果，0：成功，其他：失败

            ,pErrMsg out varchar2 --错误信息，当失败时回写

  );


  --统计当前运行的任务数
  function count_running_longtask(
            pTaskType in varchar2 --任务类型
            ,pTaskKey in varchar2 --任务关键字

            ,pParameterNames in varchar2 --参数名，以;分隔
            ,pParameterValues in varchar2 --参数值，以;分隔
            ,pParameterExact in integer --参数精确匹配，0表示不精确，其他标识精确
            ,pResult out integer --操作结果，0：成功，其他：失败

            ,pErrMsg out varchar2 --错误信息，当失败时回写

  ) return number;

  --获取任务参数
  procedure get_longtask_parameters(
            pTaskId in number --任务标识
            ,pParameterNames out varchar2 --参数名称，以;分隔
            ,pParameterValues out varchar2 --参数值，以;分隔
            ,pResult out integer --操作结果，0：成功，其他：失败

            ,pErrMsg out varchar2 --错误信息，当失败时回写

  );

  --获取任务结果
  procedure get_longtask_results(
            pTaskId in number --任务标识
            ,pItemNames out varchar2 --参数名称，以;分隔
            ,pItemValues out varchar2 --参数值，以;分隔
            ,pResult out integer --操作结果，0：成功，其他：失败

            ,pErrMsg out varchar2 --错误信息，当失败时回写

  );



  --分割字符串

  function split(seperatedString in varchar2,seperator in varchar2,low_bound in integer := 0)
           return varchar2_table;
  --合并字符串

  function join(array in varchar2_table,seperator in varchar2)
           return varchar2;

end longtask_utils;


/
