CREATE package body HISTORY_UTIL is

  -- Private type declarations

  -- Private constant declarations

  -- Private variable declarations
  v_tables_no_rollback ARRAY_UTIL.varchar2_table;

  -- Function and procedure implementations

   procedure get_sequence(seqid out number,action out number) is
        cursor cur_sequence is
              select a.SEQUENCEID,a.ACTIONTYPE into seqid,action
              from HISTORY_SESSION_STATE a
              where rownum<2 order by a.sequenceid desc;
        row_sequence cur_sequence%ROWTYPE;
   begin
        open cur_sequence;
        fetch cur_sequence into row_sequence;
        if cur_sequence%FOUND then
           seqid:=row_sequence.sequenceid;
           action:=row_sequence.actiontype;
        end if;
        close cur_sequence;

        if seqid is null then
           seqid:=DEFAULT_SEQUENCE_ID;
           action:=HISTORY_UTIL.ACTION_UNKNOWN;
        end if;

        exception when others then
            if cur_sequence%ISOPEN then
               close cur_sequence;
            end if;
   end;

   function get_sequence_no return number is
        seqid number;
        action number;
   begin
        get_sequence(seqid,action);
        return seqid;
   end;

  --创建线索
  procedure create_sequence(seqid number,action number) is
  begin
    insert into HISTORY_SESSION_STATE(SEQUENCEID,ACTIONTYPE)
    values(seqid,action);
  end;

  procedure remove_sequence(seqid number) is
  begin
    delete from HISTORY_SESSION_STATE where SEQUENCEID=seqid;
  end;


  procedure to_history(op_type in number,table_name in varchar2
           ,pk_values in out ant_type_table,c_values in out ant_type_table
           ,has_history_table in number:=0) is
     tid number;
     seqid number;
     action number;
     rbsql varchar2(4096);
     pksql varchar2(2000);
     csql varchar2(4096);

     his_rbsql varchar2(3000);

     i integer;
  begin
    if op_type!=OPTYPE_INSERT and c_values.count=0 then
       return;
    end if;

    select seq_history_table.nextval into tid from dual;

    get_sequence(seqid,action);

    if action=HISTORY_UTIL.ACTION_ROLLBACK then
       return;
    end if;

    if op_type=OPTYPE_INSERT then
       /*
        * delete from xxx where
        *  (id1,id2,...)
        *  =
        *  (select h.pc1.type_value,h.pc2.type_value,... from history_table h where h.tid=tid)
        */
       rbsql:='delete from '||table_name||' where (';

       for i in 1..pk_values.count loop
           if i=1 then
              rbsql:=rbsql||pk_values(i).name;
              pksql:='h.pc'||i||'.'||pk_values(i).type||'_value';
           else
              rbsql:=rbsql||','||pk_values(i).name;
              pksql:=pksql||',h.pc'||i||'.'||pk_values(i).type||'_value';
           end if;
       end loop;

       rbsql:=rbsql||')=(select '||pksql||' from history_table h where h.id='||tid||')';
    elsif op_type=OPTYPE_UPDATE then
       rbsql:='update '||table_name||' a set(';
       for i in 1..c_values.count loop
           if i=1 then
              rbsql:=rbsql||c_values(i).name;
              csql:='h.c'||i||'.'||c_values(i).type||'_value';
           else
              rbsql:=rbsql||','||c_values(i).name;
              csql:=csql||',h.c'||i||'.'||c_values(i).type||'_value';
           end if;
       end loop;
       rbsql:=rbsql||')=(select '||csql||' from HISTORY_TABLE h where id='||tid||') where (';
       for i in 1..pk_values.count loop
           if i=1 then
              pksql:=pk_values(i).name;
           else
              pksql:=pksql||','||pk_values(i).name;
           end if;
       end loop;
       rbsql:=rbsql||pksql||')=(select ';
       for i in 1..pk_values.count loop
           if i=1 then
              rbsql:=rbsql||'h.pc'||i||'.'||pk_values(i).type||'_value';
           else
              rbsql:=rbsql||',h.pc'||i||'.'||pk_values(i).type||'_value';
           end if;
       end loop;
       rbsql:=rbsql||' from HISTORY_TABLE h where h.id='||tid||')';
    else
       rbsql:='insert into '||table_name||'(';
       for i in 1..pk_values.count loop
           if i>1 then
              rbsql:=rbsql||','||pk_values(i).name;
              pksql:=pksql||',h.pc'||i||'.'||pk_values(i).type||'_value';
           else
              rbsql:=rbsql||pk_values(i).name;
              pksql:='h.pc'||i||'.'||pk_values(i).type||'_value';
           end if;
       end loop;
       for i in 1..c_values.count loop
           rbsql:=rbsql||','||c_values(i).name;
           csql:=csql||',h.c'||i||'.'||c_values(i).type||'_value';
       end loop;
       rbsql:=rbsql||')(select '||pksql||csql||' from HISTORY_TABLE h where h.id='||tid||')';
    end if;

    for i in pk_values.count+1..10 loop
        pk_values(i):=null;
    end loop;
    for i in c_values.count+1..100 loop
        c_values(i):=null;
    end loop;

    if has_history_table=CREATE_HISTORY_TABLE and  op_type!=OPTYPE_INSERT then
       his_rbsql:='delete from H_'||table_name||' where '||NEW_SEQUENCE_COLUMN||'='||seqid;
    end if;

    insert into history_table(
      id,op_type,table_name,rollback_sql,rollback_histable_sql,rollbacked,sid
      ,PC1,PC2,PC3,PC4,PC5,PC6,PC7,PC8,PC9,PC10
      ,C1,C2,C3,C4,C5,C6,C7,C8,C9,C10
      ,C11,C12,C13,C14,C15,C16,C17,C18,C19,C20
      ,C21,C22,C23,C24,C25,C26,C27,C28,C29,C30
      ,C31,C32,C33,C34,C35,C36,C37,C38,C39,C40
      ,C41,C42,C43,C44,C45,C46,C47,C48,C49,C50
      ,C51,C52,C53,C54,C55,C56,C57,C58,C59,C60
      ,C61,C62,C63,C64,C65,C66,C67,C68,C69,C70
      ,C71,C72,C73,C74,C75,C76,C77,C78,C79,C80
      ,C81,C82,C83,C84,C85,C86,C87,C88,C89,C90
      ,C91,C92,C93,C94,C95,C96,C97,C98,C99,C100
    )values(
      tid,op_type,table_name,rbsql,his_rbsql,'0',seqid
      ,pk_values(1),pk_values(2),pk_values(3),pk_values(4),pk_values(5),pk_values(6),pk_values(7),pk_values(8),pk_values(9),pk_values(10)
      ,c_values(1),c_values(2),c_values(3),c_values(4),c_values(5),c_values(6),c_values(7),c_values(8),c_values(9),c_values(10)
      ,c_values(11),c_values(12),c_values(13),c_values(14),c_values(15),c_values(16),c_values(17),c_values(18),c_values(19),c_values(20)
      ,c_values(21),c_values(22),c_values(23),c_values(24),c_values(25),c_values(26),c_values(27),c_values(28),c_values(29),c_values(30)
      ,c_values(31),c_values(32),c_values(33),c_values(34),c_values(35),c_values(36),c_values(37),c_values(38),c_values(39),c_values(40)
      ,c_values(41),c_values(42),c_values(43),c_values(44),c_values(45),c_values(46),c_values(47),c_values(48),c_values(49),c_values(50)
      ,c_values(51),c_values(52),c_values(53),c_values(54),c_values(55),c_values(56),c_values(57),c_values(58),c_values(59),c_values(60)
      ,c_values(61),c_values(62),c_values(63),c_values(64),c_values(65),c_values(66),c_values(67),c_values(68),c_values(69),c_values(70)
      ,c_values(71),c_values(72),c_values(73),c_values(74),c_values(75),c_values(76),c_values(77),c_values(78),c_values(79),c_values(80)
      ,c_values(81),c_values(82),c_values(83),c_values(84),c_values(85),c_values(86),c_values(87),c_values(88),c_values(89),c_values(90)
      ,c_values(91),c_values(92),c_values(93),c_values(94),c_values(95),c_values(96),c_values(97),c_values(98),c_values(99),c_values(100)
    );
  end;

  procedure rollback(seqid in number,rbseqid in number) is
     cursor cur_rollback(seqid number )is
       select a.rollback_sql,a.rollback_histable_sql,a.id
       from history_table a
       where a.sid=seqid
       and a.rollbacked='0'
       order by id desc;

     row_rollback cur_rollback%ROWTYPE;
     vDetailid number;
  begin
     create_rollback_state(seqid);

     create_sequence(rbseqid,HISTORY_UTIL.ACTION_ROLLBACK);

     open cur_rollback(seqid);
     loop
          fetch cur_rollback into row_rollback;
          exit when cur_rollback%NOTFOUND;

          vDetailid:=create_rollback_detailstate(seqid,row_rollback.id,row_rollback.rollback_sql,0);
          EXECUTE IMMEDIATE row_rollback.rollback_sql;
          complete_rollback_detailstate(seqid,vDetailid);

          if row_rollback.rollback_histable_sql is not null then
             vDetailid:=create_rollback_detailstate(seqid,row_rollback.id,row_rollback.rollback_histable_sql,1);
             EXECUTE IMMEDIATE row_rollback.rollback_histable_sql;
             complete_rollback_detailstate(seqid,vDetailid);
          end if;
     end loop;
     update history_table a set a.rollbacked='1' where a.sid=seqid;

     remove_sequence(rbseqid);

     complete_rollback_state(seqid);
  end;

  function get_fix_type(datatype in varchar2) return varchar2 is
  begin
     if instr('CHARACTER|VARCHAR|VARCHAR2',datatype)>0 then
        return 'string';
     elsif instr('NUMBER|INTEGER|FLOAT|DOUBLE',datatype)>0 then
        return 'number';
     elsif instr('DATE|TIMESTAMP',datatype)>0 then
        return 'date';
/*     elsif instr('BLOB',datatype)>0 then
        return 'blob';
     elsif instr('CLOB',datatype)>0 then
        return 'clob';*/
     else
        return 'unknown';
     end if;
  end;

  function create_any_type(type in varchar2,column in varchar2,scope in varchar2) return varchar2 is
  begin
      if type='string' then
         return 'any_type('''||column||''','''||type||''','||scope||'.'||column||',null,null)';
      elsif type='number' then
         return 'any_type('''||column||''','''||type||''',null,'||scope||'.'||column||',null)';
      elsif type='date' then
         return 'any_type('''||column||''','''||type||''',null,null,'||scope||'.'||column||')';
/*      elsif type='blob' then
         return 'any_type('''||column||''','''||type||''',null,null,null,'||scope||'.'||column||',null)';
      elsif type='clob' then
         return 'any_type('''||column||''','''||type||''',null,null,null,null,'||scope||'.'||column||')';*/
      else
         return 'any_type('''||column||''','''||type||''',null,null,null)';
      end if;

  end;

  procedure create_rollback_support(tablename in varchar2,crt_history_table in number:=0,crt_sequence in number :=0) is
       trigger_sql varchar2(32767);

       sql_columns varchar2(2000):=' select a.COLUMN_NAME,a.DATA_TYPE from user_tab_columns a where a.TABLE_NAME=:table_name'
                   ||' and not exists(select 1 from user_cons_columns b,user_constraints c where '
                   ||'b.constraint_name=c.constraint_name and c.CONSTRAINT_TYPE=''P'' and b.column_name=a.column_name and b.table_name=a.table_name)';
       sql_pk_columns varchar2(2000):= 'select distinct c.column_name,c.data_type from user_cons_columns a,user_constraints b,user_tab_columns c'
       ||' where a.constraint_name=b.constraint_name and c.table_name=b.table_name and  b.CONSTRAINT_TYPE=''P''and b.table_name=:table_name and c.column_name=a.column_name';

       ccolumns ARRAY_UTIL.varchar2_table_table;
       pcolumns ARRAY_UTIL.varchar2_table_table;

       columnnames array_util.varchar2_table;
       columntypes array_util.varchar2_table;

       sql_create_historytable varchar2(4000);

       i int;
       n_Count number;
       v_seqname varchar2(50);

       v_tablename varchar2(30);
       v_his_tablename varchar2(30);

       sequence_sql varchar2(2000);
  begin
       v_tablename:=upper(tablename);
       v_his_tablename:='H_'||v_tablename;

       if (v_tables_no_rollback.count>0) then
          for i in v_tables_no_rollback.first..v_tables_no_rollback.last loop
              if v_tables_no_rollback(i)=v_tablename then
                 return;
              end if;
          end loop;
       end if;

       begin
         sql_create_historytable:='alter table '||v_tablename||' add '||SEQUENCE_COLUMN||' number';
         EXECUTE IMMEDIATE sql_create_historytable;
         exception when others then
            null;
       end;

       if crt_history_table=CREATE_HISTORY_TABLE then
           begin
             EXECUTE IMMEDIATE 'drop table '||v_his_tablename;
             exception when others then
                null;
           end;
           begin
             sql_create_historytable:='create table '||v_his_tablename
                 ||' as (select * from '||v_tablename||' where 1!=1)';
             exception when others then
                null;
           end;
           begin
             EXECUTE IMMEDIATE sql_create_historytable;
             sql_create_historytable:='alter table '||v_his_tablename||' add '||NEW_SEQUENCE_COLUMN||' number';
             exception when others then
                null;
           end;
           begin
           EXECUTE IMMEDIATE sql_create_historytable;
             sql_create_historytable:='alter table '||v_his_tablename||' add constraint PK_'||v_his_tablename
                 ||' primary key ('||array_util.join(pcolumns(1),',')||','||NEW_SEQUENCE_COLUMN||')';
             EXECUTE IMMEDIATE sql_create_historytable;

             exception when others then
                null;
           end;
       end if;

       trigger_sql:='create or replace trigger TR_RB_'||v_tablename
       ||' before insert or update or delete on '||v_tablename||' for each row declare op_type number;pk_values HISTORY_UTIL.ant_type_table; c_values HISTORY_UTIL.ant_type_table;seqid number;action number;'
       ||' begin HISTORY_UTIL.get_sequence(seqid,action); if action=HISTORY_UTIL.ACTION_ROLLBACK then return; end if; if inserting then '
       ||' op_type:=HISTORY_UTIL.OPTYPE_INSERT;';
       ccolumns:=ARRAY_UTIL.get_columns(sql_columns,v_tablename,2);
       pcolumns:=ARRAY_UTIL.get_columns(sql_pk_columns,v_tablename,2);


       if crt_history_table=CREATE_HISTORY_TABLE then

          sql_create_historytable:='insert into '||v_his_tablename||'('
          ||array_util.join(pcolumns(1),',')
          ||','||array_util.join(ccolumns(1),',')
          ||','||NEW_SEQUENCE_COLUMN||')values(';

           for i in pcolumns(1).first..pcolumns(1).last loop
               if i=pcolumns(1).first then
                  sql_create_historytable:=sql_create_historytable||':old.'||pcolumns(1)(i);
               else
                  sql_create_historytable:=sql_create_historytable||',:old.'||pcolumns(1)(i);
               end if;
           end loop;

           for i in ccolumns(1).first..ccolumns(1).last loop
               sql_create_historytable:=sql_create_historytable||',:old.'||ccolumns(1)(i);
           end loop;

           sql_create_historytable:=sql_create_historytable||',seqid);';

       end if;

       columnnames:=pcolumns(1);
       columntypes:=pcolumns(2);
       for i in columnnames.first..columnnames.last loop
           trigger_sql:=trigger_sql||' pk_values(pk_values.count+1):='||create_any_type(get_fix_type(columntypes(i)),columnnames(i),':new')||';';
       end loop;

       columnnames:=ccolumns(1);
       for i in columnnames.first..columnnames.last loop
           if columnnames(i)=history_util.SEQUENCE_COLUMN then
              trigger_sql:=trigger_sql||' :new.'||history_util.SEQUENCE_COLUMN||':=seqid;';
           end if;
       end loop;

       trigger_sql:=trigger_sql||' elsif updating then '
       ||' op_type:=HISTORY_UTIL.OPTYPE_UPDATE;';
       columnnames:=pcolumns(1);
       columntypes:=pcolumns(2);
       for i in columnnames.first..columnnames.last loop
           trigger_sql:=trigger_sql||' pk_values(pk_values.count+1):='||create_any_type(get_fix_type(columntypes(i)),columnnames(i),':old')||';';

       end loop;

       columnnames:=ccolumns(1);
       columntypes:=ccolumns(2);
       for i in columnnames.first..columnnames.last loop
           if columnnames(i)=history_util.SEQUENCE_COLUMN then
              trigger_sql:=trigger_sql||' :new.'||history_util.SEQUENCE_COLUMN||':=seqid;';
           end if;

           trigger_sql:=trigger_sql||' if history_util.bool_xor(:new.'||columnnames(i)||' is null , :old.'||columnnames(i)||' is null) or '||':new.'||columnnames(i)||'!='||':old.'||columnnames(i)||' then';
           trigger_sql:=trigger_sql||' c_values(c_values.count+1):='||create_any_type(get_fix_type(columntypes(i)),columnnames(i),':old')||';';
           trigger_sql:=trigger_sql||' end if;';
       end loop;

       if crt_history_table=CREATE_HISTORY_TABLE then
          trigger_sql:=trigger_sql||sql_create_historytable;
       end if;


       trigger_sql:=trigger_sql||' else op_type:=HISTORY_UTIL.OPTYPE_DELETE;';


       columnnames:=pcolumns(1);
       columntypes:=pcolumns(2);
       for i in columnnames.first..columnnames.last loop
           trigger_sql:=trigger_sql||' pk_values(pk_values.count+1):='||create_any_type(get_fix_type(columntypes(i)),columnnames(i),':old')||';';
       end loop;
       columnnames:=ccolumns(1);
       columntypes:=ccolumns(2);
       for i in columnnames.first..columnnames.last loop
           trigger_sql:=trigger_sql||' c_values(c_values.count+1):='||create_any_type(get_fix_type(columntypes(i)),columnnames(i),':old')||';';
       end loop;

       if crt_history_table=CREATE_HISTORY_TABLE then
          trigger_sql:=trigger_sql||sql_create_historytable;
       end if;

       trigger_sql:=trigger_sql||' end if;  ';
       if crt_history_table=CREATE_HISTORY_TABLE then
          trigger_sql:=trigger_sql||'HISTORY_UTIL.to_history(op_type,'''||v_tablename||''',pk_values,c_values,'||CREATE_HISTORY_TABLE||');';
       else
          trigger_sql:=trigger_sql||'HISTORY_UTIL.to_history(op_type,'''||v_tablename||''',pk_values,c_values);';
       end if;

       trigger_sql:=trigger_sql||' end;';

      -- dbms_output.put_line(trigger_sql);
       EXECUTE IMMEDIATE trigger_sql;

       v_seqname := 'SEQ_'||array_util.join(pcolumns(1),'');
       begin
             sequence_sql :='create sequence SEQ_'||array_util.join(pcolumns(1),'')||' increment by 1 start with 1  maxvalue 999999999999999999 minvalue 1 cache 20 nocycle';
       	 	EXECUTE IMMEDIATE sequence_sql;
             exception when others then
                null;
           end;


  end;

  procedure remove_rollback_support(tablename in varchar2) is
     temp_sql varchar2(2000);
     v_tablename varchar2(30);
  begin
     v_tablename:=upper(tablename);
     begin
         temp_sql:='drop trigger TR_RB_'||v_tablename;
         EXECUTE IMMEDIATE temp_sql;
         exception when others then
                null;
     end;
     begin
         temp_sql:='drop table H_'||v_tablename||' cascade constraints';
         EXECUTE IMMEDIATE temp_sql;
         exception when others then
                null;
     end;
  end;

  function bool_xor(l in boolean,r in boolean) return boolean is
  begin
      return (l and not r) or (not l and r);
  end;

  function bool_xnor(l in boolean,r in boolean) return boolean is
  begin
      return (l and r) or (not l and not r);
  end;

  function bool_tochar(b in boolean) return varchar2 is
  begin
       if b then
          return 'true';
       else
          return 'false';
       end if;
  end;


  --创建回退状态

  procedure create_rollback_state(pSid in number) is
    --匿名事务，不受全局事务影响
		PRAGMA AUTONOMOUS_TRANSACTION;
    vRbSqlSize number;
    vRbHisSqlSize number;
  begin
     select count(*) into vRbSqlSize from history_table a where a.sid=pSid;
     select count(*) into vRbHisSqlSize from history_table a where a.sid=pSid and a.rollback_histable_sql is not null;

    insert into history_rbstate(sid,sqlsize,rbsqlsize,stime,completed)
    values(pSid,vRbSqlSize+vRbHisSqlSize,0,sysdate,0);

    COMMIT;
    EXCEPTION WHEN OTHERS THEN
              ROLLBACK;
  end;
  --完成回退状态监控

  procedure complete_rollback_state(pSid in number) is
    --匿名事务，不受全局事务影响
		PRAGMA AUTONOMOUS_TRANSACTION;
  begin
    update history_rbstate a
    set a.etime=sysdate,a.detailid=null,a.completed=1
    where a.sid=pSid;
    COMMIT;
    EXCEPTION WHEN OTHERS THEN
              ROLLBACK;
  end;
  --创建回退详细状态

  function create_rollback_detailstate(pSid in number,pHid in number,pRbSql in varchar2,pHistory in number) return number is
    --匿名事务，不受全局事务影响
		PRAGMA AUTONOMOUS_TRANSACTION;

    vDetailid number;
  begin
    select SEQ_HISTORY_RBSTATE_DETAIL.Nextval into vDetailid from dual;

    insert into history_rbstate_detail(id,hid,sid,rbsql,history,stime)
    values(vDetailid,pHid,pSid,pRbSql,pHistory,sysdate);

    COMMIT;

    return vDetailid;

    EXCEPTION WHEN OTHERS THEN
              ROLLBACK;
  end;
  --完成回退详细状态监控

  procedure complete_rollback_detailstate(pSid in number,pDetailid in number) is
    --匿名事务，不受全局事务影响
		PRAGMA AUTONOMOUS_TRANSACTION;
  begin
    update history_rbstate_detail a
    set a.etime=sysdate
    where a.id=pDetailid;

    update history_rbstate a
    set a.rbsqlsize=a.rbsqlsize+1
    where a.sid=pSid;

    COMMIT;
    EXCEPTION WHEN OTHERS THEN
              ROLLBACK;
  end;
begin
  -- Initialization
  v_tables_no_rollback:=ARRAY_UTIL.split(TABLES_NO_ROLLBACK,',');
end HISTORY_UTIL;
/
