CREATE package ROLLBACK_UTIL is
  -- Author  : SUHUALIN
  -- Created : 2008-7-26 1:58:14
  -- Purpose : 字符串处理工具包
  function get_columns(sql_columns in varchar2,table_name in varchar2) return ARRAY_UTIL.varchar2_table;
  procedure get_child_tables(
            table_name in varchar2
           ,child_table_array out ARRAY_UTIL.varchar2_table
           ,pk_column_array out ARRAY_UTIL.varchar2_table
           ,fk_column_array out ARRAY_UTIL.varchar2_table
  );

  function execute_update(sql_update in varchar2
           ,varchar2_name_array in ARRAY_UTIL.varchar2_table
           ,varchar2_value_array in ARRAY_UTIL.varchar2_table
           ,number_name_array in ARRAY_UTIL.varchar2_table
           ,number_value_array in ARRAY_UTIL.number_table
           ,seqlog_id in number:=0) return number;

  function execute_update(sql_update in varchar2,varchar2_names in varchar2,varchar2_values in varchar2
           ,number_names in varchar2,number_values in varchar2,seqlog_id in number:=0) return number;

  function execute_count(sql_count in varchar2
           ,varchar2_name_array in ARRAY_UTIL.varchar2_table
           ,varchar2_value_array in ARRAY_UTIL.varchar2_table
           ,number_name_array in ARRAY_UTIL.varchar2_table
           ,number_value_array in ARRAY_UTIL.number_table
           ,seqlog_id in number:=0) return number;
  function execute_count(sql_count in varchar2,varchar2_names in varchar2,varchar2_values in varchar2
           ,number_names in varchar2,number_values in varchar2,seqlog_id in number:=0) return number;


  --创建回退线索日志
  procedure create_sequencelog(
    pObjectIds in varchar2,--对象标识
    pObjectTypes in varchar2,--对象类型
    pBusinessAction in varchar2,--业务操作
    pOperatorId in varchar2,--用户标识
    pOperatorName in varchar2,--用户姓名
    pIpAddr in varchar2,--客户端IP地址
    pMacAddr in varchar2,--客户端MAC地址
    pOperateTime in out date, --输出操作时间
    pSeqlogId out number, --输出索引编号
    pMemo in varchar2 default null --注释
  );

  --完成线索
  procedure complete_sequence(pSeqlogId in number);

  --增加回退线索对象
  procedure add_reference_object(
    pSeqlogId in number,--线索日志编号
    pObjectIds in varchar2,--对象标识
    pObjectTypes in varchar2--对象类型
  );

  --设置注释
  procedure set_memo(
     pSeqlogId in number,--线索日志编号
     pMemo in varchar2--注释
  );

  --创建回退结果日志
  procedure create_resultlog(
    pSeqlogId in varchar2, --待回退索引日志编号
    pOperatorId in varchar2,--用户标识
    pOperatorName in varchar2,--用户姓名
    pIpAddr in varchar2,--客户端IP地址
    pMacAddr in varchar2,--客户端MAC地址
    pMemo in varchar2,--客户端MAC地址
    pOperateTime in out date, --输出操作时间
    pResultlogId out number --输出结果编号
  );

  --业务回退
  procedure rollback(
    seqlog_id in number,--回退线索日志编号
    operatorId in varchar2,--操作员标识

    operatorName in varchar2,--操作员姓名

    ipaddr in varchar2,--客户端IP地址
    macaddr in varchar2,--客户端MAC地址
    memo in varchar2,--备注
    operateTime in out date,--操作时间
    resultlogId out number,--结果日志编号
    retcode out integer,--返回代码，0标识成功，其他失败

    errmsg out varchar2,--错误信息
    errdetail out varchar2--错误明细
  );

end ROLLBACK_UTIL;
/
