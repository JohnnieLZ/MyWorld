CREATE package CODEC_UTIL is

  -- Author  : SUHUALIN
  -- Created : 2008-9-9 15:49:39
  -- Purpose : 编码解码工具类

  -- Public type declarations
  --字符串数组
  TYPE varchar2_table IS TABLE OF VARCHAR2(2000)
  INDEX BY binary_integer;
  --二维字符串数组
  TYPE varchar2_table_table is TABLE OF varchar2_table INDEX BY binary_integer;
  --数值数组
  TYPE number_table IS TABLE OF NUMBER
  INDEX BY binary_integer;

  -- Public constant declarations
  --<ConstantName> constant <Datatype> := <Value>;

  -- Public variable declarations
  --<VariableName> <Datatype>;

  -- Public function and procedure declarations
  --将二维数组编码为一个字符串
  function encode(array_values in varchar2_table_table) return varchar2;
  --将一维数组编码为一个字符串
  function encode(array_values in varchar2_table) return varchar2;
  --包装字符串为指定长度，不足长度用空格填充
  function encode(rawString in varchar2,fixsize in integer,fix in varchar2:=' ') return varchar2;
  --包装数字为指定长度字串，不足长度前补0
  function encode(rawNumber in number,fixsize in integer,scale in integer:=0) return varchar2;

  --将数组包装为指定长度的16进制大写字串
  function encode16(rawNumber in integer,fixsize in integer:=8) return varchar2;

  --解码记录集合
  function decodeRecords(encodeString in varchar2,itemsize in number_table
           ,resultString out varchar2,retcode out integer,retmsg out varchar2) return varchar2_table_table;
  --解码单条记录
  function decodeRecord(encodeString in varchar2,itemsize in number_table
           ,resultString out varchar2,retcode out integer,retmsg out varchar2) return varchar2_table;
  --解码单个元素
  function decodeItem(encodeString in varchar2,itemsize in number
           ,resultString out varchar2,retcode out integer,retmsg out varchar2) return varchar2;

  --解码列表
  function decodeList(encodeString in varchar2,
           itemsize in number_table,
           resultString out varchar2,retcode out integer,retmsg out varchar2,sizeLength in integer:=8) return varchar2_table_table;
  --将以分隔符分隔的字符串转换成数字数组
  function decode(str_itemsize in varchar2,delimiter in varchar2:=',') return number_table;
end CODEC_UTIL;


/
