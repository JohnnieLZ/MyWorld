CREATE package body CODEC_UTIL is

  -- Private type declarations
  --type <TypeName> is <Datatype>;

  -- Private constant declarations
  --<ConstantName> constant <Datatype> := <Value>;

  -- Private variable declarations
  --<VariableName> <Datatype>;

  -- Function and procedure implementations
  --将二维数组编码为一个字符串
  function encode(array_values in varchar2_table_table) return varchar2 is
        result varchar2(32767):='';
        i integer;
  begin
        if array_values.count>0 then
           for i in array_values.first..array_values.last loop
               result:=result||encode(array_values(i));
           end loop;
        end if;
        return result;
  end;

  --将一维数组编码为一个字符串
  function encode(array_values in varchar2_table) return varchar2 is
        result varchar2(32767):='';
        i integer;
  begin
        if array_values.count>0 then
           for i in array_values.first..array_values.last loop
               result:=result||array_values(i);
           end loop;
        end if;
        return result;
  end;

  --包装字符串为指定长度，不足长度用空格填充
  function encode(rawString in varchar2,fixsize in integer,fix in varchar2:=' ') return varchar2 is
       result varchar2(32767);
       blen integer;
  begin
       if rawString is null or length(rawString)=0 then
          result:=fix;
       else
          result:=rawString;
       end if;
       blen:=lengthb(result);
       if blen=fixsize then --等长，直接返回
          return result;
       elsif blen>fixsize then --大于指定长度，截断
          return substrb(result,0,fixsize);
       else --小于指定长度，补足
          result:=result||rpad(fix,fixsize-blen,fix);
          return result;
       end if;
  end;

  --包装数字为指定长度字串，不足长度前补0
  function encode(rawNumber in number,fixsize in integer,scale in integer:=0) return varchar2 is
      ipart integer;
      format varchar2(200);
      temp number;
  begin
      if rawNumber is null then
         temp:=0;
      else
         temp:=rawNumber;
      end if;

      if scale>0 then
         ipart:=fixsize-scale-1;
      else
         ipart:=fixsize;
      end if;

      if temp<0 then
         ipart:=ipart-1;
      end if;

      format:=lpad('0',ipart,'0');
      if scale>0 then
         format:=format||'.'||lpad('0',scale,'0');
      end if;

      return trim(to_char(temp,format));
  end;

 function encode16(rawNumber in integer,fixsize in integer:=8) return varchar2 is
 begin
          return trim(to_char(rawNumber,lpad('X',fixsize,'0')));
 end;

  --解码记录集合
  function decodeRecords(encodeString in varchar2
           ,itemsize in number_table
           ,resultString out varchar2,retcode out integer,retmsg out varchar2) return varchar2_table_table is
     result varchar2_table_table;
  begin
     retcode:=0;
     resultString:=encodeString;
     loop
         result(result.count):=decodeRecord(resultString,itemsize,resultString,retcode,retmsg);
         if retcode!=0 then
            return result;
         end if;
         exit when resultString is null;
     end loop;
     return result;
  end;
  --解码单条记录
  function decodeRecord(encodeString in varchar2
           ,itemsize in number_table
           ,resultString out varchar2,retcode out integer,retmsg out varchar2) return varchar2_table is
    result varchar2_table;
    i integer;
  begin
    retcode:=0;
    resultString:=encodeString;
    for i in itemsize.first..itemsize.last loop
        result(i):=rtrim(decodeItem(resultString,itemsize(i),resultString,retcode,retmsg));
        if retcode!=0 then
           return result;
        end if;
    end loop;
    return result;
  end;

  function decodeItem(encodeString in varchar2,itemsize in number
           ,resultString out varchar2,retcode out integer,retmsg out varchar2) return varchar2 is
      result varchar2(32767);
  begin
      retcode:=0;
      retmsg:='';
      if encodeString is null then
         retcode:=1;
         retmsg:='参数不能为空';
         return result;
      end if;

      result:=substrb(encodeString,1,itemsize);
      if lengthb(result)<itemsize then
          retcode:=2;
          retmsg:='非预期的长度，预期为:'||itemsize||',实际为:'||lengthb(result);
          return result;
      end if;

      resultString:=substrb(encodeString,itemsize+1);
      return result;
  end;

  function decodeList(encodeString in varchar2,
           itemsize in number_table,
           resultString out varchar2,retcode out integer,retmsg out varchar2
           ,sizeLength in integer:=8) return varchar2_table_table is
     listSize number;
     temp varchar2(32767);
     i integer;

     result varchar2_table_table;
  begin
     retcode:=0;
     temp:=decodeItem(encodeString,sizeLength,resultString,retcode,retmsg);
     if retcode!=0 then
        return result;
     end if;
     begin
         listSize:=to_number(temp,lpad('X',sizeLength,'0'));
         EXCEPTION WHEN OTHERS THEN
              retcode:=2;
              retmsg:='列表大小字串'||temp||'不是合法的16进制数';
     end;
     if retcode!=0 then
        return result;
     end if;

     for i in 0..listSize-1 loop
         result(i):=decodeRecord(resultString,itemsize,resultString,retcode,retmsg);
     end loop;
     return result;
  end;

  function decode(str_itemsize in varchar2,delimiter in varchar2:=',') return number_table is
     result number_table;
     temp varchar2(2000);
     len integer;
     i integer:=0;
     j integer:=0;
  begin
     if str_itemsize is null or length(str_itemsize)=0 then
        return result;
     end if;

     temp:=str_itemsize;
     len:=length(delimiter);
     while true loop
        i:=instr(temp,delimiter);
        if i<=0 then
          exit;
        end if;

        result(j):=substr(temp,1,i-1);

        temp:=substr(temp,i+len);

        j:=j+1;
      end loop;

      result(j):=temp;

      return result;
  end;
begin
  -- Initialization
  null;
end CODEC_UTIL;


/
