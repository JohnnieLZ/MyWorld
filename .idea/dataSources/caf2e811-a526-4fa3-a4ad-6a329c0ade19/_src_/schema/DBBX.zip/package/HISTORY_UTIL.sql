CREATE PACKAGE HISTORY_UTIL
IS
   -- Author  : SUHUALIN
   -- Created : 2008-8-17 0:23:27
   -- Purpose : 历史工具类


   -- Public type declarations
   TYPE ant_type_table IS TABLE OF any_type
      INDEX BY BINARY_INTEGER;

   -- Public constant declarations
   OPTYPE_INSERT          CONSTANT NUMBER := 1;
   OPTYPE_UPDATE          CONSTANT NUMBER := 2;
   OPTYPE_DELETE          CONSTANT NUMBER := 3;

   ACTION_NORMAL          CONSTANT NUMBER := 1;
   ACTION_ROLLBACK        CONSTANT NUMBER := 2;
   ACTION_UNKNOWN         CONSTANT NUMBER := 2;

   DEFAULT_SEQUENCE_ID    CONSTANT NUMBER := -1;

   SEQUENCE_COLUMN        CONSTANT VARCHAR2 (30) := 'SEQLOGID';

   NEW_SEQUENCE_COLUMN    CONSTANT VARCHAR2 (30) := 'NEW_SEQLOGID';

   TABLES_NO_ROLLBACK     CONSTANT VARCHAR2 (2000) := ' ';

   CREATE_HISTORY_TABLE   CONSTANT NUMBER := 1;

   AUTO_CREATE_SEQUENCE   CONSTANT NUMBER := 1;


   -- Public variable declarations

   -- Public function and procedure declarations
   --获取当前线索
   PROCEDURE get_sequence (seqid OUT NUMBER, action OUT NUMBER);

   --获取当前线索号码
   FUNCTION get_sequence_no
      RETURN NUMBER;

   --创建线索
   PROCEDURE create_sequence (seqid NUMBER, action NUMBER);

   --删除线索
   PROCEDURE remove_sequence (seqid NUMBER);

   --创建历史信息
   PROCEDURE to_history (op_type             IN     NUMBER,
                         table_name          IN     VARCHAR2,
                         pk_values           IN OUT ant_type_table,
                         c_values            IN OUT ant_type_table,
                         has_history_table   IN     NUMBER := 0);

   --回滚
   PROCEDURE rollback (seqid IN NUMBER, rbseqid IN NUMBER);

   --创建回退支持
   PROCEDURE create_rollback_support (tablename           IN VARCHAR2,
                                      crt_history_table   IN NUMBER := 0,
                                      crt_sequence        IN NUMBER := 0);

   --移除回退支持
   PROCEDURE remove_rollback_support (tablename IN VARCHAR2);

   --获取ORACLE类型和ANY_TYPE适配的类型

   FUNCTION get_fix_type (datatype IN VARCHAR2)
      RETURN VARCHAR2;

   --创建任意类型
   FUNCTION create_any_type (TYPE     IN VARCHAR2,
                             column   IN VARCHAR2,
                             scope    IN VARCHAR2)
      RETURN VARCHAR2;

   --布尔异或
   FUNCTION bool_xor (l IN BOOLEAN, r IN BOOLEAN)
      RETURN BOOLEAN;

   --布尔同或
   FUNCTION bool_xnor (l IN BOOLEAN, r IN BOOLEAN)
      RETURN BOOLEAN;

   --布尔转字符串
   FUNCTION bool_tochar (b IN BOOLEAN)
      RETURN VARCHAR2;

   --创建回退状态

   PROCEDURE create_rollback_state (pSid IN NUMBER);

   --完成回退状态监控

   PROCEDURE complete_rollback_state (pSid IN NUMBER);

   --创建回退详细状态

   FUNCTION create_rollback_detailstate (pSid       IN NUMBER,
                                         pHid       IN NUMBER,
                                         pRbSql     IN VARCHAR2,
                                         pHistory   IN NUMBER)
      RETURN NUMBER;

   --完成回退详细状态监控

   PROCEDURE complete_rollback_detailstate (pSid        IN NUMBER,
                                            pDetailid   IN NUMBER);
END HISTORY_UTIL;
/
